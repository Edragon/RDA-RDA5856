
/********************************************************************************
*                RDA API FOR MP3HOST
*
*        (c) Copyright, RDA Co,Ld.
*             All Right Reserved
*
********************************************************************************/
#ifndef _AP_UDISK_H_
#define _AP_UDISK_H_


// =============================================================================
// g_umssStorageCallbackMc
// -----------------------------------------------------------------------------
/// Callback of MC storage
// =============================================================================
//EXPORT PUBLIC CONST UMSS_STORAGE_CALLBACK_T     g_umssStorageMcCallback;

INT32 USB_Entry(INT32 param);
//��ȡU���Ƿ����  0:û����   ����:����
BOOL GetUsbCableStatus(void);


#endif /*_UDISK_H_*/



