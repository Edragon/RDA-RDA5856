/********************************************************************************
*                RDA API FOR MP3HOST
*
*        (c) Copyright, RDA Co,Ld.
*             All Right Reserved
*
********************************************************************************/
#ifndef  _AP_LINEIN_H_
#define  _AP_LINEIN_H_

#include "ap_common.h"

INT32  LINEIN_Entry(INT32 param);

#endif/*_AP_LINEIN_H_*/


