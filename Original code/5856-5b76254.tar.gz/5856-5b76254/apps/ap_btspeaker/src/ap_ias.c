#include "tgt_app_cfg.h"
#if APP_SUPPORT_LE==1
#include "ap_gui.h"

#include "bt_types.h"
#include "bt_msg.h"
#include "bt_config.h"
#include "bt_ctrl.h"

#include "ap_mgr.h"
#include "ap_message.h"
#include "mci.h"

#include "gatt.h"
#include "ias.h"

#define ATT_UUID_IAS	0x1802

#define ATT_UUID_ALERT_LEVEL	0x2A06
const char ias_dn[] = "IAS";

#if 0
//GAP service definition
static const u_int8 ias_gap_service_uuid[2] ={ATT_UUID_GAP&0xff, ATT_UUID_GAP>>8};
static gatt_chara_def_short_t ias_dn_char = {ATT_CHARA_PROP_READ, 0, 0, ATT_UUID_DEVICENAME&0xff, ATT_UUID_DEVICENAME>>8};


static gatt_chara_def_short_t ias_appear_char = {ATT_CHARA_PROP_READ, 0, 0, ATT_UUID_APPEARANCE&0xff, ATT_UUID_APPEARANCE>>8};
static u_int8 ias_appearance[2];

static gatt_chara_def_short_t ias_privacy_char = {ATT_CHARA_PROP_READ|ATT_CHARA_PROP_WRITE, 0, 0, ATT_UUID_PRIVACY_FLAG&0xff, ATT_UUID_PRIVACY_FLAG>>8};
static u_int8 ias_privacyFlag;

static gatt_chara_def_short_t ias_reconn_addr_char = {ATT_CHARA_PROP_READ, 0, 0, ATT_UUID_RECONN_ADDR&0xff, ATT_UUID_RECONN_ADDR>>8};
static u_int8 ias_reconn_addr[6];

static gatt_chara_def_short_t ias_conn_parameters_char = {ATT_CHARA_PROP_READ, 0, 0, ATT_UUID_CONN_PARAMETER&0xff, ATT_UUID_CONN_PARAMETER>>8};
static gatt_chara_pcp_t ias_pcp;

//gerneric access service
static const gatt_element_t ias_gap_service[] =
{
	{2, ATT_PM_READABLE, ATT_UUID_PRIMARY, ATT_FMT_SHORT_UUID|ATT_FMT_GROUPED, (void*)ias_gap_service_uuid, NULL},

	//device name characteristic
	{sizeof(ias_dn_char), ATT_PM_READABLE, ATT_UUID_CHAR, ATT_FMT_SHORT_UUID, (void*)&ias_dn_char, NULL},
	{sizeof(ias_dn), ATT_PM_READABLE, ATT_UUID_DEVICENAME, 0, (void*)ias_dn, NULL},

	//appearance Characteristic
	{sizeof(ias_appear_char), ATT_PM_READABLE, ATT_UUID_CHAR, ATT_FMT_SHORT_UUID, (void*)&ias_appear_char, NULL},
	{sizeof(ias_appearance), ATT_PM_READABLE, ATT_UUID_APPEARANCE, 0, (void*)ias_appearance, NULL},

	//privacy flag characteristic
	{sizeof(ias_privacy_char), ATT_PM_READABLE, ATT_UUID_CHAR, ATT_FMT_SHORT_UUID, (void*)&ias_privacy_char, NULL},
	{sizeof(ias_privacyFlag), ATT_PM_READABLE, ATT_UUID_PRIVACY_FLAG, 0, (void*)&ias_privacyFlag, NULL},

	//reconnection address characteristic
	{sizeof(ias_reconn_addr_char), ATT_PM_READABLE, ATT_UUID_CHAR, ATT_FMT_SHORT_UUID, (void*)&ias_reconn_addr_char, NULL},
	{sizeof(ias_reconn_addr), ATT_PM_READABLE, ATT_UUID_RECONN_ADDR, 0, (void*)&ias_reconn_addr, NULL},

	//connection parameters characteristic
	{sizeof(ias_conn_parameters_char), ATT_PM_READABLE, ATT_UUID_CHAR, ATT_FMT_SHORT_UUID, (void*)&ias_conn_parameters_char, NULL},
	{sizeof(ias_pcp), ATT_PM_READABLE, ATT_UUID_CONN_PARAMETER, 0, (void*)&ias_pcp, NULL},
};


static const u_int8 ias_gatt_service_uuid[2] = {ATT_UUID_GATT&0xff, ATT_UUID_GATT>>8};
static gatt_chara_def_short_t ias_gatt_char = {ATT_CHARA_PROP_INDICATE, 0, 0, ATT_UUID_SERVICE_CHANGE&0xff, ATT_UUID_SERVICE_CHANGE>>8};
static gatt_chara_sc_t ias_sc_value;
//static gatt_chara_sc_t ias_sc_char_configuration;
//static gatt_chara_def_short_t ias_gatt_char_configuration = {ATT_CHARA_PROP_INDICATE, 0, 0, ATT_UUID_CLIENT&0xff, ATT_UUID_CLIENT>>8};

//gatt service 
static const gatt_element_t ias_gatt_service[] =
{
	{2, ATT_PM_READABLE, ATT_UUID_PRIMARY, ATT_FMT_SHORT_UUID|ATT_FMT_GROUPED, (void*)ias_gatt_service_uuid, NULL},
	{sizeof(ias_gatt_char), ATT_PM_READABLE, ATT_UUID_CHAR, ATT_FMT_SHORT_UUID, (void*)&ias_gatt_char, NULL},
	{sizeof(ias_sc_value), 0, ATT_UUID_SERVICE_CHANGE, 0, (void*)&ias_sc_value, NULL},

	//{sizeof(ias_gatt_char_configuration), ATT_PM_READABLE, ATT_UUID_CHAR, ATT_FMT_SHORT_UUID, (void*)&ias_gatt_char_configuration, NULL},
	//{sizeof(ias_sc_char_configuration), 0, ATT_UUID_CLIENT, 0, (void*)&ias_sc_char_configuration, NULL},
};
#endif

const u_int8 ias_ias_service_uuid[2] = {ATT_UUID_IAS&0xff, ATT_UUID_IAS>>8};
gatt_chara_def_short_t ias_al_char = {ATT_CHARA_PROP_WWP, 0, 0, ATT_UUID_ALERT_LEVEL&0xff, ATT_UUID_ALERT_LEVEL>>8};
char alert_level[10];

//Immediate Alert Service
const gatt_element_t ias_ias[] =
{
	{2, ATT_PM_READABLE, ATT_UUID_PRIMARY, ATT_FMT_SHORT_UUID|ATT_FMT_GROUPED, (void*)ias_ias_service_uuid, NULL},
		
	{sizeof(ias_al_char), ATT_PM_READABLE, ATT_UUID_CHAR, ATT_FMT_SHORT_UUID, (void*)&ias_al_char, NULL},
	{sizeof(alert_level), ATT_PM_WRITEABLE, ATT_UUID_ALERT_LEVEL, ATT_FMT_WRITE_NOTIFY|ATT_FMT_SHORT_UUID|ATT_FMT_FIXED_LENGTH, (void*)alert_level, NULL},
};

void app_bt_start_ias_server_req(void)
{
    hal_HstSendEvent(SYS_EVENT, 0x20150918);

    app_bt_set_adv_data("ias", NULL, NULL, 0);

    app_bt_add_service_req(ias_ias, sizeof(ias_ias)/sizeof(gatt_element_t));

    app_bt_set_visible_req(NULL);
}

t_api rdabt_gatt_ias_process_msg(u_int16 msgId, void *data)
{
	switch(msgId)
	{
	case GATT_CONNECT_CNF:
		{
			gatt_connect_cnf_t *pMsg = (gatt_connect_cnf_t*)data;
			ias_connect_cnf_t msg;
			msg.result = pMsg->result;
			RDABT_Send_Message(GATT_FMP_CONNECT_CNF, RDABT_GATT_FMP, RDABT_ADP, sizeof(msg), &msg);
		}
		break;

	case GATT_DISCONNECT_IND:
		{
		}
		break;
        
	default:
		break;
	}
	return 0;
}
#endif
