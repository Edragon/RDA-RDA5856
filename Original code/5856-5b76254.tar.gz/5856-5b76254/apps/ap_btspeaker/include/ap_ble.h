#ifndef AP_BLE_H
#define AP_BLE_H

#include "tgt_app_cfg.h"

#include "bt_types.h"
#include "bt_msg.h"
#include "bt_config.h"
#include "bt_ctrl.h"

#include "ap_mgr.h"
#include "ap_message.h"

#include "gatt.h"
#include "rdabt_gatt.h"

typedef struct
{
    u_int16 att_handle;
    u_int16 length;
    u_int16 acl_handle;
    u_int8 *data;
}APP_BLE_DATA_INFO;

void app_bt_send_notify(u_int16 acl_handle, u_int16 att_handle, u_int16 length, u_int8 *data);
void app_bt_send_indication(u_int16 acl_handle, u_int16 att_handle, u_int16 length, u_int8 *data);

#endif

