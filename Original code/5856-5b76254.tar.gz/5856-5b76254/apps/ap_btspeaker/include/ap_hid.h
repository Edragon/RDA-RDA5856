#ifndef AP_HID_H
#define AP_HID_H

#include "tgt_app_cfg.h"

#if APP_SUPPORT_HID ==1
#include "cs_types.h"
#include "bt.h"
#include "bt_msg.h"
#include "cos.h"
#include "hid.h"
#include "sdp.h"
#include "sap.h"
#include "ap_mgr.h"

#define HID_ADP_STATE_IDLE                    0
#define HID_ADP_STATE_PENDING             1
#define HID_ADP_STATE_CONNECTED         2

typedef struct
{
        t_bdaddr addr;
        u_int8 hid_state;
}RDABT_Hid_Info;

typedef struct
{
        t_hid_attributes *p_hid_attributes;
        t_hidOpcode type;
}RDABT_Hid_Sdp_Info;

typedef struct
{
        u_int8 *data;
        u_int8 length;
}RDABT_Hid_Data_Info;

extern void app_hid_handle_key(u_int32 key);

#endif
#endif

