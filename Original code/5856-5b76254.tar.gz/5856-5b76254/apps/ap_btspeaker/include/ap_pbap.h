#ifndef AP_PBAP_H
#define AP_PBAP_H
#include "tgt_app_cfg.h"
#if APP_SUPPORT_PBAP==1
#include "bt_types.h"
#include "bt_msg.h"
#include "ap_mgr.h"
#include "ap_message.h"
#include "manager.h"

#define MAX_PINYIN_LEN (6)
#define MAX_PINYIN_COUNT (4)
#define PB_LENGTH                     20
#define CALL_UNKNOW	3
#define CALL_MISSED       2
#define CALL_RECEIVED     1
#define CALL_DIALED       0
#define TOTAL_CHINESE_WORD_COUNT (6766)

#define PBAP_PHONEBOOK_TYPE	1
#define PBAP_HISTORY_TYPE		2

typedef struct
{
        u_int32 pb_start;
        u_int32 pb_end;
        u_int8 pb_type;
        t_bdaddr pb_addr;
}Rdabt_pbap_msg;

void app_pbap_deal_pb_data(u_int8 *data);
void app_get_pbap_data(u_int8 type, u_int32 start, u_int32 end);
void app_get_pbap_size(t_bdaddr * pAddr);
int UTF8_to_Unicode(char *dst, const char *src);
void app_pbap_msg_handle(COS_EVENT *ev);

#endif
#endif

