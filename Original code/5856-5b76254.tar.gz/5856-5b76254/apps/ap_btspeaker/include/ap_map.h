#ifndef AP_MAP_H
#define AP_MAP_H
#include "tgt_app_cfg.h"
#if APP_SUPPORT_MAP==1
#include "cs_types.h"
#include "bt_msg.h"
#include "ap_mgr.h"
#include "ap_message.h"
#include "manager.h"

#define RDABT_MAP_STATUS_IDLE				(1)
#define RDABT_MAP_STATUS_CONNECT_PENDING	(2)
#define RDABT_MAP_STATUS_CONNECTED			(3)

#define RDABT_MSG_BUF_SIZE		(1024)
#define MAP_LENGTH	(20)
#define MAP_GET_SIZE	(1)
#define MSG_BUFF_LEN  (MAP_LENGTH*16)

typedef struct
{
        u_int32 map_start;
        u_int32 map_end;
        u_int8 map_type;
        t_bdaddr map_addr;
}Rdabt_map_msg;

int find_str(const char *src_str, const char *spec_str, int str_len);
int UTF8_to_Unicode(char *dst, const char *src);
void app_get_map_data(u_int32 start, u_int32 end);
void app_get_map_size(t_bdaddr * pAddr);
void app_map_msg_handle(COS_EVENT *ev);
int rdabt_map_deal_msglist_data(u_int8 *result_data);
#endif
#endif

