#ifndef AP_BT_TEST_H
#define AP_BT_TEST_H

#include "bt_types.h"
#include "manager.h"
#include "cs_types.h"
#include "cos.h"
#include "ap_mgr.h"

typedef struct
{
    t_bdaddr addr;
    char device_name[MAX_BT_DEVICE_NAME];
}APP_CHANGE_DEVICE_NAME_INFO;

#endif

