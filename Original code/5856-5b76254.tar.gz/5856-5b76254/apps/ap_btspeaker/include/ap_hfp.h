#ifndef AP_HFP_H
#define AP_HFP_H

#include "tgt_app_cfg.h"

#include "bt_types.h"

#if APP_SUPPORT_HFP == 1

#include "bt_msg.h"
#include "ap_mgr.h"
#include "ap_common.h"
#include "ap_message.h"
#include "obex.h"
#include "bt.h"

#define MAX_HFP_CONNECT_RETRY 1

#define HFP_MAX_MSG_BUF        32

#define HFP_CALL_STATUS_NONE             0x0000
#define HFP_CALL_STATUS_INCOMING         0x0100
#define HFP_CALL_STATUS_OUTGOING         0x0200
#define HFP_CALL_STATUS_ALERT            0x0300
#define HFP_CALL_STATUS_ACTIVE           0x0001
#define HFP_CALL_STATUS_END              0x0400

#define HFP_CALL_REQ_REJECT     0x09
#define HFP_CALL_REQ_ACCEPT     0x08
#define HFP_CALL_REQ_REDIAL     0x07
#define HFP_CALL_REQ_CALLNUMBER  0x05

#define HFP_ADP_STATE_IDLE                    0
#define HFP_ADP_STATE_PENDING             1
#define HFP_ADP_STATE_CONNECTED         2

#define BT_VOICE_NUMBER_COUNT        10

typedef enum {
    HFP_IDLE,
    HFP_CONNECTED,
    HFP_CALL_INCOMING,
    HFP_CALL_OUTGOING,
    HFP_CALL_ACTIVE,
    HFP_PLAY_SCO,
}app_hfp_state_t;

typedef struct HFP_DEVICE_INFO
{
    t_bdaddr hfp_addr;
    u_int16 hfp_call_status;
    u_int8 hfp_adp_state;
    u_int8 hfp_check_timer;
    u_int8 check_cnt;
}APP_HFP_DEVICE_INFO;

typedef struct
{
    APP_HFP_DEVICE_INFO *hfp_device_info_list;
    u_int8 hfp_max_device_num;
    u_int8 hfp_connect_index;
//used for app    
    u_int16 sco_handle;
    t_bdaddr last_addr;
}APP_HFP_ADP_INFO;

typedef struct
{
    t_bdaddr hfp_addr;
    u_int32 msg_param1;
    u_int32 msg_param2;
    u_int8 msg_buf[HFP_MAX_MSG_BUF];
}RDABT_HFP_MSG_INFO;

extern u_int8 app_hfp_handle_key(u_int32 key);
extern void app_hfp_send_vol(t_bdaddr addr, u_int8 vol);
extern void app_connect_hfp(t_bdaddr *pAddr);
extern void app_disconnect_hfp(t_bdaddr *pAddr);
extern void app_hfp_msg_handle(COS_EVENT *ev);
extern void app_hfp_check_device_conneciton(APP_HFP_DEVICE_INFO *device_info);
extern void app_hfp_get_pbap_data_req(t_bdaddr *pAddr, u_int32 start, u_int32 end);
extern APP_HFP_ADP_INFO *app_get_hfp_adp_info(void);
extern RDABT_HFP_MSG_INFO app_msg_info;
extern void app_hfp_switch_mode(void);
extern u_int16 app_get_hfp_call_status(void);

#endif
#endif

