#ifndef _AP_CODEC_H_
#define _AP_CODEC_H_

//#define AP_CODEC_USE_BT_MEM
#define AP_CODEC_USE_SHARE_MEM

#if defined(AP_CODEC_USE_BT_MEM)
#define AP_CODEC_BUFFER_SIZE_MAX    (1024*8)
#define AP_CODEC_BT_SRAM_BASE       (0xa1c80000)
#elif defined(AP_CODEC_USE_SHARE_MEM)
#define AP_CODEC_BUFFER_SIZE_MAX    (1024*8)
#define AP_CODEC_BT_SRAM_BASE       (0xa1b00000)
#else
#define AP_CODEC_BUFFER_SIZE_MAX    (1024*6)
#endif

extern INT32 UartPlayEntry(INT32 param);
extern INT32 UartRecEntry(INT32 param);

#endif     /*_AP_CODEC_H_*/

