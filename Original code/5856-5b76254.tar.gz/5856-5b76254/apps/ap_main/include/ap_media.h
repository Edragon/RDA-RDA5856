/********************************************************************************
*                RDA API FOR MP3HOST
*
*        (c) Copyright, RDA Co,Ld.
*             All Right Reserved
*
********************************************************************************/

#ifndef _AP_MEDIA_H_
#define _AP_MEDIA_H_

#include "aud_main.h"
#if defined(CAMERA_SUPPORT)
#include "cam_main.h"
#if defined(IP_CAMERA_SUPPORT)
#include "cpu_share.h"
#endif /* IP_CAMERA_SUPPORT */
#endif /* CAMERA_SUPPORT */


BOOL mediaSendCommand(UINT8 cmd, INT32 param);
UINT32 media_PlayInternalAudio(UINT8 audio_id, UINT8 times, BOOL waitKey); //times: loop times, 0 for continuous loop
void media_StopInternalAudio(void);

#if defined(CAMERA_SUPPORT)
void cam_set_pair_results(UINT32 result, UINT32 value);
BOOL media_CameraPowerOn(UINT32 mode);
BOOL media_CameraPowerDown(void);
#if defined(IP_CAMERA_SUPPORT)
BOOL media_IPCameraStart(CAM_CAPTURE_STRUCT *capture);
BOOL media_IPCameraStop(void);
UINT32 media_IPCameraGetFramBuffer(UINT8 *buffer, UINT32 max_len);
#endif /* IP_CAMERA_SUPPORT */
#endif /* CAMERA_SUPPORT */

#endif  /* _AP_MEDIA_H_ */

