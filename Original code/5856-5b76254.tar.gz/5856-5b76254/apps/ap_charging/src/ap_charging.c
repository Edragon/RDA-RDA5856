/********************************************************************************
*                RDA API FOR MP3HOST
*
*        (c) Copyright, RDA Co,Ld.
*             All Right Reserved
*
********************************************************************************/
#include "ap_gui.h"
#include "ap_charging.h"

#define IS_CHARGING()  (-1 == GetBattery())
/******************************************************************************
 * APPChargingMsgHandler:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
BOOL APPChargingMsgHandler(COS_EVENT *pEvent)
{
    APP_ASSERT(pEvent);

    switch(pEvent->nEventId)
    {
        case EV_UI_FW_ON_START:
            break;

        case EV_UI_FW_REDRAW:
#if (APP_SUPPORT_RGBLCD==1) || (APP_SUPPORT_LCD==1)
            if(AP_Support_LCD())
            {
                GUI_ClearScreen(NULL);
                if(IS_CHARGING())
                    GUI_DisplayMessage(0, GUI_STR_CHARGING, 0, GUI_MSG_FLAG_DISPLAY);
                else if(GetBattery() == 100)
                    GUI_DisplayMessage(0, GUI_STR_FULL_CHARGING, 0, GUI_MSG_FLAG_DISPLAY);

                GUI_DisplayBattaryLever();
                GUI_UpdateScreen(NULL);
            }
#elif APP_SUPPORT_LED8S==1
            {
            }
#endif
            break;


        case AP_MSG_WAIT_TIMEOUT:
        case EV_UI_FW_ON_EXIT:
            break;

        case AP_KEY_PRESS:
            if(KEY_POWER == pEvent->nParam1)
            {
                SendAppEvent(EV_DM_POWER_ON_IND, 0); /*DM_POWRN_ON_CAUSE_KEY*/
            }
            break;

        case AP_MSG_RTC:
#if APP_SUPPORT_USBDEVICE==1
            if(GetUsbCableStatus())
            {
                SendAppEvent(EV_UI_FW_SWITCH_MOD, RESULT_UDISK);
            }
            else
#endif
                /*Charge plug out*/
                if(!IS_CHARGING() && GetBattery() != 100)
                {
                    DM_DeviceSwithOff();
                }
                else
                {
                    SendAppEvent(EV_UI_FW_REDRAW, 0);
                }
            break;

        default:
            return FALSE;
    }

    return TRUE;
}

/*********************************************************************************
* Description : IDLE �������ڸ�ģʽ�����ʡ�磬����ϣ������ʾ����ʱ�ӵĹ���
*
* Arguments   :
*
* Returns     :
*
* Notes       :
*
*********************************************************************************/
INT32 Charging_Entry(void)
{
    app_trace(APP_MAIN_TRC, "====Charging_Entry====");

    EntryNewScreen(SCR_ID_CHARGING, APPChargingMsgHandler, NULL, 0, 0);

    return 0;
}


