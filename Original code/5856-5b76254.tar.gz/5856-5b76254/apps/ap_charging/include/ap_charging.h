/********************************************************************************
*                RDA API FOR MP3HOST
*
*        (c) Copyright, RDA Co,Ld.
*             All Right Reserved
*
********************************************************************************/
#ifndef  _AP_CHARGING_H_
#define  _AP_CHARGING_H_

#include "ap_common.h"

INT32  Charging_Entry(void);

#endif/*_AP_CHARGING_H_*/




