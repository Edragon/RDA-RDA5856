/********************************************************************************
*                RDA API FOR MP3HOST
*
*        (c) Copyright, RDA Co,Ld.
*             All Right Reserved
*
********************************************************************************/

#ifndef _AP_SETTING_H_
#define _AP_SETTING_H_


typedef void (*GUI_DATETIME_SET_CBK) (date_t *, ap_time_t *);

typedef struct
{
    UINT16 img_id;
    UINT16 str_id;
    date_t  *date;
    ap_time_t *time;
    GUI_DATETIME_SET_CBK cbk_func;

    BOOL   show_what;    //TRUE, ��ʾ, FALSE, ����ʾ
    BOOL     adjusting;        //��������,��Ҫ��˸
    INT8   set_what;       //0, ���趨״̬, 1,year, 2,month...
    INT8   item_start;
    INT8   item_end;
} GUI_DATETIME_SET_T, *GUI_DATETIME_SET_PTR;

typedef enum
{
    GUI_DATETIME_DRAW_BACKGROUND = 0x1,
    GUI_DATETIME_DRAW_DATE = 0x2,
    GUI_DATETIME_DRAW_TIME = 0x4,

	GUI_DATETIME_DRAW_DATETIME = 0x6,
    GUI_DATETIME_DRAW_ALL = 0x7,
} GUI_DATETIME_DRAW_ENUM;


//ϵͳ�������ڵĽӿں���
//INT32 SET_ClockSetting(void);
INT32 SET_LanguageSetting(void);
INT32 SET_PowerDownSetting(void);
INT32 SET_BackLightTimeSetting(void);
INT32 SET_BackLightSetting(void);
INT32 SET_BackLightColorSetting(void);
INT32 SET_ContrastSetting(void);
INT32 SET_StorageSetting(void);
INT32 SET_FirmwareSetting(void);
INT32 SET_SystemReset(void);
INT32 SET_UpdateSetting(void);
INT32 SET_BTSetting(void);
INT32 SET_DataFormatSetting(void);

/*Alarm Sub Menu items*/
INT32 SET_ALARMClockSetting(void);
INT32 SET_ALARMTimesSetting(void);

INT32 GUI_ClockSetting(date_t *date,ap_time_t *time,UINT16 img_id,UINT16 str_id, GUI_DATETIME_SET_CBK cbk_func);


INT32 SET_Entry(INT32 param);/*�ⲿ�ӿں���*/

#endif  /* _AP_SETTING_H_*/



