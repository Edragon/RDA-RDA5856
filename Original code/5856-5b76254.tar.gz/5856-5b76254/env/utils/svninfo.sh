#!/bin/bash

svn pl -v

echo svn info
svn info
echo svn info application 
svn info application 
echo svn info env 
svn info env 
echo svn info platform 
svn info platform 
echo svn info platform/base 
svn info platform/base 
echo svn info platform/chip 
svn info platform/chip 
echo svn info platform/csw 
svn info platform/csw 
echo svn info platform/edrv 
svn info platform/edrv 
echo svn info platform/mdi 
svn info platform/mdi 
echo svn info platform/stack 
svn info platform/stack 
echo svn info platform/svc 
svn info platform/svc 
echo svn info platform/vpp 
svn info platform/vpp 
echo svn info platform_test 
svn info platform_test 
echo svn info target 
svn info target 
echo svn info toolpool 
svn info toolpool 
