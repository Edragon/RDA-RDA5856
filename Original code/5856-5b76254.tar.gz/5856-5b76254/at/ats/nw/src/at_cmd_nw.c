/*********************************************************
 *
 * File Name
 *  ?
 * Author
 *  ?
 * Date
 *  2007/11/25
 * Descriptions:
 *  ...
 *
 *********************************************************/

#include "at_common.h"
#include "at_module.h"
#include "at_cmd_nw.h"
//#include "at_cmd_gc.h"
//#include "at_cfg.h"
#include "cfw.h"

#include "at_cmd_sim.h"

UINT8 g_uATNWECSQFlag   = 0;
UINT8 g_COPN_Index      = 1;
UINT8 g_COPS_Mode       = 2;

UINT8 g_FirstREG                    = 1;
UINT8 g_COPS_OperID[6]              = { 0 };
UINT8 g_COPS_OperID_Temp[6]         = { 0 };
BOOL g_COPS_Set_Flag[CFW_SIM_COUNT] = { 0, }; // added by yangtt at 2008-05-05 for bug 8144
extern BOOL Speeching;  // added by yangtt at 2008-05-05 for bug 8227
extern UINT8 g_cfg_cfun[2];  // added by yangtt at 2008-05-05 for bug 8411
//extern BOOL g_auto_calib;
extern UINT8 g_set_ACLB;
extern UINT8 g_ACLB_FM;
extern UINT8 g_ACLB_SIM1_FM;
extern BOOL gATSATLocalInfoFlag[];
extern BOOL gATSATComQualifier[];

UINT8 g_arrPreferredOperater[6] = {0x00,};
UINT8 g_ucFlag = 0x00;

// nw related
UINT8 gATCurrentOperFormat;// 		gAtCurrentSetting.g_OperFormat
UINT8 gATCurrentCOPS_Mode_Temp;// 	gAtCurrentSetting.g_COPS_Mode_Temp
UINT8 gATCurrentnPreferredOperFormat;// 	gAtCurrentSetting.g_nPreferredOperFormat
UINT8 gATCurrentpArrPreferredOperater;// 	gAtCurrentSetting.g_pArrPreferredOperater
UINT8 gATCurrentnPreferredOperatorIndex;// 	gAtCurrentSetting.g_nPreferredOperatorIndex
UINT8 gATCurrentnGetPreferredOperatorsCaller;// 	gAtCurrentSetting.g_nGetPreferredOperatorsCaller


extern UINT8 g_uCmer_ind[NUMBER_OF_SIM];

#define gATCurrentuCmer_ind g_uCmer_ind


// AT_20071112_CAOW_E
#ifdef AT_FTP_SUPPORT
#ifndef AT_FTP_UPDATE
BOOL AT_SetOTATimer(UINT32 nElapse);
#endif
#endif
AT_CS_STAUTS gCsStauts;

VOID cfw_PLMNtoBCD(UINT8 *pIn, UINT8 *pOut, UINT8 *nInLength);
#ifdef AT_USER_DBS
VOID AT_NW_POSI_AddData(UINT8 nflag, CFW_TSM_CURR_CELL_INFO *pCurrCellInfo,
                        CFW_TSM_ALL_NEBCELL_INFO *pNeighborCellInfo);
#ifdef AT_DUAL_SIM
VOID AT_NW_POSI_SendData(UINT8 nSim);
#else
VOID AT_NW_POSI_SendData();
#endif

#endif
#ifdef AT_DUAL_SIM
VOID AT_NW_Result_OK(UINT32 uReturnValue,
                     UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize, UINT8 nDLCI, UINT8 nSim)
#else
VOID AT_NW_Result_OK(UINT32 uReturnValue,
                     UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize, UINT8 nDLCI)
#endif
{
    PAT_CMD_RESULT pResult = NULL;

#ifdef AT_DUAL_SIM
    AT_BACKSIMID(nSim);
#endif

    // �������
    pResult = AT_CreateRC(uReturnValue,
                          uResultCode, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, nDelayTime, pBuffer, nDataSize, nDLCI);

    AT_Notify2ATM(pResult, nDLCI);

    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}

#ifdef AT_DUAL_SIM
VOID AT_NW_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI, UINT8 nSim)
#else
VOID AT_NW_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI)
#endif
{
    PAT_CMD_RESULT pResult = NULL;

#ifdef AT_DUAL_SIM
    AT_BACKSIMID(nSim);
#endif

    // �������
    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, uErrorCode, nErrorType, 0, 0, 0, nDLCI);

    AT_Notify2ATM(pResult, nDLCI);

    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}

BOOL NW_OperaterStrToBytes(UINT8 *pDestBytes, UINT8 *pSource)
{
    if ((pDestBytes == NULL) || (pSource == NULL))
    {
        return FALSE;
    }

    while (*pSource != 0)
    {
        //if ((*pSource < '0') || (*pSource > '9')||(*pSource!='f')||(*pSource!='F'))
        {
            // return FALSE;
        }
        if((*pSource >= '0') && (*pSource <= '9'))
        {
            *pDestBytes++ = *pSource++ - '0';
        }
        else if((*pSource == 'f') || (*pSource == 'F'))
        {
            *pDestBytes++ = 0x0f;
            pSource++;
        }
        else
        {
            return FALSE;
        }
    }

    return TRUE;

}

#if 0
UINT32 SRVAPI CFW_SimGetPrefOperatorListEX(UINT16 nUTI)
{
    return 0;
}

UINT32 SRVAPI CFW_SimSetPrefOperatorListEX(UINT8 *pOperatorList, UINT8 nSize, UINT16 nUTI)
{
    return 0;
}

UINT32 CFW_SimGetICCID(UINT16 nUTI)
{
    return 0;
}

#endif
UINT8 Gprs_APN[8];
UINT8 Gprs_APN_Len = 0x00;

#ifdef AT_DUAL_SIM
VOID NW_GetPreferredOperators(UINT8 nDLCI, UINT8 nSim)
#else
VOID NW_GetPreferredOperators(UINT8 nDLCI)
#endif
{
    // UINT32 nResult = CFW_SimGetPrefOperatorListEX(1,0);
    UINT32 nResult = CFW_SimGetPrefOperatorList(nDLCI, nSim);

    if (ERR_SUCCESS == nResult)
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, nDLCI, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, nDLCI);
#endif
        return;
    }
    else
    {
        AT_TC(g_sw_AT_NW, "nw-CFW_SimGetPrefOperatorList error\n");
        UINT32 nErrorCode = AT_SetCmeErrorCode(nResult, FALSE);

#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, nDLCI, nSim);
#else
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, nDLCI);
#endif
        return;
    }

    return;
}

// for +cpol=?  get the max num of preferred operators
VOID NW_AsyncEventProcess_GetPreferredOperatorMaxNum(CFW_EVENT cfwEvent)
{
    UINT32 nErrorCode = 0;

#ifdef AT_DUAL_SIM
    UINT8 nSim = cfwEvent.nFlag;
#endif
    AT_TC(g_sw_AT_NW, "NW-EV_CFW_SIM_GET_PREF_OPT_LIST_MAXNUM_RSP come!\n");

    if (cfwEvent.nType == 0)
    {
        UINT8 arrRes[30];

        AT_MemZero(arrRes, sizeof(arrRes));
        AT_Sprintf(arrRes, "+CPOL: (1-%u),(0,2)", cfwEvent.nParam1);
#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), cfwEvent.nUTI);
#endif
        return;
    }
    else if (cfwEvent.nType == 0xF0)
    {
        AT_TC(g_sw_AT_NW, "EV_CFW_SIM_GET_PREF_OPT_LIST_MAXNUM_RSP error");
        nErrorCode = AT_SetCmeErrorCode(cfwEvent.nParam1, FALSE);
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
        return;
    }
    else
    {
        AT_TC(g_sw_AT_NW, "EV_CFW_SIM_GET_PREF_OPT_LIST_MAXNUM_RSP:  error!!!---CfwEvent.nType --0x%x\n\r", cfwEvent.nType);
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif

        return;
    }

}

VOID NW_AsyncEventProcess_GetPreferredOperators_Set(CFW_EVENT cfwEvent)
{

    UINT8 *pTemp         = (UINT8 *)(cfwEvent.nParam1);
    UINT8 nOperatorCount = cfwEvent.nParam2;

#ifdef AT_DUAL_SIM
    UINT8 nSim = cfwEvent.nFlag;
#endif
    AT_TC(g_sw_AT_NW, "NW-NW_AsyncEventProcess_GetPreferredOperators_Set ---%d!\n", nOperatorCount);

    AT_TC(g_sw_AT_NW, "cfwEvent.nParam1 ---%d!\n", cfwEvent.nParam1);
    AT_TC(g_sw_AT_NW, "gATCurrentnPreferredOperatorIndex ---%d!\n", gATCurrentnPreferredOperatorIndex);
    AT_TC(g_sw_AT_NW, "g_arrPreferredOperater ---%d!\n", g_arrPreferredOperater[0]);

    // if ((g_nPreferredOperatorIndex>nOperatorCount)
    // if ((gATCurrentnPreferredOperatorIndex > nOperatorCount) // +9 by wulc

    if ((gATCurrentnPreferredOperatorIndex > nOperatorCount + 9)
            || ((gATCurrentnPreferredOperatorIndex == 0) && (g_arrPreferredOperater[0] == 0xff)))
    {
        AT_TC(g_sw_AT_NW, "NW_AsyncEventProcess_GetPreferredOperators_Set:  param error!!!\n\r");
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif

        return;
    }

    if (gATCurrentnPreferredOperatorIndex == 0)
    {
        UINT8 nTemp = 0;

        for (nTemp = 0; nTemp < nOperatorCount; nTemp++)

        {
            if (pTemp[nTemp * 6] == 0xff)
            {
                gATCurrentnPreferredOperatorIndex = nTemp + 1;
                break;
            }
        }

        if (gATCurrentnPreferredOperatorIndex == 0)
        {
            AT_TC(g_sw_AT_NW, "NW_AsyncEventProcess_GetPreferredOperators_Set error:  full !!!\n\r");
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
            return;
        }
    }

    UINT8 nTemp = 0;

    UINT8 nTempBase = 0;

    for (nTemp = 0; nTemp < nOperatorCount; nTemp++)
    {
        nTempBase = 6 * nTemp;
        AT_TC(g_sw_AT_NW, "NW-get -no.%d--0x%x-%x-%x-%x-%x-%x!\n",
              nTemp + 1, pTemp[nTempBase], pTemp[nTempBase + 1], pTemp[nTempBase + 2],
              pTemp[nTempBase + 3], pTemp[nTempBase + 4], pTemp[nTempBase + 5]);
    }

    UINT8 *arrOperatorList = NULL ;
    UINT32 narrOperatorListSize = 0x00;

    if(nOperatorCount < gATCurrentnPreferredOperatorIndex)
    {
        nOperatorCount = gATCurrentnPreferredOperatorIndex;
    }

    if(nOperatorCount)
    {
        narrOperatorListSize = nOperatorCount * 6;
    }
    else
    {
        narrOperatorListSize = 6;
    }

    arrOperatorList = (UINT8 *)AT_MALLOC(narrOperatorListSize);

    AT_MemSet(arrOperatorList, 0xff, narrOperatorListSize);
    AT_MemCpy(arrOperatorList, pTemp, narrOperatorListSize);
    AT_MemCpy(&(arrOperatorList[(gATCurrentnPreferredOperatorIndex - 1) * 6]), g_arrPreferredOperater,
              sizeof(g_arrPreferredOperater));

    pTemp     = arrOperatorList;
    nTempBase = 0;

    for (nTemp = 0; nTemp < nOperatorCount; nTemp++)
    {
        nTempBase = 6 * nTemp;
        AT_TC(g_sw_AT_NW, "NW-to set -no.%d--0x%x-%x-%x-%x-%x-%x!\n",
              nTemp + 1, pTemp[nTempBase], pTemp[nTempBase + 1], pTemp[nTempBase + 2],
              pTemp[nTempBase + 3], pTemp[nTempBase + 4], pTemp[nTempBase + 5]);
    }
    AT_TC(g_sw_AT_NW, "NW_AsyncEventProcess_GetPreferredOperators_Set  sizeof(arrOperatorList) %d\n\r", narrOperatorListSize);

    AT_TC(g_sw_AT_NW, "gATCurrentnPreferredOperatorIndex %d\n\r", gATCurrentnPreferredOperatorIndex);

    AT_TC_MEMBLOCK(g_sw_AT_NW, arrOperatorList, narrOperatorListSize, 16);

    AT_TC_MEMBLOCK(g_sw_AT_NW, g_arrPreferredOperater, sizeof(g_arrPreferredOperater), 16);

    UINT32 nResult = CFW_SimSetPrefOperatorList(arrOperatorList, narrOperatorListSize, cfwEvent.nUTI, nSim);

    AT_FREE(arrOperatorList);
    if (ERR_SUCCESS == nResult)
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI);
#endif
        return;
    }
    else
    {
        AT_TC(g_sw_AT_NW, "nw-CFW_SimSetPrefOperatorList error\n");
        UINT32 nErrorCode = AT_SetCmeErrorCode(nResult, FALSE);

#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
        return;
    }

    return;
}

VOID NW_AsyncEventProcess_GetPreferredOperators_Read(CFW_EVENT cfwEvent)
{
    UINT8 arrRes[100];
    UINT32 nResult = ERR_SUCCESS;
    UINT8 arrOperatorName[17];
    UINT8 nTemp          = 0;
    UINT8 *pTemp         = (UINT8 *)(cfwEvent.nParam1);
    UINT8 nOperatorCount = cfwEvent.nParam2;
    UINT8 nTempBase      = 0;
    UINT8 *pOperatorName = NULL;

#ifdef AT_DUAL_SIM
    UINT8 nSim = cfwEvent.nFlag;
#endif
    AT_TC(g_sw_AT_NW, "NW-EV_CFW_SIM_GET_PREF_OPERATOR_LIST_RSP ---%d!\n", nOperatorCount);

    for (nTemp = 0; nTemp < nOperatorCount; nTemp++)
    {
        nTempBase = 6 * nTemp;
        AT_TC(g_sw_AT_NW, "NW-NW_AsyncEventProcess_GetPreferredOperators_Read -no.%d--0x%x-%x-%x-%x-%x-%x!\n",
              nTemp + 1, pTemp[nTempBase], pTemp[nTempBase + 1], pTemp[nTempBase + 2],
              pTemp[nTempBase + 3], pTemp[nTempBase + 4], pTemp[nTempBase + 5]);
    }

    for (nTemp = 0; nTemp < nOperatorCount; nTemp++)
    {
        nTempBase = 6 * nTemp;

        if (pTemp[nTempBase] == 0xFF)
        {
            continue;
        }

        AT_MemZero(arrRes, sizeof(arrRes));

        if(pTemp[nTempBase ] != 0x0F)
        {

            if (pTemp[nTempBase + 5] != 0x0F)
            {
                AT_Sprintf(arrRes, "+CPOL: %u,%u,\"%u%u%u%u%u%u\"", nTemp + 1, NW_PREFERRED_OPERATOR_FORMAT_NUMERIC,
                           pTemp[nTempBase], pTemp[nTempBase + 1], pTemp[nTempBase + 2],
                           pTemp[nTempBase + 3], pTemp[nTempBase + 4], pTemp[nTempBase + 5]);
            }
            else
            {
                AT_Sprintf(arrRes, "+CPOL: %u,%u,\"%u%u%u%u%u\"", nTemp + 1, NW_PREFERRED_OPERATOR_FORMAT_NUMERIC,
                           pTemp[nTempBase], pTemp[nTempBase + 1], pTemp[nTempBase + 2],
                           pTemp[nTempBase + 3], pTemp[nTempBase + 4]);
            }

        }


        // if (g_nPreferredOperFormat == NW_PREFERRED_OPERATOR_FORMAT_ALPHANUMERIC_LONG)
        if (gATCurrentnPreferredOperFormat == NW_PREFERRED_OPERATOR_FORMAT_ALPHANUMERIC_LONG)
        {
            AT_MemZero(arrOperatorName, sizeof(arrOperatorName));
            pOperatorName = arrOperatorName;
            nResult       = CFW_CfgNwGetOperatorName(pTemp + nTempBase, &pOperatorName);

            if (nResult == ERR_SUCCESS)
            {
                AT_TC(g_sw_AT_NW, "CFW_CfgNwGetOperatorName---success!\n");
                AT_MemZero(arrRes, sizeof(arrRes));
                AT_Sprintf(arrRes, "+CPOL: %u,%u,\"%s\"", nTemp + 1, NW_PREFERRED_OPERATOR_FORMAT_ALPHANUMERIC_LONG,
                           pOperatorName);
            }
            else
            {
                AT_TC(g_sw_AT_NW, "CFW_CfgNwGetOperatorName---error!\n");
            }
        }
#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), cfwEvent.nUTI);
#endif

    }

#ifdef AT_DUAL_SIM
    AT_NW_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, NULL, 0, cfwEvent.nUTI, nSim);
    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI, nSim);
#else
    AT_NW_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, NULL, 0, cfwEvent.nUTI);
    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI);
#endif

    return;
}

// for +cpol?  get the preferred operators
VOID NW_AsyncEventProcess_GetPreferredOperators(CFW_EVENT cfwEvent)
{
    UINT32 nErrorCode = 0;

#ifdef AT_DUAL_SIM
    UINT8 nSim = cfwEvent.nFlag;
#endif
    AT_TC(g_sw_AT_NW, "NW-EV_CFW_SIM_GET_PREF_OPERATOR_LIST_RSP come!\n");

    if (cfwEvent.nType == 0)
    {
        if (gATCurrentnGetPreferredOperatorsCaller == NW_GETPREFERREDOPERATORS_CALLER_READ)
        {
            NW_AsyncEventProcess_GetPreferredOperators_Read(cfwEvent);
            return;
        }
        else if (gATCurrentnGetPreferredOperatorsCaller == NW_GETPREFERREDOPERATORS_CALLER_SET)
        {
            NW_AsyncEventProcess_GetPreferredOperators_Set(cfwEvent);
            return;
        }

    }
    else if (cfwEvent.nType == 0xF0)
    {
        AT_TC(g_sw_AT_NW, "EV_CFW_SIM_GET_PREF_OPERATOR_LIST_RSP error");
        nErrorCode = AT_SetCmeErrorCode(cfwEvent.nParam1, FALSE);
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
        return;
    }
    else
    {
        AT_TC(g_sw_AT_NW, "EV_CFW_SIM_GET_PREF_OPERATOR_LIST_RSP:  error!!!---CfwEvent.nType --0x%x\n\r", cfwEvent.nType);
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif

        return;
    }

}

// for +cpol,  add or delete the preferred operator
VOID NW_AsyncEventProcess_SetPreferredOperators(CFW_EVENT cfwEvent)
{
    UINT32 nErrorCode = 0;

#ifdef AT_DUAL_SIM
    UINT8 nSim = cfwEvent.nFlag;
#endif
    AT_TC(g_sw_AT_NW, "NW-EV_CFW_SIM_SET_PREF_OPERATOR_LIST_RSP come!\n");

    if (cfwEvent.nType == 0)
    {
        AT_TC(g_sw_AT_NW, "NW-cpol set success!\n");
#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI);
#endif
        return;
    }
    else if (cfwEvent.nType == 0xF0)
    {
        AT_TC(g_sw_AT_NW, "EV_CFW_SIM_SET_PREF_OPERATOR_LIST_RSP error");
        nErrorCode = AT_SetCmeErrorCode(cfwEvent.nParam1, FALSE);
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
        return;
    }
    else
    {
        AT_TC(g_sw_AT_NW, "EV_CFW_SIM_SET_PREF_OPERATOR_LIST_RSP:  error!!!---CfwEvent.nType --0x%x\n\r", cfwEvent.nType);
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif

        return;
    }

}
extern BOOL gbPowerCommMsgFlag[];
VOID NW_AsyncEventProcess_SetCom(CFW_EVENT cfwEvent)
{
    //UINT32 nErrorCode = 0;
    //UINT32 nRet       = 0;

#ifdef AT_DUAL_SIM
    UINT8 nSim = cfwEvent.nFlag;
#endif
    //hal_HstSendEvent(0xfc000012);
    //hal_HstSendEvent(cfwEvent.nType);

    if (cfwEvent.nType != 0)
    {
        AT_TC(g_sw_AT_NW, "AsyncEventProcess_SetCom:   ERROR!!!---CfwEvent.nType --0x%x\n\r", cfwEvent.nType);
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
        return;
    }
    AT_TC(g_sw_AT_NW, "AsyncEventProcess_SetCom:   g_set_ACLB: 0x%x\n\r", g_set_ACLB);
    //hal_HstSendEvent(0xaabbcc00);
    //hal_HstSendEvent(g_set_ACLB);
    //hal_HstSendEvent(nSim);

    if(( 1 == g_set_ACLB) && (0 == nSim)) //fm mode
    {
        //hal_HstSendEvent(0xaabbcc01);
        CFW_SetComm(CFW_ENABLE_COMM, 0, cfwEvent.nUTI, nSim);
//        g_auto_calib = TRUE;
        g_set_ACLB = 2;
    }
    else if(( 2 == g_set_ACLB) && (0 == nSim) )
    {
        //hal_HstSendEvent(0xaabbcc02);
    }
    else if(( 3 == g_set_ACLB) && (0 == nSim))
    {
        //hal_HstSendEvent(0xaabbcc03);
        VOID calib_DaemonUsrDataProcess(VOID);

        calib_DaemonUsrDataProcess();

        if( CFW_ENABLE_COMM == g_ACLB_FM)
        {
            g_set_ACLB = 4;
//            g_auto_calib = FALSE;
            CFW_SetComm(CFW_ENABLE_COMM, 0, cfwEvent.nUTI, nSim);
        }
        else
        {
//            g_auto_calib = FALSE;
            g_set_ACLB = 0;
            g_ACLB_FM   = CFW_CHECK_COMM;
            if(CFW_ENABLE_COMM == g_ACLB_SIM1_FM )
            {
                g_ACLB_SIM1_FM = CFW_CHECK_COMM;
                CFW_SetComm(CFW_ENABLE_COMM, 0, cfwEvent.nUTI, 1);
            }
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI);
#endif
        }
    }
    else if(( 4 == g_set_ACLB) && (0 == nSim))
    {
        //hal_HstSendEvent(0xaabbcc04);
        //calib_DaemonUsrDataProcess();
        //g_auto_calib = FALSE;
        //g_set_ACLB = 0;
    }
    else if((g_set_ACLB > 0) && (1 == nSim))
    {
        //hal_HstSendEvent(0xaabbcc05);
    }
    else
    {
        //hal_HstSendEvent(0xaabbcc06);
        if(TRUE == gbPowerCommMsgFlag[nSim] )
        {
            gbPowerCommMsgFlag[nSim] = FALSE;
        }
        else
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI);
#endif
        }
    }
    return;
}

#ifdef AT_USER_DBS
// for +POSI
AT_POSI_LIST gPosiList;
AT_ARRES gPosiArres;

extern CFW_INIT_INFO cfwInitInfo;

VOID NW_AsyncEventProcess_GetCellInfo(CFW_EVENT cfwEvent)
{
    UINT32 nErrorCode              = 0;
    UINT32 nRet                    = 0;
    static BOOL nICflag            = FALSE;
    static UINT8 nCellInfoTimes[2] = { 0, };

#ifdef AT_DUAL_SIM
    UINT8 nSim = cfwEvent.nFlag;
#endif
    AT_POSI tPosiData;
    CFW_TSM_CURR_CELL_INFO tCurrCellInf;
    CFW_TSM_ALL_NEBCELL_INFO tNeighborCellInfo;

    AT_MemSet(&tCurrCellInf, 0x0, sizeof(CFW_TSM_CURR_CELL_INFO));
    AT_MemSet(&tNeighborCellInfo, 0x0, sizeof(CFW_TSM_ALL_NEBCELL_INFO));
    AT_MemSet(&tPosiData, 0x0, sizeof(AT_POSI));

    AT_TC(g_sw_AT_NW, "NW_AsyncEvent come in DBS!\n");
    if (cfwEvent.nType == 0xF0)
    {
        AT_TC(g_sw_AT_NW, "NW_AsyncEvent ERROR");
        nErrorCode = AT_SetCmeErrorCode(cfwEvent.nParam1, FALSE);
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
        return;
    }
    if (cfwEvent.nType != 0)
    {
        AT_TC(g_sw_AT_NW, "NW_AsyncEvent:   ERROR!!!---CfwEvent.nType --0x%x\n\r", cfwEvent.nType);
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif

        return;
    }

    {

        AT_TC(g_sw_AT_NW, "NW_AsyncEvent nCellInfoTimes:%d!\n", nCellInfoTimes);

        // if(0 == nCellInfoTimes[nSim])
        {
            AT_TC(g_sw_AT_NW, "NW_AsyncEvent 000 nParam2:%d!\n", cfwEvent.nParam2);

            if (cfwEvent.nParam2 == CFW_TSM_CURRENT_CELL)
            {
                nRet = CFW_GetCellInfo(&tCurrCellInf, &tNeighborCellInfo, nSim);
                if (nRet != ERR_SUCCESS)
                {
                    AT_TC(g_sw_AT_NW, "NW_AsyncEvent ERROR nRet:0x%x!\n", nRet);
#ifdef AT_DUAL_SIM
                    CFW_EmodOutfieldTestEnd(cfwEvent.nUTI, nSim);
#else
                    CFW_EmodOutfieldTestEnd(cfwEvent.nUTI);
#endif

                    // nICflag = FALSE;
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
                    return;
                }
                AT_NW_POSI_AddData(0, &tCurrCellInf, &tNeighborCellInfo);

                // no have CellInf
                if (0xffff == tCurrCellInf.nTSM_Arfcn)
                {
                    AT_TC(g_sw_AT_NW, "NW_AsyncEvent no have CellInf ! \n");

                    if (CFW_INIT_STATUS_NO_SIM == cfwInitInfo.noSim[nSim].nType)
                    {

#ifdef AT_DUAL_SIM
                        CFW_EmodOutfieldTestEnd(cfwEvent.nUTI, nSim);
#else
                        CFW_EmodOutfieldTestEnd(cfwEvent.nUTI);
#endif
                        nCellInfoTimes[nSim] = 1;
                        if (((0 == nSim) && (1 == nCellInfoTimes[1])) || ((1 == nSim) && (1 == nCellInfoTimes[0])))
                        {
#ifdef AT_DUAL_SIM
                            AT_NW_POSI_SendData(nSim);
#else
                            AT_NW_POSI_SendData();
#endif
                            nCellInfoTimes[0] = 0x00;
                            nCellInfoTimes[1] = 0x00;
                        }
                    }
                    else
                    {
                        gPosiList.iNum = 0xff;
#ifdef AT_DUAL_SIM
                        CFW_EmodOutfieldTestEnd(cfwEvent.nUTI, nSim);
#else
                        CFW_EmodOutfieldTestEnd(cfwEvent.nUTI);
#endif
                        nCellInfoTimes[nSim] = 0x00;
#ifdef AT_DUAL_SIM
                        AT_NW_POSI_SendData(nSim);
#else
                        AT_NW_POSI_SendData();
#endif
                    }
#ifdef AT_DUAL_SIM
                    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI, nSim);
#else
                    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI);
#endif
                    return;
                }

            }

            if (cfwEvent.nParam2 == CFW_TSM_NEIGHBOR_CELL)
            {

                AT_TC(g_sw_AT_NW, "NW_AsyncEvent NEIGHBOR_CELL!:\n");
                nRet = CFW_GetCellInfo(&tCurrCellInf, &tNeighborCellInfo, nSim);
                if (nRet != ERR_SUCCESS)
                {
                    AT_TC(g_sw_AT_NW, "NW_AsyncEvent NEIGHBOR_CELL ERROR:0x!%x\n", nRet);
                    AT_GetFreeUTI(0, &cfwEvent.nUTI);
                    nCellInfoTimes[nSim] = 1;
#ifdef AT_DUAL_SIM
                    UINT32 nRet = CFW_EmodOutfieldTestEnd(cfwEvent.nUTI, nSim);
                    if(ERR_CFW_NOT_EXIST_AO != nRet)
                        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
                    CFW_EmodOutfieldTestEnd(cfwEvent.nUTI);
                    AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
                    return;
                }

                AT_TC(g_sw_AT_NW, "NW_AsyncEvent nTSM_NebCellNUM :%d!\n", tNeighborCellInfo.nTSM_NebCellNUM);

                if (tNeighborCellInfo.nTSM_NebCellNUM != 0)
                {
                    AT_NW_POSI_AddData(1, &tCurrCellInf, &tNeighborCellInfo);
                }

                if (CFW_INIT_STATUS_NO_SIM == cfwInitInfo.noSim[nSim].nType)
                {
                    // CFW_NwStopStack(0);
                    nCellInfoTimes[nSim] = 1;
                    if (((0 == nSim) && (1 == nCellInfoTimes[1])) || ((1 == nSim) && (1 == nCellInfoTimes[0])))
                    {
#ifdef AT_DUAL_SIM
                        AT_NW_POSI_SendData(nSim);
#else
                        AT_NW_POSI_SendData();
#endif
                        nCellInfoTimes[0] = 0x00;
                        nCellInfoTimes[1] = 0x00;
                    }
                }
                else
                {
                    nCellInfoTimes[nSim] = 0x00;
#ifdef AT_DUAL_SIM
                    AT_NW_POSI_SendData(nSim);
#else
                    AT_NW_POSI_SendData();
#endif
                }
                AT_GetFreeUTI(0, &cfwEvent.nUTI);
#ifdef AT_DUAL_SIM
                CFW_EmodOutfieldTestEnd(cfwEvent.nUTI, nSim);
#else
                CFW_EmodOutfieldTestEnd(cfwEvent.nUTI);
#endif
            }
            return;
        }
    }

    AT_TC(g_sw_AT_NW, "NW-POSI set success!\n");

    return;
}

#else
// for +CCED
#ifdef AT_DUAL_SIM
BOOL AT_EMOD_CCED_ProcessData(UINT8 nSim, CFW_TSM_CURR_CELL_INFO *pCurrCellInfo,
                              CFW_TSM_ALL_NEBCELL_INFO *pNeighborCellInfo, UINT8 *nStrPosiList)
#else
BOOL AT_EMOD_CCED_ProcessData(CFW_TSM_CURR_CELL_INFO *pCurrCellInfo, CFW_TSM_ALL_NEBCELL_INFO *pNeighborCellInfo,
                              UINT8 *nStrPosiList)
#endif
{
    UINT8 i                   = 0;
    VOLATILE AT_CCED PosiList ;
    UINT8 nStr[100]           = { 0 };

    SUL_ZeroMemory8((VOID *)&PosiList, sizeof(AT_CCED));

    AT_TC(g_sw_AT_NW, "AT_EMOD_CCED_ProcessData!");
    if ((NULL == pCurrCellInfo && NULL == pNeighborCellInfo) || (NULL == nStrPosiList))
    {
        AT_TC(g_sw_AT_NW, "AT_EMOD_CCED_ProcessData InputErr\n");
        return FALSE;
    }
    AT_Sprintf(nStrPosiList, "+CCED:");

    AT_TC(g_sw_AT_NW, "pCurrCellInfo != NULL");
    if (pCurrCellInfo != NULL)
    {
        PosiList.sMcc[0] = pCurrCellInfo->nTSM_LAI[0] & 0x0F;
        PosiList.sMcc[1] = pCurrCellInfo->nTSM_LAI[0] >> 4;
        PosiList.sMcc[2] = pCurrCellInfo->nTSM_LAI[1] & 0x0F;
        PosiList.nArfcn = pCurrCellInfo->nTSM_Arfcn;

#if 1
        PosiList.sMnc[0] = pCurrCellInfo->nTSM_LAI[2] & 0x0F;
        PosiList.sMnc[1] = pCurrCellInfo->nTSM_LAI[2] >> 4;
        PosiList.sMnc[2] = pCurrCellInfo->nTSM_LAI[1] >> 4;
        if (PosiList.sMnc[2] > 9)
            PosiList.sMnc[2] = 0;
#else
        PosiList.sMnc[0] = pCurrCellInfo->nTSM_LAI[1] >> 4;
        if (PosiList.sMnc[0] > 9)
            PosiList.sMnc[0] = 0;
        PosiList.sMnc[1]   = pCurrCellInfo->nTSM_LAI[2] & 0x0F;
        PosiList.sMnc[2]   = pCurrCellInfo->nTSM_LAI[2] >> 4;
#endif

        PosiList.sLac    = (pCurrCellInfo->nTSM_LAI[3] << 8) | (pCurrCellInfo->nTSM_LAI[4]);
        PosiList.sCellID = (pCurrCellInfo->nTSM_CellID[0] << 8) | (pCurrCellInfo->nTSM_CellID[1]);

        PosiList.iBsic     = pCurrCellInfo->nTSM_Bsic;

        //PosiList.iRxLev    = ((110 - pCurrCellInfo->nTSM_AvRxLevel) * 100) / 64;
        //Get Real RSSI for 8810 CCED issue by XP 20130930
        PosiList.iRxLev = pCurrCellInfo->nTSM_AvRxLevel;
        PosiList.iRxLevSub = pCurrCellInfo->nTSM_RxQualSub;

        AT_TC(g_sw_AT_NW,
              "AT_EMOD_CCED_ProcessData pCurrCellInfo\n sMcc=%d%d%d,sMnc=%d%d%d,sLac=%x,sCellID=%x,iBsic=%d,iRxLev=%d,iRxLevSub=%d PosiList.nArfcn=0x%x",
              PosiList.sMcc[0], PosiList.sMcc[1], PosiList.sMcc[2], PosiList.sMnc[0], PosiList.sMnc[1], PosiList.sMnc[2],
              PosiList.sLac, PosiList.sCellID, PosiList.iBsic, PosiList.iRxLev, PosiList.iRxLevSub, PosiList.nArfcn);
#ifndef CHIP_HAS_AP
        SUL_StrPrint(nStr, "%d%d%d,%d%d%d,%x,%x,%d,%d,%d,%x",
                     PosiList.sMcc[0], PosiList.sMcc[1], PosiList.sMcc[2],
                     PosiList.sMnc[0], PosiList.sMnc[1], PosiList.sMnc[2],
                     PosiList.sLac, PosiList.sCellID, PosiList.iBsic, PosiList.iRxLev, PosiList.iRxLevSub, PosiList.nArfcn);
#else
        SUL_StrPrint(nStr, "%d%d%d,%d%d%d,%x,%x,%d,%d,%d",
                     PosiList.sMcc[0], PosiList.sMcc[1], PosiList.sMcc[2],
                     PosiList.sMnc[0], PosiList.sMnc[1], PosiList.sMnc[2],
                     PosiList.sLac, PosiList.sCellID, PosiList.iBsic, PosiList.iRxLev, PosiList.iRxLevSub);
#endif
        SUL_StrCat(nStrPosiList, nStr);

    }

    if (pNeighborCellInfo != NULL)
    {
        int iCount = 0x00;
        for (i = 0; i < pNeighborCellInfo->nTSM_NebCellNUM; i++)
        {
            if (!((pNeighborCellInfo->nTSM_NebCell[i].nTSM_CellID[0] == 0)
                    && (pNeighborCellInfo->nTSM_NebCell[i].nTSM_CellID[1] == 0)))
            {

                PosiList.sMcc[0] = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[0] & 0x0F;
                PosiList.sMcc[1] = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[0] >> 4;
                PosiList.sMcc[2] = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[1] & 0x0F;

#  if 1
                PosiList.sMnc[0] = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[2] & 0x0F;
                PosiList.sMnc[1] = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[2] >> 4;
                PosiList.sMnc[2] = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[1] >> 4;
                if (PosiList.sMnc[2] > 9)
                    PosiList.sMnc[2] = 0;
#else
                PosiList.sMnc[0] = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[1] >> 4;
                if (PosiList.sMnc[0] > 9)
                    PosiList.sMnc[0] = 0;
                PosiList.sMnc[1]   = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[2] & 0x0F;
                PosiList.sMnc[2]   = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[2] >> 4;
#endif

                PosiList.sLac =
                    (pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[3] << 8) | (pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[4]);
                PosiList.sCellID =
                    (pNeighborCellInfo->nTSM_NebCell[i].nTSM_CellID[0] << 8) | (pNeighborCellInfo->nTSM_NebCell[i].
                            nTSM_CellID[1]);

                PosiList.iBsic  = pNeighborCellInfo->nTSM_NebCell[i].nTSM_Bsic;
                //Get Real RSSI for 8810 CCED issue by XP 20130930
                //PosiList.iRxLev = ((110 - pNeighborCellInfo->nTSM_NebCell[i].nTSM_AvRxLevel) * 100) / 64;
                PosiList.iRxLev = pNeighborCellInfo->nTSM_NebCell[i].nTSM_AvRxLevel;
                if (pCurrCellInfo != NULL || i > 0)
                {
                    AT_TC(g_sw_AT_NW, "pCurrCellInfo 0x%x,i=%d", pCurrCellInfo, i);
                    if(iCount > 0)
                        SUL_StrCat(nStrPosiList, ",");
                }
                iCount ++;

                SUL_StrPrint(nStr, "%d%d%d,%d%d%d,%d,%d,%d,%d",
                             PosiList.sMcc[0], PosiList.sMcc[1], PosiList.sMcc[2],
                             PosiList.sMnc[0], PosiList.sMnc[1], PosiList.sMnc[2],
                             PosiList.sLac, PosiList.sCellID, PosiList.iBsic, PosiList.iRxLev);

                AT_TC(g_sw_AT_NW,
                      "AT_EMOD_CCED_ProcessData pNeighborCellInfo[%d] sMcc=%d%d%d,sMnc=%d%d%d,sLac=%x,sCellID=%x,iBsic=%d,iRxLev=%d,iRxLevSub=%d",
                      i, PosiList.sMcc[0], PosiList.sMcc[1], PosiList.sMcc[2], PosiList.sMnc[0], PosiList.sMnc[1],
                      PosiList.sMnc[2], PosiList.sLac, PosiList.sCellID, PosiList.iBsic, PosiList.iRxLev);
                SUL_StrCat(nStrPosiList, nStr);
            }
        }
    }
    return TRUE;
}

VOID NWSATCellInfo(CFW_EVENT cfwEvent)
{
#ifdef AT_DUAL_SIM
    UINT8 nSim = cfwEvent.nFlag;
#endif

    AT_TC(g_sw_AT_NW, "NWSATCellInfo cfwEvent.nType0x%x!\n", cfwEvent.nType);

    if (cfwEvent.nType == 0xF0)
    {
        AT_TC(g_sw_AT_NW, "NW_AsyncEvent ERROR");
        UINT32 nErrorCode = AT_SetCmeErrorCode(cfwEvent.nParam1, FALSE);
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
        return;
    }
    if (cfwEvent.nType != 0)
    {
        AT_TC(g_sw_AT_NW, "NW_AsyncEvent:   ERROR!!!---CfwEvent.nType --0x%x\n\r", cfwEvent.nType);
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
        return;
    }
    AT_TC(g_sw_AT_NW, "NWSATCellInfo cfwEvent.nParam2 0x%x!\n", cfwEvent.nParam2);

    if (cfwEvent.nParam2 == CFW_TSM_CURRENT_CELL)
    {
        CFW_TSM_CURR_CELL_INFO tCurrCellInf;
        CFW_TSM_ALL_NEBCELL_INFO tNeighborCellInfo;

        AT_MemSet(&tCurrCellInf, 0x0, sizeof(CFW_TSM_CURR_CELL_INFO));
        AT_MemSet(&tNeighborCellInfo, 0x0, sizeof(CFW_TSM_ALL_NEBCELL_INFO));

        UINT32 nRet = CFW_GetCellInfo(&tCurrCellInf, &tNeighborCellInfo, nSim);
        CFW_EmodOutfieldTestEnd(cfwEvent.nUTI, nSim);

        // hal_DbgAssert("NW_AsyncEventProcess_GetCellInfo CFW_TSM_CURRENT_CELL", NULL);
        if (nRet != ERR_SUCCESS)
        {
            AT_TC(g_sw_AT_NW, "NW_AsyncEvent ERROR nRet:0x%x!\n", nRet);
#ifdef AT_DUAL_SIM
            //CFW_EmodOutfieldTestEnd(cfwEvent.nUTI, nSim);
            AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);

#else
            //CFW_EmodOutfieldTestEnd(cfwEvent.nUTI);
            AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif

            return;
        }
        if(0x00 == gATSATComQualifier[nSim])
        {
            SAT_LOCALINFO_RSP LocaInf;
            UINT8 nMNClen = 3;
            memset(&LocaInf, 0, sizeof(SAT_LOCALINFO_RSP));
            LocaInf.nCellIdentify = (tCurrCellInf.nTSM_CellID[0] << 8) | (tCurrCellInf.nTSM_CellID[1]);


            cfw_PLMNtoBCD(tCurrCellInf.nTSM_LAI, LocaInf.nMCC_MNC_Code, &nMNClen);

            LocaInf.nLocalAreaCode = (tCurrCellInf.nTSM_LAI[3] << 8 ) | (tCurrCellInf.nTSM_LAI[4]);

            UINT8 nUTI = 0x00;
            AT_GetFreeUTI(CFW_NW_SRV_ID, &nUTI);

            CFW_NW_STATUS_INFO nStatusInfo;
            UINT32 nStatus = 0x00;
#ifdef AT_DUAL_SIM

            if (ERR_SUCCESS != CFW_NwGetStatus(&nStatusInfo, nSim))
#else
            if (ERR_SUCCESS != CFW_NwGetStatus(&nStatusInfo))

#endif
            {
                AT_TC(g_sw_AT_NW, "CFW_NwGetStatus Error\n");

#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
                return;
            }
            AT_TC(g_sw_AT_NW, "NWSATCellInfo nStatusInfo.nStatus  %d\n", nStatusInfo.nStatus);

            if (nStatusInfo.nStatus == CFW_NW_STATUS_NOTREGISTERED_SEARCHING || nStatusInfo.nStatus == CFW_NW_STATUS_NOTREGISTERED_NOTSEARCHING ||
                    nStatusInfo.nStatus == CFW_NW_STATUS_REGISTRATION_DENIED || nStatusInfo.nStatus == CFW_NW_STATUS_UNKNOW)
            {
                nStatus = 0x06;
            }

            if(0x00 == nStatus)
#ifdef AT_DUAL_SIM
                nRet = CFW_SatResponse (0x26, nStatus, 0x0, &LocaInf, sizeof(SAT_LOCALINFO_RSP), nUTI, nSim);
#else
                nRet = CFW_SatResponse (0x26, nStatus, 0x0, &LocaInf, sizeof(SAT_LOCALINFO_RSP), nUTI);
#endif
            else
#ifdef AT_DUAL_SIM
                nRet = CFW_SatResponse (0x26, nStatus, 0x0, NULL, 0, nUTI, nSim);
#else
                nRet = CFW_SatResponse (0x26, nStatus, 0x0, NULL, 0, nUTI);
#endif
        }
        else if(0x05 == gATSATComQualifier[nSim])
        {
            SAT_TIMINGADV_RSP nTA;
            nTA.nME_Status = 0x00;
            nTA.nTimingAdv = tCurrCellInf.nTSM_TimeADV;
            UINT32 nStatus = 0x00;
            CFW_NW_STATUS_INFO nStatusInfo;
#ifdef AT_DUAL_SIM

            if (ERR_SUCCESS != CFW_NwGetStatus(&nStatusInfo, nSim))
#else
            if (ERR_SUCCESS != CFW_NwGetStatus(&nStatusInfo))

#endif
            {
                AT_TC(g_sw_AT_NW, "CFW_NwGetStatus Error\n");

#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
                return;
            }
            AT_TC(g_sw_AT_NW, "NWSATCellInfo nStatusInfo.nStatus  %d\n", nStatusInfo.nStatus);

            if (nStatusInfo.nStatus == CFW_NW_STATUS_NOTREGISTERED_SEARCHING || nStatusInfo.nStatus == CFW_NW_STATUS_NOTREGISTERED_NOTSEARCHING ||
                    nStatusInfo.nStatus == CFW_NW_STATUS_REGISTRATION_DENIED || nStatusInfo.nStatus == CFW_NW_STATUS_UNKNOW)
            {
                nStatus = 0x06;
            }
            if(0x00 == nStatus)
#ifdef AT_DUAL_SIM
                nRet = CFW_SatResponse (0x26, nStatus, 0x0, &nTA, sizeof(SAT_TIMINGADV_RSP), AT_ASYN_GET_DLCI(nSim), nSim);
#else
                nRet = CFW_SatResponse (0x26, nStatus, 0x0, &nTA, sizeof(SAT_TIMINGADV_RSP), AT_ASYN_GET_DLCI());
#endif
            else
#ifdef AT_DUAL_SIM
                nRet = CFW_SatResponse (0x26, nStatus, 0x0, NULL, 0, AT_ASYN_GET_DLCI(nSim), nSim);
#else
                nRet = CFW_SatResponse (0x26, nStatus, 0x0, NULL, 0, AT_ASYN_GET_DLCI());
#endif
        }


        AT_TC(g_sw_AT_NW, "CFW_SatResponse nRet:0x%x!\n", nRet);


    }
}
extern UINT32 gSATCurrentCmdStamp[];
VOID NW_AsyncEventProcess_GetCellInfo(CFW_EVENT cfwEvent)
{
    UINT32 nErrorCode              = 0;
    UINT32 nRet                    = 0;
    //  static BOOL nICflag            = FALSE;
    static UINT8 nCellInfoTimes[2] = { 0, };

#ifdef AT_DUAL_SIM
    UINT8 nSim = cfwEvent.nFlag;
#endif
    BOOL bRet = FALSE;
    CFW_TSM_CURR_CELL_INFO tCurrCellInf;
    CFW_TSM_ALL_NEBCELL_INFO tNeighborCellInfo;
    UINT8 pTxtBuf[500] = { 0 };

    AT_MemSet(&tCurrCellInf, 0x0, sizeof(CFW_TSM_CURR_CELL_INFO));
    AT_MemSet(&tNeighborCellInfo, 0x0, sizeof(CFW_TSM_ALL_NEBCELL_INFO));

    AT_TC(g_sw_AT_NW, "NW_AsyncEvent come gATSATLocalInfoFlag[%d] %d!\n", nSim, gATSATLocalInfoFlag[nSim]);


    if(TRUE == gATSATLocalInfoFlag[nSim] )
    {
        //gSATCurrentCmdStamp[nSim] = 0x00;
        NWSATCellInfo(cfwEvent);
        return;
    }

    if (cfwEvent.nType == 0xF0)
    {
        AT_TC(g_sw_AT_NW, "NW_AsyncEvent ERROR");
        nErrorCode = AT_SetCmeErrorCode(cfwEvent.nParam1, FALSE);
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
        return;
    }
    if (cfwEvent.nType != 0)
    {
        AT_TC(g_sw_AT_NW, "NW_AsyncEvent:   ERROR!!!---CfwEvent.nType --0x%x\n\r", cfwEvent.nType);
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
        return;
    }

    AT_TC(g_sw_AT_NW, "NW_AsyncEvent nCellInfoTimes:%d!\n", nCellInfoTimes);

    AT_TC(g_sw_AT_NW, "NW_AsyncEvent 000 nParam2:%d!\n", cfwEvent.nParam2);


    if (cfwEvent.nParam2 == CFW_TSM_CURRENT_CELL)
    {
        nRet = CFW_GetCellInfo(&tCurrCellInf, &tNeighborCellInfo, nSim);

        // hal_DbgAssert("NW_AsyncEventProcess_GetCellInfo CFW_TSM_CURRENT_CELL", NULL);
        if (nRet != ERR_SUCCESS)
        {
            AT_TC(g_sw_AT_NW, "NW_AsyncEvent ERROR nRet:0x%x!\n", nRet);
#ifdef AT_DUAL_SIM
            CFW_EmodOutfieldTestEnd(cfwEvent.nUTI, nSim);
            AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);

#else
            CFW_EmodOutfieldTestEnd(cfwEvent.nUTI);
            AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
            return;
        }

#ifdef AT_DUAL_SIM
        bRet = AT_EMOD_CCED_ProcessData(nSim, &tCurrCellInf, NULL, pTxtBuf);
        if (bRet)
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pTxtBuf, AT_StrLen(pTxtBuf), cfwEvent.nUTI, nSim);
        else
            AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);

        CFW_EmodOutfieldTestEnd(cfwEvent.nUTI, nSim);

#else
        bRet = AT_EMOD_CCED_ProcessData(&tCurrCellInf, NULL, pTxtBuf);
        if (bRet)
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pTxtBuf, AT_StrLen(pTxtBuf), cfwEvent.nUTI);
        else
            AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);

        CFW_EmodOutfieldTestEnd(cfwEvent.nUTI);
#endif

    }
    else if (cfwEvent.nParam2 == CFW_TSM_NEIGHBOR_CELL)
    {
        AT_TC(g_sw_AT_NW, "NW_AsyncEvent NEIGHBOR_CELL!:\n");
        nRet = CFW_GetCellInfo(&tCurrCellInf, &tNeighborCellInfo, nSim);

        // hal_DbgAssert("NW_AsyncEventProcess_GetCellInfo CFW_TSM_NEIGHBOR_CELL", NULL);

        if (nRet != ERR_SUCCESS)
        {
            AT_TC(g_sw_AT_NW, "NW_AsyncEvent NEIGHBOR_CELL ERROR:0x!%x\n", nRet);
#ifdef AT_DUAL_SIM
            CFW_EmodOutfieldTestEnd(cfwEvent.nUTI, nSim);
            AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
            CFW_EmodOutfieldTestEnd(cfwEvent.nUTI);
            AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
            return;
        }

        AT_TC(g_sw_AT_NW, "NW_AsyncEvent nTSM_NebCellNUM :%d!\n", tNeighborCellInfo.nTSM_NebCellNUM);

        // tNeighborCellInfo.nTSM_NebCellNUM
#ifdef AT_DUAL_SIM
        bRet = AT_EMOD_CCED_ProcessData(nSim, NULL, &tNeighborCellInfo, pTxtBuf);
        if (bRet)
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pTxtBuf, AT_StrLen(pTxtBuf), cfwEvent.nUTI, nSim);
        else
            AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);

        CFW_EmodOutfieldTestEnd(cfwEvent.nUTI, nSim);
#else
        bRet = AT_EMOD_CCED_ProcessData(NULL, &tNeighborCellInfo, pTxtBuf);
        if (bRet)
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pTxtBuf, AT_StrLen(pTxtBuf), cfwEvent.nUTI);
        else
            AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);

        CFW_EmodOutfieldTestEnd(cfwEvent.nUTI);
#endif

    }
    else
    {
#ifdef AT_DUAL_SIM
        CFW_EmodOutfieldTestEnd(cfwEvent.nUTI, nSim);
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
        CFW_EmodOutfieldTestEnd(cfwEvent.nUTI);
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
    }
}
#endif

/**************************************************************************************************
 * @fn
 *
 * @brief
 *
 * @param
 *
 * @return
 **************************************************************************************************/
VOID AT_NW_CmdFunc_CCED(AT_CMD_PARA *pParam)
{
    UINT8 paraCount = 0;
    //UINT32 nResult  = ERR_SUCCESS;
    INT32 iRet      = 0;

    UINT8 nMode    = 0, nRequestedDump = 0;
    UINT8 nTypSize = 0;
    UINT8 nIndex   = 0;

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

    AT_TC(g_sw_GPRS, "AT+CCED:AT_NW_CmdFunc_CCED");
    if (pParam == NULL)
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    switch (pParam->iType)
    {
    case AT_CMD_SET:
        iRet = AT_Util_GetParaCount(pParam->pPara, &paraCount);
        if ((iRet != ERR_SUCCESS) || (paraCount != 2))
        {
            AT_TC(g_sw_GPRS, "AT+CCED ERROR:paraCount: %d", paraCount);
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // index is 0,get MODE
        nIndex   = 0;
        nTypSize = 1;
        iRet     = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_UINT8, &nMode, &nTypSize);
        AT_TC(g_sw_GPRS, "AT+CCED nMode: %d", nMode);
        if (ERR_SUCCESS != iRet || nMode > 0)
        {
            AT_TC(g_sw_GPRS, "AT+CCED ERROR:nMode!=1 !");
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // index is 1,get RequestedDump
        nIndex++;
        iRet = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_UINT8, &nRequestedDump, &nTypSize);

        if (iRet == ERR_SUCCESS && nRequestedDump != 1 && nRequestedDump != 2 && nRequestedDump != 8)
        {
            AT_TC(g_sw_GPRS, "AT+CCED ERROR:iRet: %d, nRequestedDump ", nRequestedDump);
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;

        }
        else if (iRet != ERR_SUCCESS)
        {
            AT_TC(g_sw_GPRS, "AT+CCED ERROR:iRet: %d, GetPara ", iRet);
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // gPosiList.iMode = nMode;

        if (8 == nRequestedDump)
        {
            // dispaly RSSI
            // same as CSQ
            UINT8 nSignalLevel = 0;
            UINT8 nBitError    = 0;
            UINT8 nBuf[20]     = { 0 };

#ifdef AT_DUAL_SIM
            iRet = CFW_NwGetSignalQuality(&nSignalLevel, &nBitError, nSim);
#else
            iRet = CFW_NwGetSignalQuality(&nSignalLevel, &nBitError);
#endif
            AT_TC(g_sw_AT_NW, "AT+CCED CFW_NwGetSignalQuality:nRet = 0x%x\n\r", iRet);
            AT_TC(g_sw_AT_NW, "AT+CCED=0,8:   nSignalLevel = %d,nBitError = %d\n\r", nSignalLevel, nBitError);

            if (ERR_SUCCESS == iRet)
            {
                UINT8 nSL[3] = { 0 };
                UINT8 nBE[5] = { 0 };

                SUL_ZeroMemory8(nBuf, 20);
                SUL_StrPrint(nSL, (PCSTR)"%d", nSignalLevel);
                SUL_StrPrint(nBE, (PCSTR)"%d", nBitError);
                SUL_StrCopy(nBuf, "+CCED: ");
                SUL_StrCat(nBuf, nSL);
                SUL_StrCat(nBuf, ",");
                SUL_StrCat(nBuf, nBE);

#ifdef AT_DUAL_SIM
                AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, nBuf, AT_StrLen(nBuf), pParam->nDLCI, nSim);
#else
                AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, nBuf, AT_StrLen(nBuf), pParam->nDLCI);
#endif

                return;
            }
        }
        else
        {
            // get Cell info
            CFW_TSM_FUNCTION_SELECT tSelecFUN;
            SUL_ZeroMemory8(&tSelecFUN, SIZEOF(CFW_TSM_FUNCTION_SELECT));

            UINT8 nUTI = 0;

            if (1 == nRequestedDump)
            {
                tSelecFUN.nServingCell = 1;
            }
            else
            {
                tSelecFUN.nNeighborCell = 1;
            }

            AT_GetFreeUTI(0, &nUTI);
            iRet = CFW_EmodOutfieldTestStart(&tSelecFUN, pParam->nDLCI, nSim);
            if (iRet != ERR_SUCCESS)
            {
                AT_TC(g_sw_GPRS, "AT+CCED ERROR:iRet: %d, Emod", iRet);
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }

#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN_CLEAR_CMD, CMD_RC_OK, 60, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN_CLEAR_CMD, CMD_RC_OK, 60, NULL, 0, pParam->nDLCI);
#endif
        }

        break;

    case AT_CMD_READ:
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        break;

    case AT_CMD_TEST:
    {
        UINT8 AtTri[64] = { 0 };

        AT_Sprintf(AtTri, "+CCED: (0),(1,2,8)");
#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtTri, (UINT16)AT_StrLen(AtTri), pParam->nDLCI, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtTri, (UINT16)AT_StrLen(AtTri), pParam->nDLCI);
#endif
    }
    break;

    default:
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        break;
    }

    return;
}
BOOL g_simopen_creg_flag = FALSE;

VOID AT_NW_AsyncEventProcess(COS_EVENT *pEvent)
{
    // AT_20071112_CAOW_B
    UINT8 uSignal[20]    = { 0 };
    UINT8 uRegStatus[40] = { 0 };
    UINT8 ucSignal       = 0;

    // AT_20071112_CAOW_E

    // AT_20071112_CAOW_E

#if 1
    CFW_EVENT cfwEvent;

    // [[ yy [new] 2008-4-23 for Bug ID:8176
    UINT8 AreaStr[5]  = { 0 };
    UINT8 CellStr[5]  = { 0 };
    // ]] yy [new] 2008-4-23 for Bug ID:8176
#ifdef AT_DUAL_SIM
    UINT8 nSim; // = (UINT8 )(pEvent->nParam3&0x000000ff);
#endif

    AT_CosEvent2CfwEvent(pEvent, &cfwEvent);

    UINT16 uiCellCode = LOUINT16(cfwEvent.nParam2);
    UINT16 uiAreaCode = HIUINT16(cfwEvent.nParam2);

#ifdef AT_DUAL_SIM
    nSim = cfwEvent.nFlag;
#endif

//    if (bMuxActiveStatus)
//    {
//        cfwEvent.nUTI = AT_ASYN_GET_DLCI(nSim);
//    }

    switch (pEvent->nEventId)
    {
        // AT_20071112_CAOW_B //add for +CIEV

    case EV_CFW_NW_SIGNAL_QUALITY_IND:

        if (gATCurrentuCmer_ind[nSim] == 2)
        {
            if (cfwEvent.nType == 0)
            {
                if (cfwEvent.nParam1 == 0 || cfwEvent.nParam1 == 99)
                    ucSignal = 0;
                else if (cfwEvent.nParam1 >= 1 && cfwEvent.nParam1 < 7)
                    ucSignal = 1;
                else if (cfwEvent.nParam1 >= 7 && cfwEvent.nParam1 < 13)
                    ucSignal = 2;
                else if (cfwEvent.nParam1 >= 13 && cfwEvent.nParam1 < 19)
                    ucSignal = 3;
                else if (cfwEvent.nParam1 >= 19 && cfwEvent.nParam1 < 25)
                    ucSignal = 4;
                else if (cfwEvent.nParam1 >= 25 && cfwEvent.nParam1 < 32)
                    ucSignal = 5;

                if (g_uATNWECSQFlag == 1)
                {
                    SUL_ZeroMemory8(uSignal, sizeof(uSignal));
                    SUL_StrPrint(uSignal, "+ECSQ: %d,%d", cfwEvent.nParam1, cfwEvent.nParam2);
#ifdef AT_DUAL_SIM
                    AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, uSignal, AT_StrLen(uSignal), cfwEvent.nUTI, nSim);
#else
                    AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, uSignal, AT_StrLen(uSignal), cfwEvent.nUTI);
#endif
                }

            }
        }

        break;

        // AT_20071112_CAOW_E

    case EV_CFW_NW_REG_STATUS_IND:
        //hal_HstSendEvent(0xaabbccd0);
        //hal_HstSendEvent(g_set_ACLB);
        if( (2 == g_set_ACLB) && (0 == nSim) )
        {
            CFW_COMM_MODE nMode;
            //hal_HstSendEvent(0xaabbccd1);

            CFW_GetComm( &nMode , nSim);
            if(nMode == CFW_ENABLE_COMM)
            {
                g_set_ACLB = 3;
                //hal_HstSendEvent(0xaabbccd2);
                CFW_SetComm(CFW_DISABLE_COMM, 0, cfwEvent.nUTI, nSim);
                return ;
            }
        }
        else if( (4 == g_set_ACLB) && (0 == nSim) )
        {
            //hal_HstSendEvent(0xaabbccd3);
//            g_auto_calib = FALSE;
            g_set_ACLB = 0;
            g_ACLB_FM   = CFW_CHECK_COMM;
            if(CFW_ENABLE_COMM == g_ACLB_SIM1_FM )
            {
                g_ACLB_SIM1_FM = CFW_CHECK_COMM;
                CFW_SetComm(CFW_ENABLE_COMM, 0, cfwEvent.nUTI, 1);
            }

        }
        // ---------------------------------------------------------
        // CREG URC
        // ---------------------------------------------------------
        gCsStauts.nParam1 = cfwEvent.nParam1;
        gCsStauts.nType   = cfwEvent.nType;
        if (2 == cfwEvent.nType)
        {

            if(g_simopen_creg_flag == TRUE)
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, NULL, 0, cfwEvent.nUTI, nSim);
#else
                AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, NULL, 0, cfwEvent.nUTI);
#endif
                g_simopen_creg_flag = FALSE;
                return;
            }
            // AT_20071112_CAOW_B   //add for +CIEV
            if (gATCurrentuCmer_ind[nSim] == 2)
            {
                SUL_ZeroMemory8(uRegStatus, 40);

                if (cfwEvent.nParam1 == CFW_NW_STATUS_REGISTERED_HOME || cfwEvent.nParam1 == CFW_NW_STATUS_REGISTERED_ROAMING)
                    SUL_StrPrint(uRegStatus, "+CIEV: service,  1\r\n");
                else
                    SUL_StrPrint(uRegStatus, "+CIEV: service,  0\r\n");

                if (cfwEvent.nParam1 == CFW_NW_STATUS_REGISTERED_ROAMING)
                    SUL_StrCat(uRegStatus, "+CIEV: roam, 1");
                else
                    SUL_StrCat(uRegStatus, "+CIEV: roam, 0");
#ifdef AT_DUAL_SIM
                AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, uRegStatus, AT_StrLen(uRegStatus), cfwEvent.nUTI, nSim);
#else
                AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, uRegStatus, AT_StrLen(uRegStatus), cfwEvent.nUTI);
#endif
                SUL_ZeroMemory8(uRegStatus, 40);


                if(2 == cfwEvent.nParam2)
                    SUL_StrPrint(uRegStatus, "+GSM  Service\r\n");
                else if(4 == cfwEvent.nParam2)
                    SUL_StrPrint(uRegStatus, "+UMTS Service\r\n");

#ifdef AT_DUAL_SIM
                AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, uRegStatus, AT_StrLen(uRegStatus), cfwEvent.nUTI, nSim);
#else
                AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, uRegStatus, AT_StrLen(uRegStatus), cfwEvent.nUTI);
#endif

            }

            // AT_20071112_CAOW_E

            if ((CFW_NW_STATUS_REGISTERED_HOME == cfwEvent.nParam1) || (CFW_NW_STATUS_REGISTERED_ROAMING == cfwEvent.nParam1))
            {
                if (g_FirstREG)
                {
                    UINT8 ucMode = 0;

#ifdef AT_DUAL_SIM
                    CFW_NwGetCurrentOperator(g_COPS_OperID, &ucMode, nSim);
#else
                    CFW_NwGetCurrentOperator(g_COPS_OperID, &ucMode);

#endif
                    g_COPS_Mode = 0;
                    g_FirstREG  = 0;
                }
            }

            UINT8 n = 0;

#ifdef AT_DUAL_SIM

            UINT32 nRet = CFW_CfgGetNwStatus(&n, nSim);
#else
            UINT32 nRet = CFW_CfgGetNwStatus(&n);

#endif

            if (ERR_SUCCESS != nRet)
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
                return;
            }

            if (0 == n)
            {
                return;
            }

            UINT8 uOutstr[80] = { 0 };  // yy [mod] 2008-4-24 for Bug ID:8176

            if ((0 != cfwEvent.nParam2) && (2 == n))
            {
                // [[ yy [mod]  2008-4-23 for Bug ID:8176
#  if 0
                UINT8 AreaStr[5]  = { 0 };
                UINT8 CellStr[5]  = { 0 };
                UINT16 uiCellCode = LOUINT16(cfwEvent.nParam2);
                UINT16 uiAreaCode = HIUINT16(cfwEvent.nParam2);
#endif
                // ]] yy [mod] 2008-4-23 for Bug ID:8176

                if (uiAreaCode < 16)
                {
                    SUL_StrPrint(AreaStr, "000%x", uiAreaCode);
                }
                else if (uiAreaCode < 256)
                {
                    SUL_StrPrint(AreaStr, "00%x", uiAreaCode);
                }
                else if (uiAreaCode < 4096)
                {
                    SUL_StrPrint(AreaStr, "0%x", uiAreaCode);
                }
                else
                {
                    SUL_StrPrint(AreaStr, "%x", uiAreaCode);
                }

                if (uiCellCode < 16)
                {
                    SUL_StrPrint(CellStr, "000%x", uiCellCode);
                }
                else if (uiCellCode < 256)
                {
                    SUL_StrPrint(CellStr, "00%x", uiCellCode);
                }
                else if (uiCellCode < 4096)
                {
                    SUL_StrPrint(CellStr, "0%x", uiCellCode);
                }
                else
                {
                    SUL_StrPrint(CellStr, "%x", uiCellCode);
                }

                AT_StrUpr(CellStr);

                AT_StrUpr(AreaStr);

                // AT_SIM_20071011_CAOW_B
#  if 0
                SUL_StrPrint(uOutstr, "+CREG: %d,\"%s\",\"%s\"\r\n", cfwEvent.nParam1, AreaStr, CellStr);
#else
                SUL_StrPrint(uOutstr, "+CREG: %d,\"%s\",\"%s\"", cfwEvent.nParam1, AreaStr, CellStr);
#endif
                // AT_SIM_20071011_CAOW_E

            }
            else
            {
                SUL_StrPrint(uOutstr, "+CREG: %d", cfwEvent.nParam1);
                AT_TC(g_sw_GPRS, "+CREG: %d", cfwEvent.nParam1);
#ifdef AT_FTP_SUPPORT
#ifdef AT_FTP_UPDATE
                if(cfwEvent.nParam1)
                {
                    UINT32 nRet = CFW_GprsAtt(CFW_GPRS_ATTACHED, 2,  nSim);
                    AT_TC(g_sw_GPRS, "CFW_GprsAtt: %x", nRet);

                }
#else
// set a timer for OTA
                BOOL bOTATimer = FALSE;
                bOTATimer= AT_SetOTATimer(ATE_OTA_CHECK_ELAPSE);
                AT_TC(g_sw_GPRS, "SetOTATimer: %d", bOTATimer);
#endif
#endif
            }


#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, uOutstr, AT_StrLen(uOutstr), cfwEvent.nUTI, nSim);
#else
            AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, uOutstr, AT_StrLen(uOutstr), cfwEvent.nUTI);
#endif
            SUL_ZeroMemory8(uOutstr, 80);
            if(2 == cfwEvent.nParam2)
                SUL_StrPrint(uOutstr, "+GSM Service\r\n");
            else if(4 == cfwEvent.nParam2)
                SUL_StrPrint(uOutstr, "+UMTS Service\r\n");

#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, uOutstr, AT_StrLen(uOutstr), cfwEvent.nUTI, nSim);
#else
            AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, uOutstr, AT_StrLen(uOutstr), cfwEvent.nUTI);
#endif
            return;
        }

        break;

    case EV_CFW_NW_DEREGISTER_RSP:
        // ---------------------------------------------------------
        // COPS deregister Event
        // ---------------------------------------------------------

        if (0 == pEvent->nParam1)
        {
            UINT8 uOutstr[80] = { 0 };
            SUL_StrPrint(uOutstr, "+CREG: 0\r\n");
            g_COPS_Mode = 2;
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutstr, AT_StrLen(uOutstr), cfwEvent.nUTI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutstr, AT_StrLen(uOutstr), cfwEvent.nUTI);
#endif


            return;
        }
        else
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(pEvent->nParam1 - ERR_CME_PHONE_FAILURE, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
            AT_NW_Result_Err(pEvent->nParam1 - ERR_CME_PHONE_FAILURE, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
            return;
        }

        break;

    case EV_CFW_NW_SET_REGISTRATION_RSP:
        // ---------------------------------------------------------
        // COPS register Event
        // ---------------------------------------------------------

        // caow add
        AT_TC(g_sw_AT_NW, "EV_CFW_NW_SET_REGISTRATION_RSP cfwEvent.nType==%d\r\n", cfwEvent.nType);
        if(gATCurrentCOPS_Mode_Temp == 4)
        {
            UINT8 nOperatorId[6] = { 0 };
            if(0 != cfwEvent.nType)
            {
#ifdef AT_DUAL_SIM
                CFW_NwSetRegistration(nOperatorId, 0, cfwEvent.nUTI, nSim);
#else
                CFW_NwSetRegistration(nOperatorId, 0, cfwEvent.nUTI);
#endif
                g_COPS_Mode = gATCurrentCOPS_Mode_Temp = 0;

                return;
            }

        }

        // caow end
        // caow add
        // AT_TC(g_sw_NW, "caowei333----------------g_COPS_Mode_Temp==%d\r\n--------------caowei",g_COPS_Mode_Temp);
        // caow end
        if ((g_COPS_Set_Flag[nSim] == TRUE) && (0 == cfwEvent.nType))
        {
            g_COPS_Set_Flag[nSim] = FALSE;
            g_COPS_Mode           = gATCurrentCOPS_Mode_Temp;

#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, cfwEvent.nUTI);
#endif
            return;
        }

        // AT_20071029_CAOW_B
        g_COPS_Set_Flag[nSim] = FALSE;  // added by yangtt at 2008-05-05 for bug 8144

        if (0 == cfwEvent.nType)
        {
            // g_COPS_Mode = g_COPS_Mode_Temp;
            g_COPS_Mode = gATCurrentCOPS_Mode_Temp;

#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, NULL, 0, cfwEvent.nUTI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, NULL, 0, cfwEvent.nUTI);
#endif
            return;
        }
        else
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(pEvent->nParam1 - ERR_CME_PHONE_FAILURE, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
            AT_NW_Result_Err(pEvent->nParam1 - ERR_CME_PHONE_FAILURE, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
            return;
        }

        // AT_20071029_CAOW_E
        break;

    case EV_CFW_NW_GET_AVAIL_OPERATOR_RSP:

        // ---------------------------------------------------------
        // COPS Event
        // ---------------------------------------------------------
    {
        CFW_NW_OPERATOR_INFO *pOperInfo = NULL;

        UINT32 nRet;
        UINT8 outstr[400] = { 0 ,};
        UINT8 outemp[200]  = { 0 ,};
        UINT8 *pOperName  = NULL;
        UINT8 i;

        if (0 == cfwEvent.nType)
        {
            pOperInfo = (CFW_NW_OPERATOR_INFO *)(cfwEvent.nParam1);
            SUL_ZeroMemory8(outstr, 400);
            SUL_StrCat(outstr, "+COPS: ");

            for (i = 0; i < cfwEvent.nParam2; i++)
            {
                if (i > 0)
                {
                    SUL_StrCat(outstr, ",");
                }

                nRet = CFW_CfgNwGetOperatorName(pOperInfo[i].nOperatorId, &pOperName);  /* required format is long format, so get name */

                if (nRet != ERR_SUCCESS)
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
                    return;
                }

                SUL_ZeroMemory8(outemp, 200);

                SUL_StrPrint(outemp, "(%d,\"%s\",\"%s\",\"%d%d%d%d%d\")", pOperInfo[i].nStatus, pOperName, pOperName,
                             pOperInfo[i].nOperatorId[0], pOperInfo[i].nOperatorId[1], pOperInfo[i].nOperatorId[2],
                             pOperInfo[i].nOperatorId[3], pOperInfo[i].nOperatorId[4]);
                SUL_StrCat(outstr, outemp);
            }

#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, outstr, AT_StrLen(outstr), cfwEvent.nUTI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, outstr, AT_StrLen(outstr), cfwEvent.nUTI);
#endif

            return;
        }
        else
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(pEvent->nParam1 - ERR_CME_PHONE_FAILURE, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI, nSim);
#else
            AT_NW_Result_Err(pEvent->nParam1 - ERR_CME_PHONE_FAILURE, CMD_ERROR_CODE_TYPE_CME, cfwEvent.nUTI);
#endif
            return;
        }

    }

    break;

    case EV_CFW_SIM_GET_PREF_OPT_LIST_MAXNUM_RSP:
        // for +cpol=?  get the max num of preferred operators
        NW_AsyncEventProcess_GetPreferredOperatorMaxNum(cfwEvent);
        break;

    case EV_CFW_SIM_GET_PREF_OPERATOR_LIST_RSP:
        // for +cpol?  get the preferred operators
        NW_AsyncEventProcess_GetPreferredOperators(cfwEvent);
        break;

    case EV_CFW_SIM_SET_PREF_OPERATOR_LIST_RSP:
        // for +cpol,  add or delete the preferred operator
        NW_AsyncEventProcess_SetPreferredOperators(cfwEvent);
        break;
    case EV_CFW_TSM_INFO_IND:

        // for +cpol,  add or delete the preferred operator
        //#ifdef AT_USER_DBS
        NW_AsyncEventProcess_GetCellInfo(cfwEvent);
        //#endif
        break;
    case EV_CFW_SET_COMM_RSP:
        NW_AsyncEventProcess_SetCom(cfwEvent);
        break;
    case EV_CFW_NW_STORELIST_IND:
    {
        UINT8 uOutStr[60 + 4 * 33] = {0};
        SUL_ZeroMemory8(uOutStr, 60 + 4 * 33);
        CFW_StoredPlmnList *a  = (CFW_StoredPlmnList *)(cfwEvent.nParam1);
        SUL_StrPrint(uOutStr, "+PLMNLIST: %02x%02x%02x, nCount: %d ", (((a->Plmn[0]) << 4) | ((a->Plmn[0]) >> 4)) & 0xff, (((a->Plmn[1]) << 4) | ((a->Plmn[1]) >> 4)) & 0xff, (((a->Plmn[2]) << 4) | ((a->Plmn[2]) >> 4)) & 0xff, a->nCount);

        UINT8 i = 0x00;
        for(; i < a->nCount; i++)
        {
            UINT8 p[6] = {0x00,};
            SUL_StrPrint(p, "0x%x ", a->ArfcnL[i]);
            SUL_StrCat((TCHAR *)uOutStr, (CONST TCHAR *)p);
        }

#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, uOutStr, AT_StrLen(uOutStr), cfwEvent.nUTI, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, uOutStr, AT_StrLen(uOutStr), cfwEvent.nUTI);
#endif
        break;
    }
    case EV_CFW_NW_NETWORKINFO_IND:
    {
        CFW_NW_NETWORK_INFO *p = cfwEvent.nParam1;

        if(p)
        {
            AT_TC(g_sw_AT_NW, "Get EV_CFW_NW_NETWORKINFO_IND \r\n");
            AT_TC_MEMBLOCK(g_sw_AT_NW, p, sizeof(CFW_NW_NETWORK_INFO), 16);

            // "yy/mm/dd,hh:mm:ss(+/-)tz"
            // tz is in number of quarter-hours
            UINT8 W[200] = {0x00,};
            SUL_StrPrint(W, "+CTZV:%x/%x/%x,%x:%x:%x,%x",
                         p->nUniversalTimeZone[0], p->nUniversalTimeZone[1], p->nUniversalTimeZone[2], p->nUniversalTimeZone[3],
                         p->nUniversalTimeZone[4], p->nUniversalTimeZone[5], p->nUniversalTimeZone[6]);
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, W, AT_StrLen(W), cfwEvent.nUTI, nSim);
#else
            AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, W, AT_StrLen(W), cfwEvent.nUTI);
#endif
        }

        break;
    }
    default:
        break;
    }

#endif
    return;
}

VOID NW_SetOperFormatTemp(UINT8 nFormat)
{
    // g_OperFormat = nFormat;
    gATCurrentOperFormat = nFormat;
    return;
}

VOID NW_GetOperFormatTemp(UINT8 *nFormat)
{
    // *nFormat = g_OperFormat;
    COS_Sleep(100);
    *nFormat = gATCurrentOperFormat;
    AT_TC(g_sw_AT_NW, "NW_GetOperFormatTemp %d\r\n", gATCurrentOperFormat);

    return;
}

UINT32 _ClearCommandPatch4Cops(CFW_SIM_ID nSimID)
{
    AT_TC(g_sw_AT_NW, "_ClearCommandPatch4Cops g_COPS_Set_Flag[%d] %d\r\n", nSimID, g_COPS_Set_Flag[nSimID]);

    if(TRUE == g_COPS_Set_Flag[nSimID])
    {
        g_COPS_Set_Flag[nSimID] = FALSE;
    }

    return ERR_SUCCESS;
}

UINT32 CFW_GetSimSPN(CFW_SIM_ID nSimID, CFW_SPN_INFO *pSPNInfo);
BOOL g_simopen_flag = TRUE;

VOID AT_NW_CmdFunc_COPS(AT_CMD_PARA *pParam)
{
    UINT8 *upPos;
    UINT8 uOutputStr[64] = { 0 };
    UINT8 uOutStr[12]    = { 0 };
    UINT8 uOperId[6]     = { 0 };
    UINT8 nFM = 0;

    // AT_20071128_CAOW_B
    UINT8 *pOperId = NULL;

    // AT_20071128_CAOW_E
    UINT8 nOperatorId[6] = { 0 };
    UINT8 nMode          = 0;
    UINT8 uParaCount     = 0;
    UINT8 uStrLen        = 0;
    UINT32 nRet          = CMD_ERROR_CODE_OK;
    UINT32 eParamOk;
    UINT8 nFormat = 2;
    UINT8 nCnt    = 0; // added by yangtt at 2008-05-05 for bug 8227

    // AT_20071031_CAOW_B
    CFW_NW_STATUS_INFO nStatusInfo;

    // AT_20071031_CAOW_E

    CFW_CC_CURRENT_CALL_INFO CallInfo[7]; // added by yangtt at 2008-05-05 for bug 8227

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

#ifdef AT_DUAL_SIM

    nRet = CFW_CcGetCurrentCall(CallInfo, &nCnt, nSim); // added by yangtt at 2008-05-05 for bug 8227
#else
    nRet = CFW_CcGetCurrentCall(CallInfo, &nCnt); // added by yangtt at 2008-05-05 for bug 8227

#endif

    if (g_COPS_Set_Flag[nSim] == TRUE)  // added by yangtt at 2008-05-05 for bug 8144
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

        return;
    }

    #if defined(__AT_MOD_GC__)
    if (g_cfg_cfun[nSim]  == 6)  // added by yangtt at 2008-05-05 for bug 8411
    {
    #ifdef AT_DUAL_SIM
	AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
    #else
	AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
    #endif
	return;
    }
    #else /*!__AT_MOD_GC__*/
    #endif /*__AT_MOD_GC__*/



    // check [in] param
    if (pParam == NULL)
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }
    AT_TC(g_sw_AT_NW, "AT+COPS: pParam->iType %d\n\r", pParam->iType);

    switch (pParam->iType)
    {

    case AT_CMD_SET:

        if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        /* check para count */
        if ((1 > uParaCount) || (3 < uParaCount))
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        /* has at least 1 param, first get mode */
        upPos = pParam->pPara;

        uStrLen = 1;

        eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &nMode, &uStrLen);

        if (eParamOk != ERR_SUCCESS)  /* get mode failed */
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        /* get mode successful */
        if (nMode > 4)  /* veritify mode */
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // added by yangtt at 05-16 for bug 8227  begin
        if (nMode == 4)
        {

#ifdef AT_DUAL_SIM

            if (ERR_SUCCESS != CFW_NwGetStatus(&nStatusInfo, nSim))
#else
            if (ERR_SUCCESS != CFW_NwGetStatus(&nStatusInfo))

#endif
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            } // nStatusInfo.nStatus == CFW_NW_STATUS_NOTREGISTERED_NOTSEARCHING || //deleted by yangtt at 05-23 for bug 8541
            else if (nStatusInfo.nStatus == CFW_NW_STATUS_NOTREGISTERED_SEARCHING ||
                     nStatusInfo.nStatus == CFW_NW_STATUS_REGISTRATION_DENIED || nStatusInfo.nStatus == CFW_NW_STATUS_UNKNOW)
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
        }

        // added by yangtt at 05-16 for bug 8227  end

        // AT_20071217_CAOW_B for bug#7214
        if ((nMode == 0) && (uParaCount == 3))
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // AT_20071217_CAOW_E

        if (nMode == 2) /* deregister from network */
        {
            if(g_simopen_flag != FALSE)
            {
#ifdef AT_DUAL_SIM
                CFW_SimClose(pParam->nDLCI, nSim);
#else
                CFW_SimClose(pParam->nDLCI);
#endif
            }
            g_simopen_flag = FALSE;
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
            return;
#if 0
            if (uParaCount > 1)
            {
                uStrLen  = 1;
                eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &nFormat, &uStrLen);

                if (eParamOk != ERR_SUCCESS)  /* failed or format out of range */
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }

                if ((0 != nFormat) || (2 != nFormat))
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }

#if 0
                if (ERR_SUCCESS != (nRet = CFW_CfgSetNwOperDispFormat(nFormat)))  /* save format here */
                {
                    AT_TC(g_sw_AT_NW, "AT+COPS:   \n\r");
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                    return;
                }

#endif
                NW_SetOperFormatTemp(nFormat);
            }

            // UINT8 nUTI = 0;
            // AT_GetFreeUTI(CFW_NW_SRV_ID, &nUTI);

#ifdef AT_DUAL_SIM
            nRet = CFW_NwDeRegister(pParam->nDLCI, nSim);
#else
            nRet = CFW_NwDeRegister(pParam->nDLCI);

#endif

            AT_TC(g_sw_AT_NW, "AT+COPS:   nRet = 0X%x\n\r", nRet);

            if (ERR_SUCCESS != nRet)
            {
                if (ERR_MENU_ALLOC_MEMORY == nRet)
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
                else
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
            }

#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif

            return;
#endif
        }
        else if (nMode == 3)  /* set format only */
        {

            if (uParaCount > 1)
            {
                // AT_20071120_CAOW_B for bug#7058
                if (uParaCount != 2)
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }

                // AT_20071120_CAOW_E

                uStrLen = 1;

                eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &nFormat, &uStrLen);

                if (eParamOk != ERR_SUCCESS)  /* failed or format out of range */
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }

                AT_TC(g_sw_AT_NW, "AT+COPS:   nFormat = %d\n\r", nFormat);

                if ((0 != nFormat) && (1 != nFormat) && (2 != nFormat))
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
                else
                {
#if 0
                    uok = CFW_CfgSetNwOperDispFormat(nFormat);
                    AT_TC(g_sw_AT_NW, "AT+COPS:   uok = 0X%x\n\r", uok);

                    if (uok != ERR_SUCCESS) /* save format here */
                    {
                        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                        return;
                    }
                    else
                    {
                        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
                        return;
                    }

#endif
                    NW_SetOperFormatTemp(nFormat);
                    AT_TC(g_sw_AT_NW, "AT+COPS:   should be ok\n\r");

#ifdef AT_DUAL_SIM
                    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif

                    return;
                }
            }
            else
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
        }
        else  /* register to a network */
        {

            if(g_simopen_flag != TRUE)
            {
#ifdef AT_DUAL_SIM
                CFW_SetCommSIMOpen(nSim);
#else
                CFW_SetCommSIMOpen();
#endif
                g_simopen_creg_flag = TRUE;
                g_simopen_flag = TRUE;
            }
            if(nMode == 0)
            {
                if (ERR_SUCCESS != CFW_GetComm((CFW_COMM_MODE *)&nFM, nSim))
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
#if 0
                if (CFW_ENABLE_COMM == nFM)
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
                    return;
                }
#endif
                if(ERR_SUCCESS == CFW_SetComm(CFW_ENABLE_COMM, 0, pParam->nDLCI, nSim))
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
                    return;
                }
                else
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
            }
            if (((1 == nMode) || (4 == nMode)) && (uParaCount != 3))
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }

            if (uParaCount > 1) /* has at least 2 param, get format param */
            {
                uStrLen  = 1;
                eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &nFormat, &uStrLen);

                if (eParamOk != ERR_SUCCESS)  /* failed or format out of range */
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }

                AT_TC(g_sw_AT_NW, "AT+COPS:   nFormat = %d uParaCount %d\n\r", nFormat, uParaCount);

                if ((0 != nFormat) && (2 != nFormat))

                    // if ((0 != nFormat) && (1 != nFormat)&& (2 != nFormat))
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }

#if 0
                nRet = CFW_CfgSetNwOperDispFormat(nFormat);

                AT_TC(g_sw_AT_NW, "AT+COPS:   nRet = 0X%x\n\r", nRet);

                if (ERR_SUCCESS != nRet)  /* save format here */
                {
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                    return;
                }

#endif

                // AT_20071121_CAOW_B shield for bug#7056
#if 0
                NW_SetOperFormatTemp(nFormat);

#endif
                // AT_20071121_CAOW_E

                /* get format success */
                if (uParaCount == 3)  /* if have 3 params, get the operator */
                {
                    if (nFormat == 2) /* numberic format,but need to change to hex mode when send operid to stack */
                    {
                        uStrLen  = 8;
                        eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_STRING, nOperatorId, &uStrLen);

                        if (eParamOk != ERR_SUCCESS)  /* failed to get numberic id */
                        {
#ifdef AT_DUAL_SIM
                            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                            return;
                        }
                        else  /* change string mode operid to hex mode */
                        {

                            // AT_20071121_CAOW_B add for bug#7056
#if 1
                            NW_SetOperFormatTemp(nFormat);
#endif
                            // AT_20071121_CAOW_E

                            UINT8 i;

                            for (i = 0; i < uStrLen; i++)
                            {
                                nOperatorId[i] -= '0';
                            }

                            if (uStrLen == 5)
                                nOperatorId[i] = 0x0f;
                        }
                    }
                    else if (nFormat == 0)  /* long format */
                    {
                        uStrLen = 64;

                        SUL_ZeroMemory8(uOutputStr, uStrLen);
                        eParamOk = AT_Util_GetParaWithRule(upPos, 2, AT_UTIL_PARA_TYPE_STRING, (UINT32 *)uOutputStr, &uStrLen);

                        if (eParamOk != ERR_SUCCESS)  /* failed to get numberic id */
                        {
#ifdef AT_DUAL_SIM
                            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                            return;
                        }
                        else
                        {
                            AT_TC(g_sw_AT_NW, "AT+COPS:   pOutputStr = %s\n\r", uOutputStr);

                            // AT_20071128_CAOW_B
#if 0
                            SUL_ZeroMemory8(uOperId, 6);
                            eParamOk = CFW_CfgNwGetOperatorId(&uOperId, uOutputStr);
#else
                            pOperId = uOperId;

                            SUL_ZeroMemory8(uOperId, 6);

                            eParamOk = CFW_CfgNwGetOperatorId(&pOperId, uOutputStr);
#endif
                            // AT_20071128_CAOW_E
                            AT_TC(g_sw_AT_NW, "AT+COPS:   eParamOk = 0x%x, OperId = %x %x %x %x %x %x\n\r", eParamOk, uOperId[0],
                                  uOperId[1], uOperId[2], uOperId[3], uOperId[4], uOperId[5]);

                            if (eParamOk != ERR_SUCCESS)  /* failed to get numberic id */
                            {
#ifdef AT_DUAL_SIM
                                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                                return;
                            }
                            else
                            {

                                // AT_20071121_CAOW_B add for bug#7056
#if 1
                                NW_SetOperFormatTemp(nFormat);
#endif
                                // AT_20071121_CAOW_E
                                // AT_20071128_CAOW_B
#if 0
                                SUL_MemCopy8(nOperatorId, uOperId, 6);
#else
                                SUL_MemCopy8(nOperatorId, pOperId, 6);
#endif
                                // AT_20071128_CAOW_E
                            }
                        }
                    }
                }

                // AT_20071205_CAOW_B for bug#7149
                else if ((uParaCount == 2) && (nMode == 0))
                {
#if 1
                    NW_SetOperFormatTemp(nFormat);
#endif
                    SUL_ZeroMemory8(nOperatorId, 8);
                }

                // AT_20071205_CAOW_E
            }
            else
            {
                SUL_ZeroMemory8(nOperatorId, 6);
            }

            AT_TC(g_sw_AT_NW, "AT+COPS:   eParamOk = 0x%x, OperId = %x %x %x %x %x %x\n\r", eParamOk, nOperatorId[0],
                  nOperatorId[1], nOperatorId[2], nOperatorId[3], nOperatorId[4], nOperatorId[5]);

            /* get all params successful, call FW function */

            // AT_20071122_CAOW_B
            /*
               nRet = AT_GetFreeUTI(CFW_NW_SRV_ID,&nUTI);
               if(nRet != ERR_SUCCESS)
               {
               AT_NW_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
               return;
               }
             */
            // AT_20071122_CAOW_E

            // caow add for test bug#7048


#if 0
            nRet = ERR_SUCCESS;
#else
#ifdef AT_DUAL_SIM

            nRet = CFW_NwSetRegistration(nOperatorId, nMode, pParam->nDLCI, nSim);
#else
            nRet = CFW_NwSetRegistration(nOperatorId, nMode, pParam->nDLCI);

#endif
            AT_TC(g_sw_AT_NW, "AT+COPS:   nRet = 0X%x\n\r", nRet);
#endif
            // caow end

            if (ERR_SUCCESS == nRet)
            {
                g_COPS_Mode = gATCurrentCOPS_Mode_Temp = nMode;

                AT_TC(g_sw_AT_NW, "CFW_NwSetRegistration nMode==%d\r\n", nMode);


                if (Speeching == TRUE)  // added by yangtt at 2008-05-05 for bug 8227
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }

                g_COPS_Set_Flag[nSim] = TRUE; // added by yangtt at 2008-05-05 for bug 8144

#if 0
                AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);  // by wulc
#else
#ifdef AT_DUAL_SIM
                AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 180, NULL, 0, pParam->nDLCI, nSim);
#else
                AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 180, NULL, 0, pParam->nDLCI);
#endif
#endif
                // caow end
                return;
            }
            else
            {
                if (ERR_CFW_INVALID_PARAMETER == nRet)
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
                else if (ERR_MENU_ALLOC_MEMORY == nRet)
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
                else
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
            }
        }

        break;

    case AT_CMD_TEST:  /* deal with the test command */

        if (Speeching == TRUE)  // added by yangtt at 2008-05-05 for bug 8227
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // AT_20071031_CAOW_B
#if 1
#ifdef AT_DUAL_SIM

        if (ERR_SUCCESS != CFW_NwGetStatus(&nStatusInfo, nSim))
#else
        if (ERR_SUCCESS != CFW_NwGetStatus(&nStatusInfo))

#endif
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }
#if 0
        else if (nStatusInfo.nStatus == CFW_NW_STATUS_NOTREGISTERED_NOTSEARCHING ||
                 nStatusInfo.nStatus == CFW_NW_STATUS_NOTREGISTERED_SEARCHING )//||
            //             nStatusInfo.nStatus == CFW_NW_STATUS_REGISTRATION_DENIED || nStatusInfo.nStatus == CFW_NW_STATUS_UNKNOW)
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }
#endif
#endif
        // AT_20071031_CAOW_E

        // AT_20071119_CAOW_B
        /*
           nRet = AT_GetFreeUTI(CFW_NW_SRV_ID,&nUTI);
           if(nRet != ERR_SUCCESS)
           {
           AT_NW_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
           return;
           }
         */
        // AT_20071119_CAOW_E
#ifdef AT_DUAL_SIM

        nRet = CFW_NwGetAvailableOperators(pParam->nDLCI, nSim);
#else
        nRet = CFW_NwGetAvailableOperators(pParam->nDLCI);

#endif

        AT_TC(g_sw_AT_NW, "AT+COPS:   nRet = 0x%x\n\r", nRet);

        if (ERR_SUCCESS == nRet)
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 90, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 90, NULL, 0, pParam->nDLCI);
#endif
            return;
        }
        else
        {
            if (ERR_MENU_ALLOC_MEMORY == nRet)
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
            else
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
        }

        break;

    case AT_CMD_READ:
    {

#ifdef AT_DUAL_SIM
        if (ERR_SUCCESS != CFW_NwGetStatus(&nStatusInfo, nSim))
#else
        if (ERR_SUCCESS != CFW_NwGetStatus(&nStatusInfo))

#endif
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }
        else if (nStatusInfo.nStatus == CFW_NW_STATUS_NOTREGISTERED_NOTSEARCHING ||
                 nStatusInfo.nStatus == CFW_NW_STATUS_NOTREGISTERED_SEARCHING ||
                 nStatusInfo.nStatus == CFW_NW_STATUS_REGISTRATION_DENIED || nStatusInfo.nStatus == CFW_NW_STATUS_UNKNOW)
        {
            SUL_ZeroMemory8(uOutStr, 12);

            SUL_StrPrint(uOutStr, (UINT8 *)"+COPS: %d", g_COPS_Mode);
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutStr, AT_StrLen(uOutStr), pParam->nDLCI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutStr, AT_StrLen(uOutStr), pParam->nDLCI);
#endif

            return;
        }
#ifdef AT_DUAL_SIM

        nRet = CFW_NwGetCurrentOperator(nOperatorId, &nMode, nSim); // added by yangtt at 2008-05-12 for bug 8282
#else
        nRet = CFW_NwGetCurrentOperator(nOperatorId, &nMode); // added by yangtt at 2008-05-12 for bug 8282

#endif

        if (ERR_SUCCESS != nRet)
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

            return;
        }

        // nMode = gAtCurrentSetting.g_COPS_Mode_Temp; // added by yangtt at 05-16 for bug 8250

        /* make up string of current operator */
        UINT8 *pOperName = NULL;

        NW_GetOperFormatTemp(&nFormat);

        if (0 == nFormat)
        {

            //CFW_NW_STATUS_INFO nStatusInfo;
            CFW_SPN_INFO SPNInfo;

            //UINT32 nRet;

            SUL_ZeroMemory8(&SPNInfo, SIZEOF(CFW_SPN_INFO));
            SUL_ZeroMemory8(&nStatusInfo, SIZEOF(CFW_NW_STATUS_INFO));

#ifdef AT_DUAL_SIM
            nRet = CFW_NwGetStatus(&nStatusInfo, nSim);
#else
            nRet = CFW_NwGetStatus(&nStatusInfo);
#endif
            if (ERR_SUCCESS != nRet)
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return ;
            }
            if (nStatusInfo.nStatus == CFW_NW_STATUS_REGISTERED_HOME)
            {
                CFW_GetSimSPN(nSim, &SPNInfo);
            }

            AT_TC(g_sw_AT_NW, "COPS: nSPNameLen %d nSPNDisplayFlag %d\n\r", SPNInfo.nSPNameLen, SPNInfo.nSPNDisplayFlag);

            if(SPNInfo.nSPNameLen && SPNInfo.nSPNDisplayFlag)
            {
                pOperName = SPNInfo.nSpnName;
                AT_TC(g_sw_AT_NW, "COPS: SPN name  %s\n\r", pOperName);
            }
            else
            {
                nRet = CFW_CfgNwGetOperatorName(nOperatorId, &pOperName); /* required format is long format, so get name */
                AT_TC(g_sw_AT_NW, "COPS: Table name  %s\n\r", pOperName);
            }

            AT_TC(g_sw_AT_NW, "AT+COPS:   CFW_CfgNwGetOperatorName   nRet = 0X%x\n\r", nRet);

            if (nRet != ERR_SUCCESS)
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
        }

        SUL_ZeroMemory8(uOutputStr, 40);

        AT_TC(g_sw_AT_NW, "COPS nFormat %d", nFormat);

        if (nFormat == 2) /* numberic format */
        {
            if (0x0f == nOperatorId[5])
            {
                SUL_StrPrint(uOutputStr, (UINT8 *)"+COPS: %d,%d,\"%d%d%d%d%d\"", nMode, nFormat,
                             nOperatorId[0], nOperatorId[1], nOperatorId[2], nOperatorId[3], nOperatorId[4]);
            }
            else
            {
                SUL_StrPrint(uOutputStr, (UINT8 *)"+COPS: %d,%d,\"%d%d%d%d%d%d\"", nMode, nFormat,
                             nOperatorId[0], nOperatorId[1], nOperatorId[2], nOperatorId[3], nOperatorId[4], nOperatorId[5]);
            }
        }
        else  /* long or short format */
        {
            SUL_StrPrint(uOutputStr, (UINT8 *)"+COPS: %d,%d,\"%s\"", nMode, nFormat, pOperName);
        }

#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutputStr, AT_StrLen(uOutputStr), pParam->nDLCI, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutputStr, AT_StrLen(uOutputStr), pParam->nDLCI);
#endif

        return;
        break;
    }

    default:
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
        break;
    }

    return;
}

VOID AT_NW_CmdFunc_CSQ(AT_CMD_PARA *pParam)
{
    UINT8 nSignalLevel    = 0;
    UINT8 nBitError       = 0;
    UINT32 nRet           = 0;
    UINT8 nBuf[20]        = { 0 };
    UINT8 uHelpString[40] = { 0 };

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

    // Check [in] Param

    if (pParam == NULL)
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }
    else
    {
        switch (pParam->iType)
        {

        case AT_CMD_EXE:

            if (pParam->pPara == NULL)
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
            else
            {

#ifdef AT_DUAL_SIM
                nRet = CFW_NwGetSignalQuality(&nSignalLevel, &nBitError, nSim);
#else
                nRet = CFW_NwGetSignalQuality(&nSignalLevel, &nBitError);

#endif
                AT_TC(g_sw_AT_NW, "AT+CSQ:   nRet = 0x%x\n\r", nRet);
                AT_TC(g_sw_AT_NW, "AT+CSQ:   nSignalLevel = %d,nBitError = %d\n\r", nSignalLevel, nBitError);

                if (ERR_SUCCESS == nRet)
                {
                    UINT8 nSL[3] = { 0 };
                    UINT8 nBE[5] = { 0 };

                    SUL_ZeroMemory8(nBuf, 20);
                    SUL_StrPrint(nSL, (PCSTR)"%d", nSignalLevel);
                    SUL_StrPrint(nBE, (PCSTR)"%d", nBitError);
                    SUL_StrCopy(nBuf, "+CSQ: ");
                    SUL_StrCat(nBuf, nSL);
                    SUL_StrCat(nBuf, ",");
                    SUL_StrCat(nBuf, nBE);

#ifdef AT_DUAL_SIM
                    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, nBuf, AT_StrLen(nBuf), pParam->nDLCI, nSim);
#else
                    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, nBuf, AT_StrLen(nBuf), pParam->nDLCI);
#endif

                    return;
                }
                else
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
            }

            break;

        case AT_CMD_TEST:
            AT_StrCpy(uHelpString, "+CSQ: (0-31,99),(0-7,99)");
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uHelpString, AT_StrLen(uHelpString), pParam->nDLCI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uHelpString, AT_StrLen(uHelpString), pParam->nDLCI);
#endif

            break;

        default:
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
            break;
        }
    }

    return;
}

VOID AT_NW_CmdFunc_ECSQ(AT_CMD_PARA *pParam)
{

    UINT8 iResult     = 0;
    UINT8 uParamCount = 0;
    UINT8 uSize       = 0;
    UINT8 uState      = 0;
    UINT8 AtRet[20]   = { 0X00, };

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

    if (AT_CMD_SET == pParam->iType)
    {
        if (NULL == pParam->pPara)
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);
        if ((iResult != ERR_SUCCESS) || (uParamCount != 1))
        {
            AT_TC(g_sw_AT_NW, "exe       in AT_NW_CmdFunc_ECSQ, parameters error or no parameters offered \n");
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // get <state>
        uSize = 1;

        iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uState, &uSize);

        if ((iResult != ERR_SUCCESS) || ((uState != 1) && (uState != 0)))
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }
        else
        {
            AT_TC(g_sw_AT_NW, "AT+ECSQ:   uState = 0x%x\n\r", uState);

            if (uState == 1)
            {
                g_uATNWECSQFlag = 1;
            }
            else
            {
                g_uATNWECSQFlag = 0;
            }
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
            return;
        }
    }
    else if (AT_CMD_READ == pParam->iType)
    {
        if (g_uATNWECSQFlag == 1)
        {
            AT_Sprintf(AtRet, "+ECSQ: 1");
        }
        else if (g_uATNWECSQFlag == 0)
        {
            AT_Sprintf(AtRet, "+ECSQ: 0");
        }
        else
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }
#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI);
#endif
        return;
    }
    else if (AT_CMD_TEST == pParam->iType)
    {
        AT_Sprintf(AtRet, "+ECSQ: (0,1)");
#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI);
#endif
        return;
    }
    else
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }
    return;

}

VOID AT_NW_CmdFunc_COPN(AT_CMD_PARA *pParam)
{
    UINT8 uParaCount;

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

    // check [in] param

    if (pParam == NULL)
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    switch (pParam->iType)
    {

    case AT_CMD_EXE:

        if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount)))
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }
        else
        {
            if (uParaCount)
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
            else
            {
                UINT8 *pOperatorId;
                UINT8 *pOperatorName;
                UINT8 pOutputStr[COPN_INFO_LEN] = { 0 };

                UINT32 uOk = ERR_SUCCESS;

                uOk = CFW_CfgNwGetOperatorInfo(&pOperatorId, &pOperatorName, g_COPN_Index);
                AT_TC(g_sw_AT_NW, "+COPN CFW_CfgNwGetOperatorInfo    RET = %d", uOk);

                while (uOk == ERR_SUCCESS)
                {
                    /* init memory */
                    SUL_ZeroMemory8(pOutputStr, COPN_INFO_LEN);

                    /* here to make up the string */

                    if (*(pOperatorId + 5) == 0x0f) /* end with f, f won't be printed,print lenth is 5 */
                    {
                        SUL_StrPrint(pOutputStr, (UINT8 *)"+COPN: \"%d%d%d%d%d\",\"%s\"",
                                     *(pOperatorId), *(pOperatorId + 1), *(pOperatorId + 2), *(pOperatorId + 3),
                                     *(pOperatorId + 4), pOperatorName);
                    }
                    else
                    {
                        SUL_StrPrint(pOutputStr, (UINT8 *)"+COPN: \"%d%d%d%d%d%d\",\"%s\"",
                                     *(pOperatorId), *(pOperatorId + 1), *(pOperatorId + 2), *(pOperatorId + 3),
                                     *(pOperatorId + 4), *(pOperatorId + 5), pOperatorName);

                    }

                    g_COPN_Index++;
#ifdef AT_DUAL_SIM
                    AT_NW_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pOutputStr, AT_StrLen(pOutputStr), pParam->nDLCI, nSim);
#else
                    AT_NW_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pOutputStr, AT_StrLen(pOutputStr), pParam->nDLCI);
#endif
                    uOk = CFW_CfgNwGetOperatorInfo(&pOperatorId, &pOperatorName, g_COPN_Index);
                }

                if (uOk == ERR_CFW_NOT_EXIST_OPERATOR_ID)
                {
                    g_COPN_Index = 1;
#ifdef AT_DUAL_SIM
                    AT_NW_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, NULL, 0, pParam->nDLCI, nSim);
                    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, NULL, 0, pParam->nDLCI);
                    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
                    return;
                }
                else
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
            }
        }

        break;

    case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
        return;
        break;

    default:
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
        break;
    }

    return;
}

// ===================================================================
// AT_CMD_CREG
//
// ===================================================================
// #define ERR_CFG_PARAM_OUT_RANGR 0x10001
// #define ERR_AT_CMS_OPER_NOT_ALLOWED         0x10002

VOID AT_NW_CmdFunc_CREG(AT_CMD_PARA *pParam)
{
    UINT8 uParaCount;
    UINT8 uOutputStr[20] = { 0 };
    UINT8 uOutStr[40]    = { 0 };
    UINT8 uString[20]    = { 0 };
    CFW_NW_STATUS_INFO nStatusInfo;

    UINT32 nRet;
    UINT8 n;

    // caowei add for test
    /* UINT8 i,j,k;
       i = j = k = 0;

       if(AT_CIND_NetWork(&i, &j, &k))
       {
       AT_TC(g_sw_NW, "caowei test==== i: %d, j:%d, k: %d\n\r",i,j,k);
       }
     */
    // caowei add end

    // check [in] param
#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

    if (pParam == NULL)
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }
    else
    {
        switch (pParam->iType)
        {

        case AT_CMD_SET:

            if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
            else
            {
                if (uParaCount != 1)
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
                else
                {
                    UINT8 uData;
                    UINT32 eParamOk;
                    UINT8 nLen = 1;

                    eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uData, &nLen);

                    if (eParamOk == ERR_SUCCESS)
                    {
                        //UINT32 nRet;

                        if (uData > 2)
                        {
#ifdef AT_DUAL_SIM
                            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                            return;
                        }
#ifdef AT_DUAL_SIM

                        nRet = CFW_CfgSetNwStatus(uData, nSim);
#else
                        nRet = CFW_CfgSetNwStatus(uData);

#endif

                        if (ERR_SUCCESS == nRet)
                        {
#ifdef AT_DUAL_SIM
                            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
                            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
                            return;
                        }
                        else if (ERR_CFG_PARAM_OUT_RANGR == nRet)
                        {
#ifdef AT_DUAL_SIM
                            AT_NW_Result_Err(ERR_CME_INVALID_INDEX, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                            AT_NW_Result_Err(ERR_CME_INVALID_INDEX, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                            return;
                        }
                        else
                        {
#ifdef AT_DUAL_SIM
                            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                            return;
                        }
                    }
                    else  /* failed */
                    {
#ifdef AT_DUAL_SIM
                        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                        return;
                    }
                }
            }

            break;

        case AT_CMD_TEST:
            AT_StrCpy(uOutputStr, "+CREG: (0-2)");
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutputStr, AT_StrLen(uOutputStr), pParam->nDLCI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutputStr, AT_StrLen(uOutputStr), pParam->nDLCI);
#endif

            break;

        case AT_CMD_READ:

#ifdef AT_DUAL_SIM

            nRet = CFW_CfgGetNwStatus(&n, nSim);
#else
            nRet = CFW_CfgGetNwStatus(&n);

#endif
            AT_TC(g_sw_AT_NW, "AT+CREG:   nRet = 0X%x\n\r", nRet);

            if (ERR_SUCCESS != nRet)
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
#ifdef AT_DUAL_SIM

            nRet = CFW_NwGetStatus(&nStatusInfo, nSim);
#else
            nRet = CFW_NwGetStatus(&nStatusInfo);

#endif

            AT_TC(g_sw_AT_NW, "AT+CREG:   nRet = 0x%x\n\r", nRet);

            if (ERR_SUCCESS == nRet)
            {
                SUL_ZeroMemory8(uOutStr, 40);
#ifdef CFW_MULTI_SIM
                //      if(CFW_GetEMCStatus(nSim)==1)
#else
                //      if(CFW_GetEMCStatus() == 1)
#endif
                {

                    if(nStatusInfo.nStatus == 0)
                        nStatusInfo.nStatus = 10;

                    else if(nStatusInfo.nStatus == 2)
                        nStatusInfo.nStatus = 12;

                    else if(nStatusInfo.nStatus == 3)
                        nStatusInfo.nStatus = 13;

                    else if(nStatusInfo.nStatus == 4)
                        nStatusInfo.nStatus = 14;
                }
                SUL_StrPrint(uOutStr, "+CREG: %d,%d", n, nStatusInfo.nStatus);
                AT_TC(g_sw_AT_NW, "+CREG: nStatus %d\n\r", nStatusInfo.nStatus);

                if (n == 2)
                {
                    UINT8 AreaStr[5] = { 0 };
                    UINT8 CellStr[5] = { 0 };

                    if (nStatusInfo.nAreaCode[4] < 16)
                    {
                        SUL_StrPrint(AreaStr, "000%x", nStatusInfo.nAreaCode[4]);
                    }
                    else if (nStatusInfo.nAreaCode[3] == 0)
                    {
                        SUL_StrPrint(AreaStr, "00%x", nStatusInfo.nAreaCode[4]);
                    }
                    else if (nStatusInfo.nAreaCode[3] < 16)
                    {
                        SUL_StrPrint(AreaStr, "0%x%x", nStatusInfo.nAreaCode[3], nStatusInfo.nAreaCode[4]);
                    }
                    else
                    {
                        SUL_StrPrint(AreaStr, "%x%x", nStatusInfo.nAreaCode[3], nStatusInfo.nAreaCode[4]);
                    }

                    if (nStatusInfo.nCellId[1] < 16)
                    {
                        SUL_StrPrint(CellStr, "000%x", nStatusInfo.nCellId[1]);
                    }
                    else if (nStatusInfo.nCellId[0] == 0)
                    {
                        SUL_StrPrint(CellStr, "00%x", nStatusInfo.nCellId[1]);
                    }
                    else if (nStatusInfo.nCellId[0] < 16)
                    {
                        SUL_StrPrint(CellStr, "0%x%x", nStatusInfo.nCellId[0], nStatusInfo.nCellId[1]);
                    }
                    else
                    {
                        SUL_StrPrint(CellStr, "%x%x", nStatusInfo.nCellId[0], nStatusInfo.nCellId[1]);
                    }

                    AT_StrUpr(CellStr);

                    AT_StrUpr(AreaStr);

                    SUL_StrPrint((TCHAR *)uString, (CONST TCHAR *)",\"%s\",\"%s\"", AreaStr, CellStr);
                    SUL_StrCat((TCHAR *)uOutStr, (CONST TCHAR *)uString);
                }
                else
                {
                    ; // SUL_StrCat(pOutputStr,"\r\n");
                }
#ifdef AT_DUAL_SIM
                AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutStr, AT_StrLen(uOutStr), pParam->nDLCI, nSim);
#else
                AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutStr, AT_StrLen(uOutStr), pParam->nDLCI);
#endif

            }
            else
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }

            break;

        default:
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
            break;
        }
    }
}

#ifdef AT_DUAL_SIM
BOOL AT_CIND_NetWork(UINT8 *pSignalQ, UINT8 *pRegistS, UINT8 *pRoamS, UINT8 nDLCI, UINT8 nSim)
#else
BOOL AT_CIND_NetWork(UINT8 *pSignalQ, UINT8 *pRegistS, UINT8 *pRoamS, UINT8 nDLCI)
#endif
{
    UINT8 nSignalLevel = 0;
    UINT8 nBitError    = 0;
    CFW_NW_STATUS_INFO nStatusInfo;
    UINT32 nRet;

#ifdef AT_DUAL_SIM

    nRet = CFW_NwGetStatus(&nStatusInfo, nSim);
#else
    nRet = CFW_NwGetStatus(&nStatusInfo);

#endif

    if (ERR_SUCCESS != nRet)
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, nDLCI);
#endif
        return FALSE;
    }

    if (nStatusInfo.nStatus == CFW_NW_STATUS_REGISTERED_ROAMING)
    {
        *pRoamS   = 1;
        *pRegistS = 1;
    }
    else if (nStatusInfo.nStatus == CFW_NW_STATUS_REGISTERED_HOME)
    {
        *pRoamS   = 0;
        *pRegistS = 1;
    }
    else
    {
        *pRoamS   = 0;
        *pRegistS = 0;
    }
#ifdef AT_DUAL_SIM

    nRet = CFW_NwGetSignalQuality(&nSignalLevel, &nBitError, nSim);
#else
    nRet = CFW_NwGetSignalQuality(&nSignalLevel, &nBitError);

#endif

    if (ERR_SUCCESS != nRet)
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, nDLCI);
#endif
        return FALSE;
    }

    if (nSignalLevel == 0)
        *pSignalQ = 0;
    else if (1 <= nSignalLevel && 7 > nSignalLevel)
        *pSignalQ = 1;
    else if (7 <= nSignalLevel && 13 > nSignalLevel)
        *pSignalQ = 2;
    else if (13 <= nSignalLevel && 19 > nSignalLevel)
        *pSignalQ = 3;
    else if (19 <= nSignalLevel && 25 > nSignalLevel)
        *pSignalQ = 4;
    else if (25 <= nSignalLevel && 31 >= nSignalLevel)
        *pSignalQ = 5;

    return TRUE;

}

// set and get preferred operators list
VOID AT_NW_CmdFunc_CPOL(AT_CMD_PARA *pParam)
{
    UINT8 paraCount = 0;
    UINT32 nResult  = ERR_SUCCESS;
    INT32 iRet      = 0;

    // check [in] param
#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

    if (pParam == NULL)
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    switch (pParam->iType)
    {

    case AT_CMD_SET:
        AT_TC(g_sw_AT_NW, "CPOL SET IN \n\r");
        iRet = AT_Util_GetParaCount(pParam->pPara, &paraCount);
        AT_TC(g_sw_AT_NW, "CPOL SET paraCount %d \n\r", paraCount);

        if ((iRet != ERR_SUCCESS) || (paraCount > 3))
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        if (paraCount == 0)
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
            return;
        }

        UINT8 nParamLen = 1;

        iRet =
            AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &gATCurrentnPreferredOperatorIndex,
                                    &nParamLen);

        // AT_20071226_CAOW_B for bug#7185

        if ((gATCurrentnPreferredOperatorIndex == 0) && (iRet != ERR_AT_UTIL_CMD_PARA_NULL))
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // AT_20071226_CAOW_E

        if (iRet == ERR_AT_UTIL_CMD_PARA_NULL)
        {
            gATCurrentnPreferredOperatorIndex = 0;
        }
        else if (iRet != ERR_SUCCESS)
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // delete operator
        if (paraCount == 1)
        {
            AT_MemSet(g_arrPreferredOperater, 0xff, sizeof(g_arrPreferredOperater));
            gATCurrentnGetPreferredOperatorsCaller = NW_GETPREFERREDOPERATORS_CALLER_SET;
#ifdef AT_DUAL_SIM
            NW_GetPreferredOperators(pParam->nDLCI, nSim);
#else
            NW_GetPreferredOperators(pParam->nDLCI);
#endif
            return;
        }

        UINT8 nFormat = 0;

        nParamLen = 1;
        iRet      = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &nFormat, &nParamLen);

        if (iRet != ERR_SUCCESS)
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        if (paraCount == 2)
        {
            // set format
            if (gATCurrentnPreferredOperatorIndex == 0)
            {
                if ((nFormat != NW_PREFERRED_OPERATOR_FORMAT_ALPHANUMERIC_LONG)
                        && (nFormat != NW_PREFERRED_OPERATOR_FORMAT_NUMERIC))
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }

                // g_nPreferredOperFormat = nFormat;
                gATCurrentnPreferredOperFormat = nFormat;

#ifdef AT_DUAL_SIM
                AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
                AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif

                return;

            }
            else
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }

        }

        if (nFormat != NW_PREFERRED_OPERATOR_FORMAT_NUMERIC)
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        UINT32 arrOperator[10];

        AT_MemZero(arrOperator, sizeof(arrOperator));
        nParamLen = sizeof(arrOperator);
        iRet      = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_STRING, arrOperator, &nParamLen);

        if (iRet != ERR_SUCCESS)
        {
            AT_TC(g_sw_AT_NW, "nw-AT_Util_GetParaWithRule arrOperator error---0x%x\n", iRet);
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        if ((nParamLen != 5) && (nParamLen != 6))
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        AT_MemSet(g_arrPreferredOperater, 0x0f, sizeof(g_arrPreferredOperater));

        if (!NW_OperaterStrToBytes(g_arrPreferredOperater, (UINT8 *)arrOperator))
        {
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        gATCurrentnGetPreferredOperatorsCaller = NW_GETPREFERREDOPERATORS_CALLER_SET;

#ifdef AT_DUAL_SIM
        NW_GetPreferredOperators(pParam->nDLCI, nSim);
#else
        NW_GetPreferredOperators(pParam->nDLCI);
#endif
        return;
        break;

    case AT_CMD_READ:
        AT_TC(g_sw_AT_NW, "CPOL READ IN \n\r");
        gATCurrentnGetPreferredOperatorsCaller = NW_GETPREFERREDOPERATORS_CALLER_READ;
#ifdef AT_DUAL_SIM
        NW_GetPreferredOperators(pParam->nDLCI, nSim);
#else
        NW_GetPreferredOperators(pParam->nDLCI);
#endif

        return;
        break;

    case AT_CMD_TEST:
        AT_TC(g_sw_AT_NW, "CPOL TEST IN \n\r");

#ifdef AT_DUAL_SIM
        nResult = CFW_SimGetPrefOperatorListMaxNum(pParam->nDLCI, nSim);
#else
        nResult = CFW_SimGetPrefOperatorListMaxNum(pParam->nDLCI);

#endif

        if (ERR_SUCCESS == nResult)
        {
            AT_TC(g_sw_AT_NW, "CFW_SimGetPrefOperatorListMaxNum success \n\r");
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
            return;
        }
        else
        {
            AT_TC(g_sw_AT_NW, "nw-CFW_SimGetPrefOperatorListMaxNum error\n");
            UINT32 nErrorCode = AT_SetCmeErrorCode(nResult, FALSE);

#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

            return;
        }

        break;

    default:
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
        break;
    }

    return;
}
UINT16 SUL_AsciiToGsmBcdExForNw(
    INT8 *pNumber,  // input
    UINT8 nNumberLen,
    UINT8 *pBCD  // output should >= nNumberLen/2+1
)
{
    UINT8 Tmp;
    UINT32 i;
    UINT32 nBcdSize = 0;
    UINT8 *pTmp = pBCD;

    if(pNumber == (CONST INT8 *)NULL || pBCD == (UINT8 *)NULL)
        return FALSE;

    SUL_MemSet8(pBCD, 0, nNumberLen >> 1);

    for(i = 0; i < nNumberLen; i++)
    {
        switch(*pNumber)
        {
        case 0x41:
        case 0x61:
            Tmp = (INT8)0x0A;
            break;
        case 0x42:
        case 0x62:
            Tmp = (INT8)0x0B;
            break;
        case 0x43:
        case 0x63:
            Tmp = (INT8)0x0C;
            break;
            //--------------------------------------------
            //Modify by lixp 20070626 begin
            //--------------------------------------------
        case 0x44:
        case 0x64:
            Tmp = (INT8)0x0D;
            break;
        case 0x45:
        case 0x65:
            Tmp = (INT8)0x0E;
            break;
        case 0x46:
        case 0x66:
            Tmp = (INT8)0x0F;
            break;
            //--------------------------------------------
            //Modify by lixp 20070626 end
            //--------------------------------------------
        default:
            Tmp = (INT8)(*pNumber - '0');
            break;
        }
        if(i % 2)
        {
            *pTmp++ |= (INT8)(Tmp & 0x0F);
        }
        else
        {
            *pTmp = (Tmp << 4) & 0xF0;

        }
        pNumber++;
    }

    nBcdSize = nNumberLen >> 1;

    if(i % 2)
    {
        *pTmp |= 0xF0;
        nBcdSize += 1;
    }

    return nBcdSize;
}

VOID AT_NW_CmdFunc_CBindArfcn(AT_CMD_PARA *pParam)
{
    UINT8 uParaCount;
    UINT8 uOutputStr[20] = { 0 };
    UINT8 uOutStr[40 + 4 * 33]    = { 0 };
    //UINT8 uString[20]    = { 0 };
    //CFW_NW_STATUS_INFO nStatusInfo;

    UINT32 nRet;
    //  UINT8 n;

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
    AT_TC(g_sw_AT_CC, "CBindArfcn: pParam %d", pParam);

    if (pParam == NULL)
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }
    else
    {
        switch (pParam->iType)
        {

        case AT_CMD_SET:

            if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
            {
                AT_TC(g_sw_AT_CC, "CBindArfcn: pParam->pPara %d", pParam->pPara);
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
            else
            {
                AT_TC(g_sw_AT_CC, "CBindArfcn: uParaCount %d", uParaCount);
                if (uParaCount != 1)
                {
                    AT_TC(g_sw_AT_CC, "CBindArfcn: uParaCount %d", uParaCount);
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
                else
                {
                    UINT8 uData[4 * 33] = {0x00};
                    UINT8 uOutData[4 * 33] = {0x00,};
                    UINT32 eParamOk;
                    UINT8 nLen = 4 * 33;

                    eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, uData, &nLen);

                    if (eParamOk == ERR_SUCCESS)
                    {
                        if(nLen % 4)
                        {
                            AT_TC(g_sw_AT_CC, "CBindArfcn:Error length  nLen %d uData %s", nLen, uData);
#ifdef AT_DUAL_SIM
                            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                        }

                        //UINT32 nRet = ERR_SUCCESS;

                        CFW_StoredPlmnList a;
                        memset(&a, 0x00, sizeof(CFW_StoredPlmnList));

                        AT_TC(g_sw_AT_CC, "CBindArfcn:  nLen %d uData %s", nLen, uData);

                        SUL_AsciiToGsmBcdExForNw(uData, nLen, uOutData);

                        AT_TC(g_sw_AT_CC, "CBindArfcn: uOutData %x %x", uOutData[0], uOutData[1]);

                        a.Plmn[0] = 0x64;
                        a.Plmn[1] = 0xF0;
                        a.Plmn[2] = 0x00;

                        UINT8 i = 0x00;
                        UINT8 j = 0x00;
                        for(; i < (nLen / 4); i++)
                        {
                            a.ArfcnL[i] = uOutData[j + 1]  | uOutData[j] << 8;
                            j += 2;
                            a.nCount++;
                        }
                        if(0x00 == a.ArfcnL[0])
                            a.nCount = 0;
                        nRet = CFW_CfgSetStoredPlmnList(&a, nSim);

                        if (ERR_SUCCESS == nRet)
                        {
#ifdef AT_DUAL_SIM
                            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
                            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
                            return;
                        }
                        else if (ERR_CFG_PARAM_OUT_RANGR == nRet)
                        {
#ifdef AT_DUAL_SIM
                            AT_NW_Result_Err(ERR_CME_INVALID_INDEX, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                            AT_NW_Result_Err(ERR_CME_INVALID_INDEX, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                            return;
                        }
                        else
                        {
#ifdef AT_DUAL_SIM
                            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                            return;
                        }
                    }
                    else  /* failed */
                    {
                        AT_TC(g_sw_AT_NW, "CBindArfcn: eParamOk %x", eParamOk);
#ifdef AT_DUAL_SIM
                        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                        return;
                    }
                }
            }

            break;

        case AT_CMD_TEST:
            AT_TC(g_sw_AT_NW, "CBindArfcn: uParaCount %d", uParaCount);
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutputStr, AT_StrLen(uOutputStr), pParam->nDLCI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutputStr, AT_StrLen(uOutputStr), pParam->nDLCI);
#endif

            break;

        case AT_CMD_READ:
        {
            CFW_StoredPlmnList a;
            memset(&a, 0x00, sizeof(CFW_StoredPlmnList));

            nRet = CFW_CfgGetStoredPlmnList(&a, nSim);

            AT_TC(g_sw_AT_NW, "AT+CBindArfcn:   nRet = 0X%x\n\r", nRet);

            if (ERR_SUCCESS != nRet)
            {
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
            else
            {
                SUL_ZeroMemory8(uOutStr, 40 + 4 * 33);

                SUL_StrPrint(uOutStr, "+CBindArfcn: %d ", a.nCount);

                UINT8 i = 0x00;
                for(; i < a.nCount; i++)
                {
                    UINT8 p[6] = {0x00,};
                    SUL_StrPrint(p, "0x%x ", a.ArfcnL[i]);
                    SUL_StrCat((TCHAR *)uOutStr, (CONST TCHAR *)p);
                }


                AT_TC(g_sw_AT_NW, "+CBindArfcn: a.ArfcnL %d a.nCount %d\n\r", a.ArfcnL[0], a.nCount);

#ifdef AT_DUAL_SIM
                AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutStr, AT_StrLen(uOutStr), pParam->nDLCI, nSim);
#else
                AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutStr, AT_StrLen(uOutStr), pParam->nDLCI);
#endif

            }
        }

        break;

        default:
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
            break;
        }
    }
}

// frank add start
#ifdef AT_USER_DBS
VOID AT_NW_POSI_AddData(UINT8 nflag, CFW_TSM_CURR_CELL_INFO *pCurrCellInfo, CFW_TSM_ALL_NEBCELL_INFO *pNeighborCellInfo)
{
    UINT8 i = 0;

    AT_TC(g_sw_AT_NW, "POSI_AddData nflag: %d!\n", nflag);

    if (0 == nflag)
    {
        if (!((pCurrCellInfo->nTSM_CellID[0] == 0) && (pCurrCellInfo->nTSM_CellID[1] == 0)))  // shaochuan
        {
            gPosiList.PosiList[gPosiList.iNum].sMcc[0] = pCurrCellInfo->nTSM_LAI[0] & 0x0F;
            gPosiList.PosiList[gPosiList.iNum].sMcc[1] = pCurrCellInfo->nTSM_LAI[0] >> 4;
            gPosiList.PosiList[gPosiList.iNum].sMcc[2] = pCurrCellInfo->nTSM_LAI[1] & 0x0F;

            gPosiList.PosiList[gPosiList.iNum].sMnc[2] = pCurrCellInfo->nTSM_LAI[1] >> 4;
            gPosiList.PosiList[gPosiList.iNum].sMnc[1] = pCurrCellInfo->nTSM_LAI[2] & 0x0F;
            gPosiList.PosiList[gPosiList.iNum].sMnc[0] = pCurrCellInfo->nTSM_LAI[2] >> 4;

            gPosiList.PosiList[gPosiList.iNum].sLac    = (pCurrCellInfo->nTSM_LAI[3] << 8) | (pCurrCellInfo->nTSM_LAI[4]);
            gPosiList.PosiList[gPosiList.iNum].sCellID =
                (pCurrCellInfo->nTSM_CellID[0] << 8) | (pCurrCellInfo->nTSM_CellID[1]);

            gPosiList.PosiList[gPosiList.iNum].iBsic  = pCurrCellInfo->nTSM_Bsic;
            gPosiList.PosiList[gPosiList.iNum].iRxLev = ((110 - pCurrCellInfo->nTSM_AvRxLevel) * 100) / 64;

            gPosiList.iNum++;
        }
    }
    else
    {

        for (i = 0; i < pNeighborCellInfo->nTSM_NebCellNUM; i++)
        {
            if (!((pNeighborCellInfo->nTSM_NebCell[i].nTSM_CellID[0] == 0)
                    && (pNeighborCellInfo->nTSM_NebCell[i].nTSM_CellID[1] == 0)))
            {

                gPosiList.PosiList[gPosiList.iNum].sMcc[0] = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[0] & 0x0F;
                gPosiList.PosiList[gPosiList.iNum].sMcc[1] = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[0] >> 4;
                gPosiList.PosiList[gPosiList.iNum].sMcc[2] = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[1] & 0x0F;

                gPosiList.PosiList[gPosiList.iNum].sMnc[2] = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[1] >> 4;
                gPosiList.PosiList[gPosiList.iNum].sMnc[1] = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[2] & 0x0F;
                gPosiList.PosiList[gPosiList.iNum].sMnc[0] = pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[2] >> 4;

                gPosiList.PosiList[gPosiList.iNum].sLac =
                    (pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[3] << 8) | (pNeighborCellInfo->nTSM_NebCell[i].nTSM_LAI[4]);
                gPosiList.PosiList[gPosiList.iNum].sCellID =
                    (pNeighborCellInfo->nTSM_NebCell[i].nTSM_CellID[0] << 8) | (pNeighborCellInfo->nTSM_NebCell[i].
                            nTSM_CellID[1]);

                gPosiList.PosiList[gPosiList.iNum].iBsic  = pNeighborCellInfo->nTSM_NebCell[i].nTSM_Bsic;
                gPosiList.PosiList[gPosiList.iNum].iRxLev =
                    ((110 - pNeighborCellInfo->nTSM_NebCell[i].nTSM_AvRxLevel) * 100) / 64;

                gPosiList.iNum++;
            }
        }

    }

    return;
}

#define RAND_RAM_LEN 40
typedef struct _AT_RAND_RAM
{
    UINT8 nRandRamBase[RAND_RAM_LEN];
    UINT8 nMod;
    struct AT_RAND_RAM *pBef;
    struct AT_RAND_RAM *pNext;
} AT_RAND_RAM;

AT_RAND_RAM *gRandRamBase = NULL;

BOOL AT_RandRamPush(UINT8 *pRanRam, UINT32 nRamRamLen, UINT8 nMod)
{
    AT_RAND_RAM *p = gRandRamBase;

    if (!p)
    {
        p = (AT_RAND_RAM *)AT_MALLOC(SIZEOF(AT_RAND_RAM));
        if (!p)
        {
            // FAILED
            return FALSE;
        }
        AT_MemZero(p, SIZEOF(AT_RAND_RAM));

        p->pNext = NULL;
        p->pBef  = NULL;
        p->nMod  = nMod;
        AT_MemCpy(p->nRandRamBase, pRanRam, nRamRamLen < RAND_RAM_LEN ? nRamRamLen : RAND_RAM_LEN - 1);

        gRandRamBase = p;
    }
    else
    {
        while (p->pNext)
            p = p->pNext;

        AT_RAND_RAM *q;
        q = (AT_RAND_RAM *)AT_MALLOC(SIZEOF(AT_RAND_RAM));
        if (!q)
        {
            // FAILED
            return FALSE;
        }
        AT_MemZero(q, SIZEOF(AT_RAND_RAM));

        q->pNext = NULL;
        q->pBef  = p;
        p->pNext = q;
        q->nMod  = nMod;
        AT_MemCpy(q->nRandRamBase, pRanRam, nRamRamLen < RAND_RAM_LEN ? nRamRamLen : RAND_RAM_LEN - 1);
    }
    return TRUE;
}

BOOL AT_RandRamPop(UINT8 *pRandRamData, UINT32 *pLen, UINT8 *pMod)
{

    AT_RAND_RAM *p = gRandRamBase;
    if (!p)
    {
        *pLen = 0x00;
        return NULL;
    }
    else
    {
        *pLen = AT_StrLen(p->nRandRamBase);
        *pMod = p->nMod;
        AT_MemCpy(pRandRamData, p->nRandRamBase, *pLen);

        // gRandRamBase = p->pNext;

        AT_RAND_RAM *q;
        q = p->pNext;
        if (q)
            q->pBef    = NULL;
        gRandRamBase = q;
        AT_FREE(p);

    }
}
VOID AT_DBSBubbleSort()
{
    UINT8 i        = 0;
    UINT8 j        = 0;
    UINT8 nRxLev   = 0;
    UINT8 nArr[32] = { 0x00, };

    if (gPosiList.iNum <= 1)
    {
        return;
    }

    for (i = 0; i < gPosiList.iNum - 1; i++)
    {
        for (j = gPosiList.iNum - 2; j > i; j--)
        {
            if (gPosiList.PosiList[j].iRxLev > gPosiList.PosiList[j - 1].iRxLev)
            {
                AT_MemCpy(nArr, gPosiArres.arres[j].ndsposi, 32);
                AT_MemCpy(gPosiArres.arres[j].ndsposi, gPosiArres.arres[j - 1].ndsposi, 32);
                AT_MemCpy(gPosiArres.arres[j - 1].ndsposi, nArr, 32);

                nRxLev                       = gPosiList.PosiList[j].iRxLev;
                gPosiList.PosiList[j].iRxLev = gPosiList.PosiList[j - 1].iRxLev;
                gPosiList.PosiList[j - 1].iRxLev = nRxLev;
            }
        }
    }

    return;
}

VOID AT_ProcessPosiData(UINT8 *pSigndata)
{

    INT nSeedRet        = 0;
    UINT8 nGetSeedLen   = 0;
    UINT8 nGetSeed[63]  = { 0x00, };
    UINT8 nSeedData[44] = { 0x00, };
    UINT8 nSeedBCD[40]  = { 0x00, };

    UINT8 nSignDataLen      = 50;
    UINT8 nSignData[50]     = { 0x00, };
    UINT8 nSrcSignDataLen   = 0;
    UINT8 nSrcSignData[400] = { 0x00, };
    UINT8 randNumASCII_len  = 0;
    UINT8 nRandNumBCD_len   = 0;
    UINT8 nRandNumBCD[20]   = { 0x00, };
    UINT8 nCidver[10]       = { 0x00, };

    if (gPosiList.iNum == 1)
    {
        AT_Sprintf(nSrcSignData, "+POSI:%x,%s,\"%s\"", gPosiList.iMode, gPosiArres.arres[0].ndsposi, gPosiList.sRandNum);
    }
    else if (gPosiList.iNum == 2)
    {
        AT_Sprintf(nSrcSignData, "+POSI:%x,%s,%s,\"%s\"",
                   gPosiList.iMode, gPosiArres.arres[0].ndsposi, gPosiArres.arres[1].ndsposi, gPosiList.sRandNum);
    }
    else if (gPosiList.iNum == 3)
    {
        AT_Sprintf(nSrcSignData, "+POSI:%x,%s,%s,%s,\"%s\"",
                   gPosiList.iMode, gPosiArres.arres[0].ndsposi, gPosiArres.arres[1].ndsposi, gPosiArres.arres[2].ndsposi,
                   gPosiList.sRandNum);
    }
    else if (gPosiList.iNum == 4)
    {
        AT_Sprintf(nSrcSignData, "+POSI:%x,%s,%s,%s,%s,\"%s\"",
                   gPosiList.iMode, gPosiArres.arres[0].ndsposi, gPosiArres.arres[1].ndsposi, gPosiArres.arres[2].ndsposi,
                   gPosiArres.arres[3].ndsposi, gPosiList.sRandNum);
    }
    else if (gPosiList.iNum == 5)
    {
        AT_Sprintf(nSrcSignData, "+POSI:%x,%s,%s,%s,%s,%s,\"%s\"",
                   gPosiList.iMode, gPosiArres.arres[0].ndsposi, gPosiArres.arres[1].ndsposi, gPosiArres.arres[2].ndsposi,
                   gPosiArres.arres[3].ndsposi, gPosiArres.arres[4].ndsposi, gPosiList.sRandNum);
    }
    else if (gPosiList.iNum == 6)
    {
        AT_Sprintf(nSrcSignData, "+POSI:%x,%s,%s,%s,%s,%s,%s,\"%s\"",
                   gPosiList.iMode, gPosiArres.arres[0].ndsposi, gPosiArres.arres[1].ndsposi, gPosiArres.arres[2].ndsposi,
                   gPosiArres.arres[3].ndsposi, gPosiArres.arres[4].ndsposi, gPosiArres.arres[5].ndsposi,
                   gPosiList.sRandNum);
    }
    else if (gPosiList.iNum == 7)
    {
        AT_Sprintf(nSrcSignData, "+POSI:%x,%s,%s,%s,%s,%s,%s,%s,\"%s\"",
                   gPosiList.iMode, gPosiArres.arres[0].ndsposi, gPosiArres.arres[1].ndsposi, gPosiArres.arres[2].ndsposi,
                   gPosiArres.arres[3].ndsposi, gPosiArres.arres[4].ndsposi, gPosiArres.arres[5].ndsposi,
                   gPosiArres.arres[6].ndsposi, gPosiList.sRandNum);
    }
    else if (gPosiList.iNum == 8)
    {
        AT_Sprintf(nSrcSignData, "+POSI:%x,%s,%s,%s,%s,%s,%s,%s,%s,\"%s\"",
                   gPosiList.iMode, gPosiArres.arres[0].ndsposi, gPosiArres.arres[1].ndsposi, gPosiArres.arres[2].ndsposi,
                   gPosiArres.arres[3].ndsposi, gPosiArres.arres[4].ndsposi, gPosiArres.arres[5].ndsposi,
                   gPosiArres.arres[6].ndsposi, gPosiArres.arres[7].ndsposi, gPosiList.sRandNum);
    }
    else if (gPosiList.iNum == 9)
    {
        AT_Sprintf(nSrcSignData, "+POSI:%x,%s,%s,%s,%s,%s,%s,%s,%s,%s,\"%s\"",
                   gPosiList.iMode, gPosiArres.arres[0].ndsposi, gPosiArres.arres[1].ndsposi, gPosiArres.arres[2].ndsposi,
                   gPosiArres.arres[3].ndsposi, gPosiArres.arres[4].ndsposi, gPosiArres.arres[5].ndsposi,
                   gPosiArres.arres[6].ndsposi, gPosiArres.arres[7].ndsposi, gPosiArres.arres[8].ndsposi,
                   gPosiList.sRandNum);
    }
    else
    {
        AT_Sprintf(nSrcSignData, "+POSI:%x,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\"%s\"",
                   gPosiList.iMode, gPosiArres.arres[0].ndsposi, gPosiArres.arres[1].ndsposi, gPosiArres.arres[2].ndsposi,
                   gPosiArres.arres[3].ndsposi, gPosiArres.arres[4].ndsposi, gPosiArres.arres[5].ndsposi,
                   gPosiArres.arres[6].ndsposi, gPosiArres.arres[7].ndsposi, gPosiArres.arres[8].ndsposi,
                   gPosiArres.arres[gPosiList.iNum - 1].ndsposi, gPosiList.sRandNum);
    }

    nSrcSignDataLen  = AT_StrLen(nSrcSignData);
    randNumASCII_len = AT_StrLen(gPosiList.sRandNum);
    nRandNumBCD_len  = AT_DBSAsciiToGsmBcd(gPosiList.sRandNum, randNumASCII_len, nRandNumBCD);

    CFW_GetDBSSeed(nGetSeed);
    nGetSeedLen = AT_StrLen(nGetSeed);
    AT_DBSAsciiToGsmBcd(nGetSeed, nGetSeedLen, nSeedBCD);
    {
        AT_MemCpy(nCidver, nSeedBCD, 4);
        AT_MemCpy(nSeedData, (nSeedBCD + 4), 16);
        const UINT8 *idv  = nCidver;
        const UINT8 *gidv = g_Gidver;

        nSeedRet = sarft_sign_data(nSrcSignData, nSrcSignDataLen, nRandNumBCD,
                                   nRandNumBCD_len, idv, gidv, nSeedData, nSignData, &nSignDataLen);
    }
    if (nSeedRet != 0)
    {
        // UINT8* seedstr = sarft_error_str(sarft_sign_errno);
        // AT_TC(g_sw_GPRS, "ProcessPosiData sign error: %s\n", seedstr);
    }
    else
    {
        AT_TC(g_sw_GPRS, "ProcessPosiData sign success!\n");
    }

    AT_Sprintf(pSigndata,
               "%s,\"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x\"",
               nSrcSignData, nSignData[0], nSignData[1], nSignData[2], nSignData[3], nSignData[4], nSignData[5],
               nSignData[6], nSignData[7], nSignData[8], nSignData[9], nSignData[10], nSignData[11], nSignData[12],
               nSignData[13], nSignData[14], nSignData[15], nSignData[16], nSignData[17], nSignData[18], nSignData[19],
               nSignData[20], nSignData[21], nSignData[22], nSignData[23]);

    return;
}

#ifdef AT_DUAL_SIM
VOID AT_NW_POSI_SendData(UINT8 nSim)
#else
VOID AT_NW_POSI_SendData()
#endif
{
    UINT8 i              = 0;
    UINT8 nSignData[450] = { 0x00, };

    AT_TC(g_sw_AT_NW, "SendData iNum: %d!\n", gPosiList.iNum);

    if ((gPosiList.iNum > 0) && (gPosiList.iNum < 15))
    {
        UINT32 nRandRamLen = 0x00;
        UINT8 nRandRamMode = 0x00;

        AT_MemZero(gPosiList.sRandNum, 40);
        gPosiList.iMode = 0x00;

        AT_RandRamPop(gPosiList.sRandNum, &nRandRamLen, &gPosiList.iMode);

        for (i = 0; i < gPosiList.iNum; i++)
        {

            if (1 == gPosiList.iNum)  // only one item
            {
                gPosiList.PosiList[gPosiList.iNum - 1].iEndED = 1;

                // send  start and end

                AT_Sprintf(&gPosiArres.arres[0].ndsposi, "%x%x%x,%x%x,%x,%x,%x,%x,%x",
                           gPosiList.PosiList[i].sMcc[0], gPosiList.PosiList[i].sMcc[1], gPosiList.PosiList[i].sMcc[2],
                           gPosiList.PosiList[i].sMnc[1], gPosiList.PosiList[i].sMnc[0], gPosiList.PosiList[i].sLac,
                           gPosiList.PosiList[i].sCellID, gPosiList.PosiList[i].iBsic, gPosiList.PosiList[i].iRxLev,
                           gPosiList.PosiList[i].iEndED);

            }
            else if (i + 1 == gPosiList.iNum) // last  item
            {
                gPosiList.PosiList[gPosiList.iNum - 1].iEndED = 1;

                // send  end
                AT_Sprintf(&gPosiArres.arres[i].ndsposi, "%x%x%x,%x%x,%x,%x,%x,%x,%x",
                           gPosiList.PosiList[i].sMcc[0], gPosiList.PosiList[i].sMcc[1], gPosiList.PosiList[i].sMcc[2],
                           gPosiList.PosiList[i].sMnc[1], gPosiList.PosiList[i].sMnc[0], gPosiList.PosiList[i].sLac,
                           gPosiList.PosiList[i].sCellID, gPosiList.PosiList[i].iBsic, gPosiList.PosiList[i].iRxLev,
                           gPosiList.PosiList[i].iEndED);
            }
            else if (0 == i)  // frist item
            {

                gPosiList.PosiList[gPosiList.iNum - 1].iEndED = 0;

                AT_Sprintf(&gPosiArres.arres[i].ndsposi, "%x%x%x,%x%x,%x,%x,%x,%x,%x",
                           gPosiList.PosiList[i].sMcc[0], gPosiList.PosiList[i].sMcc[1], gPosiList.PosiList[i].sMcc[2],
                           gPosiList.PosiList[i].sMnc[1], gPosiList.PosiList[i].sMnc[0], gPosiList.PosiList[i].sLac,
                           gPosiList.PosiList[i].sCellID, gPosiList.PosiList[i].iBsic, gPosiList.PosiList[i].iRxLev,
                           gPosiList.PosiList[i].iEndED);

            }
            else
            {
                gPosiList.PosiList[gPosiList.iNum - 1].iEndED = 0;

                AT_Sprintf(&gPosiArres.arres[i].ndsposi, "%x%x%x,%x%x,%x,%x,%x,%x,%x",
                           gPosiList.PosiList[i].sMcc[0], gPosiList.PosiList[i].sMcc[1], gPosiList.PosiList[i].sMcc[2],
                           gPosiList.PosiList[i].sMnc[1], gPosiList.PosiList[i].sMnc[0], gPosiList.PosiList[i].sLac,
                           gPosiList.PosiList[i].sCellID, gPosiList.PosiList[i].iBsic, gPosiList.PosiList[i].iRxLev,
                           gPosiList.PosiList[i].iEndED);

            }

        }

        // bubble sort
        AT_DBSBubbleSort();
        AT_ProcessPosiData(nSignData);
#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_SUCC_NO_CLEAR_CMD, CMD_RC_OK, 0, nSignData, AT_StrLen(nSignData), 0, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_SUCC_NO_CLEAR_CMD, CMD_RC_OK, 0, nSignData, AT_StrLen(nSignData), 0);
#endif
        AT_MemZero(&gPosiList, sizeof(gPosiList));

    }
    else if (0 == gPosiList.iNum)
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_SUCC_NO_CLEAR_CMD, CMD_RC_OK, 0, NULL, 0, 0, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_SUCC_NO_CLEAR_CMD, CMD_RC_OK, 0, NULL, 0, 0);
#endif
    }
    else if (0xff == gPosiList.iNum)
    {
        AT_TC(g_sw_AT_NW, "SendData NO cell info!\n");
    }
    else
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, 0, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, 0);
#endif
    }
    return;
}
VOID AT_NW_CmdFunc_POSI(AT_CMD_PARA *pParam)
{
    UINT8 paraCount = 0;
    UINT32 nResult  = ERR_SUCCESS;
    INT32 iRet      = 0;

    UINT8 nMode        = 0;
    UINT8 nTypSize     = 0;
    UINT8 nIndex       = 0;
    UINT8 nRandNum[40] = { 0x00, };

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

    AT_TC(g_sw_GPRS, "AT+POSI:AT_NW_CmdFunc_POSI");
    if (pParam == NULL)
    {
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    switch (pParam->iType)
    {
    case AT_CMD_SET:
        iRet = AT_Util_GetParaCount(pParam->pPara, &paraCount);
        if ((iRet != ERR_SUCCESS) || (paraCount != 2))
        {
            AT_TC(g_sw_GPRS, "AT+POSI ERROR:paraCount: %d", paraCount);
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // index is 0,get MODE
        nIndex   = 0;
        nTypSize = 1;
        iRet     = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_UINT8, &nMode, &nTypSize);
        AT_TC(g_sw_GPRS, "AT+POSI nMode: %d", nMode);
        if (ERR_SUCCESS != iRet)
        {
            AT_TC(g_sw_GPRS, "AT+POSI ERROR:nMode!=1 !");
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // index is 1,get RANDNUM
        nIndex++;
        nTypSize = sizeof(nRandNum);
        AT_MemZero(nRandNum, nTypSize);
        iRet = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_STRING, nRandNum, &nTypSize);
        if (iRet != ERR_SUCCESS)
        {
            AT_TC(g_sw_GPRS, "AT+POSI ERROR:iRet: %d, GetPara ", iRet);
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // AT_MemZero(&gPosiList, sizeof(gPosiList));
        // memcpy(&gPosiList.sRandNum, nRandNum, nTypSize);
        AT_RandRamPush(nRandNum, nTypSize, nMode);

        // gPosiList.iMode = nMode;

        // get Cell info
        {
            CFW_TSM_FUNCTION_SELECT tSelecFUN;
            UINT16 nUTI = 0;

            tSelecFUN.nNeighborCell = 1;
            tSelecFUN.nServingCell  = 1;
            AT_GetFreeUTI(0, &nUTI);
            iRet = CFW_EmodOutfieldTestStart(&tSelecFUN, pParam->nDLCI, nSim);
            if (iRet != ERR_SUCCESS)
            {
                AT_TC(g_sw_GPRS, "AT+POSI ERROR:iRet: %d, Emod", iRet);
#ifdef AT_DUAL_SIM
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }

            if (CFW_INIT_STATUS_NO_SIM == cfwInitInfo.noSim[0].nType)
            {
                // get sim1 cell info
                AT_GetFreeUTI(0, &nUTI);
                iRet = CFW_EmodOutfieldTestStart(&tSelecFUN, pParam->nDLCI, nSim);
                if (iRet != ERR_SUCCESS)
                {
                    AT_TC(g_sw_GPRS, "AT+POSI ERROR:iRet: %d, Emod", iRet);
#ifdef AT_DUAL_SIM
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
            }
#ifdef AT_DUAL_SIM
            AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN_CLEAR_CMD, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_NW_Result_OK(CMD_FUNC_SUCC_ASYN_CLEAR_CMD, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
        }

        break;

    case AT_CMD_READ:
        // break;

    case AT_CMD_TEST:
        // break;

    default:
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        break;
    }

    return;
}
UINT16 AT_DBSAsciiToGsmBcd(INT8 *pNumber, UINT8 nNumberLen, UINT8 *pBCD)
{
    UINT8 Tmp;
    UINT32 i;
    UINT32 nBcdSize = 0;
    UINT8 *pTmp     = pBCD;

    if (pNumber == (CONST INT8 *)NULL || pBCD == (UINT8 *)NULL)
        return FALSE;

    SUL_MemSet8(pBCD, 0, nNumberLen >> 1);

    for (i = 0; i < nNumberLen; i++)
    {
        switch (*pNumber)
        {
        case 'A':
        case 'a':
            Tmp = (INT8)0x0A;
            break;
        case 'B':
        case 'b':
            Tmp = (INT8)0x0B;
            break;
        case 'C':
        case 'c':
            Tmp = (INT8)0x0C;
            break;

            // --------------------------------------------
            // Modify by lixp 20070626 begin
            // --------------------------------------------
        case 'D':
        case 'd':
            Tmp = (INT8)0x0D;
            break;
        case 'E':
        case 'e':
            Tmp = (INT8)0x0E;
            break;
        case 'F':
        case 'f':
            Tmp = (INT8)0x0F;
            break;

            // --------------------------------------------
            // Modify by lixp 20070626 end
            // --------------------------------------------
        default:
            Tmp = (INT8)(*pNumber - '0');
            break;
        }
#  if 1
        if (i % 2)
        {
            *pTmp++ |= Tmp & 0x0F;
        }
        else
        {
            *pTmp = (Tmp & 0x0F) << 4;
        }
#endif

#  if 0
        if (i % 2)
        {
            *pTmp++ |= (Tmp << 4) & 0xF0;
        }
        else
        {
            *pTmp = (INT8)(Tmp & 0x0F);
        }
#endif
        pNumber++;
    }

    nBcdSize = nNumberLen >> 1;
    if (i % 2)
    {
        *pTmp |= 0x00;
        nBcdSize += 1;
    }
    return nBcdSize;
}
VOID AT_ProcessCgsnData(UINT8 *pSigndata, UINT8 *pRandNum, UINT8 nTypSize)
{
    UINT8 nImei[16]  = { 0x00, };
    UINT8 nImeiLen   = 0;
    UINT8 nImeiD[16] = { 0x00, };

    INT nSeedRet        = 0;
    UINT8 nGetSeedLen   = 0;
    UINT8 nGetSeed[63]  = { 0x00, };
    UINT8 nSeedData[44] = { 0x00, };
    UINT8 nSeedBCD[40]  = { 0x00, };

    UINT8 nSignDataLen      = 50;
    UINT8 nSignData[50]     = { 0x00, };
    UINT8 nSrcSignDataLen   = 0;
    UINT8 nSrcSignData[400] = { 0x00, };
    UINT8 nRandNumASCIILen  = 0;
    UINT8 nRandNumBCDLen    = 0;
    UINT8 nRandNumBCD[20]   = { 0x00, };
    UINT8 nCidver[10]       = { 0x00, };

    UINT8 i                = 0;
    UINT8 nGidverASCII[64] = { 0x00 };
    INT64 iGidverD         = 0;

    nRandNumBCDLen = AT_DBSAsciiToGsmBcd(pRandNum, nTypSize, nRandNumBCD);

    // get imei num
    CFW_EmodGetIMEI(nImei, &nImeiLen, 0);

    AT_Sprintf(nSrcSignData, "+CGSN:%s,\"%s\"", nImei, pRandNum);
    nSrcSignDataLen = AT_StrLen(nSrcSignData);

    for (i = 0; i < 15; i++)
    {
        nImeiD[i] = nImei[i] - '0';
    }

    iGidverD = nImeiD[14] + nImeiD[13] * (10) + nImeiD[12] * (1.0e2) + nImeiD[11] * (1.0e3) + nImeiD[10] * (1.0e4) +
               nImeiD[9] * (1.0e5) + nImeiD[8] * (1.0e6) + nImeiD[7] * (1.0e7) + nImeiD[6] * (1.0e8) + nImeiD[5] * (1.0e9) +
               nImeiD[4] * (1.0e10) + nImeiD[3] * (1.0e11) + nImeiD[2] * (1.0e12) + nImeiD[1] * (1.0e13) + nImeiD[0] * (1.0e14);
    ui64toa(iGidverD, nGidverASCII, 16);
    nRandNumASCIILen = AT_StrLen(nGidverASCII);
    AT_DBSAsciiToGsmBcd(nGidverASCII, nRandNumASCIILen, g_Gidver);

    CFW_GetDBSSeed(nGetSeed);

    nGetSeedLen = AT_StrLen(nGetSeed);
    AT_DBSAsciiToGsmBcd(nGetSeed, nGetSeedLen, nSeedBCD);
    {
        AT_MemCpy(nCidver, nSeedBCD, 4);
        AT_MemCpy(nSeedData, (nSeedBCD + 4), 16);
        const UINT8 *idv  = nCidver;
        const UINT8 *gidv = g_Gidver;

        nSeedRet = sarft_sign_data(nSrcSignData, nSrcSignDataLen, nRandNumBCD,
                                   nRandNumBCDLen, idv, gidv, nSeedData, nSignData, &nSignDataLen);
    }
    if (nSeedRet != 0)
    {
        AT_TC(g_sw_GPRS, "ProcessPosiData: sign error: %d", nSeedRet);

        // sarft_error_str(sarft_sign_errno);
    }
    else
    {
        AT_TC(g_sw_GPRS, "sign success: %d", nSeedRet);
    }

    AT_Sprintf(pSigndata,
               "%s,\"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x\"",
               nSrcSignData, nSignData[0], nSignData[1], nSignData[2], nSignData[3], nSignData[4], nSignData[5],
               nSignData[6], nSignData[7], nSignData[8], nSignData[9], nSignData[10], nSignData[11], nSignData[12],
               nSignData[13], nSignData[14], nSignData[15], nSignData[16], nSignData[17], nSignData[18], nSignData[19],
               nSignData[20], nSignData[21], nSignData[22], nSignData[23]);

    return;
}
VOID AT_NW_CmdFunc_CGSN(AT_CMD_PARA *pParam)
{
    UINT8 paraCount = 0;
    UINT32 nResult  = ERR_SUCCESS;
    INT32 iRet      = 0;

    UINT8 nTypSize     = 0;
    UINT8 nIndex       = 0;
    UINT8 nRandNum[40] = { 0x00, };

    // UINT8 nImei[16]={0};
    UINT8 nImei[16] = { 0x00, };
    UINT8 nImeiLen  = 0;

    UINT8 nArrRes[120];
    UINT8 nSignData[50] = { 0x00, };  // NDS
    int nSignDataLen    = 50;  // NDS
    int nSeedRet;
    UINT8 nWaitSignedData[70] = { 0x00, };
    int nWaitSignedDataLen;
    UINT8 nCidVer[10] = { 0x00, };

    // UINT8 gidver[10] = {0x00,};
    UINT8 nGetSeed[63]    = { 0x00, };
    UINT8 nSeedData[44]   = { 0x00, };
    int nRandNumBCD_len   = 0;
    UINT8 nRandNumBCD[20] = { 0x00, };
    UINT8 nGetSeedLen     = 0;
    UINT8 nSeedBCD[40]    = { 0x00, };
    UINT8 nSeedBCDLen     = 0;

    UINT8 nImeiD[16] = { 0x00, };
    UINT8 nImeiD_len = 0;

    // /UINT32* VERP = (UINT8*)0xfffc;
    UINT8 nJbcd            = 0;
    UINT8 nGidVerAscii[64] = { 0x00 };
    UINT8 nGidVerAsciiLen  = 0;
    INT64 nGidVerD         = 0;
    UINT8 nGidVerLen       = 0;

    // int randNum_len = 0;
#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
    AT_TC(g_sw_GPRS, "AT+CGSN:CmdFunc_CGSN: ");

    if (pParam == NULL)
    {
        AT_TC(g_sw_GPRS, "AT+CGSN:pParam == NULL !");
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }
    switch (pParam->iType)
    {
    case AT_CMD_SET:
        iRet = AT_Util_GetParaCount(pParam->pPara, &paraCount);
        if ((iRet != ERR_SUCCESS) || (paraCount != 1))
        {
            AT_TC(g_sw_GPRS, "AT+CGSN:paraCount: %d", paraCount);
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        nTypSize = sizeof(nRandNum);
        AT_MemZero(nRandNum, nTypSize);
        iRet = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_STRING, nRandNum, &nTypSize);
        if (iRet != ERR_SUCCESS)
        {
            AT_TC(g_sw_GPRS, "AT+CGSN:iRet : %d !", iRet);
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        nRandNumBCD_len = AT_DBSAsciiToGsmBcd(nRandNum, nTypSize, nRandNumBCD);

        // get imei num
        CFW_EmodGetIMEI(nImei, &nImeiLen, 0);

        AT_Sprintf(nWaitSignedData, "+CGSN:%s,\"%s\"", nImei, nRandNum);
        nWaitSignedDataLen = AT_StrLen(nWaitSignedData);

        // get imei num
        // CFW_EmodGetIMEI(nImei, &nImeiLen,0);
        for (nJbcd = 0; nJbcd < 15; nJbcd++)
        {
            nImeiD[nJbcd] = nImei[nJbcd] - '0';
        }

        nGidVerD =
            nImeiD[14] + nImeiD[13] * (10) + nImeiD[12] * (1.0e2) + nImeiD[11] * (1.0e3) + nImeiD[10] * (1.0e4) +
            nImeiD[9] * (1.0e5) + nImeiD[8] * (1.0e6) + nImeiD[7] * (1.0e7) + nImeiD[6] * (1.0e8) + nImeiD[5] * (1.0e9) +
            nImeiD[4] * (1.0e10) + nImeiD[3] * (1.0e11) + nImeiD[2] * (1.0e12) + nImeiD[1] * (1.0e13) + nImeiD[0] * (1.0e14);
        ui64toa(nGidVerD, nGidVerAscii, 16);
        nGidVerAsciiLen = AT_StrLen(nGidVerAscii);
        nGidVerLen      = AT_DBSAsciiToGsmBcd(nGidVerAscii, nGidVerAsciiLen, g_Gidver);

        CFW_GetDBSSeed(nGetSeed);

        // AT_TC(g_sw_GPRS, "nGetSeed : %s !",nGetSeed);
        nGetSeedLen = AT_StrLen(nGetSeed);
        nSeedBCDLen = AT_DBSAsciiToGsmBcd(nGetSeed, nGetSeedLen, nSeedBCD);

        AT_MemCpy(nCidVer, nSeedBCD, 4);
        AT_MemCpy(nSeedData, (nSeedBCD + 4), 16);
        const UINT8 *idv  = nCidVer;
        const UINT8 *gidv = g_Gidver;

        nSeedRet = sarft_sign_data(nWaitSignedData, nWaitSignedDataLen, nRandNumBCD,
                                   nRandNumBCD_len, idv, gidv, nSeedData, nSignData, &nSignDataLen);

        if (nSeedRet != 0)
        {
            AT_TC(g_sw_GPRS, "sign error: %d", nSeedRet);

            // UINT8* seedstr = sarft_error_str(sarft_sign_errno);

            // AT_TC(g_sw_GPRS, "sign error: %s\n", seedstr);

        }
        else
        {
            AT_TC(g_sw_GPRS, "sign success: %d", nSeedRet);
        }

        AT_Sprintf(nArrRes,
                   "%s,\"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x\"",
                   nWaitSignedData, nSignData[0], nSignData[1], nSignData[2], nSignData[3], nSignData[4], nSignData[5],
                   nSignData[6], nSignData[7], nSignData[8], nSignData[9], nSignData[10], nSignData[11], nSignData[12],
                   nSignData[13], nSignData[14], nSignData[15], nSignData[16], nSignData[17], nSignData[18], nSignData[19],
                   nSignData[20], nSignData[21], nSignData[22], nSignData[23]);
#ifdef AT_DUAL_SIM
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, nArrRes, AT_StrLen(nArrRes), pParam->nDLCI, nSim);
#else
        AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, nArrRes, AT_StrLen(nArrRes), pParam->nDLCI);
#endif

        break;

    case AT_CMD_READ:
        // break;

    case AT_CMD_TEST:
        // break;

    default:
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        break;
    }

    return;
}

#ifdef AT_DUAL_SIM
VOID AT_DBS_Result_Str(UINT8 *pBuffer, UINT16 nDataSize, UINT8 nDLCI, UINT8 nSim)
#else
VOID AT_DBS_Result_Str(UINT8 *pBuffer, UINT16 nDataSize, UINT8 nDLCI)
#endif
{
    PAT_CMD_RESULT pResult = NULL;

#ifdef AT_DUAL_SIM
    AT_BACKSIMID(nSim);
#endif

    // �������
    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_CR, 0, 0, 0, pBuffer, nDataSize, nDLCI);

    AT_Notify2ATM(pResult, nDLCI);

    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}
VOID AT_NW_CmdFunc_GSMSTATUS(AT_CMD_PARA *pParam)
{
    UINT8 paraCount = 0;
    INT32 iRet      = 0;

    UINT8 nStauts = 0;

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

    AT_TC(g_sw_GPRS, "AT+CGSN:CmdFunc_GSMSTATUS: ");

    if (pParam == NULL)
    {
        AT_TC(g_sw_GPRS, "AT+GSMSTATUS:pParam == NULL !");
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    switch (pParam->iType)
    {
    case AT_CMD_EXE:
        iRet = AT_Util_GetParaCount(pParam->pPara, &paraCount);
        if ((iRet != ERR_SUCCESS) || (paraCount != 0))
        {
            AT_TC(g_sw_GPRS, "AT+GSMSTATUS:paraCount: %d", paraCount);
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }
        nStauts = AT_ModuleGetInitResult();

        // netwrok error
        if ((2 == gCsStauts.nType) && ((CFW_NW_STATUS_NOTREGISTERED_NOTSEARCHING == gCsStauts.nParam1) ||
                                       (CFW_NW_STATUS_NOTREGISTERED_SEARCHING == gCsStauts.nParam1) ||
                                       (CFW_NW_STATUS_UNKNOW == gCsStauts.nParam1)))
        {
#ifdef AT_DUAL_SIM
            AT_DBS_Result_Str("NETERR", AT_StrLen("NETERR"), pParam->nDLCI, nSim);
#else
            AT_DBS_Result_Str("NETERR", AT_StrLen("NETERR"), pParam->nDLCI);
#endif
            return;
        }

        switch (nStauts)
        {
            // sim error
        case AT_MODULE_INIT_NO_SIM:
        case AT_MODULE_INIT_SIM_AUTH_READY:
        case AT_MODULE_INIT_SIM_AUTH_WAIT_PUK1:
        case AT_MODULE_INIT_SIM_AUTH_WAIT_PIN1:
        case AT_MODULE_INIT_SAT_ERROR:
        case AT_MODULE_INIT_NORMAL_SIM_CARD:
        case AT_MODULE_INIT_CHANGED_SIM_CARD:
#ifdef AT_DUAL_SIM
            AT_DBS_Result_Str("SIMERR", AT_StrLen("SIMERR"), pParam->nDLCI, nSim);
#else
            AT_DBS_Result_Str("SIMERR", AT_StrLen("SIMERR"), pParam->nDLCI);
#endif
            break;

            // other error
        case AT_MODULE_INIT_SIM_SMS_ERROR:
        case AT_MODULE_INIT_SIM_PBK_ERROR:
        case AT_MODULE_INIT_ME_SMS_ERROR:
        case AT_MODULE_INIT_ME_PBK_ERROR:
#ifdef AT_DUAL_SIM
            AT_DBS_Result_Str("OTHERERR", AT_StrLen("OTHERERR"), pParam->nDLCI, nSim);
#else
            AT_DBS_Result_Str("OTHERERR", AT_StrLen("OTHERERR"), pParam->nDLCI);
#endif
            break;

            // initing
        case AT_MODULE_INIT_SIM_PBK_OK:
        case AT_MODULE_INIT_ME_SMS_OK:
        case AT_MODULE_INIT_ME_PBK_OK:
        case AT_MODULE_NOT_INIT:
#ifdef AT_DUAL_SIM
            AT_DBS_Result_Str("INITERR", AT_StrLen("INITERR"), pParam->nDLCI, nSim);
#else
            AT_DBS_Result_Str("INITERR", AT_StrLen("INITERR"), pParam->nDLCI);
#endif
            break;

            // ok
        case AT_MODULE_INIT_SIM_SMS_OK:
            if (2 == gCsStauts.nType)
            {
                if ((CFW_NW_STATUS_REGISTERED_ROAMING == gCsStauts.nParam1) ||
                        (CFW_NW_STATUS_REGISTERED_HOME == gCsStauts.nParam1))
                {
#ifdef AT_DUAL_SIM
                    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
                    AT_NW_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
                }
                else
                {
#ifdef AT_DUAL_SIM
                    AT_DBS_Result_Str("NETERR", AT_StrLen("NETERR"), pParam->nDLCI, nSim);
#else
                    AT_DBS_Result_Str("NETERR", AT_StrLen("NETERR"), pParam->nDLCI);
#endif
                }
            }
            else
            {
#ifdef AT_DUAL_SIM
                AT_DBS_Result_Str("NETERR", AT_StrLen("NETERR"), pParam->nDLCI, nSim);
#else
                AT_DBS_Result_Str("NETERR", AT_StrLen("NETERR"), pParam->nDLCI);
#endif
            }
            break;

        default:
#ifdef AT_DUAL_SIM
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            break;
        }

        break;

    case AT_CMD_READ:
        // break;

    case AT_CMD_TEST:
        // break;

    default:
#ifdef AT_DUAL_SIM
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_NW_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        break;
    }

    return;
}






#endif
// frank add end

