/******************************************************************************************
	Copyright (C), 2002-2010, Coolsand. Co., Ltd.
	File name     : at_cmd_gc.c
	Author         : wangqunyang
	Version        : 2.0
	Date            : 2008.03.20
	Description   : This file implements AT General Command functions
	Others          :
	History         :

   1.        Date   : 2007/11/25
           Author   : Felix
      Description  : build this file
          Version   : V1.0

   2.        Date  : 2008.03.20
           Author  : wangqunyang
      Description : modify some code and added comment
          Version  : V2.0


*******************************************************************************************/

#include "at_common.h"
#include "at_module.h"
#include "at_cmd_sms.h"
//#include "at_cmd_gc.h"
//#include "at_cfg.h"

#include "at_sa.h"
#include "at_common.h"
#include "at_parser.h"
//#include "at_cmd_pbk.h"
#include "at_cmd_sim.h"
// //////////////////////////////////////////////////////////////////////////////////////////
//
// Define and desclare the variable
//
// //////////////////////////////////////////////////////////////////////////////////////////
// sms related settings
typedef struct _AT_CNMI
{
	UINT8 nMode;
	UINT8 nMt;
	UINT8 nBm;
	UINT8 nDs;
	UINT8 nBfr;
} AT_CNMI;


typedef struct _AT_CONFIG_INFO
{
	AT_CNMI sCnmi;
	UINT8 nStorage1;
	UINT8 nStorage2;
	UINT8 nStorage3;

	UINT8 nTotal1;
	UINT8 nTotal2;
	UINT8 nTotal3;

	UINT8 nUsed1;
	UINT8 nUsed2;
	UINT8 nUsed3;

	UINT8 nServType;
	UINT8 nOverflowCtrl;
	UINT8 nOverflowMode;

} AT_CONFIG_INFO;

struct at_sms_settings
{
	// sms related
	UINT8 g_CSMP_fo;  // [+]2007.11.20 bug 7000
	UINT8 g_CSDH_show;  // show header
	AT_CONFIG_INFO g_AtSMSInfo[NUMBER_OF_SIM]; // CPMSÃüÁîÏà¹ØµÄ´æ´¢Æ÷ÐÅÏ¢
	UINT8 g_SMSFormat;  // SMS Foramt: 0: PDU 1:text
}g_AtSmsSetting;

typedef struct at_sms_settings AT_SMS_SETTINGS, * P_ATSMSETTING;
// sms related
#define gATCurrentAtSmsSettingSCSMP_fo 		g_AtSmsSetting.g_CSMP_fo
#define gATCurrentAtSmsSettingSCSDH_show 	g_AtSmsSetting.g_CSDH_show
#define gATCurrentAtSmsSettingSg_SMSFormat 	g_AtSmsSetting.g_SMSFormat
#define gATCurrentAtSMSInfo 	g_AtSmsSetting.g_AtSMSInfo



/*
** check number valid befor input data
** cmgw only use g_cmgw_cmgs save BCD number
*/
CFW_TELNUMBER g_cmgw_cmgs =
{
	.nTelNumber = {0}
	,
	.nType   = 0,
	.nSize   = 0,
	.padding = {0}  // save sms status
};
static UINT8 g_cmgw_cmgs_pdu_length = 0;
static UINT8 g_cmgw_cmgs_pdu_status = 0;

// [+]2007.10.22 for +CIEV
static UINT8 g_SMS_CIND_NewMsg = 0; // [mod]2007.10.30

/**************************************************/
// memfull according to different storage, we support storage
// "ME" and "SM", this gloable variable set flag as following:
// bit 7 6 5 4 3 2 1 0
// bit0  "ME" memfull flag, 0: not full 1: memfull
// bit1  "SM" memfull flag, 0: not full 1: memfull
// bit 2~bit7 reserved for other storage future
/*************************************************/
#ifdef AT_DUAL_SIM
static UINT8 g_SMS_CIND_MemFull[2] = {0x00,};
#else
static UINT8 g_SMS_CIND_MemFull = 0;  // [mod]2007.10.30
#endif
/*
** CMSS: Recv resp message, for check it ,
** we should record when execute CMSS command
*/
static UINT8 g_CMSS_BCD[12]   = { 0 };
static UINT8 g_CMSS_BCDLen    = 0;
static UINT8 g_CMSS_StringLen = 0;
static UINT8 g_CMSS_nToDA     = 0;
static UINT8 g_CMSS_DA_Flag   = 0;
static UINT8 g_CMSS_Index     = 0;
static UINT8 g_CMSS_Status    = 0;

/* SMS cmd stamp define */
static UINT32 g_SMS_CurCmdStamp = 0;

CFW_INIT_INFO cfwInitInfo;


extern UINT8 g_uCmer_ind[NUMBER_OF_SIM];

#define gATCurrentuCmer_ind g_uCmer_ind

#ifdef __MODEM_LP_MODE_ENABLE__
UINT8 *g_sms_delaybuffer = NULL;
#endif

#ifdef AT_DUAL_SIM
//extern AT_FDN_PBK_LIST *pgATFNDlist[CFW_SIM_COUNT];
#endif
BOOL AT_SMS_GetPDUNUM(UINT8 *pPDUData, UINT8 *pPDUNUM, UINT8 *pType,UINT8 *nPDULen);
BOOL AT_SMS_GetSCANUM(UINT8 *pPDUData, UINT8 *pSACNUM, UINT8 *nPDULen);
BOOL AT_GetCfwInitSmsInfo(CFW_EVENT *pCfwEvent);
// //////////////////////////////////////////////////////////////////////////////////////////
// //////////////////////////////////////////////////////////////////////////////////////////

/******************************************************************************************
Function			:	AT_SMS_INIT
Description		:   	SMS module init procedure
Called By			:	SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	void
Output			:
Return			:	UINT32
Others			:
*******************************************************************************************/
#ifdef AT_DUAL_SIM
UINT32 AT_SMS_INIT(UINT8 nSim)
#else
UINT32 AT_SMS_INIT(VOID)
#endif
{
	/* Define the variable */
	CFW_SMS_PARAMETER sInfo           = { 0 };
	CFW_SMS_STORAGE_INFO sStorageInfo = { 0 };
	UINT8 nOption                     = 0;
	UINT8 nNewSmsStorage              = 0;
	UINT8 ReportBuff[32]              = { 0 };
	UINT32 nOperationRet              = 0;

#if 0
	UINT16 nUTI = 0;  // add uti for set sms parameter calling
#endif

	// Just for debug
	AT_TC(g_sw_AT_SMS, "SMS init beginning .......");

	/* set default show text mode parameters, show all header or not */

#ifdef AT_DUAL_SIM
	nOperationRet = CFW_CfgSetSmsShowTextModeParam(1, nSim);
#else
	nOperationRet = CFW_CfgSetSmsShowTextModeParam(1);

#endif
	if (nOperationRet != ERR_SUCCESS)
	{
		return ERR_AT_CMS_MEM_FAIL;
	}

	/* set defualt value for +ciev, the buffer overflow, notify to AT or not */

#ifdef AT_DUAL_SIM
	nOperationRet = CFW_CfgSetSmsOverflowInd(1, nSim);
#else
	nOperationRet = CFW_CfgSetSmsOverflowInd(1);

#endif
	if (nOperationRet != ERR_SUCCESS)
	{
		return ERR_AT_CMS_MEM_FAIL;
	}

	/********************************************************************/
	// update SMS parameters, we first get the current value ,then
	// modify the segments we needed.
	/********************************************************************/
#ifndef __NGUX_PLATFORM__

#ifdef AT_DUAL_SIM
	nOperationRet = CFW_CfgGetSmsParam(&sInfo, 0, nSim);
#else
	nOperationRet = CFW_CfgGetSmsParam(&sInfo, 0);

#endif
	if (nOperationRet != ERR_SUCCESS)
	{
		return ERR_AT_CMS_MEM_FAIL;
	}

	// ///////////////////////////////////////////////////////
	// modify the segments we need to change in default value
	// according to the 3GPP 27.005 the default value is:
	// "fo" = 17, "vp" = 167, "dcs" = 0, "pid" = 0
	// ///////////////////////////////////////////////////////
	/****************************************/
	// "fo" composition :
	// bit    7    6      5     4      3     2    1     0
	// RP UDHI SSR VPF  VPF  RD MTI MTI
	/****************************************/
#if 0
	sInfo.rp   = (17 & 0x80) >> 7;
	sInfo.udhi = (17 & 0x40) >> 6;
#endif
	sInfo.ssr = (17 & 0x20) >> 5;

#if 0
	sInfo.vpf = (17 & 0x18) >> 3;
	sInfo.rd  = (17 & 0x04) >> 2;
	sInfo.mti = 17 & 0x03;
#endif

	sInfo.vp  = 167;
	sInfo.dcs = 0;
	sInfo.pid = 0;

#if 0
	/* set param location */
	sInfo.nIndex         = 0; // the first profile of parameters
	sInfo.nSaveToSimFlag = 0x00;  // set param to mobile flash , sync procedure calling
	sInfo.bDefault       = TRUE;  // as current parameters

	/* get the UTI and free it after finished calling */
	if (0 == (nUTI = AT_AllocUserTransID()))
	{
		return ERR_AT_CMS_MEM_FAIL;
	}

	/* set sms parameters request, sync procedure calling */
	nOperationRet = CFW_CfgSetSmsParam(&sInfo, nUTI);
	AT_FreeUserTransID(nUTI);
#else

#ifdef AT_DUAL_SIM
	nOperationRet = CFW_CfgSetSmsParam(&sInfo, 0, nSim);
#else
	nOperationRet = CFW_CfgSetSmsParam(&sInfo, 0);

#endif
#endif

	/* asyn procedure calling */
	if (ERR_SUCCESS != nOperationRet)
	{
		return ERR_AT_CMS_MEM_FAIL;

	}
#endif
	// //////////////////////////////////////////
	/* status report value, get the current value and  */
	/* then update we needed                                  */
	// //////////////////////////////////////////

#ifdef AT_DUAL_SIM
	if (ERR_SUCCESS != CFW_CfgGetNewSmsOption(&nOption, &nNewSmsStorage, nSim))
#else
	if (ERR_SUCCESS != CFW_CfgGetNewSmsOption(&nOption, &nNewSmsStorage))

#endif
	{
		return ERR_AT_CMS_MEM_FAIL;
	}
#ifdef AT_DUAL_SIM

	if (ERR_SUCCESS != CFW_CfgSetNewSmsOption(nOption | CFW_SMS_ROUT_DETAIL_INFO, gATCurrentAtSMSInfo[nSim].nStorage3, nSim))
#else
	if (ERR_SUCCESS != CFW_CfgSetNewSmsOption(nOption | CFW_SMS_ROUT_DETAIL_INFO, gATCurrentAtSMSInfo[nSim].nStorage3))

#endif
	{

		return ERR_AT_CMS_MEM_FAIL;
	}

	// //////////////////////////////////////////
	/* support multi language                                   */
	// //////////////////////////////////////////
	ML_Init();

	/********************************************************************/
	// get SM storage info and save the init value
	/********************************************************************/

#ifdef AT_DUAL_SIM
	if (ERR_SUCCESS != CFW_CfgGetSmsStorageInfo(&sStorageInfo, CFW_SMS_STORAGE_SM, nSim))
#else
	if (ERR_SUCCESS != CFW_CfgGetSmsStorageInfo(&sStorageInfo, CFW_SMS_STORAGE_SM))

#endif

	{
		return ERR_AT_CMS_MEM_FAIL;
	}

	/* SM is default storage of Mobile */
	gATCurrentAtSMSInfo[nSim].nTotal1 = gATCurrentAtSMSInfo[nSim].nTotal2 = gATCurrentAtSMSInfo[nSim].nTotal3 = sStorageInfo.totalSlot;
	gATCurrentAtSMSInfo[nSim].nUsed1  = gATCurrentAtSMSInfo[nSim].nUsed2 = gATCurrentAtSMSInfo[nSim].nUsed3 = sStorageInfo.usedSlot;

	/* if SM storage buffer is full and set flag */
	if ((sStorageInfo.totalSlot == sStorageInfo.usedSlot) && (sStorageInfo.usedSlot != 0))
	{
		/* SM storage is full, set bit1 is 1 */
#ifdef AT_DUAL_SIM
		g_SMS_CIND_MemFull[nSim] |= CFW_SMS_STORAGE_SM;
#else
		g_SMS_CIND_MemFull |= CFW_SMS_STORAGE_SM;
#endif
	}

	if (sStorageInfo.unReadRecords != 0)
	{
		g_SMS_CIND_NewMsg += sStorageInfo.unReadRecords;
	}

	/********************************************************************/
	// ME storage info and save the init value
	/********************************************************************/

#ifdef AT_DUAL_SIM
	if (ERR_SUCCESS != CFW_CfgGetSmsStorageInfo(&sStorageInfo, CFW_SMS_STORAGE_ME, nSim))
#else
	if (ERR_SUCCESS != CFW_CfgGetSmsStorageInfo(&sStorageInfo, CFW_SMS_STORAGE_ME))

#endif

	{
		return ERR_AT_CMS_MEM_FAIL;
	}

	/* ME storage buffer is full and set flag */
	if ((sStorageInfo.totalSlot == sStorageInfo.usedSlot) && (sStorageInfo.usedSlot != 0))
	{
		/* ME storage is full, set bit0 is 1 */
#ifdef AT_DUAL_SIM
		g_SMS_CIND_MemFull[nSim] |= CFW_SMS_STORAGE_ME;
#else
		g_SMS_CIND_MemFull |= CFW_SMS_STORAGE_ME;
#endif

	}

	if (sStorageInfo.unReadRecords != 0)  // [+]for cind command new message 2007.11.05
	{
		g_SMS_CIND_NewMsg += sStorageInfo.unReadRecords;
	}

	AT_TC(g_sw_SA, ("We Got gATCurrentuCmer_ind nSim[%d] to %d\n"), nSim, gATCurrentuCmer_ind[nSim]);

	/***********************************
	**  Report to CMER, if necessary
	***********************************/
	if (gATCurrentuCmer_ind[nSim])
	{
		/* if SM and ME storage bit flag are both "1", bit0 = 1 and bit1 =1 , then the SMSFULL is 1 */
#ifdef AT_DUAL_SIM
		AT_Sprintf(ReportBuff, "+CIEV: \"SMSFULL\",%u",
		           ((CFW_SMS_STORAGE_SM == (g_SMS_CIND_MemFull[nSim] & CFW_SMS_STORAGE_SM))
		            && (CFW_SMS_STORAGE_ME == (g_SMS_CIND_MemFull[nSim] & CFW_SMS_STORAGE_ME))) ? 1 : 0);

		AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ReportBuff, (UINT16)AT_StrLen(ReportBuff), 0, nSim);
#else
		AT_Sprintf(ReportBuff, "+CIEV: \"SMSFULL\",%u",
		           ((CFW_SMS_STORAGE_SM == (g_SMS_CIND_MemFull & CFW_SMS_STORAGE_SM))
		            && (CFW_SMS_STORAGE_ME == (g_SMS_CIND_MemFull & CFW_SMS_STORAGE_ME))) ? 1 : 0);

		AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ReportBuff, (UINT16)AT_StrLen(ReportBuff), 0);
#endif

		AT_MemZero(ReportBuff, 32);

		AT_Sprintf(ReportBuff, "+CIEV: \"MESSAGE\",%u", g_SMS_CIND_NewMsg ? 1 : 0);
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ReportBuff, (UINT16)AT_StrLen(ReportBuff), 0, nSim);
#else
		AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ReportBuff, (UINT16)AT_StrLen(ReportBuff), 0);
#endif

	}

	// Just for debug
	AT_TC(g_sw_AT_SMS, "SMS init OK!");

	return ERR_SUCCESS;

}

/******************************************************************************************
Function			:	AT_SMS_AsyncEventProcess
Description		:   	async event process function
Called By			:	AT SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	COS_EVENT *pEvent
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/
extern BOOL gATSATSendSMSFlag[];
VOID AT_SMS_AsyncEventProcess(COS_EVENT *pEvent)
{

	// /////////////////////////////////////////////////////////////////////////////
	//
	// In order to display event the SMS received in this function, add trace of which event recieved.
	// add by wangqunyang 2008.04.08
	//
	// //////////////////////////////////////////////////////////////////////////////

	AT_ASSERT(NULL != pEvent);
	CFW_EVENT CfwEvent       = { 0 };

	AT_CosEvent2CfwEvent(pEvent, &CfwEvent);

	switch (pEvent->nEventId)
	{

	case EV_CFW_SMS_SEND_MESSAGE_RSP:

		AT_TC(g_sw_AT_SMS, " AT SMS Get Async Event:  EV_CFW_SMS_SEND_MESSAGE_RSP\n ");
		if (AT_IsAsynCmdAvailable("+CMGS", g_SMS_CurCmdStamp, HIUINT16(pEvent->nParam3))
		        || AT_IsAsynCmdAvailable("+CMSS", g_SMS_CurCmdStamp, HIUINT16(pEvent->nParam3)))
		{
			AT_SMS_CMGS_CMSS_SendMessage_rsp(pEvent);
		}
		else if(gATSATSendSMSFlag[CfwEvent.nFlag])
		{

			if (0 == CfwEvent.nType)
			{
				CFW_SatResponse(0x13, 0x00, 0x00, NULL, 0x00, 12, CfwEvent.nFlag);
			}
			else
			{
				CFW_SatResponse(0x13, 0x35, 0x00, NULL, 0x00, 12, CfwEvent.nFlag);
			}
			//gATSATSendSMSFlag[CfwEvent.nFlag] = FALSE;
		}
		else
		{
			AT_TC(g_sw_AT_SMS, " SMS recieved event, and not for us, discard it !");
		}

		break;

	case EV_CFW_SMS_DELETE_MESSAGE_RSP:
		AT_TC(g_sw_AT_SMS, " AT SMS Get Async Event:  EV_CFW_SMS_DELETE_MESSAGE_RSP\n ");
		if (AT_IsAsynCmdAvailable("+CMGD", g_SMS_CurCmdStamp, HIUINT16(pEvent->nParam3)))
		{
			AT_SMS_DeleteMessage_rsp(pEvent);
		}
		else
		{
			AT_TC(g_sw_AT_SMS, " SMS recieved event, and not for us, discard it !");
		}

		break;

	case EV_CFW_SMS_READ_MESSAGE_RSP:

		AT_TC(g_sw_AT_SMS, " AT SMS Get Async Event:  EV_CFW_SMS_READ_MESSAGE_RSP\n ");
		CFW_EVENT nCfwEvent = {0};
		nCfwEvent.nFlag = CfwEvent.nFlag;


#ifndef __NGUX_PLATFORM__
		BOOL bReturn = AT_GetCfwInitSmsInfo(&nCfwEvent);
		if ((bReturn == 0) || (nCfwEvent.nParam1 == 1)) // me init not finished
			//if (bReturn == 0)  // me init not finished
		{
			AT_SMS_MOInit_ReadMessage_rsp(pEvent);
		}
#endif

		if (AT_IsAsynCmdAvailable("+CMGR", g_SMS_CurCmdStamp, HIUINT16(pEvent->nParam3)))
		{
			AT_SMS_CMGR_ReadMessage_rsp(pEvent);
		}
		else if (AT_IsAsynCmdAvailable("+CMSS", g_SMS_CurCmdStamp, HIUINT16(pEvent->nParam3)))
		{
			AT_SMS_CMSS_ReadMessage_rsp(pEvent);
		}
		else
		{
			AT_TC(g_sw_AT_SMS, " SMS recieved event, and not for us, discard it !");
		}

		break;

	case EV_CFW_SMS_WRITE_MESSAGE_RSP:

		AT_TC(g_sw_AT_SMS, " AT SMS Get Async Event:  EV_CFW_SMS_WRITE_MESSAGE_RSP\n ");
		if (AT_IsAsynCmdAvailable("+CMGW", g_SMS_CurCmdStamp, HIUINT16(pEvent->nParam3)))
		{
			AT_SMS_WriteMessage_rsp(pEvent);
		}
		else
		{
			AT_TC(g_sw_AT_SMS, " SMS recieved event, and not for us, discard it !");
		}

		break;

	case EV_CFW_SMS_LIST_MESSAGE_RSP:

		AT_TC(g_sw_AT_SMS, " AT SMS Get Async Event:  EV_CFW_SMS_LIST_MESSAGE_RSP\n ");
		if (AT_IsAsynCmdAvailable("+CMGL", g_SMS_CurCmdStamp, HIUINT16(pEvent->nParam3)))
		{
			AT_SMS_ListMessage_rsp(pEvent);
		}
		else
		{
			AT_TC(g_sw_AT_SMS, " SMS recieved event, and not for us, discard it !");
		}

		break;

	case EV_CFW_NEW_SMS_IND:
		AT_TC(g_sw_AT_SMS, " AT SMS Get Async Event:  EV_CFW_NEW_SMS_IND\n ");
		AT_SMS_RecvNewMessage_Indictation(pEvent);
		break;

	case EV_CFW_SMS_INFO_IND:

		AT_TC(g_sw_AT_SMS, " AT SMS Get Async Event:  EV_CFW_SMS_INFO_IND\n ");
		AT_SMS_RecvBuffOverflow_Indictation(pEvent);
		break;

#if 0
		/* add event response for setting sca, 20080708, wangqy
		   ** +CSCA or +CSMP or SMS init with set param request */
	case EV_CFW_SMS_SET_PARAM_RSP:

		AT_TC(g_sw_AT_SMS, " AT SMS Get Async Event:  EV_CFW_SMS_SET_PARAM_RSP\n ");
		if ((AT_IsAsynCmdAvailable("+CSCA", g_SMS_CurCmdStamp)) || (AT_IsAsynCmdAvailable("+CSAS", g_SMS_CurCmdStamp))  // to be continue implements
		        || (AT_IsAsynCmdAvailable("+CRES", g_SMS_CurCmdStamp))) // to be continue implements
		{
			AT_SMS_SetSMSParam_rsp(pEvent);
		}
		else
		{
			AT_TC(g_sw_AT_SMS, " SMS recieved event, and not for us, discard it !");
		}

		break;
#endif

	default:

		AT_TC(g_sw_AT_SMS, " AT SMS Get Async Event:  Unknown EventId = %u\n ", pEvent->nEventId);
		break;

	}

	return;
}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CMSS
Description		:   	CMSS procedure function
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by wangqunyang 2008.04.07
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CMSS(AT_CMD_PARA *pParam)
{
	CFW_EVENT nCfwEvent = {0,};
	CFW_SMS_STORAGE_INFO sStorageInfo = { 0 };

	UINT8 BCDDataBuff[12] = { 0 };
	UINT8 BCDDataLength   = 0;

	UINT8 DialNumberBuff[TEL_NUMBER_MAX_LEN] = { 0 };
	UINT8 DialNumberLen                      = 24;
	UINT8 nDialNumType                       = 0;

	UINT8 nParamLen   = 0;
	UINT8 nParamCount = 0;

	UINT16 nIndex = 0;

	UINT32 nOperationRet = 0;

	BOOL bReturn;
	BOOL bIsInternational = FALSE;
	UINT16 nUTI           = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
	nCfwEvent.nFlag = nSim;
#endif

	AT_ASSERT(NULL != pParam);

	g_SMS_CurCmdStamp = pParam->uCmdStamp;

	// Reset the record of SMSS variable
	AT_MemZero(g_CMSS_BCD, 12);
	g_CMSS_BCDLen    = 0;
	g_CMSS_StringLen = 0;
	g_CMSS_DA_Flag   = 0;
	g_CMSS_nToDA     = 0;
	g_CMSS_Index     = 0;
	g_CMSS_Status    = 0;

	bReturn = AT_GetCfwInitSmsInfo(&nCfwEvent);

	if ((bReturn == 0) || (nCfwEvent.nParam1 == 1)) // me init not finished
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmss: AT_GetCfwInitSmsInfo() failure", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmss: AT_GetCfwInitSmsInfo() failure", pParam->nDLCI);
#endif
		return;
	}

	/***********************************************/
	// Operation is set mode
	/***********************************************/
	if (pParam->iType == AT_CMD_SET)
	{
		nOperationRet = AT_Util_GetParaCount(pParam->pPara, &nParamCount);
		if ((nOperationRet != ERR_SUCCESS) || (nParamCount == 0) || (nParamCount > 3))  // [mod]2007.111.20 max param count = 3
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmss: get param counter error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmss: get param counter error", pParam->nDLCI);
#endif
			return;
		}

		// //////////////////////////////////////////
		// process different part according to para counts
		// //////////////////////////////////////////
		if (1 == nParamCount)
			goto CMSS_label_para1;

		if (2 == nParamCount)
			goto CMSS_label_para2;

		if (3 == nParamCount)
			goto CMSS_label_para3;

CMSS_label_para3:
		// /////////////////////////////////////////////////////////////////////////
		// para 3
		// ////////////////////////////////////////////////////////////////////////
		AT_TC(g_sw_AT_SMS, "CMSS==== para3");
		nParamLen     = 1;
		nOperationRet =
		    AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_UINT8, (void *)(&nDialNumType), &nParamLen);

		/* Dial number can omit and set default value */
		if (ERR_AT_UTIL_CMD_PARA_NULL == nOperationRet)
		{
			nDialNumType = CFW_TELNUMBER_TYPE_INTERNATIONAL;
		}
		else
		{
			if (nOperationRet != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmss: get param 3 error", pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmss: get param 3 error", pParam->nDLCI);
#endif
				return;
			}
		}

		if ((nDialNumType != CFW_TELNUMBER_TYPE_INTERNATIONAL)
		        && (nDialNumType != CFW_TELNUMBER_TYPE_NATIONAL) && (nDialNumType != CFW_TELNUMBER_TYPE_UNKNOWN))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmss: dial number wrong type", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmss: dial number wrong type", pParam->nDLCI);
#endif
			return;

		}

CMSS_label_para2:
		// /////////////////////////////////////////////////////////////////////////
		// para 2
		// ////////////////////////////////////////////////////////////////////////
		AT_TC(g_sw_AT_SMS, "CMSS === para2");
		nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, DialNumberBuff, &DialNumberLen);

		if ((ERR_SUCCESS != nOperationRet) || (0 == DialNumberLen))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmss: get param 2 error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmss: get param 2 error", pParam->nDLCI);
#endif
			return;
		}

		if (!AT_SMS_IsValidPhoneNumber(DialNumberBuff, DialNumberLen, &bIsInternational))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmss: nuber invalid error!", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmss: nuber invalid error!", pParam->nDLCI);
#endif
			return;
		}

		// Set user input data to handle
		if (bIsInternational)
		{
			DialNumberLen--;
			if (DialNumberLen > 20)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmss with '+': dial num len too long", pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmss with '+': dial num len too long", pParam->nDLCI);
#endif
				return;
			}

			BCDDataLength = SUL_AsciiToGsmBcd(&DialNumberBuff[1], DialNumberLen, BCDDataBuff);

		}
		else
		{
			if (DialNumberLen > 20)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmss without '+': dial num len too long", pParam->nDLCI,
				                  nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmss without '+': dial num len too long", pParam->nDLCI);
#endif
				return;
			}

			BCDDataLength = SUL_AsciiToGsmBcd(DialNumberBuff, DialNumberLen, BCDDataBuff);

		}

		// mark the flag : dial number is input:
		g_CMSS_DA_Flag = 1;

CMSS_label_para1:
		// /////////////////////////////////////////////////////////////////////////
		// para 1
		// ////////////////////////////////////////////////////////////////////////
		AT_TC(g_sw_AT_SMS, "CMSS==== para1");
		nParamLen     = 2;
		nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT16, (void *)(&nIndex), &nParamLen);
		if ((nOperationRet != ERR_SUCCESS) || (0 == nIndex))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmss: get param 1 error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmss: get param 1 error", pParam->nDLCI);
#endif
			return;
		}

		// From storage2's message

#ifdef AT_DUAL_SIM
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage2, nSim);
#else
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage2);

#endif

		if ((ERR_SUCCESS != nOperationRet) || (nIndex > sStorageInfo.totalSlot))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_MEM_INDEX, NULL, 0, "cmss: index > total slot", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_MEM_INDEX, NULL, 0, "cmss: index > total slot", pParam->nDLCI);
#endif
			return;

		}

		/* according to spec, we check dial number first */
		if (bIsInternational)
		{
			nDialNumType = CFW_TELNUMBER_TYPE_INTERNATIONAL;
		}
		else
		{
			if (0 == nDialNumType)
			{
				/* no input num type  */
				nDialNumType = CFW_TELNUMBER_TYPE_UNKNOWN;
			}
			else if (CFW_TELNUMBER_TYPE_INTERNATIONAL == nDialNumType)
			{
				/* have no '+' , but the num type is 145, replace 129 with is  */
				nDialNumType = CFW_TELNUMBER_TYPE_UNKNOWN;
			}
			else
			{
				/* get the input num type  */
			}
		}

		/*****************************************************/
		// Record the CMSS data and reference by cmss read msg resp
		/*****************************************************/
		AT_MemCpy(g_CMSS_BCD, BCDDataBuff, BCDDataLength);
		g_CMSS_nToDA     = nDialNumType;
		g_CMSS_BCDLen    = BCDDataLength;
		g_CMSS_StringLen = DialNumberLen;
		g_CMSS_Index     = nIndex;

		/* get the UTI and free it after finished calling */
		if (0 == (nUTI = AT_AllocUserTransID()))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmss: malloc UTI error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmss: malloc UTI error", pParam->nDLCI);
#endif
			return;
		}

#ifdef AT_DUAL_SIM

		nOperationRet = CFW_SmsReadMessage(gATCurrentAtSMSInfo[nSim].nStorage2, CFW_SMS_TYPE_PP, nIndex, pParam->nDLCI, nSim);
#else
		nOperationRet = CFW_SmsReadMessage(gATCurrentAtSMSInfo[nSim].nStorage2, nIndex, pParam->nDLCI);

#endif

		AT_FreeUserTransID(nUTI);

		if (nOperationRet == ERR_SUCCESS)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_CR, 0, NULL, 0, pParam->nDLCI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_CR, 0, NULL, 0, pParam->nDLCI);
#endif
			return;
		}
		else
		{
			nOperationRet = AT_SMS_ERR_Change(nOperationRet);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmss: check read message param exception", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmss: check read message param exception", pParam->nDLCI);
#endif
			return;

		}

	}
	else if (pParam->iType == AT_CMD_TEST)
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
		return;
	}
	else
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cmss: wrong cmd mode", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cmss: wrong cmd mode", pParam->nDLCI);
#endif
		return;
	}

	return;

}

const U8 ATExtendedAsciiToDefaultArray[] =
{
	0, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 27, 32, 32,
	32, 32, 10, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 60, 47, 62, 20, 32, 32, 32, 32, 32,
	32, 101, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 40, 64, 41, 61, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 101, 32, 32, 32, 32, 32, 32, 32,	/*	Changed character at 162 to 101 (old value was 32)	*/
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32
};
const U8 ATAsciiToDefaultArray[] =
{
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	10, 32, 32, 13, 32, 32, 16, 32, 18, 19,
	20, 21, 22, 23, 24, 25, 26, 27, 32, 32,
	32, 32, 32, 33, 34, 35, 2, 37, 38, 39,
	40, 41, 42, 43, 44, 45, 46, 47, 48, 49,
	50, 51, 52, 53, 54, 55, 56, 57, 58, 59,
	60, 61, 62, 63, 0, 65, 66, 67, 68, 69,
	70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
	80, 81, 82, 83, 84, 85, 86, 87, 88, 89,
	90, 32, 32, 32, 32, 17, 32, 97, 98, 99,
	100, 101, 102, 103, 104, 105, 106, 107, 108, 109,
	110, 111, 112, 113, 114, 115, 116, 117, 118, 119,
	120, 121, 122, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 64, 32, 1, 36, 3, 32, 95, 32, 32,
	32, 32, 32, 64, 32, 32, 32, 32, 32, 32,
	32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
	32, 96, 32, 32, 32, 32, 91, 14, 28, 9,
	31, 32, 32, 32, 32, 32, 32, 32, 32, 93,
	32, 32, 32, 32, 92, 32, 11, 32, 32, 32,
	94, 32, 32, 30, 127, 32, 32, 32, 123, 15,
	29, 32, 4, 5, 32, 32, 7, 32, 32, 32,
	32, 125, 8, 32, 32, 32, 124, 32, 12, 6,
	32, 32, 126, 32, 32, 32
};

const U8 ATDefaultToAsciiArray[128] =
{
	64, 163, 36, 165, 232, 233, 249, 236, 242, 199,
	10, 216, 248, 13, 197, 229, 16, 95, 18, 19,
	20, 21, 22, 23, 24, 25, 26, 27, 198, 230,
	223, 200, 32, 33, 34, 35, 164, 37, 38, 39,
	40, 41, 42, 43, 44, 45, 46, 47, 48, 49,
	50, 51, 52, 53, 54, 55, 56, 57, 58, 59,
	60, 61, 62, 63, 161, 65, 66, 67, 68, 69,
	70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
	80, 81, 82, 83, 84, 85, 86, 87, 88, 89,
	90, 196, 214, 209, 220, 167, 191, 97, 98, 99,
	100, 101, 102, 103, 104, 105, 106, 107, 108, 109,
	110, 111, 112, 113, 114, 115, 116, 117, 118, 119,
	120, 121, 122, 228, 246, 241, 252, 224
};
const U8 ATDefaultToExtendedAsciiArray[128] =
{
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	32, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* Page Break at 10=32 Change Later*/
	94, 0, 0, 0, 0, 0, 0, 32, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	123, 125, 0, 0, 0, 0, 0, 92, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	91, 126, 93, 0, 124, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 162, 0, 0, 0, 0, 0, 0, 0, 0,	/*	Euro character at 101 changed to 162 */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0
};

#define AT_TEST_GSM_EXTENDED(c)     \
(     (c==0xA2)                     \
   || (c=='^')                      \
   || (c=='{')                      \
   || (c=='}')                      \
   || (c=='\\')                     \
   || (c=='[')                      \
   || (c=='~')                      \
   || (c==']')                      \
   || (c=='|')                      \
)                                   \
 


void ATConvertAsciiEncodingToGSM7BitDefault (U8 *message, U8 *msg, U16 length, U16 *outLen)
{
	U16 i, j;
	for(i = 0, j = 0; i < length; i++, j++)
	{
		if(AT_TEST_GSM_EXTENDED(msg[i]))
		{
			if(i > 0 && msg[i - 1] == 0x1b)
			{
				message[j] = ATExtendedAsciiToDefaultArray[msg[i]];
			}
			else
			{
				message[j++] = 0x1b;
				message[j] = ATExtendedAsciiToDefaultArray[msg[i]];
			}
		}
		else
		{
			message[j] = ATAsciiToDefaultArray[msg[i]];
		}
	}
	if(outLen != NULL) *outLen = j;
}

void ATConvertGSM7BitDefaultEncodingToAscii (U8 *message, U8 *msg, U16 length, U16 *outLen)
{
	U16 i, j = 0;
	for(i = 0; i < length; i++)
	{
		if(msg[i] != 27)	//escape char ?
		{
			// if(msg[i]!=13)	//CR ?
			message[j++] = ATDefaultToAsciiArray[msg[i]];
		}
		else
		{
			//treat escape char as a space
			//message[j++] = 32;
			//if current char is escape, then mean next char is extend ascii char
			i++;
			message[j++] = ATDefaultToExtendedAsciiArray[msg[i]];
		}
	}
	if(outLen != NULL) *outLen = j;
}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CMGS
Description		:   	CMGS procedure function
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CMGS(AT_CMD_PARA *pParam)
{
	UINT8 *pSmsSendData    = NULL;
	UINT32 nSmsSendDatalen = 0;

	UINT8 *PduData   = NULL;
	UINT8 *pduaddsca = NULL;

	CFW_DIALNUMBER Number             = { 0 };
	CFW_SMS_PARAMETER sInfoForChinese = { 0 };

	UINT8 nParamCount                        = 0;
	UINT8 nFormat                            = 0;
	UINT8 PromptMsg[8]                       = { 0 };
	UINT8 DialNumberBuff[TEL_NUMBER_MAX_LEN] = { 0 };
	UINT8 DialNumberLen                      = 24;
	UINT8 nDialNumType                       = 0;
	UINT8 nParamLen                          = 0;

	UINT8 *pUCS2Data = NULL;

	UINT8 BCDDataBuff[TEL_NUMBER_MAX_LEN] = { 0 };
	UINT8 BCDDataLength                   = 0;

	UINT8 nPduTotalDataLen = 0;
	UINT16 pdulen;
	UINT32 nUCS2DataSize      = 0;
	UINT16 nRetGetChineseInfo = 0;

	UINT32 nOperationRet = ERR_SUCCESS;
	UINT32 nRetSendMsg   = ERR_SUCCESS;

	BOOL bIsInternational = FALSE;
	UINT16 nUTI           = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	AT_ASSERT(NULL != pParam);

	// Get cmd stamp
	g_SMS_CurCmdStamp = pParam->uCmdStamp;

	switch (pParam->iType)
	{
	case AT_CMD_SET:
		/***************************************
			** Prompt input send message data
			***************************************/
		if (!pParam->iExDataLen)
		{
			nFormat = gATCurrentAtSmsSettingSg_SMSFormat;

			// get param count
			nOperationRet = AT_Util_GetParaCount(pParam->pPara, &nParamCount);

			// nOperationRet is failure, or nFormat is not 0 or 1
			if ((nOperationRet != ERR_SUCCESS) || (nParamCount > 2) || (!((nFormat == 0) || (nFormat == 1))))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgs text mode: get param counter error ", pParam->nDLCI,
				                  nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgs text mode: get param counter error ", pParam->nDLCI);
#endif
				return;
			}

			// ////////////////////////////////////////////////////////
			// text mode prompt
			// ////////////////////////////////////////////////////////
			if (nFormat == 1)
			{
				// First reset the value
				memset(&g_cmgw_cmgs, 0, sizeof(CFW_TELNUMBER)); // text mode

				// //////////////////////
				// param 1
				// //////////////////////
				if (nParamCount > 0)
				{
					// get the first param, da in string mode
					nOperationRet =
					    AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, DialNumberBuff, &DialNumberLen);
					if (nOperationRet != ERR_SUCCESS)
					{
#ifdef AT_DUAL_SIM
						AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmgs text mode: get param 1 error ", pParam->nDLCI, nSim);
#else
						AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmgs text mode: get param 1 error ", pParam->nDLCI);
#endif
						return;
					}

					// number is empty return error
					if (DialNumberLen == 0)
					{
#ifdef AT_DUAL_SIM
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgs text mode: DialNumberLen==0", pParam->nDLCI,
						                  nSim);
#else
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgs text mode: DialNumberLen==0", pParam->nDLCI);
#endif
						return;
					}
					if (!AT_SMS_IsValidPhoneNumber(DialNumberBuff, DialNumberLen, &bIsInternational))
					{
#ifdef AT_DUAL_SIM
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_CHAR, NULL, 0, "cmgs text mode: number invalid", pParam->nDLCI,
						                  nSim);
#else
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_CHAR, NULL, 0, "cmgs text mode: number invalid", pParam->nDLCI);
#endif
						return;
					}

					// Internal format of tel num
					if (bIsInternational)
					{
						DialNumberLen--;
						if (DialNumberLen > 20)
						{
#ifdef AT_DUAL_SIM
							AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgs text mode with '+': number len too long",
							                  pParam->nDLCI, nSim);
#else
							AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgs text mode with '+': number len too long",
							                  pParam->nDLCI);
#endif
							return;
						}

						BCDDataLength = SUL_AsciiToGsmBcd(&DialNumberBuff[1], DialNumberLen, BCDDataBuff);

						g_cmgw_cmgs.nSize = BCDDataLength;
						AT_MemCpy(g_cmgw_cmgs.nTelNumber, BCDDataBuff, BCDDataLength);
					}

					// national format tel num
					else
					{
						if (DialNumberLen > 20)
						{
#ifdef AT_DUAL_SIM
							AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgs text mode without '+': number len too long",
							                  pParam->nDLCI, nSim);
#else
							AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgs text mode without '+': number len too long",
							                  pParam->nDLCI);
#endif
							return;
						}
						BCDDataLength = SUL_AsciiToGsmBcd(DialNumberBuff, DialNumberLen, BCDDataBuff);

						g_cmgw_cmgs.nSize = BCDDataLength;
						AT_MemCpy(g_cmgw_cmgs.nTelNumber, BCDDataBuff, BCDDataLength);

					}
				}

				// //////////////////////
				// param 2
				// //////////////////////
				if (nParamCount > 1)
				{
					nParamLen     = 1;
					nOperationRet =
					    AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, (void *)(&nDialNumType), &nParamLen);

					/* Dial number can omit and set default value */
					if (ERR_AT_UTIL_CMD_PARA_NULL == nOperationRet)
					{
						nDialNumType = CFW_TELNUMBER_TYPE_INTERNATIONAL;
					}
					else
					{
						if (nOperationRet != ERR_SUCCESS)
						{
#ifdef AT_DUAL_SIM
							AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgs text mode: get param 2 error",
							                  pParam->nDLCI, nSim);
#else
							AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgs text mode: get param 2 error",
							                  pParam->nDLCI);
#endif
							return;
						}
					}

					if ((nDialNumType != CFW_TELNUMBER_TYPE_INTERNATIONAL)
					        && (nDialNumType != CFW_TELNUMBER_TYPE_NATIONAL) && (nDialNumType != CFW_TELNUMBER_TYPE_UNKNOWN))
					{
#ifdef AT_DUAL_SIM
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgs text mode: dial number type error",
						                  pParam->nDLCI, nSim);
#else
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgs text mode: dial number type error",
						                  pParam->nDLCI);
#endif
						return;
					}

					// set cmgs dial num type
					g_cmgw_cmgs.nType = nDialNumType;

				}

				/* according to spec, we check dial number first */
				if (bIsInternational)
				{
					nDialNumType = CFW_TELNUMBER_TYPE_INTERNATIONAL;
				}
				else
				{
					if (0 == nDialNumType)
					{
						/* no input num type  */
						nDialNumType = CFW_TELNUMBER_TYPE_UNKNOWN;
					}
					else if (CFW_TELNUMBER_TYPE_INTERNATIONAL == nDialNumType)
					{
						/* have no '+' , but the num type is 145, replace 129 with is  */
						nDialNumType = CFW_TELNUMBER_TYPE_UNKNOWN;
					}
					else
					{
						/* get the input num type  */
					}
				}

				g_cmgw_cmgs.nType = nDialNumType;

			}

			// //////////////////////////////////////////////////////////
			// pdu mode prompt
			// //////////////////////////////////////////////////////////
			if (nFormat == 0)
			{
				g_cmgw_cmgs_pdu_length = 0;
				if (nParamCount > 1)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgs pdu mode: get param counter error",
					                  pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgs pdu mode: get param counter error",
					                  pParam->nDLCI);
#endif
					return;
				}

				// parse param
				nParamLen     = 1;
				nOperationRet =
				    AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, (void *)(&nPduTotalDataLen), &nParamLen);
				AT_TC(g_sw_AT_SMS, "CMGS GetPara: 0x%x", nOperationRet);

				if (nOperationRet != ERR_SUCCESS)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgs pdu mode: get param error", pParam->nDLCI,
					                  nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgs pdu mode: get param error", pParam->nDLCI);
#endif
					return;
				}

				// Pdu total data length is valid or not
				if ((nPduTotalDataLen > 164) || (nPduTotalDataLen == 0))
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgs pdu mode: pdu len too long", pParam->nDLCI,
					                  nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgs pdu mode: pdu len too long", pParam->nDLCI);
#endif
					return;
				}
				g_cmgw_cmgs_pdu_length = nPduTotalDataLen;

			}

			// /////////////////////////////////////////////////////////////////////////////
			// display in the screen, and need input
			// /////////////////////////////////////////////////////////////////////////////
			PromptMsg[0] = CHAR_CR; //AT_GC_CfgGetS3Value();
			PromptMsg[1] = CHAR_LF; //AT_GC_CfgGetS4Value();
			AT_StrCat(PromptMsg, "> ");

			/* time  waiting for input sms data , set 180s now, if update we can change it */
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_WAIT_SMS, CMD_RC_OK, 180, (UINT8 *)PromptMsg, AT_StrLen(PromptMsg), pParam->nDLCI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_WAIT_SMS, CMD_RC_OK, 180, (UINT8 *)PromptMsg, AT_StrLen(PromptMsg), pParam->nDLCI);
#endif
			return;
		}

		/*******************************************
			**  with msg body,input data process is starting
			*******************************************/
		else
		{
			if (pParam->pExData[pParam->iExDataLen - 1] == 27)  // end with esc, cancel send
			{
				/* if escape , reset gloable variable */
				AT_MemSet(&g_cmgw_cmgs, 0, sizeof(CFW_TELNUMBER));
#ifdef AT_DUAL_SIM
				AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
				AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
				return;
			}
			else if (pParam->pExData[pParam->iExDataLen - 1] != 26) // not end with ctl+z, err happen
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgs data: not with 'ctr+Z' ", pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgs data: not with 'ctr+Z' ", pParam->nDLCI);
#endif
				return;
			}
			nFormat = gATCurrentAtSmsSettingSg_SMSFormat;

			// ////////////////////////////////////////////////////////
			// text mode procedure and send message
			// ////////////////////////////////////////////////////////
			if (nFormat)
			{
				BOOL bParaVerifyErrorFlag = FALSE;

#ifdef AT_DUAL_SIM
				nRetGetChineseInfo = CFW_CfgGetSmsParam(&sInfoForChinese, 0, nSim);
#else
				nRetGetChineseInfo = CFW_CfgGetSmsParam(&sInfoForChinese, 0);
#endif
				if (nRetGetChineseInfo != ERR_SUCCESS)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgs text mode data: get sms prarameters error",
					                  pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgs text mode data: get sms prarameters error",
					                  pParam->nDLCI);
#endif
					return;
				}

				/* Just for debug */
				AT_TC(g_sw_AT_SMS, "cmgs text mode data: pParam->iExDataLen = %u", pParam->iExDataLen);

				AT_TC(g_sw_AT_SMS, "sInfoForChinese.dcs = %d", sInfoForChinese.dcs);

				/* check the dcs value */
				if (sInfoForChinese.dcs == 0)
				{
					if (pParam->iExDataLen - 1 > 160)
					{
						bParaVerifyErrorFlag = TRUE;
					}
					nSmsSendDatalen = pParam->iExDataLen - 1;

				}
				else if (sInfoForChinese.dcs == 4)
				{
					if (pParam->iExDataLen - 1 > 140)
					{
						bParaVerifyErrorFlag = TRUE;
					}

					nSmsSendDatalen = pParam->iExDataLen - 1;

				}
				else if (sInfoForChinese.dcs == 8)  // This for chinese message
				{
					UINT32 UCSlength       = 0;
					INT32 nLocal2UCSReturn = ERR_SUCCESS;

					UCSlength = SUL_CharacterLen(pParam->pExData, pParam->iExDataLen - 1);

					if (UCSlength == -1 || UCSlength - 1 > 70)
					{
						bParaVerifyErrorFlag = TRUE;
					}
					else
					{
						/* we must use uniform transport mode: big ending */
						//AT_Set_MultiLanguage();
						nLocal2UCSReturn =
						    ML_LocalLanguage2Unicode(pParam->pExData, pParam->iExDataLen - 1, &pUCS2Data, &nUCS2DataSize, NULL);

						if (ERR_SUCCESS != nLocal2UCSReturn)
						{
							nLocal2UCSReturn = AT_SMS_ERR_Change(nLocal2UCSReturn);
#ifdef AT_DUAL_SIM
							AT_SMS_Result_Err(nLocal2UCSReturn, NULL, 0, "cmgs text mode data:  local to ucs 2", pParam->nDLCI, nSim);
#else
							AT_SMS_Result_Err(nLocal2UCSReturn, NULL, 0, "cmgs text mode data:  local to ucs 2", pParam->nDLCI);
#endif
							return;
						}

						nSmsSendDatalen = nUCS2DataSize;
						AT_MemZero(pParam->pExData, AT_CMD_LINE_BUFF_LEN);

						// buffer overflow
						if (nSmsSendDatalen > AT_CMD_LINE_BUFF_LEN)
						{
#ifdef AT_DUAL_SIM
							AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgs text mode data:  buffer overflow",
							                  pParam->nDLCI, nSim);
#else
							AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgs text mode data:  buffer overflow",
							                  pParam->nDLCI);
#endif
							return;
						}

						// move the data to pSmsSendData
						AT_MemCpy(pParam->pExData, pUCS2Data, nSmsSendDatalen);

						// Free inout para resource
						AT_FREE(pUCS2Data);

					}
				}

				/* Exception happened  */
				if (bParaVerifyErrorFlag)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgs text mode data: input data's length error",
					                  pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgs text mode data: input data's length error",
					                  pParam->nDLCI);
#endif
					return;
				}

				// get message context,dynamic alloc
				pSmsSendData = (UINT8 *)AT_MALLOC(nSmsSendDatalen * 2);

				if (pSmsSendData == NULL)
				{
					AT_FREE(pUCS2Data);
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgs text mode data: MALLOC ERROR 11",
					                  pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgs text mode data: MALLOC ERROR 11",
					                  pParam->nDLCI);
#endif
					return;
				}
				AT_MemZero(pSmsSendData, nSmsSendDatalen * 2);
				if (sInfoForChinese.dcs == 0)
				{
					ATConvertAsciiEncodingToGSM7BitDefault(pSmsSendData, pParam->pExData, nSmsSendDatalen, (UINT16 *)&nSmsSendDatalen);
				}
				else
					AT_MemCpy(pSmsSendData, pParam->pExData, nSmsSendDatalen);

				// validate the value dial number
				Number.nDialNumberSize = g_cmgw_cmgs.nSize;
				Number.pDialNumber     = g_cmgw_cmgs.nTelNumber;
				Number.nType           = g_cmgw_cmgs.nType;

				/* just for debug */
				AT_TC(g_sw_AT_SMS, "Text mode data to need to send: nSmsSendDatalen = %u", nSmsSendDatalen);
				AT_TC_MEMBLOCK(g_sw_AT_SMS, pSmsSendData, nSmsSendDatalen, 16);

				/* get the UTI and free it after finished calling */
				if (0 == (nUTI = AT_AllocUserTransID()))
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgs text mode dat: malloc UTI error", pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgs text mode dat: malloc UTI error", pParam->nDLCI);
#endif
					return;
				}

				/* Send message and free UTI */

#ifdef AT_DUAL_SIM
				nRetSendMsg = CFW_SmsSendMessage(&Number, pSmsSendData, nSmsSendDatalen, pParam->nDLCI, nSim);
#else
				nRetSendMsg = CFW_SmsSendMessage(&Number, pSmsSendData, nSmsSendDatalen, pParam->nDLCI);
#endif
				AT_FreeUserTransID(nUTI);

				if (ERR_SUCCESS != nRetSendMsg)
				{
					AT_FREE(pSmsSendData);
					nRetSendMsg = AT_SMS_ERR_Change(nRetSendMsg);
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(nRetSendMsg, NULL, 0, " cmgs text mode data: sand message check param error", pParam->nDLCI,
					                  nSim);
#else
					AT_SMS_Result_Err(nRetSendMsg, NULL, 0, " cmgs text mode data: sand message check param error",
					                  pParam->nDLCI);
#endif
					return;
				}

				/* Different networks have different response time, according to networks status,
				   ** we set general enough time(here is 60s ) to waiting for networks response */
#ifdef AT_DUAL_SIM
				AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 60, NULL, 0, pParam->nDLCI, nSim);
#else
				AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 60, NULL, 0, pParam->nDLCI);
#endif
				AT_FREE(pSmsSendData);

				return;

			}

			// ////////////////////////////////////////////////////////
			// pdu mode procedure and send message
			// ////////////////////////////////////////////////////////
			else
			{
				/* Get PDU mode input param */
				nPduTotalDataLen = g_cmgw_cmgs_pdu_length;

				/* Starting send pdu message */
				nSmsSendDatalen = pParam->iExDataLen - 1;

				pSmsSendData = (UINT8 *)AT_MALLOC(nSmsSendDatalen);
				if (pSmsSendData == NULL)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgs pdu mode data: MALLOC ERROR 22", pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgs pdu mode data: MALLOC ERROR 22", pParam->nDLCI);
#endif
					return;
				}

				/* clear buffer and copy data */
				AT_MemSet(pSmsSendData, 0, nSmsSendDatalen);
				AT_MemCpy(pSmsSendData, &(pParam->pExData[0]), pParam->iExDataLen - 1);

				pdulen  = (nSmsSendDatalen % 2) ? (nSmsSendDatalen / 2 + 1) : (nSmsSendDatalen / 2);
				PduData = (UINT8 *)AT_MALLOC(pdulen);
				if (PduData == NULL)
				{
					AT_FREE(pSmsSendData);
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgs pdu mode data: MALLOC ERROR 33", pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgs pdu mode data: MALLOC ERROR 33", pParam->nDLCI);
#endif
					return;
				}

				/* clear buffer */
				AT_MemSet(PduData, 0, pdulen);

				pdulen = SMS_PDUAsciiToBCD(pSmsSendData, nSmsSendDatalen, PduData);
				if (pdulen == 0)
				{
					AT_FREE(pSmsSendData);
					AT_FREE(PduData);
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgs pdu mode data: pdulen == 0", pParam->nDLCI,
					                  nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgs pdu mode data: pdulen == 0", pParam->nDLCI);
#endif
					return;
				}

				/*
				   ** check param1(length:TP DATA UNIT) pdu length not include sca length
				   ** check total pdu length
				 */
				if ((nSmsSendDatalen + 1 > 353) || (pdulen != nPduTotalDataLen + 1 + PduData[0]))
				{
					AT_FREE(pSmsSendData);
					AT_FREE(PduData);
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgs pdu mode data: (SmsDatalen+1 > 353)", pParam->nDLCI,
					                  nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgs pdu mode data: (SmsDatalen+1 > 353)", pParam->nDLCI);
#endif
					return;
				}

				pduaddsca = (UINT8 *)AT_MALLOC(pdulen + 23);
				if (pduaddsca == NULL)  // [+]2007.10.16
				{
					AT_FREE(pSmsSendData);
					AT_FREE(PduData);
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgs pdu mode data:MALLOC ERROR!55", pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgs pdu mode data:MALLOC ERROR!55", pParam->nDLCI);
#endif
					return;
				}

				/* clear buffer */
				AT_MemSet(pduaddsca, 0, pdulen + 23);
#ifdef AT_DUAL_SIM
				if (!(SMS_AddSCA2PDU(PduData, pduaddsca, &pdulen, nSim)))
#else
				if (!(SMS_AddSCA2PDU(PduData, pduaddsca, &pdulen)))
#endif
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgs pdu mode data: MALLOC ERROR!66", pParam->nDLCI,
					                  nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgs pdu mode data: MALLOC ERROR!66",
					                  pParam->nDLCI);
#endif
					return;
				}
				AT_TC_MEMBLOCK(g_sw_AT_SMS, pduaddsca, pdulen, 16);
				if (!AT_SMS_CheckPDUIsValid(pduaddsca, (UINT8 *)&pdulen, FALSE))
				{

					AT_FREE(pSmsSendData);
					AT_FREE(PduData);
					AT_FREE(pduaddsca);
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "cmgs pdu mode data: Check Valid_PDU Error ",
					                  pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "cmgs pdu mode data: Check Valid_PDU Error ",
					                  pParam->nDLCI);
#endif
					return;
				}

				// ////////////////////////////////////////////////////
				/* starting send message     */
				// ////////////////////////////////////////////////////
				/* just for debug */
				AT_TC(g_sw_AT_SMS, "Pdu mode data to need to send: pdulen = %u", pdulen);
				AT_TC_MEMBLOCK(g_sw_AT_SMS, pduaddsca, pdulen, 16);

				/* get the UTI and free it after finished calling */
				if (0 == (nUTI = AT_AllocUserTransID()))
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgs pdu mode data: malloc UTI error", pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgs pdu mode data: malloc UTI error", pParam->nDLCI);
#endif
					return;
				}

#if 0
				AT_TC(g_sw_AT_SMS, "CMGS pgATFNDlist[nSim]: %d!\n\r", pgATFNDlist[nSim]);
				if(pgATFNDlist[nSim])
				{
					AT_TC(g_sw_AT_SMS, "CMGS pgATFNDlist[nSim]->nFDNSatus: %d!\n\r", pgATFNDlist[nSim]->nFDNSatus);
					if( 1 == pgATFNDlist[nSim]->nFDNSatus )
					{
						UINT8 nNumSize =0;
						UINT8 nSCANumSize =0;
						UINT8 nType =0;
						UINT8 nFDNNumbers[20] = {0xff,};
						UINT8 nSCANumbers[20] = {0xff,};

						AT_MemSet(nFDNNumbers,0xff,20);
						if(FALSE == AT_SMS_GetPDUNUM(pduaddsca, nFDNNumbers,&nType, &nNumSize))
							return ;
						
						AT_MemSet(nSCANumbers,0xff,20);
						if(FALSE == AT_SMS_GetSCANUM(pduaddsca, nSCANumbers, &nSCANumSize))
						{
							AT_TC(g_sw_AT_SMS, "CMGS Warning don't FDN SCA number!\n\r");

							//SUL_StrPrint(g_pCeer, "+CEER: %d", ERR_AT_CME_SIM_CONDITION_NO_FULLFILLED);
#ifdef AT_DUAL_SIM
							AT_CC_Result_Err(ERR_AT_CME_SIM_CONDITION_NO_FULLFILLED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
							AT_CC_Result_Err(ERR_AT_CME_SIM_CONDITION_NO_FULLFILLED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

						}
						if( FALSE == AT_FDN_CompareNumber(nSCANumbers, nSCANumSize,0xff, nSim) )
						{
							AT_TC(g_sw_AT_SMS, "CMGS Warning don't FDN SCA record number!\n\r");

							SUL_StrPrint(g_pCeer, "+CEER: %d", ERR_AT_CME_SIM_CONDITION_NO_FULLFILLED); //adapt to android by wulc
#ifdef AT_DUAL_SIM
							AT_CC_Result_Err(ERR_AT_CME_SIM_CONDITION_NO_FULLFILLED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
							AT_CC_Result_Err(ERR_AT_CME_SIM_CONDITION_NO_FULLFILLED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

							return;
						}

						if(0x91 == nType )
						{
							nType = CFW_TELNUMBER_TYPE_INTERNATIONAL;
						}
						
						if( FALSE == AT_FDN_CompareNumber(nFDNNumbers, nNumSize,nType, nSim) )
						{
							AT_TC(g_sw_AT_SMS, "CMGS Warning don't FDN record number!\n\r");

							SUL_StrPrint(g_pCeer, "+CEER: %d", ERR_AT_CME_SIM_CONDITION_NO_FULLFILLED); //adapt to android by wulc
#ifdef AT_DUAL_SIM
							AT_CC_Result_Err(ERR_AT_CME_SIM_CONDITION_NO_FULLFILLED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
							AT_CC_Result_Err(ERR_AT_CME_SIM_CONDITION_NO_FULLFILLED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

							return;
						}
					}
				}
#endif
				/* Send message and free UTI */

#ifdef AT_DUAL_SIM
				nRetSendMsg = CFW_SmsSendMessage(NULL, pduaddsca, pdulen, pParam->nDLCI, nSim);
#else
				nRetSendMsg = CFW_SmsSendMessage(NULL, pduaddsca, pdulen, pParam->nDLCI);
#endif
				AT_FreeUserTransID(nUTI);
				if (ERR_SUCCESS != nRetSendMsg)
				{
					AT_FREE(pSmsSendData);
					AT_FREE(PduData);
					AT_FREE(pduaddsca);

					nRetSendMsg = AT_SMS_ERR_Change(nRetSendMsg);
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(nRetSendMsg, NULL, 0, "cmgs pdu mode data: Send msg check param error 22", pParam->nDLCI,
					                  nSim);
#else
					AT_SMS_Result_Err(nRetSendMsg, NULL, 0, "cmgs pdu mode data: Send msg check param error 22", pParam->nDLCI);
#endif
					return;
				}

				AT_FREE(pSmsSendData);
				AT_FREE(PduData);
				AT_FREE(pduaddsca);

				/* Different networks have different response time, according to networks status,
				   ** we set general enough time(here is 60s ) to waiting for networks response */
#ifdef AT_DUAL_SIM
				AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 60, NULL, 0, pParam->nDLCI, nSim);
#else
				AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 60, NULL, 0, pParam->nDLCI);
#endif
				break;

			}
		}

		break;

	case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
		break;
	default:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cmgs pdu mode data: wrong cmd mode", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cmgs pdu mode data: wrong cmd mode", pParam->nDLCI);
#endif
		break;

	}

	return;

}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CMGW
Description		:   	CMGW procedure function
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CMGW(AT_CMD_PARA *pParam)
{
	CFW_SMS_WRITE SmsWrite;

	CFW_SMS_MO_INFO_ADD *pSmsMOInfo = NULL;
	CFW_EVENT nCfwEvent = {0,};

	CFW_SMS_PARAMETER sInfoForChinese       = { 0 };
	UINT8 nParamCount                       = 0;
	UINT8 BCDDataBuff[AT_SMS_BODY_BUFF_LEN] = { 0 };
	UINT8 nFormat                           = 0;

	UINT8 DialNumberBuff[TEL_NUMBER_MAX_LEN] = { 0 };
	UINT8 nDialNumberLen                     = 24;
	UINT8 nDialNumType                       = 0;
	UINT8 nParamLen                          = 0;

	INT8 InputState[16] = { 0 };
	UINT8 nPDUParamLen  = 0;

	UINT8 *pUCS2Data     = NULL;
	UINT32 nUCS2DataSize = 0;
	UINT16 retForChinese = 0;
	INT32 nOperationRet  = ERR_SUCCESS;
	INT32 nWriteMsgRet   = ERR_SUCCESS;

	UINT8 *pSmsDataBuff = NULL;
	UINT32 SmsDatalen   = 0;

	BOOL bReturn          = FALSE;
	BOOL bIsInternational = FALSE;

	UINT8 PromptMsg[8] = { 0 };

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
	nCfwEvent.nFlag = nSim;
#endif

	/********************************************************************/

	CFW_SMS_STORAGE_INFO sStorageInfo = { 0 };
#ifdef AT_DUAL_SIM
	if (ERR_SUCCESS != CFW_CfgGetSmsStorageInfo(&sStorageInfo, CFW_SMS_STORAGE_SM, nSim))
#else
	if (ERR_SUCCESS != CFW_CfgGetSmsStorageInfo(&sStorageInfo, CFW_SMS_STORAGE_SM))

#endif

	{
		return;
	}


	AT_TC(g_sw_AT_SMS, "sStorageInfo totalSlot = %d,usedSlot = %d", sStorageInfo.totalSlot, sStorageInfo.usedSlot);
	/* if SM storage buffer is full and set flag */
	if ((sStorageInfo.totalSlot == sStorageInfo.usedSlot) && (sStorageInfo.usedSlot != 0))
	{
		/* SM storage is full, set bit1 is 1 */
#ifdef AT_DUAL_SIM
		g_SMS_CIND_MemFull[nSim] |= CFW_SMS_STORAGE_SM;
#else
		g_SMS_CIND_MemFull |= CFW_SMS_STORAGE_SM;
#endif
	}
	else if(sStorageInfo.totalSlot != sStorageInfo.usedSlot)
	{
#ifdef AT_DUAL_SIM
		g_SMS_CIND_MemFull[nSim] = 0;
#else
		g_SMS_CIND_MemFull = 0;
#endif

	}


	AT_ASSERT(NULL != pParam);
	g_SMS_CurCmdStamp = pParam->uCmdStamp;

	bReturn = AT_GetCfwInitSmsInfo(&nCfwEvent);
	if ((bReturn == 0) || (nCfwEvent.nParam1 == 1))
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgw: SMS INIT FAIL", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgw: SMS INIT FAIL", pParam->nDLCI);
#endif
		return;

	}

	// check the mode and process
	switch (pParam->iType)
	{
	case AT_CMD_SET:

		/***************************************************/
		/* return error if the buff is overflow, and check "SM" storage */
		/* and "ME" storage eparately, 2008.07.03, by wangqy           */
		/***************************************************/
		if (gATCurrentAtSMSInfo[nSim].nStorage2 & CFW_SMS_STORAGE_SM)
		{

			/* bit0 flag of SM is "1", SM memfull */
#ifdef AT_DUAL_SIM
			if (CFW_SMS_STORAGE_SM == (g_SMS_CIND_MemFull[nSim] & CFW_SMS_STORAGE_SM))
#else
			if (CFW_SMS_STORAGE_SM == (g_SMS_CIND_MemFull & CFW_SMS_STORAGE_SM))
#endif
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_MEM_FULL, NULL, 0, "cmgw set mode: message buffer of SM is overflow",
				                  pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_MEM_FULL, NULL, 0, "cmgw set mode: message buffer of SM is overflow",
				                  pParam->nDLCI);
#endif
				return;
			}

		}
		else if (gATCurrentAtSMSInfo[nSim].nStorage2 & CFW_SMS_STORAGE_ME)
		{
			/* bit1 flag of ME is "1", ME memfull */
#ifdef AT_DUAL_SIM
			if (CFW_SMS_STORAGE_ME == (g_SMS_CIND_MemFull[nSim] & CFW_SMS_STORAGE_ME))
#else
			if (CFW_SMS_STORAGE_ME == (g_SMS_CIND_MemFull & CFW_SMS_STORAGE_ME))
#endif
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_MEM_FULL, NULL, 0, "cmgw set mode: message buffer of ME is overflow",
				                  pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_MEM_FULL, NULL, 0, "cmgw set mode: message buffer of ME is overflow",
				                  pParam->nDLCI);
#endif
				return;
			}

		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, NULL, 0, "cmgw set mode: not support this storage", pParam->nDLCI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, NULL, 0, "cmgw set mode: not support this storage", pParam->nDLCI);
#endif
			return;
		}

		/***************************************
			**
			** Prompt input send message data
			**
			***************************************/
		if (pParam->pExData == NULL)
		{

			nFormat = gATCurrentAtSmsSettingSg_SMSFormat;

			// get param count
			nOperationRet = AT_Util_GetParaCount(pParam->pPara, &nParamCount);

			if ((nOperationRet != ERR_SUCCESS) || (nParamCount == 0) || (nParamCount > 3))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgw text mode: get param counter error", pParam->nDLCI,
				                  nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgw text mode: get param counter error", pParam->nDLCI);
#endif
				return;
			}

			if (!(nFormat == 0 || nFormat == 1))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgw text mode: Format exception", pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgw text mode: Format exception", pParam->nDLCI);
#endif
				return;
			}

			/******************************************************************
				**				nFormat==1
				******************************************************************/
			if (nFormat == 1)
			{

				/* set default value of status */
				AT_MemSet(&g_cmgw_cmgs, 0, sizeof(CFW_TELNUMBER));
				g_cmgw_cmgs.padding[0] = CFW_SMS_STORED_STATUS_UNSENT;

				// //////////////////////////////////////////
				// process different part according to para counts
				// //////////////////////////////////////////
				if (1 == nParamCount)
					goto CMGW_label_para1;

				if (2 == nParamCount)
					goto CMGW_label_para2;

				if (3 == nParamCount)
					goto CMGW_label_para3;

CMGW_label_para3:

				// /////////////////////////////////////////////////////////////////////////
				// para 3
				// ////////////////////////////////////////////////////////////////////////

				nParamLen     = 16;
				nOperationRet =
				    AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_STRING, (void *)(InputState), &nParamLen);

				/* Dial number can omit and set default value */
				if (ERR_AT_UTIL_CMD_PARA_NULL == nOperationRet)
				{
					AT_MemZero(InputState, 16);
					nParamLen = 0;
				}
				else
				{
					if (nOperationRet != ERR_SUCCESS)
					{
#ifdef AT_DUAL_SIM
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgw text mode: get param 3 error", pParam->nDLCI,
						                  nSim);
#else
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgw text mode: get param 3 error",
						                  pParam->nDLCI);
#endif
						return;
					}

					AT_StrUpr(InputState);
					if (!AT_SMS_StringOrDataToStatusMacroFlag(InputState, g_cmgw_cmgs.padding, nFormat))
					{
#ifdef AT_DUAL_SIM
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgw text mode: wrong status", pParam->nDLCI,
						                  nSim);
#else
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgw text mode: wrong status", pParam->nDLCI);
#endif
						return;
					}
				}

CMGW_label_para2:

				// /////////////////////////////////////////////////////////////////////////
				// para 2
				// ////////////////////////////////////////////////////////////////////////
				nParamLen = 1;

				nOperationRet =
				    AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, (void *)(&nDialNumType), &nParamLen);

				/* Dial number can omit and set default value */
				if (ERR_AT_UTIL_CMD_PARA_NULL == nOperationRet)
				{
					nDialNumType = CFW_TELNUMBER_TYPE_UNKNOWN;
				}
				else
				{
					if (nOperationRet != ERR_SUCCESS)
					{
#ifdef AT_DUAL_SIM
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgw text mode: get param 3 error", pParam->nDLCI,
						                  nSim);
#else
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgw text mode: get param 3 error",
						                  pParam->nDLCI);
#endif
						return;
					}
				}

				if ((nDialNumType != CFW_TELNUMBER_TYPE_INTERNATIONAL)
				        && (nDialNumType != CFW_TELNUMBER_TYPE_NATIONAL) && (nDialNumType != CFW_TELNUMBER_TYPE_UNKNOWN))
				{
					AT_MemSet(&g_cmgw_cmgs, 0, sizeof(CFW_TELNUMBER));
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgw text mode: wrong type of num", pParam->nDLCI,
					                  nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgw text mode: wrong type of num", pParam->nDLCI);
#endif
					return;
				}

CMGW_label_para1:
				// /////////////////////////////////////////////////////////////////////////
				// para 1
				// ////////////////////////////////////////////////////////////////////////
				nOperationRet =
				    AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, (void *)DialNumberBuff, &nDialNumberLen);

				/* cmgw: write message: dialnumber can be null and omit */
				if (ERR_AT_UTIL_CMD_PARA_NULL == nOperationRet)
				{
					AT_MemZero(DialNumberBuff, TEL_NUMBER_MAX_LEN);
					nDialNumberLen = 0;
				}
				else
				{
					if (nOperationRet != ERR_SUCCESS)
					{
#ifdef AT_DUAL_SIM
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgw text mode: get param 1 error", pParam->nDLCI,
						                  nSim);
#else
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgw text mode: get param 1 error",
						                  pParam->nDLCI);
#endif
						return;
					}
				}

				/* have dialnumber input and check it */
				if (0 != nDialNumberLen)
				{
					if (!AT_SMS_IsValidPhoneNumber(DialNumberBuff, nDialNumberLen, &bIsInternational))
					{
#ifdef AT_DUAL_SIM
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgw text mode: number invalid", pParam->nDLCI, nSim);
#else
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgw text mode: number invalid", pParam->nDLCI);
#endif
						return;
					}
				}

				if (bIsInternational)
				{
					nDialNumberLen--;
					if (nDialNumberLen > 20)
					{
#ifdef AT_DUAL_SIM
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgw text mode with '+': number len too long",
						                  pParam->nDLCI, nSim);
#else
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgw text mode with '+': number len too long",
						                  pParam->nDLCI);
#endif
						return;
					}
					else
					{
						if (nDialNumberLen)
						{
							g_cmgw_cmgs.nSize = SUL_AsciiToGsmBcd(&DialNumberBuff[1], nDialNumberLen, g_cmgw_cmgs.nTelNumber);
						}
					}
				}
				else
				{
					if (nDialNumberLen > 20)
					{
#ifdef AT_DUAL_SIM
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgw text mode without '+': number len too long",
						                  pParam->nDLCI, nSim);
#else
						AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgw text mode without '+': number len too long",
						                  pParam->nDLCI);
#endif
						return;
					}
					else
					{

						if (nDialNumberLen)
						{
							g_cmgw_cmgs.nSize = SUL_AsciiToGsmBcd(DialNumberBuff, nDialNumberLen, g_cmgw_cmgs.nTelNumber);
						}

					}
				}

				/* according to spec, we check dial number first */
				if (bIsInternational)
				{
					nDialNumType = CFW_TELNUMBER_TYPE_INTERNATIONAL;
				}
				else
				{
					if (0 == nDialNumType)
					{
						/* no input num type  */
						nDialNumType = CFW_TELNUMBER_TYPE_UNKNOWN;
					}
					else if (CFW_TELNUMBER_TYPE_INTERNATIONAL == nDialNumType)
					{
						/* have no '+' , but the num type is 145, replace 129 with is  */
						nDialNumType = CFW_TELNUMBER_TYPE_UNKNOWN;
					}
					else
					{
						/* get the input num type  */
					}
				}

				g_cmgw_cmgs.nType = nDialNumType;

			}

			/******************************************************************
				**				nFormat==0
				******************************************************************/
			else
			{

				if (nParamCount > 2)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode : get param counter exception",
					                  pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode : get param counter exception",
					                  pParam->nDLCI);
#endif
					return;
				}

				// set default value of status
				g_cmgw_cmgs_pdu_length = 0;
				g_cmgw_cmgs_pdu_status = CFW_SMS_STORED_STATUS_UNSENT;

				/******************************/
				// procedure this pdu imput message
				/******************************/
				if (1 == nParamCount)
					goto CMGW_PDU_label_para1;

				if (2 == nParamCount)
					goto CMGW_PDU_label_para2;

CMGW_PDU_label_para2:

				nParamLen = 1;

				nOperationRet =
				    AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, (void *)(&InputState[0]), &nParamLen);
				if (nOperationRet != ERR_SUCCESS)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode: get param 2 error", pParam->nDLCI,
					                  nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode: get param 2 error", pParam->nDLCI);
#endif
					return;
				}

				if (InputState[0] < 3)
				{
					g_cmgw_cmgs_pdu_status = 1 << (InputState[0]);
				}
				else if (InputState[0] == 3)
				{
					g_cmgw_cmgs_pdu_status = CFW_SMS_STORED_STATUS_SENT_NOT_SR_REQ;
				}
				else
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode: wrong status value", pParam->nDLCI,
					                  nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode: wrong status value", pParam->nDLCI);
#endif
					return;
				}

CMGW_PDU_label_para1:

				nParamLen = 1;

				nOperationRet =
				    AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, (void *)(&nPDUParamLen), &nParamLen);
				if (nOperationRet != ERR_SUCCESS)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode: get param 1 error", pParam->nDLCI,
					                  nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode: get param 1 error", pParam->nDLCI);
#endif
					return;
				}

				// in cmgw pdu lengt can be 0 but cmgs length!=0
				if ((nPDUParamLen > 164) || (nPDUParamLen == 0))
				{

#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode: nPDUParamLen > 164 ", pParam->nDLCI,
					                  nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode: nPDUParamLen > 164 ", pParam->nDLCI);
#endif
					return;
				}
				else
				{
					g_cmgw_cmgs_pdu_length = nPDUParamLen;

				}

			}

			// /////////////////////////////////////////////////////////////////////////////
			// display in the screen, and need input
			// /////////////////////////////////////////////////////////////////////////////
			PromptMsg[0] = CHAR_CR; //AT_GC_CfgGetS3Value();
			PromptMsg[1] = CHAR_LF; //AT_GC_CfgGetS4Value();
			AT_StrCat(PromptMsg, "> ");

			/* time  waiting for input sms data , set 180s now, if update we can change it */
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_WAIT_SMS, CMD_RC_OK, 180, (UINT8 *)PromptMsg, AT_StrLen(PromptMsg), pParam->nDLCI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_WAIT_SMS, CMD_RC_OK, 180, (UINT8 *)PromptMsg, AT_StrLen(PromptMsg), pParam->nDLCI);
#endif
			return;

		}

		/*******************************************
			 **
			 **  with msg body,input data process is starting
			 **
			*******************************************/
		else
		{
			if (pParam->pExData[pParam->iExDataLen - 1] == 27)  // end with esc, cancel write
			{
				AT_MemSet(&g_cmgw_cmgs, 0, sizeof(CFW_TELNUMBER));
#ifdef AT_DUAL_SIM
				AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
				AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
				return;
			}
			else if (pParam->pExData[pParam->iExDataLen - 1] != 26) // not end with ctl+z, err happen
			{
				AT_MemSet(&g_cmgw_cmgs, 0, sizeof(CFW_TELNUMBER));
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgw text mode data: msg body not end with ctrl+z",
				                  pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgw text mode data: msg body not end with ctrl+z",
				                  pParam->nDLCI);
#endif
				return;
			}

			nFormat = gATCurrentAtSmsSettingSg_SMSFormat;

			if (!(nFormat == 0 || nFormat == 1))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgw text mode data: Format exception", pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgw text mode data: Format exception", pParam->nDLCI);
#endif
				return;
			}

			// ///////////////////////////////
			// do text write message nFormat == 1
			// ///////////////////////////////
			if (nFormat == 1)
			{

				BOOL bParaVerifyErrorFlag = FALSE;

				pSmsMOInfo =
				    (CFW_SMS_MO_INFO_ADD *)AT_MALLOC(sizeof(CFW_SMS_MO_INFO_ADD) + g_cmgw_cmgs.nSize + pParam->iExDataLen - 1);

				if (!pSmsMOInfo)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgw text mode data: malloc is error", pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgw text mode data: malloc is error", pParam->nDLCI);
#endif
					return;

				}

				AT_MemSet(pSmsMOInfo, 0, sizeof(CFW_SMS_MO_INFO_ADD) + g_cmgw_cmgs.nSize + pParam->iExDataLen - 1);

				/* get dianumber information */
				pSmsMOInfo->sNumber.nType           = g_cmgw_cmgs.nType;
				pSmsMOInfo->sNumber.nDialNumberSize = g_cmgw_cmgs.nSize;

				if (g_cmgw_cmgs.nSize == 0)
				{
					pSmsMOInfo->sNumber.pDialNumber = (UINT8 *)AT_MALLOC(g_cmgw_cmgs.nSize);
					AT_MemZero(pSmsMOInfo->sNumber.pDialNumber, g_cmgw_cmgs.nSize);
				}
				else
				{
					pSmsMOInfo->sNumber.pDialNumber = (UINT8 *)((UINT8 *)pSmsMOInfo + sizeof(CFW_SMS_MO_INFO_ADD));
					AT_MemCpy(pSmsMOInfo->sNumber.pDialNumber, g_cmgw_cmgs.nTelNumber, g_cmgw_cmgs.nSize);

				}

				/* get SMS message content */
				pSmsMOInfo->nDataSize = pParam->iExDataLen - 1;
				pSmsMOInfo->pData     = (UINT8 *)((UINT8 *)pSmsMOInfo + sizeof(CFW_SMS_MO_INFO_ADD) + g_cmgw_cmgs.nSize);
				pSmsMOInfo->nStatus   = g_cmgw_cmgs.padding[0];
				pSmsMOInfo->nFormat   = nFormat;
				pSmsMOInfo->nLocation = gATCurrentAtSMSInfo[nSim].nStorage2;

				// just it is chinese message send or not

#ifdef AT_DUAL_SIM
				retForChinese = CFW_CfgGetSmsParam(&sInfoForChinese, 0, nSim);
#else
				retForChinese = CFW_CfgGetSmsParam(&sInfoForChinese, 0);

#endif

				if (retForChinese != ERR_SUCCESS)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgw text mode data: Get chinese info error",
					                  pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgw text mode data: Get chinese info error",
					                  pParam->nDLCI);
#endif
					AT_FREE(pSmsMOInfo);
					return;
				}

				/* Just for debug */
				AT_TC(g_sw_AT_SMS, "cmgw text mode: pParam->iExDataLen = %u", pParam->iExDataLen);

				/* according to the dcs value and judge */
				if (sInfoForChinese.dcs == 0)
				{
					if (pParam->iExDataLen - 1 > 160)
					{
						bParaVerifyErrorFlag = TRUE;
					}

					SmsDatalen   = pSmsMOInfo->nDataSize;
					pSmsDataBuff = pParam->pExData;

				}
				else if (sInfoForChinese.dcs == 4)
				{
					if (pParam->iExDataLen - 1 > 140)
					{
						bParaVerifyErrorFlag = TRUE;
					}

					SmsDatalen   = pSmsMOInfo->nDataSize;
					pSmsDataBuff = pParam->pExData;

				}
				else if (sInfoForChinese.dcs == 8)
				{

					UINT32 UCSlength       = 0;
					INT32 nLocal2UCSReturn = ERR_SUCCESS;

					UCSlength = SUL_CharacterLen(pParam->pExData, pParam->iExDataLen - 1);

					if (UCSlength == -1 || UCSlength - 1 > 70)
					{
						bParaVerifyErrorFlag = TRUE;
					}
					else
					{

						/* When send data to low layer, used uniform transport mode: big ending */
						//AT_Set_MultiLanguage();

						nLocal2UCSReturn =
						    ML_LocalLanguage2Unicode(pParam->pExData, pParam->iExDataLen - 1, &pUCS2Data, &nUCS2DataSize, NULL);

						if (ERR_SUCCESS != nLocal2UCSReturn)
						{
							nLocal2UCSReturn = AT_SMS_ERR_Change(nLocal2UCSReturn);
#ifdef AT_DUAL_SIM
							AT_SMS_Result_Err(nLocal2UCSReturn, NULL, 0, "cmgw text mode data: local to ucs error", pParam->nDLCI,
							                  nSim);
#else
							AT_SMS_Result_Err(nLocal2UCSReturn, NULL, 0, "cmgw text mode data: local to ucs error", pParam->nDLCI);
#endif
							return;
						}

						// get message context
						SmsDatalen   = nUCS2DataSize;
						pSmsDataBuff = pUCS2Data;

					}
				}

				if (bParaVerifyErrorFlag)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgw text mode data: input data's length error",
					                  pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgw text mode data: input data's length error",
					                  pParam->nDLCI);
#endif
					AT_FREE(pSmsMOInfo);
					return;
				}

				/* just for debug */
				AT_TC(g_sw_AT_SMS, "Text mode data to need to write: SmsDatalen = %u", SmsDatalen);
				AT_TC_MEMBLOCK(g_sw_AT_SMS, pSmsDataBuff, SmsDatalen, 16);

				// pSmsMOInfo->sNumber.pDialNumber
				AT_TC_MEMBLOCK(g_sw_AT_SMS, pSmsMOInfo->sNumber.pDialNumber, pSmsMOInfo->sNumber.nDialNumberSize, 16);

				// wulc add begin 2011-12-28
				SmsWrite.sNumber   = pSmsMOInfo->sNumber;
				SmsWrite.pData     = pSmsDataBuff;
				SmsWrite.nDataSize = SmsDatalen;
				SmsWrite.nStorage  = pSmsMOInfo->nLocation;
				SmsWrite.nStatus   = pSmsMOInfo->nStatus;
				SmsWrite.nIndex    = 0;
				SmsWrite.nType     = CFW_SMS_TYPE_PP;

				// end
				AT_TC_MEMBLOCK(g_sw_AT_SMS, SmsWrite.sNumber.pDialNumber, SmsWrite.sNumber.nDialNumberSize, 16);

				// wulc  20110524
#ifdef AT_DUAL_SIM

				nWriteMsgRet = CFW_SmsWriteMessage(&SmsWrite, pParam->nDLCI, nSim);
#else
				nWriteMsgRet = CFW_SmsWriteMessage(&pSmsMOInfo->sNumber, pSmsDataBuff,
				                                   SmsDatalen, pSmsMOInfo->nLocation, 0, pSmsMOInfo->nStatus, pParam->nDLCI);

#endif

				// Free inout para resource
				AT_FREE(pUCS2Data);

			}

			// ////////////////////////////////////////
			// pdu write message procedure nFormat == 0
			// ////////////////////////////////////////
			else
			{
				// judge the max data len is valid
				if (pParam->iExDataLen > 353)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode data: iExDataLen>353 error",
					                  pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode data: iExDataLen>353 error",
					                  pParam->nDLCI);
#endif
					return;
				}

				pParam->iExDataLen = SMS_PDUAsciiToBCD((pParam->pExData), pParam->iExDataLen - 1, BCDDataBuff);

				if (pParam->iExDataLen == 0)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode data: iExDataLen is 0 ",
					                  pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode data: iExDataLen is 0 ",
					                  pParam->nDLCI);
#endif
					return;
				}

				// check param1(length:TP DATA UNIT) pdu length not include sca length
				if (pParam->iExDataLen != g_cmgw_cmgs_pdu_length + 1 + BCDDataBuff[0])
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0,
					                  "cmgw pdu mode data: input pdu data length not match", pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0,
					                  "cmgw pdu mode data: input pdu data length not match", pParam->nDLCI);
#endif
					return;
				}

				pSmsMOInfo = (CFW_SMS_MO_INFO_ADD *)AT_MALLOC(sizeof(CFW_SMS_MO_INFO_ADD) + AT_SMS_BODY_BUFF_LEN);

				if (!pSmsMOInfo)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgw pdu mode data: malloc is error 22", pParam->nDLCI,
					                  nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgw pdu mode data: malloc is error 22", pParam->nDLCI);
#endif
					return;
				}

				AT_MemSet(pSmsMOInfo, 0, (sizeof(CFW_SMS_MO_INFO_ADD) + AT_SMS_BODY_BUFF_LEN));

				pSmsMOInfo->nDataSize = pParam->iExDataLen; // -1?;
				pSmsMOInfo->pData     = (UINT8 *)((UINT8 *)pSmsMOInfo + sizeof(CFW_SMS_MO_INFO_ADD));
				pSmsMOInfo->nStatus   = g_cmgw_cmgs_pdu_status;
				pSmsMOInfo->nLocation = gATCurrentAtSMSInfo[nSim].nStorage2;

#ifdef AT_DUAL_SIM
				if (!(SMS_AddSCA2PDU(BCDDataBuff, pSmsMOInfo->pData, &(pSmsMOInfo->nDataSize), nSim)))
#else
				if (!(SMS_AddSCA2PDU(BCDDataBuff, pSmsMOInfo->pData, &(pSmsMOInfo->nDataSize))))
#endif
				{
					AT_FREE(pSmsMOInfo);
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode data: AddSCA2PDU error",
					                  pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgw pdu mode data: AddSCA2PDU error",
					                  pParam->nDLCI);
#endif
					return;
				}

				// check it add one sca or not
				if (!AT_SMS_CheckPDUIsValid(pSmsMOInfo->pData, (UINT8 *) & (pSmsMOInfo->nDataSize), FALSE))
				{
					AT_FREE(pSmsMOInfo);
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "cmgw pdu mode data: check pdu is invalid",
					                  pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "cmgw pdu mode data: check pdu is invalid",
					                  pParam->nDLCI);
#endif
					return;
				}

				/* just for debug */
				AT_TC(g_sw_AT_SMS, "Pdu mode data to need to write: pSmsMOInfo->nDataSize = %u", pSmsMOInfo->nDataSize);
				AT_TC_MEMBLOCK(g_sw_AT_SMS, pSmsMOInfo->pData, pSmsMOInfo->nDataSize, 16);

				/* get the UTI and free it after finished calling */

				// starting write message

				// SmsWrite.sNumber = pSmsMOInfo->sNumber =;
				SmsWrite.pData     = pSmsMOInfo->pData;
				SmsWrite.nDataSize = pSmsMOInfo->nDataSize;
				SmsWrite.nStorage  = pSmsMOInfo->nLocation;
				SmsWrite.nStatus   = pSmsMOInfo->nStatus;
				SmsWrite.nIndex    = 0;
				SmsWrite.nType     = CFW_SMS_TYPE_PP;
#ifdef AT_DUAL_SIM
				nWriteMsgRet = CFW_SmsWriteMessage(&SmsWrite, pParam->nDLCI, nSim);
#else
				nWriteMsgRet = CFW_SmsWriteMessage(NULL, pSmsMOInfo->pData, pSmsMOInfo->nDataSize,
				                                   pSmsMOInfo->nLocation, 0, pSmsMOInfo->nStatus, pParam->nDLCI);

#endif
			}

			// //////////////////////////////////////////////////////////////////
			// sms:    write message result: text mode and pdu mode
			// /////////////////////////////////////////////////////////////////
			if (nWriteMsgRet == ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
				AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
			}
			else
			{
				nWriteMsgRet = AT_SMS_ERR_Change(nWriteMsgRet);
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(nWriteMsgRet, NULL, 0, "cmgw data: write message check param error", pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(nWriteMsgRet, NULL, 0, "cmgw data: write message check param error", pParam->nDLCI);
#endif
			}

			AT_FREE(pSmsMOInfo);

			return;

		}

		break;

	case AT_CMD_EXE:

		/***************************************************/
		/* return error if the buff is overflow, and check "SM" storage */
		/* and "ME" storage eparately, 2008.07.03, by wangqy           */
		/***************************************************/
		if (gATCurrentAtSMSInfo[nSim].nStorage2 & CFW_SMS_STORAGE_SM)
		{

			/* bit0 flag of SM is "1", SM memfull */
#ifdef AT_DUAL_SIM
			if (CFW_SMS_STORAGE_SM == (g_SMS_CIND_MemFull[nSim] & CFW_SMS_STORAGE_SM))
#else
			if (CFW_SMS_STORAGE_SM == (g_SMS_CIND_MemFull & CFW_SMS_STORAGE_SM))
#endif
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_MEM_FULL, NULL, 0, "cmgw exe mode: message buffer of SM is overflow",
				                  pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_MEM_FULL, NULL, 0, "cmgw exe mode: message buffer of SM is overflow",
				                  pParam->nDLCI);
#endif
				return;
			}

		}
		else if (gATCurrentAtSMSInfo[nSim].nStorage2 & CFW_SMS_STORAGE_ME)
		{
			/* bit1 flag of ME is "1", ME memfull */
#ifdef AT_DUAL_SIM
			if (CFW_SMS_STORAGE_ME == (g_SMS_CIND_MemFull[nSim] & CFW_SMS_STORAGE_ME))
#else
			if (CFW_SMS_STORAGE_ME == (g_SMS_CIND_MemFull & CFW_SMS_STORAGE_ME))
#endif
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_MEM_FULL, NULL, 0, "cmgw exe mode: message buffer of ME is overflow",
				                  pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_MEM_FULL, NULL, 0, "cmgw exe mode: message buffer of ME is overflow",
				                  pParam->nDLCI);
#endif
				return;
			}

		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, NULL, 0, "cmgw exe mode: not support this storage", pParam->nDLCI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, NULL, 0, "cmgw exe mode: not support this storage", pParam->nDLCI);
#endif
			return;
		}

		{
			// /////////////////////////////////////////////////////////////////////////////
			// display in the screen, and write null message in the text mode
			// /////////////////////////////////////////////////////////////////////////////
			CFW_DIALNUMBER NumBuff = { 0 };

			// UINT8 DataBuff[8] = {0};

			PromptMsg[0] = CHAR_CR; //AT_GC_CfgGetS3Value();
			PromptMsg[1] = CHAR_LF; //AT_GC_CfgGetS4Value();
			AT_StrCat(PromptMsg, "> ");
			PromptMsg[AT_StrLen(PromptMsg)] = 0x1A; /* ctrl+Z */
			PromptMsg[AT_StrLen(PromptMsg)] = '\0'; /* end of the string */

			/* no time delay in this case */
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, (UINT8 *)PromptMsg, AT_StrLen(PromptMsg), pParam->nDLCI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, (UINT8 *)PromptMsg, AT_StrLen(PromptMsg), pParam->nDLCI);
#endif
			/* set value of NumBuff */
			NumBuff.nType       = CFW_TELNUMBER_TYPE_UNKNOWN;
			NumBuff.pDialNumber = (UINT8 *)AT_MALLOC(0);
			AT_MemZero(NumBuff.pDialNumber, 0);

			/* Text mode have execute mode */
			if (gATCurrentAtSmsSettingSg_SMSFormat)
			{
				SmsWrite.sNumber   = NumBuff;
				SmsWrite.pData     = NULL;
				SmsWrite.nDataSize = 0;
				SmsWrite.nStorage  = gATCurrentAtSMSInfo[nSim].nStorage2;
				SmsWrite.nStatus   = CFW_SMS_STORED_STATUS_UNSENT;
				SmsWrite.nIndex    = 0;
				SmsWrite.nType     = CFW_SMS_TYPE_PP;

#ifdef AT_DUAL_SIM

				nWriteMsgRet = CFW_SmsWriteMessage(&SmsWrite, pParam->nDLCI, nSim);
#else
				nWriteMsgRet = CFW_SmsWriteMessage(&NumBuff, DataBuff,
				                                   0,
				                                   gATCurrentAtSMSInfo[nSim].nStorage2,
				                                   0, CFW_SMS_STORED_STATUS_UNSENT, pParam->nDLCI);
#endif

			}

			/* PDU mode have execute mode */
			else
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, NULL, 0, "cmgw exe mode: pdu mode can't write NULL msg",
				                  pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, NULL, 0, "cmgw exe mode: pdu mode can't write NULL msg",
				                  pParam->nDLCI);
#endif
				return;
			}

			// //////////////////////////////////////////////////////////////////
			// sms:    write message result: text mode and pdu mode
			// /////////////////////////////////////////////////////////////////
			if (nWriteMsgRet == ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
				AT_SMS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
			}
			else
			{
				nWriteMsgRet = AT_SMS_ERR_Change(nWriteMsgRet);
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(nWriteMsgRet, NULL, 0, "cmgw exe mode: write NULL msg check param error", pParam->nDLCI,
				                  nSim);
#else
				AT_SMS_Result_Err(nWriteMsgRet, NULL, 0, "cmgw exe mode: write NULL msg check param error", pParam->nDLCI);
#endif
			}

		}

		break;
	case AT_CMD_TEST:

#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cmgw default: wrong cmd mode", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cmgw default: wrong cmd mode", pParam->nDLCI);
#endif
		break;;
	}

	return;

} // end with msg

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CPMS
Description		:   	CPMS procedure function
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CPMS(AT_CMD_PARA *pParam)
{

	CFW_EVENT nCfwEvent = {0,};
	CFW_SMS_STORAGE_INFO sStorageInfo = { 0 };
	UINT8 MemBuff[8]                  = { 0 };
	UINT8 nParamLen                   = 5;
	UINT8 nParamCount                 = 0;

	UINT8 PromptBuff[64] = { 0 };
	UINT8 nStorage1Last  = 0;
	UINT8 nStorage2Last  = 0;
	UINT8 nStorage3Last  = 0;

	UINT32 nOperationRet = ERR_SUCCESS;
	BOOL bReturn         = FALSE;

	UINT8 ReadMem1[3] = { 0 };
	UINT8 ReadMem2[3] = { 0 };
	UINT8 ReadMem3[3] = { 0 };

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
	nCfwEvent.nFlag = nSim;
#endif

	AT_ASSERT(NULL != pParam);

	bReturn = AT_GetCfwInitSmsInfo(&nCfwEvent);
	if ((!bReturn) || (nCfwEvent.nParam1 == 1))
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cpms: AT_GetCfwInitSmsInfo() false", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cpms: AT_GetCfwInitSmsInfo() false", pParam->nDLCI);
#endif
		return;
	}

	// ///////////////////////////////////////////
	// command execute mode
	// //////////////////////////////////////////
	switch (pParam->iType)
	{
	case AT_CMD_SET:

		nStorage1Last = gATCurrentAtSMSInfo[nSim].nStorage1;
		nStorage2Last = gATCurrentAtSMSInfo[nSim].nStorage2;
		nStorage3Last = gATCurrentAtSMSInfo[nSim].nStorage3;

		nOperationRet = AT_Util_GetParaCount(pParam->pPara, &nParamCount);

		if (nOperationRet != ERR_SUCCESS || (nParamCount == 0) || (nParamCount > 3))
		{
			nOperationRet = ERR_AT_CMS_INVALID_PARA;
		}

		// /////////////////////////////////////////////
		// para1, para 2 and para3 process these code
		// ////////////////////////////////////////////
		if (nOperationRet == ERR_SUCCESS && nParamCount > 0)
		{
			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, (void *)MemBuff, &nParamLen);

			if (nOperationRet == ERR_SUCCESS)
			{

				AT_StrUpr(MemBuff);

				if (!strcmp(MemBuff, "ME"))
				{
					gATCurrentAtSMSInfo[nSim].nStorage1 = CFW_SMS_STORAGE_ME;
				}
				else if (!strcmp(MemBuff, "SM"))
				{
					gATCurrentAtSMSInfo[nSim].nStorage1 = CFW_SMS_STORAGE_SM;
				}
				else
				{
					nOperationRet = ERR_AT_CMS_INVALID_PARA;
				}

				if (ERR_SUCCESS == nOperationRet)
				{

#ifdef AT_DUAL_SIM
					nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage1, nSim);

#else
					nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage1);

#endif
					if (ERR_SUCCESS == nOperationRet)
					{
						gATCurrentAtSMSInfo[nSim].nTotal1 = sStorageInfo.totalSlot;
						gATCurrentAtSMSInfo[nSim].nUsed1  = sStorageInfo.usedSlot;

					}
					else
					{
						nOperationRet = ERR_AT_CMS_MEM_FAIL;
					}
				}
			}
		}

		// /////////////////////////////////////////////
		// para 2 and para3 process these code
		// ////////////////////////////////////////////
		if (nOperationRet == ERR_SUCCESS && nParamCount > 1)
		{
			nParamLen = 5;
			AT_MemSet(MemBuff, 0, 8);
			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, (void *)MemBuff, &nParamLen);

			if (nOperationRet == ERR_SUCCESS)
			{
				AT_StrUpr(MemBuff);

				if (!strcmp(MemBuff, "ME"))
				{
					gATCurrentAtSMSInfo[nSim].nStorage2 = CFW_SMS_STORAGE_ME;
				}
				else if (!strcmp(MemBuff, "SM"))
				{
					gATCurrentAtSMSInfo[nSim].nStorage2 = CFW_SMS_STORAGE_SM;
				}
				else
				{
					nOperationRet = ERR_AT_CMS_INVALID_PARA;
				}

				if (ERR_SUCCESS == nOperationRet)
				{

#ifdef AT_DUAL_SIM
					nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage2, nSim);

#else
					nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage2);

#endif
					if (ERR_SUCCESS == nOperationRet)
					{
						gATCurrentAtSMSInfo[nSim].nTotal2 = sStorageInfo.totalSlot;
						gATCurrentAtSMSInfo[nSim].nUsed2  = sStorageInfo.usedSlot;

					}
					else
					{
						nOperationRet = ERR_AT_CMS_MEM_FAIL;
					}
				}
			}
		}

		// /////////////////////////////////////////////
		// para3 process these code
		// ////////////////////////////////////////////
		if (nOperationRet == ERR_SUCCESS && nParamCount > 2)
		{
			nParamLen = 5;
			AT_MemSet(MemBuff, 0, 8);
			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_STRING, (void *)MemBuff, &nParamLen);

			if (nOperationRet == ERR_SUCCESS)
			{
				AT_StrUpr(MemBuff);

				if (!strcmp(MemBuff, "ME"))
				{
					gATCurrentAtSMSInfo[nSim].nStorage3 = CFW_SMS_STORAGE_ME;
				}
				else if (!strcmp(MemBuff, "SM"))
				{
					gATCurrentAtSMSInfo[nSim].nStorage3 = CFW_SMS_STORAGE_SM;
				}
				else
				{
					nOperationRet = ERR_AT_CMS_INVALID_PARA;
				}

				if (ERR_SUCCESS == nOperationRet)
				{
					UINT8 nOption        = 0;
					UINT8 nNewSmsStorage = 0;

#ifdef AT_DUAL_SIM

					nOperationRet = CFW_CfgGetNewSmsOption(&nOption, &nNewSmsStorage, nSim);
					nOperationRet = CFW_CfgSetNewSmsOption(nOption, gATCurrentAtSMSInfo[nSim].nStorage3, nSim);
					nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage3, nSim);
#else
					nOperationRet = CFW_CfgGetNewSmsOption(&nOption, &nNewSmsStorage);
					nOperationRet = CFW_CfgSetNewSmsOption(nOption, gATCurrentAtSMSInfo[nSim].nStorage3);
					nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage3);
#endif

					if (ERR_SUCCESS == nOperationRet)
					{
						gATCurrentAtSMSInfo[nSim].nTotal3 = sStorageInfo.totalSlot;
						gATCurrentAtSMSInfo[nSim].nUsed3  = sStorageInfo.usedSlot;
					}
					else
					{
						nOperationRet = ERR_AT_CMS_MEM_FAIL;
					}
				}

			}

		}

		if (ERR_SUCCESS == nOperationRet)
		{

			AT_Sprintf(PromptBuff, "+CPMS: %u,%u,%u,%u,%u,%u",
			           gATCurrentAtSMSInfo[nSim].nUsed1,
			           gATCurrentAtSMSInfo[nSim].nTotal1,
			           gATCurrentAtSMSInfo[nSim].nUsed2,
			           gATCurrentAtSMSInfo[nSim].nTotal2, gATCurrentAtSMSInfo[nSim].nUsed3, gATCurrentAtSMSInfo[nSim].nTotal3);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, PromptBuff, (UINT16)AT_StrLen(PromptBuff), pParam->nDLCI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, PromptBuff, (UINT16)AT_StrLen(PromptBuff), pParam->nDLCI);
#endif
			return;
		}
		else
		{

			gATCurrentAtSMSInfo[nSim].nStorage1 = nStorage1Last;
			gATCurrentAtSMSInfo[nSim].nStorage2 = nStorage2Last;
			gATCurrentAtSMSInfo[nSim].nStorage3 = nStorage3Last;
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "cpms set mode: CfgGetSmsStorageInfo() exception", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "cpms set mode: CfgGetSmsStorageInfo() exception", pParam->nDLCI);
#endif
			return;
		}

		break;

	case AT_CMD_READ:
		// ///////////////////////////////
		/* read mem1 buffer                        */
		// ///////////////////////////////

#ifdef AT_DUAL_SIM
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage1, nSim);
#else
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage1);

#endif
		if (ERR_SUCCESS == nOperationRet)
		{
			gATCurrentAtSMSInfo[nSim].nTotal1 = sStorageInfo.totalSlot;
			gATCurrentAtSMSInfo[nSim].nUsed1  = sStorageInfo.usedSlot;

		}
		else
		{
			nOperationRet = ERR_AT_CMS_MEM_FAIL;
		}

		if (gATCurrentAtSMSInfo[nSim].nStorage1 & CFW_SMS_STORAGE_ME)
		{
			strcpy(ReadMem1, "ME");
		}
		else if (gATCurrentAtSMSInfo[nSim].nStorage1 & CFW_SMS_STORAGE_SM)
		{
			strcpy(ReadMem1, "SM");
		}

		// ///////////////////////////////
		/* read mem2 buffer                        */
		// ///////////////////////////////

#ifdef AT_DUAL_SIM
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage2, nSim);
#else
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage2);

#endif
		if (ERR_SUCCESS == nOperationRet)
		{
			gATCurrentAtSMSInfo[nSim].nTotal2 = sStorageInfo.totalSlot;
			gATCurrentAtSMSInfo[nSim].nUsed2  = sStorageInfo.usedSlot;
		}
		else
		{
			nOperationRet = ERR_AT_CMS_MEM_FAIL;
		}

		if (gATCurrentAtSMSInfo[nSim].nStorage2 & CFW_SMS_STORAGE_ME)
		{
			strcpy(ReadMem2, "ME");
		}
		else if (gATCurrentAtSMSInfo[nSim].nStorage2 & CFW_SMS_STORAGE_SM)
		{
			strcpy(ReadMem2, "SM");
		}

		// ///////////////////////////////
		/* read mem3 buffer                        */
		// ///////////////////////////////

#ifdef AT_DUAL_SIM
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage3, nSim);
#else
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage3);

#endif
		if (ERR_SUCCESS == nOperationRet)
		{
			gATCurrentAtSMSInfo[nSim].nTotal3 = sStorageInfo.totalSlot;
			gATCurrentAtSMSInfo[nSim].nUsed3  = sStorageInfo.usedSlot;
		}
		else
		{
			nOperationRet = ERR_AT_CMS_MEM_FAIL;
		}

		if (gATCurrentAtSMSInfo[nSim].nStorage3 & CFW_SMS_STORAGE_ME)
		{
			strcpy(ReadMem3, "ME");
		}
		else if (gATCurrentAtSMSInfo[nSim].nStorage3 & CFW_SMS_STORAGE_SM)
		{
			strcpy(ReadMem3, "SM");
		}

		if (ERR_SUCCESS == nOperationRet)
		{
			AT_Sprintf(PromptBuff, "+CPMS: \"%s\",%u,%u,\"%s\",%u,%u,\"%s\",%u,%u",
			           ReadMem1,
			           gATCurrentAtSMSInfo[nSim].nUsed1,
			           gATCurrentAtSMSInfo[nSim].nTotal1,
			           ReadMem2,
			           gATCurrentAtSMSInfo[nSim].nUsed2,
			           gATCurrentAtSMSInfo[nSim].nTotal2, ReadMem3, gATCurrentAtSMSInfo[nSim].nUsed3, gATCurrentAtSMSInfo[nSim].nTotal3);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, PromptBuff, (UINT16)AT_StrLen(PromptBuff), pParam->nDLCI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, PromptBuff, (UINT16)AT_StrLen(PromptBuff), pParam->nDLCI);
#endif
			return;
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cpms read mode: CfgGetSmsStorageInfo() exception", pParam->nDLCI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cpms read mode: CfgGetSmsStorageInfo() exception", pParam->nDLCI);
#endif
			return;
		}

		break;

	case AT_CMD_TEST:

		AT_Sprintf(PromptBuff, "+CPMS: (\"ME\",\"SM\"),(\"ME\",\"SM\"),(\"ME\",\"SM\")");
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, PromptBuff, (UINT16)AT_StrLen(PromptBuff), pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CCMD_FUNC_SUCC, CMD_RC_OK, 0, PromptBuff, (UINT16)AT_StrLen(PromptBuff), pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cpms: wrong cmd mode", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cpms: wrong cmd mode", pParam->nDLCI);
#endif
		break;

	}

	return;

}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CMGL
Description		:   	CMGL procedure function
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CMGL(AT_CMD_PARA *pParam)
{
	CFW_EVENT nCfwEvent = {0,};
	CFW_SMS_LIST ListInfo;

	CFW_SMS_MO_INFO_ADD *pSmsMOInfo = NULL;
	CFW_SMS_STORAGE_INFO sStorageInfo = { 0 };

	UINT8 nParamCount    = 0;
	UINT8 nFormat        = 0;
	UINT32 nOperationRet = ERR_SUCCESS;
	UINT32 nListMsgRet   = ERR_SUCCESS;
	BOOL bReturn         = FALSE;
	UINT8 nState[16]     = { 0 };
	UINT8 nParamLen      = 0;
	UINT8 PromptBuff[64] = { 0 };
	UINT8 nUTI           = pParam->nDLCI; // change by wulc

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
	nCfwEvent.nFlag = nSim;
#endif

	AT_ASSERT(NULL != pParam);

	g_SMS_CurCmdStamp = pParam->uCmdStamp;
	bReturn           = AT_GetCfwInitSmsInfo(&nCfwEvent);

	if ((!bReturn) || (nCfwEvent.nParam1 == 1))
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgl: AT_GetCfwInitSmsInfo() failure", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgl: AT_GetCfwInitSmsInfo() failure", pParam->nDLCI);
#endif
		return;
	}

	nFormat = gATCurrentAtSmsSettingSg_SMSFormat;

#ifdef AT_DUAL_SIM
	nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage1, nSim);
#else
	nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage1);

#endif

	if (ERR_SUCCESS == nOperationRet)
	{
		gATCurrentAtSMSInfo[nSim].nTotal1 = sStorageInfo.totalSlot;
		gATCurrentAtSMSInfo[nSim].nUsed1  = sStorageInfo.usedSlot;
	}

	/* debug for current storage total and used slot */
	AT_TC(g_sw_AT_SMS, "gATCurrentAtSMSInfo[%d].nTotal1 = %u", nSim, gATCurrentAtSMSInfo[nSim].nTotal1);
	AT_TC(g_sw_AT_SMS, "gATCurrentAtSMSInfo[%d].nUsed1 = %u", nSim, gATCurrentAtSMSInfo[nSim].nUsed1);

	if ((nOperationRet != ERR_SUCCESS) || (nFormat > 1))
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgl: Get sms storage or nFormat error", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgl: Get sms storage or nFormat error", pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{

	case AT_CMD_SET:

		nOperationRet = AT_Util_GetParaCount(pParam->pPara, &nParamCount);

		if (nOperationRet != ERR_SUCCESS || nParamCount != 1)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgl: set mode get param counter error", pParam->nDLCI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgl: set mode get param counter error", pParam->nDLCI);
#endif
			return;
		}

		if (nFormat)
		{
			nParamLen     = 16;
			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, (void *)(nState), &nParamLen);
			if (nOperationRet != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgl text mode: get param error", pParam->nDLCI,
				                  nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgl text mode: get param error", pParam->nDLCI);
#endif
				return;
			}

			AT_StrUpr(nState);

			if (!AT_SMS_StringOrDataToStatusMacroFlag(nState, nState, nFormat))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgl text mode: StatusMacroFlagToStringOrData 1",
				                  pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgl text mode: StatusMacroFlagToStringOrData 1",
				                  pParam->nDLCI);
#endif
				return;
			}

		}
		else  // pdu mode, state in int mode
		{
			nParamLen = 1;

			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, (void *)nState, &nParamLen);

			if (nOperationRet != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgl pdu mode: get param error", pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgl pdu mode: get param error", pParam->nDLCI);
#endif
				return;
			}

			if (!AT_SMS_StringOrDataToStatusMacroFlag(nState, nState, nFormat))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgl pdu mode: StatusMacroFlagToStringOrData 2",
				                  pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_PARAM, NULL, 0, "cmgl pdu mode: StatusMacroFlagToStringOrData 2",
				                  pParam->nDLCI);
#endif
				return;
			}

		}

		// //////////////////////////////////////////////////////////////////////////
		// 1. list status is: READ, but readRecords is 0, return OK immediately
		// 2. list status is: UNREAD, but unReadRecords is 0, return OK immediately
		// 3. list status is: SENT, but sentRecords is 0, return OK immediately
		// 4. list status is: UNSENT, but unsentRecords is 0, return OK immediately
		// 5. list status is: ALL, but usedSlot is 0, return OK immediately
		// /////////////////////////////////////////////////////////////////////////
		if (((CFW_SMS_STORED_STATUS_READ == nState[0]) && (0 == sStorageInfo.readRecords))
		        || ((CFW_SMS_STORED_STATUS_UNREAD == nState[0]) && (0 == sStorageInfo.unReadRecords))
		        || (((CFW_SMS_STORED_STATUS_SENT_NOT_SR_REQ & nState[0]) != 0) && (0 == sStorageInfo.sentRecords))
		        || ((CFW_SMS_STORED_STATUS_UNSENT == nState[0]) && (0 == sStorageInfo.unsentRecords))
		        || ((CFW_SMS_STORED_STATUS_STORED_ALL == nState[0]) && (0 == sStorageInfo.usedSlot)))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
			return;
		}

		pSmsMOInfo = (CFW_SMS_MO_INFO_ADD *)AT_MALLOC(sizeof(CFW_SMS_MO_INFO_ADD));
		if (!pSmsMOInfo)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgl: malloc memory error 1", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgl: malloc memory error 1", pParam->nDLCI);
#endif
			return;
		}

		AT_MemSet(pSmsMOInfo, 0, sizeof(CFW_SMS_MO_INFO_ADD));

		// //////////////////////////////////////////////////////
		// set list message para value
		// /////////////////////////////////////////////////////

		UINT16 nUsedSlot = 0x00;
		UINT16 nMaxSlot = 0x00;
		UINT8 nStatusStorageInfo = nState[0];

		if(nStatusStorageInfo == CFW_SMS_STORED_STATUS_STORED_ALL)
			nStatusStorageInfo = 0x7f;

		SMS_GetStorageInfoEX(&nUsedSlot, &nMaxSlot, nSim, nStatusStorageInfo);

		pSmsMOInfo->i        = 0x00;
		ListInfo.nStorage    = pSmsMOInfo->nLocation = gATCurrentAtSMSInfo[nSim].nStorage1;

		ListInfo.nCount      = pSmsMOInfo->nListCount = nUsedSlot;//sStorageInfo.totalSlot;
		ListInfo.nStatus     = pSmsMOInfo->nStatus = nState[0];
		ListInfo.nStartIndex = pSmsMOInfo->nListStartIndex = 1;
		ListInfo.nType       = CFW_SMS_TYPE_PP;
		ListInfo.nOption     = CFW_SMS_LIST_OPTION__TIME_DESCEND_ORDER;


		AT_TC(g_sw_AT_SMS, "ListInfo.nCount = %d ListInfo.nStatus %d", ListInfo.nCount, ListInfo.nStatus);

		/* get the UTI and free it after finished calling */
		if (0 == (nUTI = AT_AllocUserTransID()))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgl: malloc UTI error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgl: malloc UTI error", pParam->nDLCI);
#endif
			return;
		}
#ifdef AT_DUAL_SIM

		nListMsgRet = CFW_SmsListMessages(&ListInfo, pParam->nDLCI, nSim);
#else
		nListMsgRet = CFW_SmsListMessages(pSmsMOInfo->nLocation, pSmsMOInfo->nStatus, pSmsMOInfo->nListCount,
		                                  pSmsMOInfo->nListStartIndex, 1, pParam->nDLCI);

#endif
		AT_TC(g_sw_AT_SMS, "cmgl: pParam->nDLCI %d", pParam->nDLCI);


		AT_FreeUserTransID(nUTI);

		if (nListMsgRet != ERR_SUCCESS)
		{
			AT_FREE(pSmsMOInfo);

			nListMsgRet = AT_SMS_ERR_Change(nListMsgRet);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(nListMsgRet, NULL, 0, "cmgl: set mode list msg check param error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(nListMsgRet, NULL, 0, "cmgl: set mode list msg check param error", pParam->nDLCI);
#endif

			return;
		}
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
		AT_FREE(pSmsMOInfo);

		break;
	case AT_CMD_EXE:
	{
		/* if the unReadRecords is 0, return OK immediately */
		if (0 == sStorageInfo.unReadRecords)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
			return;
		}

		/* get the UTI and free it after finished calling */
		if (0 == (nUTI = AT_AllocUserTransID()))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgl: exe mode malloc UTI error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgl: exe mode malloc UTI error", pParam->nDLCI);
#endif
			return;
		}
#ifdef AT_DUAL_SIM

		nListMsgRet = CFW_SmsListMessages(&ListInfo, pParam->nDLCI, nSim);
#else
		nListMsgRet = CFW_SmsListMessages(gATCurrentAtSMSInfo[nSim].nStorage1, CFW_SMS_STORED_STATUS_UNREAD,
		                                  sStorageInfo.totalSlot, 1, 1, pParam->nDLCI);

#endif

		AT_FreeUserTransID(nUTI);

		if (nListMsgRet != ERR_SUCCESS)
		{
			nListMsgRet = AT_SMS_ERR_Change(nListMsgRet);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(nListMsgRet, NULL, 0, "cmgl: exe mode list msg check param error ", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(nListMsgRet, NULL, 0, "cmgl: exe mode list msg check param error ", pParam->nDLCI);
#endif
			return;
		}
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
		break;
	}

	case AT_CMD_TEST:

		if (nFormat)
		{
			AT_Sprintf(PromptBuff, "+CMGL: (\"REC UNREAD\",\"REC READ\",\"STO UNSENT\",\"STO SENT\",\"ALL\")");
		}
		else
		{
			AT_Sprintf(PromptBuff, "+CMGL: (0-4)");
		}
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, PromptBuff, (UINT16)AT_StrLen(PromptBuff), pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, PromptBuff, (UINT16)AT_StrLen(PromptBuff), pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cmgl: wrong cmd mode", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cmgl: wrong cmd mode", pParam->nDLCI);
#endif
		break;

	}

	return;

}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CSCA
Description		:   	CSCA procedure function
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CSCA(AT_CMD_PARA *pParam)
{

	CFW_EVENT sCfwEvent         = { 0 };
	UINT8 InputSCABuff[32]      = { 0 };
	CFW_SMS_PARAMETER sParaInfo = { 0 };
	UINT8 *pSCANumBuff          = NULL;
	UINT8 nTypeOfSCA            = 0;

	UINT8 PromptBuff[128] = { 0 };
	UINT8 nParamCount     = 0;
	UINT8 nParamLen       = 0;
	INT32 nOperationRet   = 0;
	UINT8 nNumLen         = 0;

	BOOL bReturn          = FALSE;
	BOOL bIsInternational = FALSE;
	UINT16 nBCDIndex      = 0;

#if 0
	UINT16 nUTI = 0;  // add uti for set sms parameter calling
#endif
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
	sCfwEvent.nFlag = nSim;
#endif
	AT_ASSERT(NULL != pParam);
	g_SMS_CurCmdStamp = pParam->uCmdStamp;
	bReturn = AT_GetCfwInitSmsInfo(&sCfwEvent);
	if ((!bReturn) || (sCfwEvent.nParam1 == 1))
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "csca: AT_GetCfwInitSmsInfo() failure", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "csca: AT_GetCfwInitSmsInfo() failure", pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{
	case AT_CMD_SET:

		/* get current information and update value of some segment */
#ifdef AT_DUAL_SIM
		nOperationRet = CFW_CfgGetSmsParam(&sParaInfo, 0, nSim);
#else
		nOperationRet = CFW_CfgGetSmsParam(&sParaInfo, 0);

#endif
		if (ERR_SUCCESS != nOperationRet)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "csca: get sms parameters error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "csca: get sms parameters error", pParam->nDLCI);
#endif
			return;
		}

		/* parse the input parameters */
		nOperationRet = AT_Util_GetParaCount(pParam->pPara, &nParamCount);
		if (nParamCount == 0 || nParamCount > 2 || nOperationRet != ERR_SUCCESS)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csca: get param counter error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csca: get param counter error", pParam->nDLCI);
#endif
			return;
		}

		// /////////////////////////////////////////////
		// para1, para 2 process these code
		// ////////////////////////////////////////////
		if (nParamCount > 0)
		{
			nParamLen     = 24;
			nOperationRet =
			    AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, (void *)InputSCABuff, &nParamLen);

			if ((nOperationRet != ERR_SUCCESS) || (0 == nParamLen))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csca: AT_Util_GetParaWithRule 1", pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csca: AT_Util_GetParaWithRule 1", pParam->nDLCI);
#endif
				return;
			}

			if (!AT_SMS_IsValidPhoneNumber(InputSCABuff, nParamLen, &bIsInternational))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csca: check nuber invalid", pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csca: check nuber invalid", pParam->nDLCI);
#endif
				return;
			}

			if (bIsInternational)
			{
				nParamLen--;
				if (nParamLen > 20)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "csca: number len error 1", pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "csca: number len error 1", pParam->nDLCI);
#endif
					return;
				}

				pSCANumBuff = &InputSCABuff[1];

			}
			else
			{
				if (nParamLen > 20)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "csca: number len error 2", pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "csca: number len error 2", pParam->nDLCI);
#endif
					return;
				}

				pSCANumBuff = InputSCABuff;
			}

			nBCDIndex = SUL_AsciiToGsmBcd(pSCANumBuff, nParamLen, &(sParaInfo.nNumber[2]));

		}

		// /////////////////////////////////////////////
		// para 2 process these code
		// ////////////////////////////////////////////
		if (nParamCount > 1)
		{
			nParamLen     = 1;
			nOperationRet =
			    AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, (void *)&nTypeOfSCA, &nParamLen);
			if (ERR_AT_UTIL_CMD_PARA_NULL == nOperationRet)
			{
				nTypeOfSCA = CFW_TELNUMBER_TYPE_UNKNOWN;
			}
			else
			{
				if (ERR_SUCCESS != nOperationRet)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csca: AT_Util_GetParaWithRule 1", pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csca: AT_Util_GetParaWithRule 1", pParam->nDLCI);
#endif
					return;
				}

			}

			if ((nTypeOfSCA != CFW_TELNUMBER_TYPE_INTERNATIONAL)
			        && (nTypeOfSCA != CFW_TELNUMBER_TYPE_NATIONAL) && (nTypeOfSCA != CFW_TELNUMBER_TYPE_UNKNOWN))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csca: sca number type error", pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csca: sca number type error", pParam->nDLCI);
#endif
				return;
			}

		}

		/* according to spec, we check dial number first */
		if (bIsInternational)
		{
			nTypeOfSCA = CFW_TELNUMBER_TYPE_INTERNATIONAL;
		}
		else
		{
			if (0 == nTypeOfSCA)
			{
				/* no input num type  */
				nTypeOfSCA = CFW_TELNUMBER_TYPE_UNKNOWN;
			}
			else if (CFW_TELNUMBER_TYPE_INTERNATIONAL == nTypeOfSCA)
			{
				/* have no '+' , but the num type is 145, replace 129 with is  */
				nTypeOfSCA = CFW_TELNUMBER_TYPE_UNKNOWN;
			}
			else
			{
				/* get the input num type  */
			}
		}

		// set param value
		sParaInfo.nNumber[0] = nBCDIndex + 1;
		sParaInfo.nNumber[1] = nTypeOfSCA;

		AT_TC(g_sw_AT_SMS, "=====  SCA  Value ===== ");
		AT_TC_MEMBLOCK(g_sw_AT_SMS, &sParaInfo.nNumber[0], sParaInfo.nNumber[0] + 1, 16);

		// //////////////////////////////////////////////////////////
		// update SCA value to sim card
		// //////////////////////////////////////////////////////////
#if 0
		sParaInfo.nIndex         = 0; // the first profile of parameters
		sParaInfo.nSaveToSimFlag = 0x01;  // set sca to sim card
		sParaInfo.bDefault       = TRUE;  // as default parameters

		/* get the UTI and free it after finished calling */
		if (0 == (nUTI = AT_AllocUserTransID()))
		{
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "csca: malloc UTI error", pParam->nDLCI);
			return;
		}

		/* set sms parameters request */
		nOperationRet = CFW_CfgSetSmsParam(&sParaInfo, nUTI);
		AT_FreeUserTransID(nUTI);
#else
		sParaInfo.nSaveToSimFlag = 0x01;  // set sca to sim card
#ifdef AT_DUAL_SIM
		nOperationRet = CFW_CfgSetSmsParam(&sParaInfo, pParam->nDLCI, nSim);
#else
		nOperationRet = CFW_CfgSetSmsParam(&sParaInfo, pParam->nDLCI);

#endif
#endif

		if (ERR_SUCCESS != nOperationRet)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "csca: check set para error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "csca: check set para error", pParam->nDLCI);
#endif
			return;
		}

#if 0
		AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#else
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
#endif

		break;

	case AT_CMD_READ:

#ifdef AT_DUAL_SIM
		nOperationRet = CFW_CfgGetSmsParam(&sParaInfo, 0, nSim);
#else
		nOperationRet = CFW_CfgGetSmsParam(&sParaInfo, 0);

#endif

		if (ERR_SUCCESS != nOperationRet)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "csca: get prarameters error 11!", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "csca: get prarameters error 11!", pParam->nDLCI);
#endif
			break;
		}

		nOperationRet = SUL_GsmBcdToAscii(&(sParaInfo.nNumber[2]), sParaInfo.nNumber[0] - 1, InputSCABuff);

		if ((sParaInfo.nNumber[sParaInfo.nNumber[0]] & 0xf0) == 0xf0)
		{
			nNumLen = (sParaInfo.nNumber[0] - 1) * 2 - 1;
		}
		else
		{
			nNumLen = (sParaInfo.nNumber[0] - 1) * 2;
		}

		InputSCABuff[nNumLen] = '\0';

		if (sParaInfo.nNumber[1] == 0x91)
		{
			nTypeOfSCA = '+';
			AT_Sprintf(PromptBuff, "+CSCA: \"%c%s\",%u", nTypeOfSCA, InputSCABuff, sParaInfo.nNumber[1]);

		}
		else
		{
			AT_Sprintf(PromptBuff, "+CSCA: \"%s\",%u", InputSCABuff, sParaInfo.nNumber[1]);
		}
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, PromptBuff, AT_StrLen(PromptBuff), pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, PromptBuff, AT_StrLen(PromptBuff), pParam->nDLCI);
#endif

		break;

	case AT_CMD_TEST:

#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif

		break;

	default:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "csca: wrong cmd mode", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "csca: wrong cmd mode", pParam->nDLCI);
#endif

		break;
	}
	return;
}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CSMS
Description		:   	CMGS procedure function
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CSMS(AT_CMD_PARA *pParam)
{
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	AT_ASSERT(NULL != pParam);
#ifdef DEBUG_AT
#ifdef AT_DUAL_SIM
	AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
	AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
#else

	switch (pParam->iType)
	{
		/* continue to implements...... */
	case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI);
#endif
		break;
	case AT_CMD_SET:

		/* continue to implements...... */
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI);
#endif
		break;
	case AT_CMD_READ:

		/* continue to implements...... */
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, NULL, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, NULL, pParam->nDLCI);
#endif
		break;
	}
#endif
	return;

}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CMGD
Description		:   	CMGD procedure function
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CMGD(AT_CMD_PARA *pParam)
{
	CFW_SMS_MO_INFO_ADD *pSmsMOInfo = NULL;
	CFW_EVENT nCfwEvent = {0,};
	INT32 nOperationRet               = ERR_SUCCESS;
	BOOL bReturn                      = FALSE;
	UINT8 nStorage                    = 0;
	CFW_SMS_STORAGE_INFO sStorageInfo = { 0 };
	UINT8 PromptInfo[32]              = { 0 };
	UINT16 nUTI                       = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
	nCfwEvent.nFlag = nSim;
#endif

	AT_ASSERT(NULL != pParam);

	g_SMS_CurCmdStamp = pParam->uCmdStamp;

	bReturn = AT_GetCfwInitSmsInfo(&nCfwEvent);
	if ((!bReturn) || (nCfwEvent.nParam1 == 1))
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgd: SMS INIT FAIL", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgd: SMS INIT FAIL", pParam->nDLCI);
#endif
		return;
	}

	/* check storage1 have no error and get totalslot */
	nStorage = gATCurrentAtSMSInfo[nSim].nStorage1;

#ifdef AT_DUAL_SIM
	nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, nStorage, nSim);
#else
	nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, nStorage);

#endif
	if (nOperationRet != ERR_SUCCESS)
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgd: CFW_CfgGetSmsStorageInfo", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgd: CFW_CfgGetSmsStorageInfo", pParam->nDLCI);
#endif
		return;

	}

	// ///////////////////////////////////////////////////////
	// /      procedure
	// //////////////////////////////////////////////////////
	switch (pParam->iType)
	{

	case AT_CMD_SET:
	{
		UINT8 nParamCount   = 0;
		UINT8 nDeleteFlag   = 0;
		UINT16 nDelMsgIndex = 0;
		UINT8 nParamLen     = 0;
		UINT8 nStatus       = 0;

		nOperationRet = AT_Util_GetParaCount(pParam->pPara, &nParamCount);

		if (nOperationRet != ERR_SUCCESS || nParamCount > 2)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgd: nParamCount >2", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgd: nParamCount >2", pParam->nDLCI);
#endif
			return;

		}

		// /////////////////////////////////////////////
		// para1, para 2 process these code
		// ////////////////////////////////////////////
		if (nParamCount > 0)
		{
			nParamLen = 2;

			nOperationRet =
			    AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT16, (void *)(&nDelMsgIndex), &nParamLen);
			if (nOperationRet != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgd: get para 1 error", pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgd: get para 1 error", pParam->nDLCI);
#endif
				return;
			}

			// if(nDelMsgIndex < 0 || nDelMsgIndex > sStorageInfo.totalSlot)  //modify by wulc
			if (nDelMsgIndex < 0 || nDelMsgIndex > sStorageInfo.totalSlot)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_MEM_INDEX, NULL, 0, "cmgd: nDelMsgIndex > sStorageInfo.totalSlot",
				                  pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_MEM_INDEX, NULL, 0, "cmgd: nDelMsgIndex > sStorageInfo.totalSlot",
				                  pParam->nDLCI);
#endif
				return;
			}

		}

		// /////////////////////////////////////////////
		// para 2 process these code
		// ////////////////////////////////////////////
		if (nParamCount > 1)
		{
			nParamLen = 1;

			nOperationRet =
			    AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, (void *)(&nDeleteFlag), &nParamLen);
			if (nOperationRet != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgd: get para2 error", pParam->nDLCI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgd: get para2 error", pParam->nDLCI);
#endif
				return;
			}

		}

		/* Get the delete flag flag */
		switch (nDeleteFlag)
		{
		case 0:
			nStatus = 0;
			break;

		case 1:

			nStatus = CFW_SMS_STORED_STATUS_READ;
			if (0 == sStorageInfo.readRecords)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
				AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
				return;

			}
			break;

		case 2:

			nStatus =
			    CFW_SMS_STORED_STATUS_READ | CFW_SMS_STORED_STATUS_SENT_NOT_SR_REQ |
			    CFW_SMS_STORED_STATUS_SENT_SR_REQ_NOT_RECV | CFW_SMS_STORED_STATUS_SENT_SR_REQ_NOT_STORE |
			    CFW_SMS_STORED_STATUS_SENT_SR_REQ_RECV_STORE;
			if ((0 == sStorageInfo.readRecords) && (0 == sStorageInfo.unReadRecords))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
				AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
				return;

			}

			break;

		case 3:

			nStatus =
			    CFW_SMS_STORED_STATUS_READ | CFW_SMS_STORED_STATUS_SENT_NOT_SR_REQ |
			    CFW_SMS_STORED_STATUS_SENT_SR_REQ_NOT_RECV | CFW_SMS_STORED_STATUS_SENT_SR_REQ_NOT_STORE |
			    CFW_SMS_STORED_STATUS_SENT_SR_REQ_RECV_STORE | CFW_SMS_STORED_STATUS_UNSENT;
			if ((0 == sStorageInfo.readRecords) && (0 == sStorageInfo.unReadRecords) && (0 == sStorageInfo.sentRecords))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
				AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
				return;

			}

			break;

		case 4:

			nStatus = CFW_SMS_STORED_STATUS_STORED_ALL;
			if ((0 == sStorageInfo.readRecords) && (0 == sStorageInfo.unReadRecords) && (0 == sStorageInfo.sentRecords)
			        && (0 == sStorageInfo.unsentRecords))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
				AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
				return;

			}
			break;

		default:
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgd: delete flag para error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgd: delete flag para error", pParam->nDLCI);
#endif
			return;

		}

		// add by wulc for  AT+CMGD=0  begin
		if (0 == nDelMsgIndex)
		{
			nStatus = CFW_SMS_STORED_STATUS_STORED_ALL;
		}

		// add by wulc end
		// //////////////////////////////////////////////////////////////////////////
		// 1. list status is: READ, but readRecords is 0, return OK immediately
		// 2. list status is: UNREAD, but unReadRecords is 0, return OK immediately
		// 3. list status is: SENT, but sentRecords is 0, return OK immediately
		// 4. list status is: UNSENT, but unsentRecords is 0, return OK immediately
		// 5. list status is: ALL, but usedSlot is 0, return OK immediately
		// /////////////////////////////////////////////////////////////////////////
#if 0
		if (((CFW_SMS_STORED_STATUS_READ == nStatus) && (0 == sStorageInfo.readRecords))
		        || ((CFW_SMS_STORED_STATUS_UNREAD == nStatus) && (0 == sStorageInfo.unReadRecords))
		        || (((CFW_SMS_STORED_STATUS_SENT_NOT_SR_REQ & nStatus) != 0) && (0 == sStorageInfo.sentRecords))
		        || ((CFW_SMS_STORED_STATUS_UNSENT == nStatus) && (0 == sStorageInfo.unsentRecords))
		        || ((CFW_SMS_STORED_STATUS_STORED_ALL == nStatus) && (0 == sStorageInfo.usedSlot)))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
			return;
		}
#endif
		/* starting delete message */
		pSmsMOInfo = (CFW_SMS_MO_INFO_ADD *)AT_MALLOC(sizeof(CFW_SMS_MO_INFO_ADD));

		if (pSmsMOInfo == NULL)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgd: pSmsMOInfo malloc error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgd: pSmsMOInfo malloc error", pParam->nDLCI);
#endif
			return;
		}

		AT_MemSet(pSmsMOInfo, 0, sizeof(CFW_SMS_MO_INFO_ADD));

		// If the nDeleteFlag is given, then we delete kinds of message,
		// and the nDelMsgIndex is omit and value is set to 0
		if (nDeleteFlag != 0)
		{
			nDelMsgIndex = 0;
		}

		pSmsMOInfo->nLocation = gATCurrentAtSMSInfo[nSim].nStorage1;
		pSmsMOInfo->nIndex    = nDelMsgIndex;
		pSmsMOInfo->nStatus   = nStatus;

		/* get the UTI and free it after finished calling */
		if (0 == (nUTI = AT_AllocUserTransID()))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgd:  malloc UTI error", nSim, pParam->nDLCI);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgd:  malloc UTI error", pParam->nDLCI);
#endif
			return;
		}
#ifdef AT_DUAL_SIM

		nOperationRet = CFW_SmsDeleteMessage(pSmsMOInfo->nIndex, pSmsMOInfo->nStatus,
		                                     pSmsMOInfo->nLocation, 1, pParam->nDLCI, nSim);
#else
		nOperationRet = CFW_SmsDeleteMessage(pSmsMOInfo->nIndex, pSmsMOInfo->nStatus,
		                                     pSmsMOInfo->nLocation, pParam->nDLCI);

#endif

		AT_FreeUserTransID(nUTI);

		if (nOperationRet != ERR_SUCCESS)
		{
			AT_FREE(pSmsMOInfo);
			nOperationRet = AT_SMS_ERR_Change(nOperationRet);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmgd: CFW_SmsDeleteMessage error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmgd: CFW_SmsDeleteMessage error", pParam->nDLCI);
#endif
			return;
		}

		if((pSmsMOInfo->nLocation = CFW_SMS_STORAGE_SM) || (nStorage = CFW_SMS_STORAGE_SM))
		{
			sStorageInfo.usedSlot--;
			CFW_CfgSetSmsStorageInfo(&sStorageInfo, CFW_SMS_STORAGE_SM, nSim);
			AT_TC(g_sw_AT_SMS, "CMGD ok usedSlot= %d", sStorageInfo.usedSlot);

		}

		AT_FREE(pSmsMOInfo);
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif

		break;

	}

	case AT_CMD_TEST:
	{

		AT_Sprintf(PromptInfo, "+CMGD: (1-%u),(0,1,2,3,4)", sStorageInfo.totalSlot);
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, PromptInfo, AT_StrLen(PromptInfo), pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, PromptInfo, AT_StrLen(PromptInfo), pParam->nDLCI);
#endif
		break;;
	}

	default:
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cmgd: wrong cmd mode ", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cmgd: wrong cmd mode ", pParam->nDLCI);
#endif
		break;
	}

	}

	return;
}

/******************************************************************************************
Function			:	AT_CmdFunc_CMGF
Description		:   	CMGF command procedure function
					Set SMS Format include "text"(1) and "PDU"(0)
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/

VOID AT_SMS_CmdFunc_CMGF(AT_CMD_PARA *pParam)
{
	UINT8 nParaLen           = 0;
	UINT8 nParaCount         = 0;
	UINT8 nFormat            = 0;
	UINT8 PromptInfoBuff[16] = { 0 };
	UINT32 nOperationRet     = ERR_SUCCESS;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	AT_ASSERT(NULL != pParam);

	switch (pParam->iType)
	{
	case AT_CMD_SET:

		nOperationRet = AT_Util_GetParaCount(pParam->pPara, &nParaCount);
		if (nParaCount > 1 || nOperationRet != ERR_SUCCESS || (nParaCount == 0))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgf: get param counter error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgf: get param counter error", pParam->nDLCI);
#endif
			return;
		}

		nParaLen      = 1;
		nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, (void *)&nFormat, &nParaLen);
		if ((nOperationRet != ERR_SUCCESS) || (nFormat > 1))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgf: get para 1 error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "cmgf: get para 1 error", pParam->nDLCI);
#endif
			return;
		}

#ifdef AT_DUAL_SIM
		nOperationRet = CFW_CfgSetSmsFormat(nFormat, nSim);
#else
		nOperationRet = CFW_CfgSetSmsFormat(nFormat);

#endif
		if (nOperationRet != ERR_SUCCESS)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgf: CFW_CfgSetSmsFormat error 1", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgf: CFW_CfgSetSmsFormat error 1", pParam->nDLCI);
#endif
			return;
		}

		gATCurrentAtSmsSettingSg_SMSFormat = nFormat;
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif

		break;

	case AT_CMD_TEST:

		AT_Sprintf(PromptInfoBuff, "+CMGF:(0,1)");
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)PromptInfoBuff, AT_StrLen(PromptInfoBuff), pParam->nDLCI,
		                 nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)PromptInfoBuff, AT_StrLen(PromptInfoBuff), pParam->nDLCI);
#endif
		break;

	case AT_CMD_READ:

		nFormat = gATCurrentAtSmsSettingSg_SMSFormat;

		AT_Sprintf(PromptInfoBuff, "+CMGF: %u", nFormat);
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)PromptInfoBuff, AT_StrLen(PromptInfoBuff), pParam->nDLCI,
		                 nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)PromptInfoBuff, AT_StrLen(PromptInfoBuff), pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, " cmgf: wrong cmd mode", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, " cmgf: wrong cmd mode", pParam->nDLCI);
#endif
		break;

	}

	return;

}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CMGR
Description		:   	CMGR procedure function
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CMGR(AT_CMD_PARA *pParam)
{
	CFW_EVENT nCfwEvent = {0,};

	CFW_SMS_MO_INFO_ADD *pSmsMOInfo = NULL;
	INT32 nOperationRet               = ERR_SUCCESS;
	INT32 nReadMsgRet                 = ERR_SUCCESS;
	BOOL bReturn                      = FALSE;
	CFW_SMS_STORAGE_INFO sStorageInfo = { 0 };
	UINT8 nStorage                    = 0;
	UINT16 nReadMsgIndex              = 0;
	UINT8 nParamLen                   = 0;
	UINT8 nParamCount                 = 0;
	UINT16 nUTI                       = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
	nCfwEvent.nFlag = nSim;
#endif

	AT_ASSERT(NULL != pParam);

	g_SMS_CurCmdStamp = pParam->uCmdStamp;
	bReturn           = AT_GetCfwInitSmsInfo(&nCfwEvent);

	if ((bReturn == 0) || (nCfwEvent.nParam1 == 1))
	{
		AT_TC(g_sw_AT_SMS, "AT_GetCfwInitSmsInfo bReturn %d,nCfwEvent.nParam1 %d", bReturn, nCfwEvent.nParam1);
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr: SMS INIT FAIL\n", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr: SMS INIT FAIL\n", pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{
	case AT_CMD_SET:
	{
		/* get param count */
		nOperationRet = AT_Util_GetParaCount(pParam->pPara, &nParamCount);
		if (nOperationRet != ERR_SUCCESS || nParamCount != 1)
		{
			AT_TC(g_sw_AT_SMS, "AT_Util_GetParaCount %d", nOperationRet);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgr: get param counter error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgr: get param counter error", pParam->nDLCI);
#endif
			return;
		}

		/* check storage1 have no error and get totalslot */
		nParamLen = 2;
		nStorage  = gATCurrentAtSMSInfo[nSim].nStorage1;

		AT_TC(g_sw_AT_SMS, "nStorage %d", nStorage);
#ifdef AT_DUAL_SIM
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, nStorage, nSim);
#else
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, nStorage);

#endif

		if (nOperationRet != ERR_SUCCESS)
		{
			AT_TC(g_sw_AT_SMS, "CFW_CfgGetSmsStorageInfo error %d", nOperationRet);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr: get sms storage error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr: get sms storage error", pParam->nDLCI);
#endif
			return;
		}

		nOperationRet =
		    AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT16, (void *)(&nReadMsgIndex), &nParamLen);

		if (nOperationRet != ERR_SUCCESS)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgr: get sms storage error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_TXT_PARAM, NULL, 0, "cmgr: get sms storage error", pParam->nDLCI);
#endif
			return;
		}

		if (nReadMsgIndex > sStorageInfo.totalSlot)
		{
			AT_TC(g_sw_AT_SMS, "nReadMsgIndex %d, sStorageInfo.totalSlot %d", nReadMsgIndex, sStorageInfo.totalSlot);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_MEM_INDEX, NULL, 0, "cmgr: nReadMsgIndex > sStorageInfo.totalSlot",
			                  pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_MEM_INDEX, NULL, 0, "cmgr: nReadMsgIndex > sStorageInfo.totalSlot",
			                  pParam->nDLCI);
#endif
			return;
		}

		// //////////////////////////////////////////////////////////////////////////////
		// Starting read message from csw
		// //////////////////////////////////////////////////////////////////////////////
		pSmsMOInfo = (CFW_SMS_MO_INFO_ADD *)AT_MALLOC(sizeof(CFW_SMS_MO_INFO_ADD));

		if (NULL == pSmsMOInfo)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgr: pSmsMOInfo malloc error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmgr: pSmsMOInfo malloc error", pParam->nDLCI);
#endif
			return;
		}

		AT_MemSet(pSmsMOInfo, 0, sizeof(CFW_SMS_MO_INFO_ADD));

		pSmsMOInfo->nFormat = gATCurrentAtSmsSettingSg_SMSFormat;
#ifdef AT_DUAL_SIM

		nOperationRet = CFW_CfgGetSmsShowTextModeParam(&(pSmsMOInfo->nPath), nSim);
#else
		nOperationRet = CFW_CfgGetSmsShowTextModeParam(&(pSmsMOInfo->nPath));

#endif

		if (ERR_SUCCESS != nOperationRet)
		{
			AT_TC(g_sw_AT_SMS, "CFW_CfgGetSmsShowTextModeParam %d", nOperationRet);
			AT_FREE(pSmsMOInfo);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr: status exception", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr: status exception", pParam->nDLCI);
#endif
			return;
		}

		pSmsMOInfo->nIndex    = nReadMsgIndex;
		pSmsMOInfo->nLocation = nStorage;

		/* get the UTI and free it after finished calling */
		if (0 == (nUTI = AT_AllocUserTransID()))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr: malloc UTI error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr: malloc UTI error", pParam->nDLCI);
#endif
			return;
		}

#ifdef AT_DUAL_SIM

		nReadMsgRet = CFW_SmsReadMessage(pSmsMOInfo->nLocation, 1, pSmsMOInfo->nIndex, pParam->nDLCI, nSim);
#else
		nReadMsgRet = CFW_SmsReadMessage(pSmsMOInfo->nLocation, pSmsMOInfo->nIndex, pParam->nDLCI);

#endif
		AT_FreeUserTransID(nUTI);

		if (ERR_SUCCESS != nReadMsgRet)
		{
			AT_TC(g_sw_AT_SMS, "CFW_SmsReadMessage err %d", nReadMsgRet);
			AT_FREE(pSmsMOInfo);

			nReadMsgRet = AT_SMS_ERR_Change(nReadMsgRet);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(nReadMsgRet, NULL, 0, "cmgr: read message check param error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(nReadMsgRet, NULL, 0, "cmgr: read message check param error", pParam->nDLCI);
#endif
			return;
		}

		AT_FREE(pSmsMOInfo);
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
#endif
		break;

	}
	case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cmgr: wrong cmd mode", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "cmgr: wrong cmd mode", pParam->nDLCI);
#endif
		break;

	}

	return;

}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CSDH
Description		:   	CSDH procedure function
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CSDH(AT_CMD_PARA *pParam)
{

	UINT8 PromptInfoBuff[16] = { 0 };
	UINT8 nParamLen          = 0;
	UINT8 nParamCount        = 0;
	UINT8 nHeaderShow        = 0;

	INT32 nOperationRet = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	AT_ASSERT(NULL != pParam);

	switch (pParam->iType)
	{
	case AT_CMD_SET:
	{
		nOperationRet = AT_Util_GetParaCount(pParam->pPara, &nParamCount);

		if (nOperationRet != ERR_SUCCESS || nParamCount == 0 || nParamCount > 1)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csdh: get param counter error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csdh: get param counter error", pParam->nDLCI);
#endif
			return;
		}

		nParamLen     = 1;
		nOperationRet =
		    AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, (void *)&nHeaderShow, &nParamLen);

		if (ERR_SUCCESS != nOperationRet)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csdh: get param error", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csdh: get param error", pParam->nDLCI);
#endif
			return;
		}

		if (nHeaderShow == 1 || nHeaderShow == 0)
		{
			gATCurrentAtSmsSettingSCSDH_show = nHeaderShow;
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csdh: HeaderShow exception", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csdh: HeaderShow exception", pParam->nDLCI);
#endif
		}

		break;
	}

	case AT_CMD_TEST:
	{

		AT_Sprintf(PromptInfoBuff, "+CSDH: (0,1)");
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)PromptInfoBuff, AT_StrLen(PromptInfoBuff), pParam->nDLCI,
		                 nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)PromptInfoBuff, AT_StrLen(PromptInfoBuff), pParam->nDLCI);
#endif
		break;
	}

	case AT_CMD_READ:
	{

		nHeaderShow = gATCurrentAtSmsSettingSCSDH_show;
		AT_Sprintf(PromptInfoBuff, "+CSDH: %u", nHeaderShow);
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)PromptInfoBuff, AT_StrLen(PromptInfoBuff), pParam->nDLCI,
		                 nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)PromptInfoBuff, AT_StrLen(PromptInfoBuff), pParam->nDLCI);
#endif
		break;
	}

	default:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "csdh: wrong cmd mode", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "csdh: wrong cmd mode", pParam->nDLCI);
#endif
		break;

	}

	return;
}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CNMI
Description		:   	selects the procedure, how receiving of new messages from the
					network is indicated to the TE when TE is active
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CNMI(AT_CMD_PARA *pParam)
{

	UINT8 mode          = 0, mt = 0, bm = 0, ds = 0, bfr = 0;
	UINT8 modeLast      = 0, mtLast = 0, bmLast = 0, dsLast = 0, bfrLast = 0;
	UINT8 nParamLen     = 1, nParamCount = 1;
	INT32 nOperationRet = ERR_SUCCESS;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	AT_ASSERT(NULL != pParam);

	switch (pParam->iType)
	{
	case AT_CMD_SET:
	{

		// ///////////////////////////////////////////
		// Save the lates value and restore if exception
		// ///////////////////////////////////////////
		modeLast = gATCurrentAtSMSInfo[nSim].sCnmi.nMode;
		mtLast   = gATCurrentAtSMSInfo[nSim].sCnmi.nMt;
		bmLast   = gATCurrentAtSMSInfo[nSim].sCnmi.nBm;
		dsLast   = gATCurrentAtSMSInfo[nSim].sCnmi.nDs;
		bfrLast  = gATCurrentAtSMSInfo[nSim].sCnmi.nBfr;

		nOperationRet = AT_Util_GetParaCount(pParam->pPara, &nParamCount);
		if (nOperationRet != ERR_SUCCESS || nParamCount > 5)
		{
			nOperationRet = ERR_AT_CMS_INVALID_PARA;
		}

		// ///////////////////////////////////////////
		// //all param is omit , 0 param
		// ///////////////////////////////////////////
		if (0 == nParamCount)
		{
			nOperationRet                   = ERR_SUCCESS;
			gATCurrentAtSMSInfo[nSim].sCnmi.nMode = 0;

		}

		// ///////////////////////////////////////////
		// //           get para1: mode = 0
		// ///////////////////////////////////////////
		if (nOperationRet == ERR_SUCCESS && nParamCount)
		{
			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, (void *)&mode, &nParamLen);

			if ((mode != 0) && (mode != 1) && (mode != 2) & (mode != 3))
			{
				nOperationRet = ERR_AT_CMS_INVALID_PARA;
			}
			else
			{
				gATCurrentAtSMSInfo[nSim].sCnmi.nMode = mode;
			}

		}

		// ///////////////////////////////////////////
		// //           get para2: mt 0-2
		// ///////////////////////////////////////////
		if (nOperationRet == ERR_SUCCESS && nParamCount > 1)
		{
			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, (void *)&mt, &nParamLen);

			// if(mt > 2)//[mod]2007.10.18
			if ((mt != 0) && (mt != 1) && (mt != 2) & (mt != 3))
			{
				nOperationRet = ERR_AT_CMS_INVALID_PARA;
			}
			else
			{
				gATCurrentAtSMSInfo[nSim].sCnmi.nMt = mt;
			}

		}

		// ///////////////////////////////////////////
		// //           get para3: bm 0-3
		// ///////////////////////////////////////////
		if (nOperationRet == ERR_SUCCESS && nParamCount > 2)
		{
			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_UINT8, (void *)&bm, &nParamLen);
			if ((bm != 0) && (bm != 2)) // (bm > 3)---->(bm != 0)
			{
				nOperationRet = ERR_AT_CMS_INVALID_PARA;
			}
			else
			{
				gATCurrentAtSMSInfo[nSim].sCnmi.nBm = bm;
			}
		}

		// ///////////////////////////////////////////
		// //           get para4: ds 0-2
		// ///////////////////////////////////////////
		if (nOperationRet == ERR_SUCCESS && nParamCount > 3)
		{
			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 3, AT_UTIL_PARA_TYPE_UINT8, (void *)&ds, &nParamLen);
			if (ds > 1) // (ds > 2)--->(ds > 1)//[mod]2007.10.18
			{
				nOperationRet = ERR_AT_CMS_INVALID_PARA;
			}
			else
			{
				gATCurrentAtSMSInfo[nSim].sCnmi.nDs = ds;
			}
		}

		// ///////////////////////////////////////////
		// //           get para5:  bfr 0-1
		// ///////////////////////////////////////////
		if (nOperationRet == ERR_SUCCESS && nParamCount > 4)
		{
			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 4, AT_UTIL_PARA_TYPE_UINT8, (void *)&bfr, &nParamLen);
			if ((bfr != 0) && (bfr != 1))
			{
				nOperationRet = ERR_AT_CMS_INVALID_PARA;
			}
			else
			{
				gATCurrentAtSMSInfo[nSim].sCnmi.nBfr = bfr;
			}
		}

		/* Proces the result  */
		if (nOperationRet == ERR_SUCCESS)
		{
			UINT8 nOption        = 0;
			UINT8 nNewSmsStorage = 0;

#ifdef AT_DUAL_SIM
			nOperationRet = CFW_CfgGetNewSmsOption(&nOption, &nNewSmsStorage, nSim);
#else
			nOperationRet = CFW_CfgGetNewSmsOption(&nOption, &nNewSmsStorage);

#endif

			if (nOperationRet == ERR_SUCCESS)
			{
				nOption = nOption & 0x1f;
#ifdef AT_DUAL_SIM

				nOperationRet =
				    CFW_CfgSetNewSmsOption(nOption | CFW_SMS_ROUT_DETAIL_INFO, gATCurrentAtSMSInfo[nSim].nStorage3, nSim);
#else
				nOperationRet = CFW_CfgSetNewSmsOption(nOption | CFW_SMS_ROUT_DETAIL_INFO, gATCurrentAtSMSInfo[nSim].nStorage3);

#endif
				if (nOperationRet == ERR_SUCCESS)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
					AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
				}
			}

			if (ERR_SUCCESS != nOperationRet)
			{

				nOperationRet = ERR_AT_CMS_CMD_CANNOT_ACT;
			}

		}
		else
		{

			gATCurrentAtSMSInfo[nSim].sCnmi.nMode = modeLast;
			gATCurrentAtSMSInfo[nSim].sCnmi.nMt   = mtLast;
			gATCurrentAtSMSInfo[nSim].sCnmi.nBm   = bmLast;
			gATCurrentAtSMSInfo[nSim].sCnmi.nDs   = dsLast;
			gATCurrentAtSMSInfo[nSim].sCnmi.nBfr  = bfrLast;
		}

		break;

	}
	case AT_CMD_READ:
	{
		UINT8 AtTri[64] = { 0 };

		AT_Sprintf(AtTri, "+CNMI: %u,%u,%u,%u,%u",
		           gATCurrentAtSMSInfo[nSim].sCnmi.nMode, gATCurrentAtSMSInfo[nSim].sCnmi.nMt, gATCurrentAtSMSInfo[nSim].sCnmi.nBm,
		           gATCurrentAtSMSInfo[nSim].sCnmi.nDs, gATCurrentAtSMSInfo[nSim].sCnmi.nBfr);
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtTri, (UINT16)AT_StrLen(AtTri), pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtTri, (UINT16)AT_StrLen(AtTri), pParam->nDLCI);
#endif

		break;
	}
	case AT_CMD_TEST:
	{
		UINT8 AtTri[64] = { 0 };

		AT_Sprintf(AtTri, "+CNMI: (0-3),(0-3),(0,2),(0-1),(0,1)");
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtTri, (UINT16)AT_StrLen(AtTri), pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtTri, (UINT16)AT_StrLen(AtTri), pParam->nDLCI);
#endif
		break;

	}
	default:
	{
		nOperationRet = ERR_AT_CMS_OPER_NOT_SUPP;
		break;

	}
	}

	if (nOperationRet != ERR_SUCCESS)
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(nOperationRet, NULL, 0, "cnmi: exception happened", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(nOperationRet, NULL, 0, "cnmi: exception happened", pParam->nDLCI);
#endif
	}

	return;
}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CSMP
Description		:   	CSMP procedure function
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CSMP(AT_CMD_PARA *pParam)
{

	CFW_SMS_PARAMETER sInfo = { 0 };

	UINT8 nParamLen = 1, nParamCount = 0;
	UINT8 fo        = 0, vp = 0, pid = 0, dcs = 0;

	UINT8 PromptInfoBuff[20] = { 0 };
	UINT32 nOperationRet     = 0;

#if 0
	UINT16 nUTI = 0;  // add uti for set sms parameter calling
#endif
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	AT_ASSERT(NULL != pParam);

	switch (pParam->iType)
	{
	case AT_CMD_SET:
	{

		/* get the current SMS parameters and then update them */

#ifdef AT_DUAL_SIM
		nOperationRet = CFW_CfgGetSmsParam(&sInfo, 0, nSim);
#else
		nOperationRet = CFW_CfgGetSmsParam(&sInfo, 0);

#endif
		if (ERR_SUCCESS != nOperationRet)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "csmp:CfgGetSmsParam exception ", pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "csmp:CfgGetSmsParam exception ", pParam->nDLCI);
#endif
			return;
		}

		/* parser the input parameters */
		nOperationRet = AT_Util_GetParaCount(pParam->pPara, &nParamCount);
		if (nParamCount > 4 || nOperationRet != ERR_SUCCESS)  // [mod]2007.10.17
		{
			nOperationRet = ERR_AT_CMS_INVALID_PARA;
		}

		// get NO.1 param fo
		if (nOperationRet == ERR_SUCCESS && nParamCount)
		{
			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, (void *)&fo, &nParamLen);
			if (nOperationRet == ERR_SUCCESS)
			{

				/****************************************/
				// "fo" composition :
				// bit    7    6      5     4      3     2    1     0
				// RP UDHI SSR VPF  VPF  RD MTI MTI
				/****************************************/
#if 0
				sInfo.rp   = (fo & 0x80) >> 7;
				sInfo.udhi = (fo & 0x40) >> 6;
				sInfo.ssr  = (fo & 0x20) >> 5;
				sInfo.vpf  = (fo & 0x18) >> 3;
				sInfo.rd   = (fo & 0x04) >> 2;
				sInfo.mti  = fo & 0x03;

				/* for debug and testing */
				AT_TC(g_sw_AT_SMS,
				      "sInfo.rp = %u, sInfo.udhi = %u, sInfo.ssr = %u, sInfo.vpf = %02u, sInfo.rd = %u, sInfo.mti = %02u",
				      sInfo.rp, sInfo.udhi, sInfo.ssr, sInfo.vpf, sInfo.rd, sInfo.mti);

				/* mti of MO message must be "01" */
				if (0x01 != sInfo.mti)
				{
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csmp: get mti of  'fo' failure", pParam->nDLCI);
					return;
				}

#else
				// sInfo.mti = fo;
				// for version 1.0 20070918
				// [+]2007.11.20 check param fo only=17
				if (fo != 17)
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csmp: get param failure", pParam->nDLCI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "csmp: get param failure", pParam->nDLCI);
#endif
					return;
				}
#endif

			}
			else
			{
				nOperationRet = ERR_AT_CMS_INVALID_PARA;
			}
		}

		// get NO.2 param vp
		if (nOperationRet == ERR_SUCCESS && nParamCount > 1)
		{
			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, (void *)&vp, &nParamLen);

			if (nOperationRet == ERR_SUCCESS)
			{
				sInfo.vp = vp;
			}
			else
			{
				nOperationRet = ERR_AT_CMS_INVALID_PARA;
			}

		}

		// get NO.3 param pid
		if (nOperationRet == ERR_SUCCESS && nParamCount > 2)
		{
			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_UINT8, (void *)&pid, &nParamLen);
			if (nOperationRet == ERR_SUCCESS)
			{
				sInfo.pid = pid;
			}
			else
			{
				nOperationRet = ERR_AT_CMS_INVALID_PARA;
			}
		}

		// get NO.4 param dcs
		if (nOperationRet == ERR_SUCCESS && nParamCount > 3)
		{
			nOperationRet = AT_Util_GetParaWithRule(pParam->pPara, 3, AT_UTIL_PARA_TYPE_UINT8, (void *)&dcs, &nParamLen);
			if (nOperationRet == ERR_SUCCESS)
			{
				if (dcs == 0 || dcs == 4 || dcs == 8) // [+]bug 7035
				{
					sInfo.dcs = dcs;
				}
				else
				{
					nOperationRet = ERR_AT_CMS_DCS_NOT_SUPP;
				}
			}
			else
			{
				nOperationRet = ERR_AT_CMS_INVALID_PARA;
			}
		}

		if (ERR_SUCCESS == nOperationRet)
		{
#if 0
			/* set param location */
			sInfo.nIndex         = 0; // the first profile of parameters
			sInfo.nSaveToSimFlag = 0x00;  // set param to moblie flash,sync procedure calling
			sInfo.bDefault       = TRUE;  // as current parameters

			/* get the UTI and free it after finished calling */
			if (0 == (nUTI = AT_AllocUserTransID()))
			{
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "csmp: malloc UTI error", pParam->nDLCI);
				return;
			}

			/* set sms parameters request */
			nOperationRet = CFW_CfgSetSmsParam(&sInfo, nUTI);
			AT_FreeUserTransID(nUTI);
#else

#ifdef AT_DUAL_SIM
			nOperationRet = CFW_CfgSetSmsParam(&sInfo, pParam->nDLCI, nSim);
#else
			nOperationRet = CFW_CfgSetSmsParam(&sInfo, pParam->nDLCI);

#endif
#endif

			if (ERR_SUCCESS != nOperationRet)
			{
				nOperationRet = ERR_AT_CMS_MEM_FAIL;
			}

		}

		if (ERR_SUCCESS == nOperationRet)
		{

#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif

		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(nOperationRet, NULL, 0, NULL, pParam->nDLCI, nSim);
#else
			AT_SMS_Result_Err(nOperationRet, NULL, 0, NULL, pParam->nDLCI);
#endif
		}

		break;
	}

	case AT_CMD_TEST:
	{

#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, pParam->nDLCI);
#endif
		break;

	}

	case AT_CMD_READ:
	{
		/*
		   ** default value of 'fo' is 17, we can get the value
		   ** of CFW_SMS_PARAMETER
		 */
		UINT8 nSMSParamFo = 0;

#ifdef AT_DUAL_SIM
		nOperationRet = CFW_CfgGetSmsParam(&sInfo, 0, nSim);
#else
		nOperationRet = CFW_CfgGetSmsParam(&sInfo, 0);

#endif

#if 0
		/* for debug and testing */
		AT_TC(g_sw_AT_SMS,
		      "sInfo.rp = %u, sInfo.udhi = %u, sInfo.ssr = %u, sInfo.vpf = %02u, sInfo.rd = %u, sInfo.mti = %02u",
		      sInfo.rp, sInfo.udhi, sInfo.ssr, sInfo.vpf, sInfo.rd, sInfo.mti);
#endif

		if (ERR_SUCCESS == nOperationRet)
		{
#if 0
			/****************************************/
			// "fo" composition :
			// bit    7    6      5     4      3     2    1     0
			// RP UDHI SSR VPF  VPF  RD MTI MTI
			/****************************************/
			/* get 'fo' value of each bits */
			if (sInfo.rp)
				nSMSParamFo |= 1 << 7;
			if (sInfo.udhi)
				nSMSParamFo |= 1 << 6;
			if (sInfo.ssr)
				nSMSParamFo |= 1 << 5;
			if (sInfo.vpf)
				nSMSParamFo |= sInfo.vpf << 3;
			if (sInfo.rd)
				nSMSParamFo |= 1 << 2;
			if (sInfo.mti)
				nSMSParamFo |= sInfo.mti;
#else
			nSMSParamFo = 17;
#endif

			AT_Sprintf(PromptInfoBuff, "+CSMP: %u,%u,%u,%u", nSMSParamFo, sInfo.vp, sInfo.pid, sInfo.dcs);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)PromptInfoBuff, AT_StrLen(PromptInfoBuff), pParam->nDLCI,
			                 nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)PromptInfoBuff, AT_StrLen(PromptInfoBuff), pParam->nDLCI);
#endif
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, (UINT8 *)PromptInfoBuff, AT_StrLen(PromptInfoBuff), NULL, pParam->nDLCI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, (UINT8 *)PromptInfoBuff, AT_StrLen(PromptInfoBuff), NULL, pParam->nDLCI);
#endif
		}

		break;

	}

	default:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "csmp: wrong cmd mode ", pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, "csmp: wrong cmd mode ", pParam->nDLCI);
#endif
		break;

	}

	return;

}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CNMA
Description		:   	CNMA procedure function
Called By			:	ATS SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	AT_CMD_PARA *pParam
Output			:
Return			:	VOID
Others			:	build by unknown author
					modify and add comment by wangqunyang 2008.04.07
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CNMA(AT_CMD_PARA *pParam)
{
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	AT_ASSERT(NULL != pParam);

	switch (pParam->iType)
	{
		/* continue to implements...... */
	case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI);
#endif
		break;
	case AT_CMD_SET:

		/* continue to implements...... */
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
		break;
	case AT_CMD_READ:

		/* continue to implements...... */
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, NULL, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, NULL, pParam->nDLCI);
#endif
		break;
	}

	return;

}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CSAS
Description		:   	save +CSAS and +CSMP in non-volatile memory(usually SIM), and non-supported
					settings are not saved.
Test command    	:	AT+CSAS?
Exe command     	:   	AT+CSAS
Called By			:	AT_RunCommand()
Data Accessed   	:
Data Updated    	:
Input			:   	pParam
Output			:
Return			:	void
Others			:	build by wangqunyang 21/03/2008
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CSAS(AT_CMD_PARA *pParam)
{
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	AT_ASSERT(NULL != pParam);

	switch (pParam->iType)
	{
	case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI);
#endif
		break;

	case AT_CMD_SET:
		/* continue to implements...... */
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, NULL, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, NULL, pParam->nDLCI);
#endif
		break;
	}

	return;
}

/******************************************************************************************
Function			:	AT_SMS_CmdFunc_CRES
Description		:   	restores or recover SMS settings(+CSMP and +CSCA parameters) from the
					non-volatile memeory,usually SIM.

Test command    	:	AT+CRES?
Exe command     	:   	AT+CRES
Called By			:	AT_RunCommand()
Data Accessed   	:
Data Updated    	:
Input			:   	pParam
Output			:
Return			:	void
Others			:	build by wangqunyang 21/03/2008
*******************************************************************************************/
VOID AT_SMS_CmdFunc_CRES(AT_CMD_PARA *pParam)
{
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	AT_ASSERT(NULL != pParam);

	switch (pParam->iType)
	{
	case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI);
#endif
		break;

	case AT_CMD_SET:
		/* continue to implements...... */
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_NOTSUPPORT, 0, NULL, 0, pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, NULL, pParam->nDLCI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_SUPP, NULL, 0, NULL, pParam->nDLCI);
#endif
		break;
	}

	return;
}

/******************************************************************************************
Function			:	AT_SMS_CMGS_SendMessage_rsp
Description		:   	process the response of all send message about at command
Called By			:	AT_SMS_AsyncEventProcess
Data Accessed   	:
Data Updated    	:
Input			:   	COS_EVENT *pEvent
Output			:
Return			:	VOID
Others			:	modify and add comment by wangqunyang 06/04/2008
*******************************************************************************************/
VOID AT_SMS_CMGS_CMSS_SendMessage_rsp(COS_EVENT *pEvent)
{

	CFW_EVENT CfwEvent       = { 0 };
	UINT8 PromptInfoBuff[32] = { 0 };
	UINT8 CMDHeaderInfo[32]  = { 0 };
	UINT32 nOperationRet     = ERR_SUCCESS;

#ifdef AT_DUAL_SIM
	UINT8 nSim;
#endif
	/* Get event from csw for send message response */
	AT_CosEvent2CfwEvent(pEvent, &CfwEvent);
#ifdef AT_DUAL_SIM
	nSim = CfwEvent.nFlag;
#endif
	/* just for debug */
	AT_TC(g_sw_AT_SMS, "cmss/cmgs send msg resp: CfwEvent.nType = 0x%x, CfwEvent.nParam1 =  0x%x, CfwEvent.nParam2 =  u%",
	      CfwEvent.nType, CfwEvent.nParam1, CfwEvent.nParam2);

	/* Get  prompt of AT command */
	if ((AT_IsAsynCmdAvailable("+CMGS", g_SMS_CurCmdStamp, CfwEvent.nUTI))/*||gATSATSendSMSFlag[CfwEvent.nFlag] == TRUE*/)
	{
		AT_TC(g_sw_AT_SMS, "AT_SMS_CMGS_CMSS_SendMessage_rsp: +CMGS\n ");
		AT_MemCpy(CMDHeaderInfo, "+CMGS", AT_StrLen("+CMGS"));
	}
	else if (AT_IsAsynCmdAvailable("+CMSS", g_SMS_CurCmdStamp, CfwEvent.nUTI))
	{

		if (CFW_SMS_STORED_STATUS_UNSENT == g_CMSS_Status)
		{
			UINT16 nUTI = 0;

			/* get the UTI and free it after finished calling */
			if (0 == (nUTI = AT_AllocUserTransID()))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "send msg resp:  malloc UTI error", CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "send msg resp:  malloc UTI error", CfwEvent.nUTI);
#endif
				return;
			}
#ifdef AT_DUAL_SIM

			if (ERR_SUCCESS !=
			        CFW_SmsSetUnSent2Sent(gATCurrentAtSMSInfo[nSim].nStorage2, 0x01, g_CMSS_Index,
			                              CFW_SMS_STORED_STATUS_SENT_NOT_SR_REQ, CfwEvent.nUTI, nSim))
#else
			if (ERR_SUCCESS !=
			        CFW_SmsSetUnSent2Sent(gATCurrentAtSMSInfo[nSim].nStorage2, g_CMSS_Index, CFW_SMS_STORED_STATUS_SENT_NOT_SR_REQ,
			                              CfwEvent.nUTI))

#endif
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "send msg resp: change status error 11", CfwEvent.nUTI,
				                  nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "send msg resp: change status error 11", CfwEvent.nUTI);
#endif
				AT_FreeUserTransID(nUTI);
				return;

			}

			AT_FreeUserTransID(nUTI);

		}

		AT_MemCpy(CMDHeaderInfo, "+CMSS", AT_StrLen("+CMSS"));

	}

	/* check event type */
	if (0 == CfwEvent.nType)
	{
		AT_Sprintf(PromptInfoBuff, "%s: %u", CMDHeaderInfo, (unsigned int)CfwEvent.nParam1);
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, PromptInfoBuff, AT_StrLen(PromptInfoBuff), CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, PromptInfoBuff, AT_StrLen(PromptInfoBuff), CfwEvent.nUTI);
#endif
	}
	else if (0xF0 == CfwEvent.nType)
	{

		nOperationRet = AT_SMS_ERR_Change(CfwEvent.nParam1);
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmss/cmgs send msg resp: CfwEvent.nType == 0xF0", CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmss/cmgs send msg resp: CfwEvent.nType == 0xF0", CfwEvent.nUTI);
#endif

	}
	else
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "cmss/cmgs send msg resp: exception happened", CfwEvent.nUTI,
		                  nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "cmss/cmgs send msg resp: exception happened", CfwEvent.nUTI);
#endif
	}

	return;

}

/******************************************************************************************
Function			:	AT_SMS_ListMessage_rsp
Description		:   	AT list message response
Called By			:	AT_SMS_AsyncEventProcess
Data Accessed   	:
Data Updated    	:
Input			:   	COS_EVENT *pEvent
Output			:
Return			:	UINT32
Others			:   	//[+]for support CMER command :+ciev message 0/1 and cind command 2007.11.06
					modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
VOID AT_SMS_ListMessage_rsp(COS_EVENT *pEvent)
{
	CFW_EVENT CfwEvent = { 0 };

	CFW_SMS_NODE *pPendSmsMsgNode = NULL;

	UINT8 ATAckBuff[480]                   = { 0 };
	UINT8 nNodeIndex                       = 0;
	UINT8 nFormat                          = 0;
	UINT8 nstatus_tmp[12]                  = { 0 };
	UINT8 nDialNumBuff[TEL_NUMBER_MAX_LEN] = { 0 };

	UINT32 nGBKDATASize = 0;
	UINT16 nATBAckLen   = 0;
	UINT8 *pUCS2Data    = NULL;

	UINT8 pUCSLittleEndData[142] = { 0 };
	UINT32 nOperationRet         = ERR_SUCCESS;

#ifdef AT_DUAL_SIM
	UINT8 nSim;
#endif
	// Get event from csw and valicate the parameters
	AT_CosEvent2CfwEvent(pEvent, &CfwEvent);
#ifdef AT_DUAL_SIM
	nSim = CfwEvent.nFlag;
#endif
	/* just for debug */
	AT_TC(g_sw_AT_SMS,
	      "list msg resp: CfwEvent.nType = 0x%x, CfwEvent.nParam1 = 0x%x, CfwEvent.nParam2 >> 16 (total list counter) = %d",
	      CfwEvent.nType, CfwEvent.nParam1, CfwEvent.nParam2 >> 16);

	/* get SMS format and check it */
	nFormat = gATCurrentAtSmsSettingSg_SMSFormat;
	if (nFormat > 1)
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "list msg resp: nFormat > 1 ", CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "list msg resp: nFormat > 1 ", CfwEvent.nUTI);
#endif
		return;
	}

	/* check event type */
	if (0 != CfwEvent.nType)
	{
		if (0xF0 == CfwEvent.nType)
		{
			nOperationRet = AT_SMS_ERR_Change(CfwEvent.nParam1);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "list msg resp: CfwEvent.nType == 0xF0", CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "list msg resp: CfwEvent.nType == 0xF0", CfwEvent.nUTI);
#endif
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "list msg resp:exception happened", CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "list msg resp:exception happened", CfwEvent.nUTI);
#endif
		}

		return;
	}

	// //////////////////////////////////////////////////////////////////////////////////////
	// modify by wangqunyang 2008.04.09
	// /////////////////////////////////////////////////////////////////////////////////////
	for (nNodeIndex = 0; nNodeIndex < (CfwEvent.nParam2 >> 16); nNodeIndex++)
	{
		/* Every cycle we must clear buffer */
		AT_MemSet(nstatus_tmp, 0, 12);
		AT_MemSet(nDialNumBuff, 0, TEL_NUMBER_MAX_LEN);
		AT_MemSet(ATAckBuff, 0, sizeof(ATAckBuff));

		/* Get each list message node and process */

#ifdef AT_DUAL_SIM
		nOperationRet = CFW_SmsGetMessageNode((CFW_SMS_NODE *)(CfwEvent.nParam1), nNodeIndex, &pPendSmsMsgNode, nSim);
#else
		nOperationRet = CFW_SmsGetMessageNode((CFW_SMS_NODE *)(CfwEvent.nParam1), nNodeIndex, &pPendSmsMsgNode);

#endif

		if (nOperationRet != ERR_SUCCESS)
		{
			AT_TC(g_sw_AT_SMS, "list sms: some one message node exception");
			continue; /* Find next node */
		}

		nstatus_tmp[0] = pPendSmsMsgNode->nStatus & 0x0f;

		if (CFW_SMS_STORED_STATUS_UNREAD == nstatus_tmp[0])
		{
			UINT16 nUTI = 0;

			/* decrease the message couter */
			if (g_SMS_CIND_NewMsg > 0)
			{
				g_SMS_CIND_NewMsg--;
			}

			/* get the UTI and free it after finished calling */
			if (0 == (nUTI = AT_AllocUserTransID()))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "list msg resp:  malloc UTI error", /* CfwEvent.nUTI */ nUTI,
				                  nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "list msg resp:  malloc UTI error", /* CfwEvent.nUTI */ nUTI);
#endif
				AT_FREE(pPendSmsMsgNode);
				return;
			}

#ifdef AT_DUAL_SIM

			if (ERR_SUCCESS !=
			        CFW_SmsSetUnRead2Read(gATCurrentAtSMSInfo[nSim].nStorage1, 0x01, pPendSmsMsgNode->nConcatCurrentIndex,
			                              /* CfwEvent.nUTI */ nUTI, nSim))

#else
			if (ERR_SUCCESS !=
			        CFW_SmsSetUnRead2Read(gATCurrentAtSMSInfo[nSim].nStorage1, pPendSmsMsgNode->nConcatCurrentIndex,
			                              C /* CfwEvent.nUTI */ nUTI))

#endif
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "list msg resp: change status unread error", CfwEvent.nUTI,
				                  nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PARA, NULL, 0, "list msg resp: change status unread error", CfwEvent.nUTI);
#endif
				AT_FreeUserTransID(nUTI);
				AT_FREE(pPendSmsMsgNode);
				return;
			}

			AT_FreeUserTransID(nUTI);

		}

		if (!AT_SMS_StatusMacroFlagToStringOrData(nstatus_tmp, nFormat))
		{
			nOperationRet = ERR_AT_CMS_INVALID_STATUS;
			AT_TC(g_sw_AT_SMS, "list sms: status exception 11");
			AT_FREE(pPendSmsMsgNode);
			continue; /* Find next node */
		}

		// printf the sms message node type
		AT_TC(g_sw_AT_SMS, "list msg: pPendSmsMsgNode->nType = %u", pPendSmsMsgNode->nType);

		// modif csdh so ptype0,ptype2 not use 2007.09.27
		// delete ptype0,ptype2 2007.10.10
		// text mode,show param, state = unread/read msg
		if (pPendSmsMsgNode->nType == 1)
		{
			UINT8 type1[2] = "+"; // [mod]bug 7228 2007.12.12
			UINT8 count    = 0;

			CFW_SMS_TXT_DELIVERED_WITH_HRD_INFO *pType1Data = NULL;
			pType1Data = (CFW_SMS_TXT_DELIVERED_WITH_HRD_INFO *)(pPendSmsMsgNode->pNode);

			/* just for debug */
			AT_TC(g_sw_AT_SMS, "pType1Data->length = %u", pType1Data->length);
			AT_TC_MEMBLOCK(g_sw_AT_SMS, pType1Data->data, pType1Data->length, 16);

			// change to ascii and get size
			count = SUL_GsmBcdToAscii(pType1Data->oa, (pType1Data->oa_size), nDialNumBuff);
			if (0xf0 == (*(pType1Data->oa + pType1Data->oa_size - 1) & 0xf0))
			{
				pType1Data->oa_size = (UINT8)(pType1Data->oa_size * 2 - 1);
			}
			else
			{
				pType1Data->oa_size = (UINT8)(pType1Data->oa_size * 2);
			}

			// decide has + or not
			if (pType1Data->tooa != CFW_TELNUMBER_TYPE_INTERNATIONAL)
			{
				type1[0] = '\0';
			}

			if (gATCurrentAtSmsSettingSCSDH_show == 1)  /* CSDH=1 */
			{
				UINT8 *str1 = "+CMGL: %u,\"%s\",\"%s%s\",,\"%u/%02u/%02u,%02u:%02u:%02u+%02d\",%u,%u\r\n";
				UINT8 *str2 = "+CMGL: %u,\"%s\",\"%s%s\",,\"%u/%02u/%02u,%02u:%02u:%02u%03d\",%u,%u\r\n";
				UINT8 *str  = NULL;

				if (pType1Data->scts.iZone < 0)
				{
					str = str2;
				}
				else
				{
					str = str1;
				}

				// output param first
				AT_Sprintf(ATAckBuff, str,
				           pPendSmsMsgNode->nConcatCurrentIndex,
				           nstatus_tmp,
				           type1,
				           nDialNumBuff,
				           pType1Data->scts.uYear,
				           pType1Data->scts.uMonth,
				           pType1Data->scts.uDay,
				           pType1Data->scts.uHour,
				           pType1Data->scts.uMinute,
				           pType1Data->scts.uSecond, pType1Data->scts.iZone, pType1Data->tooa, pType1Data->length);
			}
			else  /* csdh=0 */
			{
				// [+]for csdh use global 2007.09.27
				// [mod]2007.10.17 show scts
				UINT8 *str1 = "+CMGL: %u,\"%s\",\"%s%s\",,\"%u/%02u/%02u,%02u:%02u:%02u+%02d\"\r\n";
				UINT8 *str2 = "+CMGL: %u,\"%s\",\"%s%s\",,\"%u/%02u/%02u,%02u:%02u:%02u%03d\"\r\n";
				UINT8 *str  = NULL;

				if (pType1Data->scts.iZone < 0)
				{
					str = str2;
				}
				else
				{
					str = str1;
				}

				// output param first
				AT_Sprintf(ATAckBuff, str,
				           pPendSmsMsgNode->nConcatCurrentIndex,
				           nstatus_tmp,
				           type1,
				           nDialNumBuff,
				           pType1Data->scts.uYear,
				           pType1Data->scts.uMonth,
				           pType1Data->scts.uDay,
				           pType1Data->scts.uHour,
				           pType1Data->scts.uMinute,
				           pType1Data->scts.uSecond, pType1Data->scts.iZone, pType1Data->tooa, pType1Data->length);

			}

			/* get prompt buffer string length */
			nATBAckLen = AT_StrLen(ATAckBuff);

			/* Chinese message list */
			if (pType1Data->dcs == 2)
			{

				/* From low layer data is big ending and transfer to little ending */
				//AT_Set_MultiLanguage();

				if (!(AT_UnicodeBigEnd2Unicode((UINT8 *)(pType1Data->data), pUCSLittleEndData, pType1Data->length)))
				{
					nOperationRet = ERR_AT_CMS_ME_FAIL;
					AT_FREE(pPendSmsMsgNode);
					AT_TC(g_sw_AT_SMS, "list sms: BigEnd to LittleEnd exception 11");
					continue; /* Find next node */
				}

				if (ERR_SUCCESS !=
				        ML_Unicode2LocalLanguage((UINT8 *)pUCSLittleEndData, pType1Data->length, &pUCS2Data, &nGBKDATASize, NULL))
				{
					nOperationRet = ERR_AT_CMS_ME_FAIL;
					AT_TC(g_sw_AT_SMS, "list sms: unicode to local language exception");
					AT_FREE(pPendSmsMsgNode);
					continue; /* Find next node */

				}

				/* buffer overflow */
				if ((pType1Data->length + nATBAckLen) > sizeof(ATAckBuff))
				{
					nOperationRet = ERR_AT_CMS_INVALID_LEN;
					AT_TC(g_sw_AT_SMS, "list sms: buffer overflow of pType1Data dcs == 2");
					AT_FREE(pPendSmsMsgNode);
					continue; /* Find next node */
				}

				AT_MemCpy(&ATAckBuff[nATBAckLen], pUCS2Data, pType1Data->length);
				nATBAckLen += pType1Data->length;

				// Free inout para resource
				AT_FREE(pUCS2Data);

			}
			else
			{

				/* buffer overflow */
				if ((pType1Data->length + nATBAckLen) > sizeof(ATAckBuff))
				{
					nOperationRet = ERR_AT_CMS_INVALID_LEN;
					AT_TC(g_sw_AT_SMS, "list sms: buffer overflow pType1Data dcs != 2");
					AT_FREE(pPendSmsMsgNode);
					continue; /* Find next node */
				}

				AT_MemCpy(&ATAckBuff[nATBAckLen], (UINT8 *)(pType1Data->data), pType1Data->length);
				nATBAckLen += pType1Data->length;

			}

			// [mod]2007.12.21 for format(based on common.c change)
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI);
#endif

		}
		else if (pPendSmsMsgNode->nType == 3) // text mode, show param, state =sent/unsent msg
		{
			CFW_SMS_TXT_SUBMITTED_WITH_HRD_INFO *pType3Data = NULL;

			UINT8 type1[2] = "+";
			UINT8 count    = 0;

			pType3Data = (CFW_SMS_TXT_SUBMITTED_WITH_HRD_INFO *)(pPendSmsMsgNode->pNode);

			/* just for debug */
			AT_TC(g_sw_AT_SMS, "pType3Data->length = %u", pType3Data->length);
			AT_TC_MEMBLOCK(g_sw_AT_SMS, pType3Data->data, pType3Data->length, 16);

			// change to ascii and get size
			count = SUL_GsmBcdToAscii(pType3Data->da, (pType3Data->da_size), nDialNumBuff);

			if (0xf0 == (*(pType3Data->da + pType3Data->da_size - 1) & 0xf0))
			{
				pType3Data->da_size = (UINT8)(pType3Data->da_size * 2 - 1);
			}
			else
			{
				pType3Data->da_size = (UINT8)(pType3Data->da_size * 2);
			}

			// decide has + or not
			if (pType3Data->toda != CFW_TELNUMBER_TYPE_INTERNATIONAL)
			{
				type1[0] = '\0';
			}

			if (gATCurrentAtSmsSettingSCSDH_show == 1)  // CSDH=1
			{

				// output param first
				AT_Sprintf(ATAckBuff, "+CMGL: %u,\"%s\",\"%s%s\",,%u,%u\r\n",
				           pPendSmsMsgNode->nConcatCurrentIndex,
				           nstatus_tmp, type1, nDialNumBuff, pType3Data->toda, pType3Data->length);
			}
			else  // csdh=0
			{
				// [+]for csdh use global 2007.09.27
				// output param first
				AT_Sprintf(ATAckBuff, "+CMGL: %u,\"%s\",\"%s%s\"\r\n",  // [mod]2007.10.17 remove ",,,"
				           pPendSmsMsgNode->nConcatCurrentIndex, nstatus_tmp, type1, nDialNumBuff);

			}

			/* get prompt buffer string length */
			nATBAckLen = AT_StrLen(ATAckBuff);

			if (pType3Data->dcs == 2) // [mod]2007.09.26 csw param ==2 for chinese sms
			{

				/* From low layer data is big ending and transfer to little ending */
				//AT_Set_MultiLanguage();

				if (!(AT_UnicodeBigEnd2Unicode((UINT8 *)(pType3Data->data), pUCSLittleEndData, pType3Data->length)))
				{
					nOperationRet = ERR_AT_CMS_ME_FAIL;
					AT_FREE(pPendSmsMsgNode);
					AT_TC(g_sw_AT_SMS, "list sms: BigEnd to LittleEnd exception 22");
					continue; /* Find next node */
				}

				if (ERR_SUCCESS !=
				        ML_Unicode2LocalLanguage((UINT8 *)pUCSLittleEndData, pType3Data->length, &pUCS2Data, &nGBKDATASize, NULL))
				{
					nOperationRet = ERR_AT_CMS_ME_FAIL;
					AT_TC(g_sw_AT_SMS, "list sms: unicode to local language exception 22");
					AT_FREE(pPendSmsMsgNode);
					continue; /* Find next node */
				}

				/* buffer overflow */
				if ((pType3Data->length + nATBAckLen) > sizeof(ATAckBuff))
				{
					nOperationRet = ERR_AT_CMS_INVALID_LEN;
					AT_TC(g_sw_AT_SMS, "list sms: buffer overflow pType3Data dcs == 2");
					AT_FREE(pPendSmsMsgNode);
					continue; /* Find next node */
				}

				AT_MemCpy(&ATAckBuff[nATBAckLen], pUCS2Data, pType3Data->length);
				nATBAckLen += pType3Data->length;

				// Free inout para resource
				AT_FREE(pUCS2Data);

			}
			else
			{
				/* buffer overflow */
				if ((pType3Data->length + nATBAckLen) > sizeof(ATAckBuff))
				{
					nOperationRet = ERR_AT_CMS_INVALID_LEN;
					AT_TC(g_sw_AT_SMS, "list sms: buffer overflow pType3Data dcs != 2");
					AT_FREE(pPendSmsMsgNode);
					continue; /* Find next node */
				}

				AT_MemCpy(&ATAckBuff[nATBAckLen], (UINT8 *)(pType3Data->data), pType3Data->length);
				nATBAckLen += pType3Data->length;
			}
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, nSim, CfwEvent.nUTI);
#else
			AT_SMS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI);
#endif

		}
		else if (pPendSmsMsgNode->nType == 7) // PDU mode, pp msg
		{
			CFW_SMS_PDU_INFO *pType7Data = NULL;
			UINT8 BCDDataBuff[200]   = { 0 };
			UINT8 ASCIIDataBuff[400] = { 0 };
			UINT16 nTotalDataLen     = 0;

			pType7Data = (CFW_SMS_PDU_INFO *)(pPendSmsMsgNode->pNode);

			/* just for debug */
			AT_TC(g_sw_AT_SMS, "Original Data: pType7Data->nDataSize = %u", pType7Data->nDataSize);

			/* check the PDU and discard unused char */
			if (!AT_SMS_CheckPDUIsValid(pType7Data->pData, (UINT8 *) & (pType7Data->nDataSize), TRUE))
			{
				nOperationRet = ERR_AT_CMS_INVALID_PDU_CHAR;
				AT_TC(g_sw_AT_SMS, "list sms: check pdu is invalid ");
				AT_FREE(pPendSmsMsgNode);
				continue; /* find next node */
			}

			/* just for debug */
			AT_TC(g_sw_AT_SMS, "Worked Data: pType7Data->nDataSize = %u", pType7Data->nDataSize);
			AT_TC_MEMBLOCK(g_sw_AT_SMS, pType7Data->pData, pType7Data->nDataSize, 16);

			/* get status from the MACRO STATUS */
			if (!(AT_SMS_StatusMacroFlagToStringOrData(&(pType7Data->nStatus), 0)))
			{
				nOperationRet = ERR_AT_CMS_INVALID_STATUS;
				AT_TC(g_sw_AT_SMS, "list sms: status exception 22");
				AT_FREE(pPendSmsMsgNode);
				continue; /* find next node */
			}

			/* output param first */
			AT_Sprintf(ATAckBuff, "+CMGL: %u,%u,,%u\r\n", pPendSmsMsgNode->nConcatCurrentIndex, pType7Data->nStatus, pType7Data->nDataSize - (pType7Data->pData[0] + 1) // old  pType7Data->nDataSize - pType7Data->pData[0] - 1
			          );

			/* get prompt buffer string length */
			nATBAckLen = AT_StrLen(ATAckBuff);

			/* add sca if have not sca */
			nTotalDataLen = pType7Data->nDataSize;
#ifdef AT_DUAL_SIM
			if (!(SMS_AddSCA2PDU(pType7Data->pData, BCDDataBuff, &(nTotalDataLen), nSim)))
#else
			if (!(SMS_AddSCA2PDU(pType7Data->pData, BCDDataBuff, &(nTotalDataLen))))
#endif
			{
				nOperationRet = ERR_AT_CMS_INVALID_PDU_CHAR;
				AT_TC(g_sw_AT_SMS, "list sms: AddSCA2PDU exception ");
				AT_FREE(pPendSmsMsgNode);
				continue; /* find next node */
			}

			/* BCD to ASCII */
			if (!(SMS_PDUBCDToASCII(BCDDataBuff, &(nTotalDataLen), ASCIIDataBuff)))
			{
				nOperationRet = ERR_AT_CMS_INVALID_PDU_CHAR;
				AT_TC(g_sw_AT_SMS, "list sms: PDUBCDToASCII exception ");
				AT_FREE(pPendSmsMsgNode);
				continue; /* find next node */
			}

			/* buffer overflow */
			if ((nATBAckLen + nTotalDataLen) > sizeof(ATAckBuff))
			{
				nOperationRet = ERR_AT_CMS_INVALID_LEN;
				AT_TC(g_sw_AT_SMS, "list sms: pType7Data buffer overflow ");
				AT_FREE(pPendSmsMsgNode);
				continue; /* find next node */
			}

			AT_MemCpy(&ATAckBuff[nATBAckLen], ASCIIDataBuff, nTotalDataLen);
			nATBAckLen += nTotalDataLen;
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI);
#endif

		}
		else if (pPendSmsMsgNode->nType == 8) // PDU mode, CB msg
		{
			nOperationRet = ERR_AT_CMS_RFQ_FAC_NOT_IMP;
		}
		else
		{
			nOperationRet = ERR_AT_CMS_UNKNOWN_ERROR;
		}

		/* finished getting one node then free mem */
		AT_FREE(pPendSmsMsgNode);

	}

	// //////////////////////////////////////////////////////////////////////////
	// check process result is successful or not by wangqunyang 2008.04.09
	// //////////////////////////////////////////////////////////////////////////
	if (nOperationRet == ERR_SUCCESS)
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, CfwEvent.nUTI);
#endif
	}
	else
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(nOperationRet, NULL, 0, "List msg resp: exception happened", CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_Err(nOperationRet, NULL, 0, "List msg resp: exception happened", CfwEvent.nUTI);
#endif
	}

	return;

}

/******************************************************************************************
Function			:	AT_SMS_WriteMessage_rsp
Description		:   	AT write message response
Called By			:	AT_SMS_AsyncEventProcess
Data Accessed   	:
Data Updated    	:
Input			:   	COS_EVENT *pEvent
Output			:
Return			:	UINT32
Others			:
					modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
VOID AT_SMS_WriteMessage_rsp(COS_EVENT *pEvent)
{
	CFW_EVENT CfwEvent                = { 0 };
	CFW_SMS_STORAGE_INFO sStorageInfo = { 0 };

	UINT8 ATAckBuff[32]  = { 0 };
	UINT32 nOperationRet = ERR_SUCCESS;

#ifdef AT_DUAL_SIM
	UINT8 nSim;
#endif
	// Get event from csw
	AT_CosEvent2CfwEvent(pEvent, &CfwEvent);
#ifdef AT_DUAL_SIM
	nSim = CfwEvent.nFlag;
#endif
	/* just for debug */
	AT_TC(g_sw_AT_SMS, "write msg resp: CfwEvent.nType = 0x%x, CfwEvent.nParam1 = 0x%x, CfwEvent.nParam2 = %u",
	      CfwEvent.nType, CfwEvent.nParam1, CfwEvent.nParam2);

	/* check event type */
	if (0 == CfwEvent.nType)
	{
		// output information to user
		AT_Sprintf(ATAckBuff, "+CMGW: %u", (unsigned int)(pEvent->nParam1 & 0x0000ffff));
#ifdef AT_DUAL_SIM
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage2, nSim);
#else
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage2);
#endif
		if (ERR_SUCCESS == nOperationRet)
		{
			gATCurrentAtSMSInfo[nSim].nTotal2 = sStorageInfo.totalSlot;
			gATCurrentAtSMSInfo[nSim].nUsed2  = sStorageInfo.usedSlot;
		}
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, ATAckBuff, AT_StrLen(ATAckBuff), CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, ATAckBuff, AT_StrLen(ATAckBuff), CfwEvent.nUTI);
#endif
	}
	else if (0xF0 == CfwEvent.nType)
	{
		nOperationRet = AT_SMS_ERR_Change(CfwEvent.nParam1);
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(nOperationRet, NULL, 0, "write msg resp: CfwEvent.nType == 0xF0", CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_Err(nOperationRet, NULL, 0, "write msg resp: CfwEvent.nType == 0xF0", CfwEvent.nUTI);
#endif
	}
	else
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "write msg resp:exception happened", CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "write msg resp:exception happened", CfwEvent.nUTI);
#endif
	}

	return;

}
typedef struct _CFW_EV
{
	UINT32 nEventId;
	UINT32 nTransId;  // only low 8bit is valid for all CFW applications.
	UINT32 nParam1;
	UINT32 nParam2;
	UINT8 nType;
	UINT8 nFlag;
	UINT8 padding[2];
} CFW_EV;

UINT32  CFW_MeGetStorageInfo (
#ifndef CFW_MULTI_SIM
    UINT16 nLocation,
#else
    CFW_SIM_ID nSimId,
#endif
    UINT8 nStatus,
    CFW_EV *pEvent
);
VOID AT_SMS_MOInit_MEMessage()
{
	UINT8 nIsFail = 0x0;
	CFW_SIM_ID nSimId;

#ifdef AT_DUAL_SIM
	for(nSimId = CFW_SIM_0; nSimId < CFW_SIM_COUNT; nSimId++)
	{
#endif
		CFW_EV sMeEvent = {0x00,};
		sMeEvent.nParam1 = (UINT32)((UINT8 *)AT_MALLOC(SIZEOF(CFW_SMS_STORAGE_INFO)));

		if((UINT8 *)sMeEvent.nParam1 == NULL)
		{
			CSW_TRACE(CFW_SMS_TS_ID, "AT_SMS_MOInit_MEMessage  sMeEvent.nParam1  malloc error!!! \n ");

		}

		SUL_ZeroMemory8((UINT8 *)sMeEvent.nParam1, SIZEOF(CFW_SMS_STORAGE_INFO));

		CFW_SMS_STORAGE_INFO *pMEStorageInfo = (CFW_SMS_STORAGE_INFO *)(sMeEvent.nParam1);

#ifndef AT_DUAL_SIM
		CFW_MeGetStorageInfo(CFW_SMS_STORAGE_ME, CFW_SMS_STORED_STATUS_STORED_ALL, (CFW_EV *)&sMeEvent);
#else
		CFW_MeGetStorageInfo(nSimId, CFW_SMS_STORED_STATUS_STORED_ALL, (CFW_EV *)&sMeEvent);
#endif

		CFW_SMS_STORAGE_INFO sStorageInfo;
		SUL_ZeroMemory8(&sStorageInfo, SIZEOF(CFW_SMS_STORAGE_INFO));

		if(sMeEvent.nType == 0)
		{
			sStorageInfo.storageId = CFW_SMS_STORAGE_ME;
			sStorageInfo.totalSlot = pMEStorageInfo->totalSlot;
			sStorageInfo.usedSlot  = pMEStorageInfo->usedSlot;

			//Get ME unReadRecords
			CFW_SMS_STORAGE_INFO *nTmpEventP1 = (CFW_SMS_STORAGE_INFO *)sMeEvent.nParam1;

			SUL_ZeroMemory8(&sMeEvent, SIZEOF(CFW_EV));
			SUL_ZeroMemory8((UINT8 *)nTmpEventP1, SIZEOF(CFW_SMS_STORAGE_INFO));

			sMeEvent.nParam1 = (UINT32)nTmpEventP1;

#ifndef AT_DUAL_SIM
			CFW_MeGetStorageInfo(CFW_SMS_STORAGE_ME, CFW_SMS_STORED_STATUS_UNREAD, &sMeEvent);
#else
			CFW_MeGetStorageInfo(nSimId, CFW_SMS_STORED_STATUS_UNREAD, &sMeEvent);
#endif
			if(sMeEvent.nType == 0)
			{
				sStorageInfo.unReadRecords = pMEStorageInfo->usedSlot;
				//Get ME readRecords
				nTmpEventP1 = (CFW_SMS_STORAGE_INFO *)sMeEvent.nParam1;
				SUL_ZeroMemory8(&sMeEvent, SIZEOF(CFW_EV));
				SUL_ZeroMemory8((UINT8 *)nTmpEventP1, SIZEOF(CFW_SMS_STORAGE_INFO));

				sMeEvent.nParam1 = (UINT32)nTmpEventP1;

#ifndef AT_DUAL_SIM
				CFW_MeGetStorageInfo(CFW_SMS_STORAGE_ME, CFW_SMS_STORED_STATUS_READ, &sMeEvent);
#else
				CFW_MeGetStorageInfo(nSimId, CFW_SMS_STORED_STATUS_READ, &sMeEvent);
#endif

				if(sMeEvent.nType == 0)
				{
					UINT8 nSentStatus = 0x0;

					sStorageInfo.readRecords = pMEStorageInfo->usedSlot;
					//Get ME sentRecords
					nTmpEventP1 = (CFW_SMS_STORAGE_INFO *)sMeEvent.nParam1;

					SUL_ZeroMemory8(&sMeEvent, SIZEOF(CFW_EV));
					SUL_ZeroMemory8((UINT8 *)nTmpEventP1, SIZEOF(CFW_SMS_STORAGE_INFO));

					sMeEvent.nParam1 = (UINT32)nTmpEventP1;

					nSentStatus = CFW_SMS_STORED_STATUS_SENT_NOT_SR_REQ | CFW_SMS_STORED_STATUS_SENT_SR_REQ_NOT_RECV |
					              CFW_SMS_STORED_STATUS_SENT_SR_REQ_NOT_STORE | CFW_SMS_STORED_STATUS_SENT_SR_REQ_RECV_STORE;
#ifndef AT_DUAL_SIM
					CFW_MeGetStorageInfo(CFW_SMS_STORAGE_ME, nSentStatus, &sMeEvent);
#else
					CFW_MeGetStorageInfo(nSimId, nSentStatus, &sMeEvent);
#endif


					if(sMeEvent.nType == 0)
					{
						sStorageInfo.sentRecords = pMEStorageInfo->usedSlot;

						//Get ME unsentRecords
						nTmpEventP1 = (CFW_SMS_STORAGE_INFO *)sMeEvent.nParam1;

						SUL_ZeroMemory8(&sMeEvent, SIZEOF(CFW_EV));
						SUL_ZeroMemory8((UINT8 *)nTmpEventP1, SIZEOF(CFW_SMS_STORAGE_INFO));

						sMeEvent.nParam1 = (UINT32)nTmpEventP1;
#ifndef AT_DUAL_SIM
						CFW_MeGetStorageInfo(CFW_SMS_STORAGE_ME, CFW_SMS_STORED_STATUS_UNSENT, &sMeEvent);
#else
						CFW_MeGetStorageInfo(nSimId, CFW_SMS_STORED_STATUS_UNSENT, &sMeEvent);
#endif
						CSW_TRACE(CFW_SMS_TS_ID, TSTXT("MeGetSI 0\n"));

						if(sMeEvent.nType == 0)
						{
							sStorageInfo.unsentRecords = pMEStorageInfo->usedSlot;
#ifndef AT_DUAL_SIM
							CFW_CfgSetSmsStorageInfo(&sStorageInfo, CFW_SMS_STORAGE_ME);
#else
							CFW_CfgSetSmsStorageInfo(&sStorageInfo, CFW_SMS_STORAGE_ME, nSimId);
#endif

							CSW_TRACE(CFW_SMS_TS_ID, TSTXT("MeGetSI 1 \n"));

							//Add by lixp at 20090213 for free crash issue
#ifdef AT_DUAL_SIM
							if( nSimId == ( CFW_SIM_COUNT - 1 ))
							{
								CSW_SMS_FREE((UINT8 *)sMeEvent.nParam1);
							}
#else
							CSW_SMS_FREE((UINT8 *)sMeEvent.nParam1);
#endif
						}//unsentRecords
						else
						{
							nIsFail = 1;
						}
					}//sentRecords
					else
					{
						nIsFail = 2;
					}
				}//readRecords
				else
				{
					nIsFail = 3;
				}
			}//unReadRecords
			else
			{
				nIsFail = 4;
			}
		}//totalSlot and usedSlot
		else
		{
			nIsFail = 5;
		}

		if(nIsFail)
		{
			CSW_TRACE(CFW_SMS_TS_ID, TSTXT("AT_SMS_MOInit_MEMessage failed  nIsFail %d\n"), nIsFail);
			break;
		}
	}


}

VOID AT_SMS_MOInit_ReadMessage_rsp(COS_EVENT *pEvent)
{
	static UINT8 nIndex[NUMBER_OF_SIM]     = {1, 1};

	UINT8 nFormat           = 0;
	UINT8 nstatus_tmp[12]   = { 0 };
	UINT8 urc_str[100]      = { 0 };


	CFW_EVENT CfwEvent      = { 0 };
	CFW_SMS_NODE *pNode     = NULL;
	PAT_CMD_RESULT pResult  = NULL;

	UINT16 nUTI = 0;

	AT_CosEvent2CfwEvent(pEvent, &CfwEvent);

#ifdef AT_DUAL_SIM
	UINT8 nSim  = CfwEvent.nFlag;;
#endif

	/* just for debug */
	AT_TC(g_sw_AT_SMS, "AT_SMS_MOInit_ReadMessage_rsp: CfwEvent.nType = 0x%x, CfwEvent.nParam1 = 0x%x, CfwEvent.nParam2 = %u,nSim %d",
	      CfwEvent.nType, CfwEvent.nParam1, CfwEvent.nParam2, nSim);

	CFW_SMS_STORAGE_INFO  sStorageInfo;
	SUL_ZeroMemory8(&sStorageInfo, SIZEOF(CFW_SMS_STORAGE_INFO));

	CFW_CfgGetSmsStorageInfo(&sStorageInfo, CFW_SMS_STORAGE_SM, nSim);
	AT_TC(g_sw_SA, "sStorageInfo.totalSlot 0x%x nIndex[nSim] %d nSim %d", sStorageInfo.totalSlot, nIndex[nSim], nSim);
	//hal_HstSendEvent(0xA1300000 + (nIndex[nSim]<<8) + nSim);
	if (0x00 != CfwEvent.nType)
	{
		if (0xF0 == CfwEvent.nType)
		{
			if(++nIndex[nSim] <= sStorageInfo.totalSlot)
			{

				AT_TC(g_sw_AT_SMS, "Begin Read nIndex[nSim] %d nSim %d", nIndex[nSim], nSim);

				UINT32 nRet = CFW_SmsReadMessage(CFW_SMS_STORAGE_SM, CFW_SMS_TYPE_PP, nIndex[nSim], CfwEvent.nUTI, nSim);

				if(ERR_SUCCESS != nRet)
				{
					AT_TC(g_sw_AT_SMS, "CFW_SmsReadMessage Error 0x%x", nRet);
					AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "SMS MO Init: ReadMessage error", nUTI, nSim);
					AT_ModuleSetInitResult(AT_MODULE_INIT_SIM_SMS_ERROR);
					return ;
				}
			}
			else
			{
				//Init Over
				AT_TC(g_sw_AT_SMS, "SMS INIT Success usedSlot %d total %d nSim %d", sStorageInfo.usedSlot, sStorageInfo.totalSlot, nSim);

				CFW_EVENT cfw_event;
				UINT32 ats_stat = 0;

				AT_ModuleSetInitResult(AT_MODULE_INIT_SIM_SMS_OK);

				/* get the UTI and free it after finished calling */
				if (0 == (nUTI = AT_AllocUserTransID()))
				{
					//hal_HstSendEvent(0xa130001);
					AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr: malloc UTI error", cfw_event.nUTI, nSim);
					return ;
				}
#ifdef  __NGUX_PLATFORM__
				UINT32 ret = CFW_SmsInitComplete(TRUE, nUTI, nSim);
#else
				UINT32 ret = CFW_SmsInitComplete(nUTI, nSim);
#endif
				if(ERR_SUCCESS != ret)
				{
					AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "SMS Init Complete failed", cfw_event.nUTI, nSim);
					return ;

				}
				AT_SMS_INIT(nSim);

				SUL_ZeroMemory8(&cfw_event, SIZEOF(cfw_event));

				cfw_event.nType   = CFW_INIT_STATUS_SMS;
				cfw_event.nParam1 = sStorageInfo.totalSlot;
				AT_MemCpy(&(cfwInitInfo.sms[nSim]), &cfw_event, sizeof(cfw_event));

				// Notify SA that the SMS (ATS) module is ready for use.
				ats_stat = SA_GetSysStatus(SA_ATS_INIT_STATUS);

				ats_stat |= SA_ATS_SMS_READY;

				SA_SetSysStatus(SA_ATS_INIT_STATUS, ats_stat);

				AT_Sprintf(urc_str, "^CINIT: SMS %u, %u, %u", cfw_event.nType, cfw_event.nParam1, cfw_event.nParam2);
				pResult = AT_CreateRC(CSW_IND_NOTIFICATION,
				                      CMD_RC_CR,
				                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, urc_str, (UINT16)AT_StrLen(urc_str), 0);
				AT_TC(g_sw_SA, "send an SMS URC to ATM, URC string=%s", urc_str);
				AT_Notify2ATM(pResult, cfw_event.nUTI);
				AT_TC(g_sw_SA, TSTXT("set gATCurrentuCmer_ind nSim[%d] to 2\n"), nSim);
				gATCurrentuCmer_ind[nSim]           = 2;
				gATCurrentAtSMSInfo[nSim].sCnmi.nMt = 2;

				AT_SMS_MOInit_MEMessage();

			}

		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "MO Init read msg resp: exception happened", CfwEvent.nUTI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "MO Init read msg resp: exception happened", CfwEvent.nUTI);
#endif
		}

		return;
	}
	pNode          = (CFW_SMS_NODE *)CfwEvent.nParam1;
	nFormat        = gATCurrentAtSmsSettingSg_SMSFormat;
	nstatus_tmp[0] = pNode->nStatus & 0x0f;

	if (nstatus_tmp[0] == CFW_SMS_STORED_STATUS_READ)
	{
		sStorageInfo.readRecords++;
	}
	else if (nstatus_tmp[0] == CFW_SMS_STORED_STATUS_UNREAD)
	{
		sStorageInfo.unReadRecords++;
	}
	else if (nstatus_tmp[0] == CFW_SMS_STORED_STATUS_SENT_NOT_SR_REQ ||
	         nstatus_tmp[0] == CFW_SMS_STORED_STATUS_SENT_SR_REQ_NOT_RECV ||
	         nstatus_tmp[0] == CFW_SMS_STORED_STATUS_SENT_SR_REQ_NOT_STORE ||
	         nstatus_tmp[0] == CFW_SMS_STORED_STATUS_SENT_SR_REQ_RECV_STORE )
	{
		sStorageInfo.sentRecords++;
	}
	else if (nstatus_tmp[0] == CFW_SMS_STORED_STATUS_UNSENT)
	{
		sStorageInfo.unsentRecords++;
	}
	else
	{
		AT_TC(g_sw_AT_SMS, "Exception Status 0x%x", nstatus_tmp[0]);
		sStorageInfo.unknownRecords++;
		//return ;
	}

	sStorageInfo.usedSlot++;

	CFW_CfgSetSmsStorageInfo(&sStorageInfo, CFW_SMS_STORAGE_SM, nSim);


	if(++nIndex[nSim] <= sStorageInfo.totalSlot)
	{

		AT_TC(g_sw_AT_SMS, "Current Index %d,Total %d nSim %d", nIndex[nSim], sStorageInfo.totalSlot, nSim);
		UINT32 nRet = CFW_SmsReadMessage(CFW_SMS_STORAGE_SM, CFW_SMS_TYPE_PP, nIndex[nSim], CfwEvent.nUTI, nSim);

		if(ERR_SUCCESS != nRet)
		{
			AT_TC(g_sw_SA, "CFW_SmsReadMessage Error 0x%x", nRet);
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "SMS MO Init: ReadMessage error", nUTI, nSim);
			AT_ModuleSetInitResult(AT_MODULE_INIT_SIM_SMS_ERROR);
			//hal_HstSendEvent(0xa130003);

			return ;
		}
	}
	else
	{
		//Init Over
		AT_TC(g_sw_AT_SMS, "SMS INIT Success usedSlot %d total %d nSim %d", sStorageInfo.usedSlot, sStorageInfo.totalSlot, nSim);

		CFW_EVENT cfw_event;
		UINT32 ats_stat = 0;

		AT_ModuleSetInitResult(AT_MODULE_INIT_SIM_SMS_OK);

		/* get the UTI and free it after finished calling */
		if (0 == (nUTI = AT_AllocUserTransID()))
		{
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr: malloc UTI error", cfw_event.nUTI, nSim);
			return ;
		}
#ifdef  __NGUX_PLATFORM__
		CFW_SmsInitComplete(TRUE, nUTI, nSim);
#else
		CFW_SmsInitComplete(nUTI, nSim);
#endif
		AT_SMS_INIT(nSim);  // hameina[+]

		SUL_ZeroMemory8(&cfw_event, SIZEOF(cfw_event));
		cfw_event.nType = CFW_INIT_STATUS_SMS;
		cfw_event.nParam1 = 0;


		AT_Sprintf(urc_str, "^CINIT: SMS %u, %u, %u", cfw_event.nType, cfw_event.nParam1, cfw_event.nParam2);
		pResult = AT_CreateRC(CSW_IND_NOTIFICATION,
		                      CMD_RC_CR,
		                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, urc_str, (UINT16)AT_StrLen(urc_str), 0);
		AT_TC(g_sw_SA, "send an SMS URC to ATM, URC string=%s", urc_str);

		AT_TC(g_sw_SA, "sStorageInfo.usedSlot 0x%x", sStorageInfo.usedSlot);

		AT_Notify2ATM(pResult, cfw_event.nUTI);
		AT_TC(g_sw_SA, TSTXT("Set gATCurrentuCmer_ind nSim[%d] to 2\n"), nSim);
		gATCurrentuCmer_ind[nSim]           = 2;
		gATCurrentAtSMSInfo[nSim].sCnmi.nMt = 2;
		AT_MemCpy(&(cfwInitInfo.sms[nSim]), &cfw_event, sizeof(cfw_event));

		// Notify SA that the SMS (ATS) module is ready for use.
		ats_stat = SA_GetSysStatus(SA_ATS_INIT_STATUS);

		ats_stat |= SA_ATS_SMS_READY;

		SA_SetSysStatus(SA_ATS_INIT_STATUS, ats_stat);
		AT_SMS_MOInit_MEMessage();
		//Init Over
	}


	return;

}
/******************************************************************************************
Function			:	AT_SMS_CMSS_ReadMessage_rsp
Description		:   	AT CMSS COMMAND read message response
Called By			:
Data Accessed   	:
Data Updated    	:
Input			:   	COS_EVENT *pEvent
Output			:
Return			:	VOID
Others			:
					modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
VOID AT_SMS_CMSS_ReadMessage_rsp(COS_EVENT *pEvent)
{

	CFW_DIALNUMBER Number = { 0 };
	CFW_EVENT CfwEvent    = { 0 };
	UINT8 *SmsData        = NULL;

	CFW_SMS_NODE *pNode = NULL;

	UINT8 nToDA           = CFW_TELNUMBER_TYPE_UNKNOWN;
	UINT8 nFormat         = 0;
	UINT8 nstatus_tmp[12] = { 0 };

	UINT32 nOperationRet = ERR_SUCCESS;
	UINT32 nSendMsgRet   = ERR_SUCCESS;

	UINT16 SmsDatalen = 0;

	UINT16 nUTI = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim;
#endif
	AT_CosEvent2CfwEvent(pEvent, &CfwEvent);
#ifdef AT_DUAL_SIM
	nSim = CfwEvent.nFlag;
#endif
	/* just for debug */
	AT_TC(g_sw_AT_SMS, "cmss read msg resp: CfwEvent.nType = 0x%x, CfwEvent.nParam1 = 0x%x, CfwEvent.nParam2 = %u",
	      CfwEvent.nType, CfwEvent.nParam1, CfwEvent.nParam2);

	/* check event type */
	if (0 != CfwEvent.nType)
	{
		if (0xF0 == CfwEvent.nType)
		{
			nOperationRet = AT_SMS_ERR_Change(CfwEvent.nParam1);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmss read msg resp: CfwEvent.nType == 0xF0", CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmss read msg resp: CfwEvent.nType == 0xF0", CfwEvent.nUTI);
#endif
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "cmss read msg resp: exception happened", CfwEvent.nUTI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "cmss read msg resp: exception happened", CfwEvent.nUTI);
#endif
		}

		return;
	}

	pNode          = (CFW_SMS_NODE *)CfwEvent.nParam1;
	nFormat        = gATCurrentAtSmsSettingSg_SMSFormat;
	nstatus_tmp[0] = pNode->nStatus & 0x0f;

	// save the cmss related status
	g_CMSS_Status = nstatus_tmp[0];

	if (!AT_SMS_StatusMacroFlagToStringOrData(nstatus_tmp, nFormat))
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_INVALID_STATUS, NULL, 0,
		                  "cmss read msg resp: AT_SMS_StatusMacroFlagToStringOrData Error", CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_INVALID_STATUS, NULL, 0,
		                  "cmss read msg resp: AT_SMS_StatusMacroFlagToStringOrData Error", CfwEvent.nUTI);
#endif
		return;
	}

	/* just for debug */
	AT_TC(g_sw_AT_SMS, "cmss read msg resp: pNode->nType = %u", pNode->nType);

	// ////////////////////////////////////////////////////////////////////////////////
	// modif csdh so ptype0,ptype2 not use 2007.09.27
	// delete ptype0,ptype2 2007.10.10
	// ///////////////////////////////////////////////////////////////////////////////
	if (pNode->nType == 1)  /* text mode,show param, state = unread/read msg */
	{
		CFW_SMS_TXT_DELIVERED_WITH_HRD_INFO *pType1Data = NULL;
		pType1Data = (CFW_SMS_TXT_DELIVERED_WITH_HRD_INFO *)(pNode->pNode);

		/* just for debug */
		AT_TC(g_sw_AT_SMS, "pType1Data->length = %u", pType1Data->length);
		AT_TC_MEMBLOCK(g_sw_AT_SMS, pType1Data->data, pType1Data->length, 16);

		SmsDatalen = pType1Data->length;
		SmsData    = (UINT8 *)AT_MALLOC(SmsDatalen);

		if (!SmsData)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmss read msg resp: malloc failure 1", CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmss read msg resp: malloc failure 1", CfwEvent.nUTI);
#endif
			return;
		}

		AT_MemSet(SmsData, 0, SmsDatalen);
		AT_MemCpy(SmsData, pType1Data->data, SmsDatalen);

		if (g_CMSS_DA_Flag == 1)
		{
			Number.nDialNumberSize = g_CMSS_BCDLen;
			Number.pDialNumber     = g_CMSS_BCD;
			Number.nType           = g_CMSS_nToDA;

		}
		else
		{

			Number.nDialNumberSize = pType1Data->oa_size;
			Number.pDialNumber     = pType1Data->oa;
			Number.nType           = nToDA;

		}

		/* get the UTI and free it after finished calling */
		if (0 == (nUTI = AT_AllocUserTransID()))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmss read msg resp:  malloc UTI error", CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmss read msg resp:  malloc UTI error", CfwEvent.nUTI);
#endif
			return;
		}

		/* Send message and free UTI */

#ifdef AT_DUAL_SIM
		nSendMsgRet = CFW_SmsSendMessage(&Number, SmsData, SmsDatalen, CfwEvent.nUTI, nSim);
#else
		nSendMsgRet = CFW_SmsSendMessage(&Number, SmsData, SmsDatalen, CfwEvent.nUTI);

#endif

		AT_FreeUserTransID(nUTI);

		AT_FREE(SmsData);

	}
	else if (pNode->nType == 3) /* text mode, show param, state =sent/unsent msg */
	{
		CFW_SMS_TXT_SUBMITTED_WITH_HRD_INFO *pType3Data;
		pType3Data = (CFW_SMS_TXT_SUBMITTED_WITH_HRD_INFO *)(pNode->pNode);

		/* just for debug */
		AT_TC(g_sw_AT_SMS, "pType3Data->length = %u", pType3Data->length);
		AT_TC_MEMBLOCK(g_sw_AT_SMS, pType3Data->data, pType3Data->length, 16);

		SmsDatalen = pType3Data->length;
		SmsData    = (UINT8 *)AT_MALLOC(SmsDatalen);

		if (!SmsData)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmss read msg resp: malloc failure 2", CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmss read msg resp: malloc failure 2", CfwEvent.nUTI);
#endif
			return;
		}

		AT_MemSet(SmsData, 0, SmsDatalen);
		AT_MemCpy(SmsData, pType3Data->data, SmsDatalen);

		if (g_CMSS_DA_Flag == 1)
		{
			Number.nDialNumberSize = g_CMSS_BCDLen;
			Number.pDialNumber     = g_CMSS_BCD;
			Number.nType           = g_CMSS_nToDA;

		}
		else
		{

			Number.nDialNumberSize = pType3Data->da_size;
			Number.pDialNumber     = pType3Data->da;
			Number.nType           = nToDA;

		}

		/* get the UTI and free it after finished calling */
		if (0 == (nUTI = AT_AllocUserTransID()))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmss read msg resp: malloc UTI error", nSim, CfwEvent.nUTI);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmss read msg resp: malloc UTI error", CfwEvent.nUTI);
#endif
			return;
		}

		/* Send message and free UTI */

#ifdef AT_DUAL_SIM
		nSendMsgRet = CFW_SmsSendMessage(&Number, SmsData, SmsDatalen, CfwEvent.nUTI, nSim);
#else
		nSendMsgRet = CFW_SmsSendMessage(&Number, SmsData, SmsDatalen, CfwEvent.nUTI);

#endif

		AT_FreeUserTransID(nUTI);

		AT_FREE(SmsData);

	}
	else if (pNode->nType == 7) /* PDU mode, pp msg */
	{
		CFW_SMS_PDU_INFO *pType7Data = NULL;
		UINT8 BCDDataBuff[200] = { 0 };

		pType7Data = (CFW_SMS_PDU_INFO *)(pNode->pNode);

		/* just for debug */
		AT_TC(g_sw_AT_SMS, "Original Data: pType7Data->nDataSize = %u", pType7Data->nDataSize);

		/* check recv pdu and discard unused char */
		if (!(AT_SMS_CheckPDUIsValid((UINT8 *)pType7Data->pData, (UINT8 *) & (pType7Data->nDataSize), TRUE)))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "cmss read msg resp: check pdu is invalid", CfwEvent.nUTI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "cmss read msg resp: check pdu is invalid",
			                  CfwEvent.nUTI);
#endif
			return;
		}

		/* just for debug */
		AT_TC(g_sw_AT_SMS, "Worked Data: pType7Data->nDataSize = %u", pType7Data->nDataSize);
		AT_TC_MEMBLOCK(g_sw_AT_SMS, pType7Data->pData, pType7Data->nDataSize, 16);

		if (g_CMSS_DA_Flag == 1)
		{

			UINT8 nSCAlen     = 0, nDAlen = 0, PDUCopyIndex = 0;
			UINT8 oldDABcdlen = 0;

			nSCAlen     = pType7Data->pData[0];
			nDAlen      = pType7Data->pData[nSCAlen + 1 + 2];
			oldDABcdlen = (nDAlen % 2 ? (nDAlen / 2) + 1 : (nDAlen / 2));
			SmsDatalen  = pType7Data->nDataSize + g_CMSS_BCDLen - oldDABcdlen;

			SmsData = (UINT8 *)AT_MALLOC(SmsDatalen);
			AT_MemSet(SmsData, 0, SmsDatalen);
			if (!SmsData)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmss read msg resp: malloc failure 3 ", CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmss read msg resp: malloc failure 3 ", CfwEvent.nUTI);
#endif
				return;

			}

			SmsData[nSCAlen + 3] = g_CMSS_StringLen;

			if (g_CMSS_nToDA != 0)
			{
				SmsData[nSCAlen + 3 + 1] = g_CMSS_nToDA;
			}
			else
			{
				if (g_CMSS_BCD[0] == 0x68)
				{
					SmsData[nSCAlen + 3 + 1] = 145;
				}
				else
				{
					SmsData[nSCAlen + 3 + 1] = 129;
				}
			}

			AT_MemCpy(&SmsData[nSCAlen + 5], g_CMSS_BCD, g_CMSS_BCDLen);

			PDUCopyIndex = nSCAlen + 1 + 2 + oldDABcdlen + 2;

			AT_MemCpy(&(SmsData[PDUCopyIndex + g_CMSS_BCDLen - oldDABcdlen]), &(pType7Data->pData[PDUCopyIndex]),
			          pType7Data->nDataSize - PDUCopyIndex);
			AT_MemCpy(SmsData, pType7Data->pData, nSCAlen + 3);

		}

		else
		{

			SmsDatalen = pType7Data->nDataSize;
			SmsData    = (UINT8 *)AT_MALLOC(SmsDatalen);

			AT_MemSet(SmsData, 0, SmsDatalen);
			if (!SmsData)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmss read msg resp: malloc failure 4", CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "cmss read msg resp: malloc failure 4", CfwEvent.nUTI);
#endif
				return;

			}

			AT_MemCpy(SmsData, pType7Data->pData, SmsDatalen);

		}

		/* add sca for read data if have not SCA */
#ifdef AT_DUAL_SIM
		if (!(SMS_AddSCA2PDU(SmsData, BCDDataBuff, &(SmsDatalen), nSim)))
#else
		if (!(SMS_AddSCA2PDU(SmsData, BCDDataBuff, &(SmsDatalen))))
#endif
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "CDSPDUReport: format is not match", CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmss read msg resp: AddSCA2PDU error", CfwEvent.nUTI);
#endif
			return;
		}

		/* get the UTI and free it after finished calling */
		if (0 == (nUTI = AT_AllocUserTransID()))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmss read msg resp:  malloc UTI error", nSim, CfwEvent.nUTI);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmss read msg resp:  malloc UTI error", CfwEvent.nUTI);
#endif
			return;
		}

		/* Send message and free UTI */

#ifdef AT_DUAL_SIM
		nSendMsgRet = CFW_SmsSendMessage(NULL, BCDDataBuff, SmsDatalen, CfwEvent.nUTI, nSim);
#else
		nSendMsgRet = CFW_SmsSendMessage(NULL, BCDDataBuff, SmsDatalen, CfwEvent.nUTI);

#endif

		AT_FreeUserTransID(nUTI);

		AT_FREE(SmsData);

	}
	else if (pNode->nType == 8) // PDU mode, CB msg
	{
		nSendMsgRet = ERR_AT_CMS_ERR_IN_MS;
	}
	else
	{
		nSendMsgRet = ERR_AT_CMS_ERR_IN_MS;
	}

	/* Judge the send message successful or not */
	if (ERR_SUCCESS != nSendMsgRet)
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(nSendMsgRet, NULL, 0, "cmss read msg resp: send read msg check param failure", CfwEvent.nUTI,
		                  nSim);
#else
		AT_SMS_Result_Err(nSendMsgRet, NULL, 0, "cmss read msg resp: send read msg check param failure", CfwEvent.nUTI);
#endif
	}
	else
	{
		/* Different networks have different response time, according to networks status,
		   ** we set general enough time(here is 60s ) to waiting for networks response */
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, NULL, 0, CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, NULL, 0, CfwEvent.nUTI);
#endif
	}

	return;

}

/******************************************************************************************
Function			:	AT_SMS_ReadMessage_rsp
Description		:   	AT SMS module read message response
Called By			:	At SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	COS_EVENT *pEvent
Output			:
Return			:	VOID
Others			:
					modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
VOID AT_SMS_CMGR_ReadMessage_rsp(COS_EVENT *pEvent)
{
	CFW_EVENT CfwEvent = { 0 };

	CFW_SMS_NODE *pNode = NULL;

	UINT8 ATAckBuff[480]                 = { 0 };
	UINT16 nATBAckLen                    = 0;
	UINT8 nFormat                        = 0;
	UINT8 nstatus_tmp[12]                = { 0 };
	UINT8 nNumber[TEL_NUMBER_MAX_LEN]    = { 0 };
	UINT8 nNumberSca[TEL_NUMBER_MAX_LEN] = { 0 };
	UINT8 pUCSLittleEndData[142]         = { 0 };

	UINT8 *pUCS2Data    = NULL;
	UINT32 nGBKDATASize = 0;
	UINT8 nDcs          = 0;

	UINT32 count         = 0;
	UINT32 nOperationRet = ERR_SUCCESS;

#ifdef AT_DUAL_SIM
	UINT8 nSim;
#endif
	/* get event */
	AT_CosEvent2CfwEvent(pEvent, &CfwEvent);
#ifdef AT_DUAL_SIM
	nSim = CfwEvent.nFlag;
#endif
	/* just for debug */
	AT_TC(g_sw_AT_SMS, "cmgr read msg resp: CfwEvent.nType = 0x%x, CfwEvent.nParam1 = 0x%x, CfwEvent.nParam2 = %u",
	      CfwEvent.nType, CfwEvent.nParam1, CfwEvent.nParam2);

	/* check event type */
	if (0 != CfwEvent.nType)
	{
		if (0xF0 == CfwEvent.nType)
		{
			nOperationRet = AT_SMS_ERR_Change(CfwEvent.nParam1);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmgr read msg resp: CfwEvent.nType == 0xF0", nSim, CfwEvent.nUTI);
#else
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmgr read msg resp: CfwEvent.nType == 0xF0", CfwEvent.nUTI);
#endif
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "cmgr read msg resp:  exception happened", CfwEvent.nUTI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "cmgr read msg resp:  exception happened", CfwEvent.nUTI);
#endif
		}

		return;
	}

	pNode          = (CFW_SMS_NODE *)CfwEvent.nParam1;
	nFormat        = gATCurrentAtSmsSettingSg_SMSFormat;
	nstatus_tmp[0] = pNode->nStatus & 0x0f;

	if (CFW_SMS_STORED_STATUS_UNREAD == nstatus_tmp[0])
	{
		/* decrease the message couter */
		if (g_SMS_CIND_NewMsg > 0)
		{
			g_SMS_CIND_NewMsg--;
		}
	}

	if (!AT_SMS_StatusMacroFlagToStringOrData(nstatus_tmp, nFormat))
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_INVALID_STATUS, NULL, 0, "cmgr read msg resp: status exception", CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_INVALID_STATUS, NULL, 0, "cmgr read msg resp: status exception", CfwEvent.nUTI);
#endif
		return;

	}

	/* just for debug */
	AT_TC(g_sw_AT_SMS, "cmgr read msg resp: pNode->nType = %u", pNode->nType);

	// /////////////////////////////////////////////////////
	// text mode,show param, state = unread/read msg
	// ///////////////////////////////////////////////////////
	if (pNode->nType == 1)
	{
		UINT8 type1[2] = "+";
		UINT8 type2[2] = "+";

		CFW_SMS_TXT_DELIVERED_WITH_HRD_INFO *pType1Data = NULL;

		pType1Data = (CFW_SMS_TXT_DELIVERED_WITH_HRD_INFO *)(pNode->pNode);

		/* just for debug */
		AT_TC(g_sw_AT_SMS, "pType1Data->length = %u", pType1Data->length);
		AT_TC_MEMBLOCK(g_sw_AT_SMS, pType1Data->data, pType1Data->length, 16);

		// change to ascii and get size
		count = SUL_GsmBcdToAscii(pType1Data->oa, (pType1Data->oa_size), nNumber);

		if (0xf0 == (*(pType1Data->oa + pType1Data->oa_size - 1) & 0xf0))
		{
			pType1Data->oa_size = (UINT8)(pType1Data->oa_size * 2 - 1);
		}
		else
		{
			pType1Data->oa_size = (UINT8)(pType1Data->oa_size * 2);
		}

		// sca  change to ascii and get size
		count = SUL_GsmBcdToAscii(pType1Data->sca, (pType1Data->sca_size), nNumberSca);

		if (0xf0 == (*(pType1Data->sca + pType1Data->sca_size - 1) & 0xf0))
		{
			pType1Data->sca_size = (UINT8)(pType1Data->sca_size * 2 - 1);
		}
		else
		{
			pType1Data->sca_size = (UINT8)(pType1Data->sca_size * 2);
		}

		// decide has + or not
		if (pType1Data->tooa != CFW_TELNUMBER_TYPE_INTERNATIONAL)
		{
			type1[0] = '\0';  // [mod]bug7227
		}

		if (pType1Data->tosca != CFW_TELNUMBER_TYPE_INTERNATIONAL)
		{
			type2[0] = '\0';  // [mod]bug7277
		}

		// ///////////////////////////////////////////////////////
		// output param first
		// [+] for dcs change from csw to correct value(3GPP) 2007.10.10
		// //////////////////////////////////////////////////////////
		nDcs = AT_SMS_DCSChange(pType1Data->dcs, nDcs);

		if (gATCurrentAtSmsSettingSCSDH_show == 1)  /* CSDH=1 */
		{

			UINT8 *str1 = "+CMGR: \"%s\",\"%s%s\",,\"%u/%02u/%02u,%02u:%02u:%02u+%02d\",%u,%u,%u,%u,\"%s%s\",%u,%u\r\n";
			UINT8 *str2 = "+CMGR: \"%s\",\"%s%s\",,\"%u/%02u/%02u,%02u:%02u:%02u%03d\",%u,%u,%u,%u,\"%s%s\",%u,%u\r\n";
			UINT8 *str  = NULL;

			if (pType1Data->scts.iZone < 0)
			{
				str = str2;
			}
			else
			{
				str = str1;
			}

			AT_Sprintf(ATAckBuff, str, nstatus_tmp, type1, nNumber, pType1Data->scts.uYear, pType1Data->scts.uMonth, pType1Data->scts.uDay, pType1Data->scts.uHour, pType1Data->scts.uMinute, pType1Data->scts.uSecond, pType1Data->scts.iZone, pType1Data->tooa, pType1Data->fo, pType1Data->pid, nDcs,  // modify value 20070926
			           type2, nNumberSca, pType1Data->tosca, pType1Data->length);

		}
		else  /* CSDH = 0 */
		{

			UINT8 *str1 = "+CMGR: \"%s\",\"%s%s\",,\"%u/%02u/%02u,%02u:%02u:%02u+%02d\"\r\n";
			UINT8 *str2 = "+CMGR: \"%s\",\"%s%s\",,\"%u/%02u/%02u,%02u:%02u:%02u%03d\"\r\n";
			UINT8 *str  = NULL;

			if (pType1Data->scts.iZone < 0)
			{
				str = str2;
			}
			else
			{
				str = str1;
			}

			AT_Sprintf(ATAckBuff, str,
			           nstatus_tmp,
			           type1,
			           nNumber,
			           pType1Data->scts.uYear,
			           pType1Data->scts.uMonth,
			           pType1Data->scts.uDay,
			           pType1Data->scts.uHour, pType1Data->scts.uMinute, pType1Data->scts.uSecond, pType1Data->scts.iZone);

		}

		/* get prompt buffer sting length */
		nATBAckLen = AT_StrLen(ATAckBuff);

		if (pType1Data->dcs == 2) /* for chinese sms */
		{
			/* From low layer data is big ending and transfer to little ending */
			//AT_Set_MultiLanguage();

			if (!(AT_UnicodeBigEnd2Unicode((UINT8 *)(pType1Data->data), pUCSLittleEndData, pType1Data->length)))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr read msg resp:  BigEnd to LittleEnd error 1",
				                  CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr read msg resp:  BigEnd to LittleEnd error 1",
				                  CfwEvent.nUTI);
#endif
				return;
			}

			if (ERR_SUCCESS !=
			        ML_Unicode2LocalLanguage((UINT8 *)pUCSLittleEndData, pType1Data->length, &pUCS2Data, &nGBKDATASize, NULL))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr read msg resp:  unicode to local language error 1",
				                  CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr read msg resp:  unicode to local language error 1",
				                  CfwEvent.nUTI);
#endif
				return;
			}

			/* buffer overflow */
			if ((pType1Data->length + nATBAckLen) > sizeof(ATAckBuff))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgr read msg resp: pType1Data buffer overflow dcs == 2",
				                  CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgr read msg resp: pType1Data buffer overflow dcs == 2",
				                  CfwEvent.nUTI);
#endif
				return;
			}

			AT_MemCpy(&ATAckBuff[nATBAckLen], pUCS2Data, pType1Data->length);
			nATBAckLen += pType1Data->length;

			// Free inout para resource
			AT_FREE(pUCS2Data);

		}
		else
		{
			/* buffer overflow */
			if ((pType1Data->length + nATBAckLen) > sizeof(ATAckBuff))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgr read msg resp: pType1Data buffer overflow dcs != 2",
				                  CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgr read msg resp: pType1Data buffer overflow dcs != 2",
				                  CfwEvent.nUTI);
#endif
				return;
			}

			AT_MemCpy(&ATAckBuff[nATBAckLen], (UINT8 *)(pType1Data->data), pType1Data->length);
			nATBAckLen += pType1Data->length;

		}
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI);
#endif

	}
	else if (nOperationRet == ERR_SUCCESS && pNode->nType == 3) // text mode, show param, state =sent/unsent msg
	{
		CFW_SMS_TXT_SUBMITTED_WITH_HRD_INFO *pType3Data = NULL;

		UINT8 type1[2] = "+";
		UINT8 type2[2] = "+";

		pType3Data = (CFW_SMS_TXT_SUBMITTED_WITH_HRD_INFO *)(pNode->pNode);

		/* just for debug */
		AT_TC(g_sw_AT_SMS, "pType3Data->length = %u", pType3Data->length);
		AT_TC_MEMBLOCK(g_sw_AT_SMS, pType3Data->data, pType3Data->length, 16);

		// change to ascii and get size
		count = SUL_GsmBcdToAscii(pType3Data->da, (pType3Data->da_size), nNumber);

		if (0xf0 == (*(pType3Data->da + pType3Data->da_size - 1) & 0xf0))
		{
			pType3Data->da_size = (UINT8)(pType3Data->da_size * 2 - 1);
		}
		else
		{
			pType3Data->da_size = (UINT8)(pType3Data->da_size * 2);
		}

		// sca  change to ascii and get size

		count = SUL_GsmBcdToAscii(pType3Data->sca, (pType3Data->sca_size), nNumberSca);

		// sms_tool_BCD2ASCII(nNumber, pType1Data->oa, (pType1Data->oa_size));
		if (0xf0 == (*(pType3Data->sca + pType3Data->sca_size - 1) & 0xf0))
		{
			pType3Data->sca_size = (UINT8)(pType3Data->sca_size * 2 - 1);
		}
		else
		{
			pType3Data->sca_size = (UINT8)(pType3Data->sca_size * 2);
		}

		// decide has + or not
		if (pType3Data->toda != CFW_TELNUMBER_TYPE_INTERNATIONAL)
		{
			type1[0] = '\0';  // [mod]bug7277
		}

		if (pType3Data->tosca != CFW_TELNUMBER_TYPE_INTERNATIONAL)
		{
			type2[0] = '\0';  // [mod]bug7277
		}

		// for dcs change from csw to correct value(3GPP) 2007.10.10
		nDcs = AT_SMS_DCSChange(pType3Data->dcs, nDcs);

		// output param first: CSDH = 1
		if (gATCurrentAtSmsSettingSCSDH_show == 1)
		{

			AT_Sprintf(ATAckBuff, "+CMGR: \"%s\",\"%s%s\",,%u,%u,%u,%u,%u,\"%s%s\",%u,%u\r\n", nstatus_tmp, type1, nNumber, pType3Data->toda, pType3Data->fo, pType3Data->pid, nDcs,  // modify value 20070926
			           pType3Data->vp, type2, nNumberSca, pType3Data->tosca, pType3Data->length);
		}
		else  /* CSDH = 0 */
		{
			AT_Sprintf(ATAckBuff, "+CMGR: \"%s\",\"%s%s\"\r\n", // [mod]2007.10.17 remove ",,"
			           nstatus_tmp, type1, nNumber);

		}

		/* get prompt buffer string length */
		nATBAckLen = AT_StrLen(ATAckBuff);

		if (pType3Data->dcs == 2) /* chinese message */
		{

			// receive from low layer and the data is big ending
			// so, we must transfer to little ending, the use it
			//AT_Set_MultiLanguage();

			if (!(AT_UnicodeBigEnd2Unicode((UINT8 *)(pType3Data->data), pUCSLittleEndData, pType3Data->length)))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr read msg resp:  BigEnd to LittleEnd error 2", nSim,
				                  CfwEvent.nUTI);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr read msg resp:  BigEnd to LittleEnd error 2",
				                  CfwEvent.nUTI);
#endif
				return;
			}

			if (ERR_SUCCESS !=
			        ML_Unicode2LocalLanguage((UINT8 *)pUCSLittleEndData, pType3Data->length, &pUCS2Data, &nGBKDATASize, NULL))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr read msg resp:  unicode to local language error 2",
				                  CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgr read msg resp:  unicode to local language error 2",
				                  CfwEvent.nUTI);
#endif
				return;
			}

			/* buffer overflow */
			if ((pType3Data->length + nATBAckLen) > sizeof(ATAckBuff))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgr read msg resp: pType3Data buffer overflow dcs == 2",
				                  CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgr read msg resp: pType3Data buffer overflow dcs == 2",
				                  CfwEvent.nUTI);
#endif
				return;
			}

			AT_MemCpy(&ATAckBuff[nATBAckLen], pUCS2Data, pType3Data->length);
			nATBAckLen += pType3Data->length;

			// Free inout para resource
			AT_FREE(pUCS2Data);

		}
		else
		{
			/* buffer overflow */
			if ((pType3Data->length + nATBAckLen) > sizeof(ATAckBuff))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgr read msg resp: pType3Data buffer overflow dcs != 2",
				                  CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgr read msg resp: pType3Data buffer overflow dcs != 2",
				                  CfwEvent.nUTI);
#endif
				return;
			}

			AT_MemCpy(&ATAckBuff[nATBAckLen], (UINT8 *)(pType3Data->data), pType3Data->length);
			nATBAckLen += pType3Data->length;

		}
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI);
#endif

	}
	else if (nOperationRet == ERR_SUCCESS && pNode->nType == 7) // PDU mode, pp msg
	{
		CFW_SMS_PDU_INFO *pType7Data = NULL;
		UINT8 nDataSizeWithoutSCA = 0;
		UINT8 BCDDataBuff[200]    = { 0 };
		UINT8 ASCIIDataBuff[400]  = { 0 };
		UINT16 nTotalDataLen      = 0;

		pType7Data = (CFW_SMS_PDU_INFO *)(pNode->pNode);

		/* just for debug */
		AT_TC(g_sw_AT_SMS, "Original Data: pType7Data->nDataSize = %u", pType7Data->nDataSize);

		/* check recv pdu and discard unused char */
		if (!(AT_SMS_CheckPDUIsValid((UINT8 *)pType7Data->pData, (UINT8 *) & (pType7Data->nDataSize), TRUE)))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "cmgr read msg resp: check pdu is invalid", CfwEvent.nUTI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "cmgr read msg resp: check pdu is invalid",
			                  CfwEvent.nUTI);
#endif
			return;
		}

		/* just for debug */
		AT_TC(g_sw_AT_SMS, "Worked Data: pType7Data->nDataSize = %u", pType7Data->nDataSize);
		AT_TC_MEMBLOCK(g_sw_AT_SMS, pType7Data->pData, pType7Data->nDataSize, 16);

		/* get status from the MACRO STATUS */
		if (!(AT_SMS_StatusMacroFlagToStringOrData(&(pType7Data->nStatus), 0)))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_STATUS, NULL, 0, "cmgr read msg resp: get pdu status exception",
			                  CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_STATUS, NULL, 0, "cmgr read msg resp: get pdu status exception",
			                  CfwEvent.nUTI);
#endif
			return;

		}

		nDataSizeWithoutSCA = pType7Data->nDataSize - (pType7Data->pData[0] + 1); /* output size exclude scasize */

		AT_Sprintf(ATAckBuff, "+CMGR: %u,,%u\r\n", pType7Data->nStatus, nDataSizeWithoutSCA);

		/* add sca if have not */
		nTotalDataLen = pType7Data->nDataSize;
#ifdef AT_DUAL_SIM
		if (!(SMS_AddSCA2PDU(pType7Data->pData, BCDDataBuff, &(nTotalDataLen), nSim)))
#else
		if (!(SMS_AddSCA2PDU(pType7Data->pData, BCDDataBuff, &(nTotalDataLen))))
#endif
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "cmgr read msg resp: AddSCA2PDU error", CfwEvent.nUTI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "cmgr read msg resp: AddSCA2PDU error", CfwEvent.nUTI);
#endif
			return;
		}

		// output msg body
		if (!(SMS_PDUBCDToASCII(BCDDataBuff, &(nTotalDataLen), ASCIIDataBuff)))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "cmgr read msg resp: PDUBCDToASCII error", CfwEvent.nUTI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "cmgr read msg resp: PDUBCDToASCII error", CfwEvent.nUTI);
#endif
			return;
		}

		nATBAckLen = AT_StrLen(ATAckBuff);

		/* buffer overflow */
		if ((nATBAckLen + nTotalDataLen) > sizeof(ATAckBuff))
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgr read msg resp: buffer overflow dcs != 2", CfwEvent.nUTI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "cmgr read msg resp: buffer overflow dcs != 2", CfwEvent.nUTI);
#endif
			return;
		}

		AT_MemCpy(&ATAckBuff[nATBAckLen], ASCIIDataBuff, nTotalDataLen);
		nATBAckLen += nTotalDataLen;
#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI);
#endif
		return;

	}
	else if (nOperationRet == ERR_SUCCESS && pNode->nType == 8) // PDU mode, CB msg
	{
		nOperationRet = ERR_AT_CMS_ERR_IN_MS;
	}
	else if (nOperationRet == ERR_SUCCESS)
	{
		nOperationRet = ERR_AT_CMS_ERR_IN_MS;
	}

	if (ERR_SUCCESS != nOperationRet) // err happen,
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmgr read msg resp: exception happened", CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmgr read msg resp: exception happened", CfwEvent.nUTI);
#endif
	}

	return;

}

/******************************************************************************************
Function			:	AT_SMS_DeleteMessage_rsp
Description		:  	AT SMS module delete message response
Called By			:	At SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	COS_EVENT *pEvent
Output			:
Return			:	VOID
Others			:
					modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
VOID AT_SMS_DeleteMessage_rsp(COS_EVENT *pEvent)
{
	CFW_EVENT CfwEvent                        = { 0 };
	CFW_SMS_STORAGE_INFO sStorageInfo         = { 0 };
	CFW_SMS_STORAGE_INFO sUpdateStorageInfoSM = { 0 };
	CFW_SMS_STORAGE_INFO sUpdateStorageInfoME = { 0 };
	UINT8 nLastSMSCINDNewMsg                  = 0;
	UINT32 nOperationRet                      = ERR_SUCCESS;

#ifdef AT_DUAL_SIM
	UINT8 nSim;
#endif
	AT_CosEvent2CfwEvent(pEvent, &CfwEvent);
#ifdef AT_DUAL_SIM
	nSim = CfwEvent.nFlag;
#endif
	/* just for debug */
	AT_TC(g_sw_AT_SMS, "cmgd msg resp: CfwEvent.nType = 0x%x, CfwEvent.nParam1 = 0x%x, CfwEvent.nParam2 = %u",
	      CfwEvent.nType, CfwEvent.nParam1, CfwEvent.nParam2);
	if (0 == CfwEvent.nType)
	{
#ifdef AT_DUAL_SIM

		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage1, nSim);
#else
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage1);

#endif
		if (ERR_SUCCESS == nOperationRet)
		{
			gATCurrentAtSMSInfo[nSim].nTotal1 = sStorageInfo.totalSlot;
			gATCurrentAtSMSInfo[nSim].nUsed1  = sStorageInfo.usedSlot;

		}
#ifdef AT_DUAL_SIM

		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage2, nSim);
#else
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage2);

#endif
		if (ERR_SUCCESS == nOperationRet)
		{
			gATCurrentAtSMSInfo[nSim].nTotal2 = sStorageInfo.totalSlot;
			gATCurrentAtSMSInfo[nSim].nUsed2  = sStorageInfo.usedSlot;

		}
#ifdef AT_DUAL_SIM

		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage3, nSim);
#else
		nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage3);

#endif
		if (ERR_SUCCESS == nOperationRet)
		{
			gATCurrentAtSMSInfo[nSim].nTotal3 = sStorageInfo.totalSlot;
			gATCurrentAtSMSInfo[nSim].nUsed3  = sStorageInfo.usedSlot;

		}

		/* save temp value of  g_SMS_CIND_NewMsg,  if we delete
		   ** the unread message ,we should update the unReadRecords */
		nLastSMSCINDNewMsg = g_SMS_CIND_NewMsg;
		g_SMS_CIND_NewMsg  = 0;

		/* update the unReadcordes of SM */

#ifdef AT_DUAL_SIM
		if (ERR_SUCCESS != CFW_CfgGetSmsStorageInfo(&sUpdateStorageInfoSM, CFW_SMS_STORAGE_SM, nSim))
#else
		if (ERR_SUCCESS != CFW_CfgGetSmsStorageInfo(&sUpdateStorageInfoSM, CFW_SMS_STORAGE_SM))

#endif
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgd msg resp: update SM error ", CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgd msg resp: update SM error ", CfwEvent.nUTI);
#endif
			return;
		}
		g_SMS_CIND_NewMsg += sUpdateStorageInfoSM.unReadRecords;

		/* update the unReadcordes of ME */

#ifdef AT_DUAL_SIM
		if (ERR_SUCCESS != CFW_CfgGetSmsStorageInfo(&sUpdateStorageInfoME, CFW_SMS_STORAGE_ME, nSim))
#else
		if (ERR_SUCCESS != CFW_CfgGetSmsStorageInfo(&sUpdateStorageInfoME, CFW_SMS_STORAGE_ME))

#endif
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgd msg resp: update ME error ", CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "cmgd msg resp: update ME error ", CfwEvent.nUTI);
#endif
			g_SMS_CIND_NewMsg = nLastSMSCINDNewMsg;
			return;
		}
		g_SMS_CIND_NewMsg += sUpdateStorageInfoME.unReadRecords;

#ifdef AT_DUAL_SIM
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, CfwEvent.nUTI);
#endif

	}
	else if (0xF0 == CfwEvent.nType)
	{
		// [+] this index  no sms  but return ok(refer simens)2007.10.11
		// Invalid memory index #define ERR_CMS_INVALID_MEMORY_INDEX 0x10100142
		if (ERR_CMS_INVALID_MEMORY_INDEX == CfwEvent.nParam1)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 180, 0, NULL, 0, CfwEvent.nUTI);
#endif
		}

		// others return error
		else
		{
			nOperationRet = AT_SMS_ERR_Change(CfwEvent.nParam1);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmgd msg resp:  CfwEvent.nType == 0xF0", CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "cmgd msg resp:  CfwEvent.nType == 0xF0", CfwEvent.nUTI);
#endif
		}
	}
	else
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "cmgd msg resp: exception happened", CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "cmgd msg resp: exception happened", CfwEvent.nUTI);
#endif
	}

	return;

}

/******************************************************************************************
Function			:	AT_SMS_RecieveOverFlow_Indictation
Description		:   	AT receive indication of overflow from csw
Called By			:	At SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	COS_EVENT *pEvent
Output			:
Return			:	VOID
Others			:
					modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
VOID AT_SMS_RecvBuffOverflow_Indictation(COS_EVENT *pEvent)
{
	CFW_EVENT CfwEvent   = { 0 };
	UINT8 ATAckBuff[32]  = { 0 };
	UINT32 nOperationRet = ERR_SUCCESS;

#ifdef AT_DUAL_SIM
	UINT8 nSim;
#endif
	/* get event */
	AT_CosEvent2CfwEvent(pEvent, &CfwEvent);
#ifdef AT_DUAL_SIM
	nSim = CfwEvent.nFlag;
#endif
	/* just for debug */
	AT_TC(g_sw_AT_SMS,
	      "msg buffer overflow indication: CfwEvent.nType = 0x%x, CfwEvent.nParam1 = 0x%x, CfwEvent.nParam2 = %u",
	      CfwEvent.nType, CfwEvent.nParam1, CfwEvent.nParam2);

	/* check event type */
	if (0 == CfwEvent.nType)
	{

		/***************************************************/
		/* according to the MEMFULL status, then set the          */
		/* message full flag, and check "SM" storage and              */
		/* "ME" storage eparately, 2008.07.03, by wangqy                 */
		/***************************************************/
		switch (CfwEvent.nParam1)
		{

		case 0:  /* delete message and storage is spare */
			if (gATCurrentAtSMSInfo[nSim].nStorage1 & CFW_SMS_STORAGE_SM)
			{
				/* save msgfull flag of SM, bit1 is set to "0" */
#ifdef AT_DUAL_SIM
				g_SMS_CIND_MemFull[nSim] &= ~CFW_SMS_STORAGE_SM;
#else
				g_SMS_CIND_MemFull &= ~CFW_SMS_STORAGE_SM;
#endif
			}
			else if (gATCurrentAtSMSInfo[nSim].nStorage1 & CFW_SMS_STORAGE_ME)
			{
				/* save msgfull flag of ME, bit0 is set to "0" */
#ifdef AT_DUAL_SIM
				g_SMS_CIND_MemFull[nSim] &= ~CFW_SMS_STORAGE_ME;
#else
				g_SMS_CIND_MemFull &= ~CFW_SMS_STORAGE_ME;
#endif
			}
			else
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, NULL, 0, "cmgd msg resp: not support this storage 0",
				                  CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, NULL, 0, "cmgd msg resp: not support this storage 0",
				                  CfwEvent.nUTI);
#endif
				return;
			}

			break;

		case 1:  /* mem full and no message waiting for */
		case 2:  /* mem full and have message waiting for */
			if ((gATCurrentAtSMSInfo[nSim].nStorage2 & CFW_SMS_STORAGE_SM) || (gATCurrentAtSMSInfo[nSim].nStorage3 & CFW_SMS_STORAGE_SM))
			{
				/* save msgfull flag of SM, bit1 is set to "1" */
#ifdef AT_DUAL_SIM
				g_SMS_CIND_MemFull[nSim] |= CFW_SMS_STORAGE_SM;
#else
				g_SMS_CIND_MemFull |= CFW_SMS_STORAGE_SM;
#endif
			}
			else if ((gATCurrentAtSMSInfo[nSim].nStorage2 & CFW_SMS_STORAGE_ME)
			         || (gATCurrentAtSMSInfo[nSim].nStorage3 & CFW_SMS_STORAGE_ME))
			{
				/* save msgfull flag of ME, bit0 is set to "1" */
#ifdef AT_DUAL_SIM
				g_SMS_CIND_MemFull[nSim] |= CFW_SMS_STORAGE_ME;
#else
				g_SMS_CIND_MemFull |= CFW_SMS_STORAGE_ME;
#endif
			}
			else
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, NULL, 0,
				                  "msg buffer overflow indication: not support this storage 12", CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, NULL, 0,
				                  "msg buffer overflow indication: not support this storage 12", CfwEvent.nUTI);
#endif
				return;
			}

			break;

		default:
			AT_TC(g_sw_AT_SMS, "msg buffer overflow indication: unknown CfwEvent.nParam1 value");

			break;

		}
		AT_TC(g_sw_SA, ("We Got gATCurrentuCmer_ind nSim[%d] to %d\n"), nSim, gATCurrentuCmer_ind[nSim]);

		/* report to CIEV or not  */
		if (gATCurrentuCmer_ind[nSim])
		{
			AT_Sprintf(ATAckBuff, "+CIEV: \"SMSFULL\",%u", (unsigned int)CfwEvent.nParam1);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, (UINT16)AT_StrLen(ATAckBuff), CfwEvent.nUTI,
			                 nSim);
#else
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, (UINT16)AT_StrLen(ATAckBuff), CfwEvent.nUTI);
#endif
		}
		else
		{
			AT_TC(g_sw_AT_SMS, "msg buffer overflow indication: received indiation, but not report to CIEV");
		}

	}
	else if (0xF0 == CfwEvent.nType)
	{
		nOperationRet = AT_SMS_ERR_Change(CfwEvent.nParam1);
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(nOperationRet, NULL, 0, "msg buffer overflow indication: CfwEvent.nType == 0xF0", nSim,
		                  CfwEvent.nUTI);
#else
		AT_SMS_Result_Err(nOperationRet, NULL, 0, "msg buffer overflow indication: CfwEvent.nType == 0xF0", CfwEvent.nUTI);
#endif
	}
	else
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "msg buffer overflow indication: exception happened",
		                  CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "msg buffer overflow indication: exception happened",
		                  CfwEvent.nUTI);
#endif
	}

	return;
}

// ZSC-T20121222-s
#ifdef __MODEM_LP_MODE_ENABLE__
VOID AT_ResendCMTMux(UINT8 nDLCI)
{
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(nDLCI);
#endif

#ifdef AT_DUAL_SIM
	AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, g_sms_delaybuffer, AT_StrLen(g_sms_delaybuffer), nDLCI, nSim); // hameina[+] ring info should be set out
#else
	AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, g_sms_delaybuffer, AT_StrLen(g_sms_delaybuffer), nDLCI); // hameina[+] ring info should be set out
#endif
	AT_FREE(g_sms_delaybuffer);
	return;
}
#endif
// ZSC-T20121222-E
/******************************************************************************************
Function			:	AT_SMS_RecieveNew_Indictation
Description		:   	AT receive indication of new
Called By			:	At SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	COS_EVENT *pEvent
Output			:
Return			:	VOID
Others			:  	modify and add comment by wangqunyang 06/04/2008
*******************************************************************************************/
VOID AT_SMS_RecvNewMessage_Indictation(COS_EVENT *pEvent)
{

	CFW_SMS_STORAGE_INFO sStorageInfo = { 0 };
	CFW_EVENT CfwEvent                = { 0 };

	CFW_NEW_SMS_NODE *pNewMsgNode = NULL;

	UINT8 ATAckBuff[480]         = { 0 };
	UINT8 nFormat                = 0;
	UINT16 nATBAckLen            = 0;
	UINT32 nGBKDATASize          = 0;
	UINT8 *pUCS2Data             = NULL;
	UINT8 pUCSLittleEndData[142] = { 0 };
	UINT8 nDcs                   = 0;
	UINT32 nOperationRet         = ERR_SUCCESS;

#ifdef AT_DUAL_SIM
	UINT8 nSim;
#endif
	/* get event */
	AT_CosEvent2CfwEvent(pEvent, &CfwEvent);
#ifdef AT_DUAL_SIM
	nSim = CfwEvent.nFlag;
#  ifndef ONLY_AT_SINGLE_SIM
	CfwEvent.nUTI = AT_ASYN_GET_DLCI(nSim);
#endif
#endif
	/* just for debug */
	AT_TC(g_sw_AT_SMS, "new msg indication: CfwEvent.nType = 0x%x, CfwEvent.nParam1 = 0x%x, CfwEvent.nParam2 = %u",
	      CfwEvent.nType, CfwEvent.nParam1, CfwEvent.nParam2);

	/* get SMS format and check it */
	nFormat = gATCurrentAtSmsSettingSg_SMSFormat;
	if (nFormat > 1)
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "new msg indication: nFormat > 1 ", CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "new msg indication: nFormat > 1 ", CfwEvent.nUTI);
#endif
		return;
	}

	/* get new message node and check it */
	pNewMsgNode = (CFW_NEW_SMS_NODE *)CfwEvent.nParam1;
	if (NULL == pNewMsgNode)
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "new msg indication: pNewMsgNode is NULL", CfwEvent.nUTI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_MEM_FAIL, NULL, 0, "new msg indication: pNewMsgNode is NULL", CfwEvent.nUTI);
#endif
		return;
	}

	/* check event type */
	if (0 != CfwEvent.nType)
	{
		if (0xF0 == CfwEvent.nType)
		{
			nOperationRet = AT_SMS_ERR_Change(CfwEvent.nParam1);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "new msg indication: CfwEvent.nType == 0xF0", CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_Err(nOperationRet, NULL, 0, "new msg indication: CfwEvent.nType == 0xF0", CfwEvent.nUTI);
#endif
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "new msg indication: exception happened", CfwEvent.nUTI,
			                  nSim);
#else
			AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "new msg indication: exception happened", CfwEvent.nUTI);
#endif
		}

		return;
	}

	/**********************************************************************/
	// Check message node type and mti, then process them
	/**********************************************************************/
	AT_TC(g_sw_AT_SMS, "pNewMsgNode->nType = 0x%x", pNewMsgNode->nType);

	/* check the msg node type */
	switch (pNewMsgNode->nType)
	{

		// ///////////////////////////////////
		// PDU Message Content
		// ///////////////////////////////////
	case 0x20:

		// //////////////////////////////////////////////////////
		// update the new message counter, and indicate to
		// CIEV that new message recieved if necessary
		// //////////////////////////////////////////////////////

		g_SMS_CIND_NewMsg++;

		// /////////////////////////////////////
		/* Report to CIEV         */
		// /////////////////////////////////////

		AT_TC(g_sw_SA, ("We Got gATCurrentuCmer_ind nSim[%d] to %d\n"), nSim, gATCurrentuCmer_ind[nSim]);

		if (gATCurrentuCmer_ind[nSim])
		{
			UINT8 nRptCMERBuff[24] = { 0 };

			AT_Sprintf(nRptCMERBuff, "+CIEV: \"MESSAGE\",%u", g_SMS_CIND_NewMsg ? 1 : 0);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, nRptCMERBuff, (UINT16)AT_StrLen(nRptCMERBuff), CfwEvent.nUTI,
			                 nSim);
#else
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, nRptCMERBuff, (UINT16)AT_StrLen(nRptCMERBuff),
			                 CfwEvent.nUTI);
#endif

		}
		else
		{
			/* Recieved new messgage but report CIEV flag is 0,
			 ** and not reptort to CIEV, this is just for debug
			 */
			AT_TC(g_sw_AT_SMS, "new msg indication: Received new message, but not report to CMER");
		}

		// //////////////////////////////////////////////////////
		// indicate to CMTI that new message recieved if necessary
		// //////////////////////////////////////////////////////

		/* No report MT == 0 */
		if (gATCurrentAtSMSInfo[nSim].sCnmi.nMt == 0)
		{
			AT_TC(g_sw_AT_SMS, "new msg indication: Received new pdu format message, but not report to CNMI");
			return;
		}

		/* dump report MT == 1 */
		else if (gATCurrentAtSMSInfo[nSim].sCnmi.nMt == 1)
		{
			if (pNewMsgNode->nStorage == 1)
			{
				AT_Sprintf(ATAckBuff, "+CMTI: \"ME\",%u", pNewMsgNode->nConcatCurrentIndex);
			}
			else
			{
				AT_Sprintf(ATAckBuff, "+CMTI: \"SM\",%u", pNewMsgNode->nConcatCurrentIndex);
			}
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, (UINT16)AT_StrLen(ATAckBuff), CfwEvent.nUTI,
			                 nSim);
#else
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, (UINT16)AT_StrLen(ATAckBuff), CfwEvent.nUTI);
#endif
			return;

		}

		/* dump report MT == 2 */
		else if (gATCurrentAtSMSInfo[nSim].sCnmi.nMt == 2)
		{
			UINT8 *pPduData        = NULL;
			UINT8 ATAsciiBuff[400] = { 0 };

			CFW_SMS_PDU_INFO *pPduNodeInfo = NULL;

			if (0 != nFormat)
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "new msg indication: Format exception", CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "new msg indication: Format exception", CfwEvent.nUTI);
#endif
				return;
			}

			pPduNodeInfo = (CFW_SMS_PDU_INFO *)(pNewMsgNode->pNode);

			/* just for debug */
			AT_TC(g_sw_AT_SMS, "new msg indication: pPduNodeInfo->nDataSize = %u", pPduNodeInfo->nDataSize);
			AT_TC_MEMBLOCK(g_sw_AT_SMS, pPduNodeInfo->pData, pPduNodeInfo->nDataSize, 16);

			/* check recv pdu and discard unused char */
			if (!(AT_SMS_CheckPDUIsValid((UINT8 *)pPduNodeInfo->pData, (UINT8 *) & (pPduNodeInfo->nDataSize), TRUE)))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "new msg indication: check pdu is invalid",
				                  CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "new msg indication: check pdu is invalid",
				                  CfwEvent.nUTI);
#endif
				return;
			}

			AT_Sprintf(ATAckBuff, "+CMT: ,%u\r\n", pPduNodeInfo->nDataSize - pPduNodeInfo->pData[0] - 1);

			/* get prompt buffer string length */
			nATBAckLen = AT_StrLen(ATAckBuff);

			pPduData = pPduNodeInfo->pData;

			if (!(SMS_PDUBCDToASCII(pPduData, &(pPduNodeInfo->nDataSize), ATAsciiBuff)))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "new msg indication: PDUBCDToASCII error",
				                  CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "new msg indication: PDUBCDToASCII error",
				                  CfwEvent.nUTI);
#endif
				return;
			}

			/* buffer overflow */
			if ((nATBAckLen + pPduNodeInfo->nDataSize) > sizeof(ATAckBuff))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "new msg indication: buffer overflow", CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0, "new msg indication: buffer overflow", CfwEvent.nUTI);
#endif

				return;
			}

			AT_MemCpy(&ATAckBuff[nATBAckLen], ATAsciiBuff, pPduNodeInfo->nDataSize);
			nATBAckLen += pPduNodeInfo->nDataSize;
#ifdef __MODEM_LP_MODE_ENABLE__
			if (sync_IsApAllowBpSleep())
			{
				sync_BpWakeUpAP();
#if 1
#ifdef AT_DUAL_SIM
				AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI);
#endif
#else
				g_sms_delaybuffer = AT_MALLOC(sizeof(ATAckBuff));
				AT_MemZero(g_sms_delaybuffer, sizeof(g_sms_delaybuffer));

				if (NULL == g_sms_delaybuffer)  /* if AT_MALLOC fail that delay here */
				{
					hal_TimDelay(250 * 16384 / 1000); // 1000ms

#ifdef AT_DUAL_SIM
					AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI, nSim);
#else
					AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI);
#endif
				}
				else
				{
					AT_MemCpy(g_sms_delaybuffer, ATAckBuff, nATBAckLen);
					AT_SetSMSTimerMux(ATE_SMS_TIME_ELAPSE, CfwEvent.nUTI);
				}
#endif
			}
			else
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI, nSim);
#else
				AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI);
#endif
			}
#else /* if not define lower function then Executive below program */

#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI);
#endif
#endif

		}

		/* MT support 0, 1 and 2, other values not implements */
		else
		{
			AT_TC(g_sw_AT_SMS, "new msg indication: Received pdu format message, but this type of MT is not implements");
		}

		break;

		// //////////////////////////////////////
		// 1. Text Message Content with header
		// 2. Text Message Content without header
		// //////////////////////////////////////
	case 0x21:
	case 0x22:

		// //////////////////////////////////////////////////////
		// update the new message counter, and indicate to
		// CIEV that new message recieved if necessary
		// //////////////////////////////////////////////////////

		g_SMS_CIND_NewMsg++;

		// /////////////////////////////////////
		/* Report to CIEV         */
		// /////////////////////////////////////
		AT_TC(g_sw_SA, ("We Got gATCurrentuCmer_ind nSim[%d] to %d\n"), nSim, gATCurrentuCmer_ind[nSim]);

		if (gATCurrentuCmer_ind[nSim])
		{
			UINT8 nRptCMERBuff[24] = { 0 };

			AT_Sprintf(nRptCMERBuff, "+CIEV: \"MESSAGE\",%u", g_SMS_CIND_NewMsg ? 1 : 0);
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, nRptCMERBuff, (UINT16)AT_StrLen(nRptCMERBuff), CfwEvent.nUTI,
			                 nSim);
#else
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, nRptCMERBuff, (UINT16)AT_StrLen(nRptCMERBuff),
			                 CfwEvent.nUTI);
#endif
		}
		else
		{
			/* Recieved new messgage but report CIEV flag is 0,
			 ** and not reptort to CIEV, this is just for debug
			 */
			AT_TC(g_sw_AT_SMS, "new msg indication: Received new message, but not report to CMER");
		}

		// //////////////////////////////////////////////////////
		// indicate to CMTI that new message recieved if necessary
		// //////////////////////////////////////////////////////

		/* No report MT == 0 */
		if (gATCurrentAtSMSInfo[nSim].sCnmi.nMt == 0)
		{
			AT_TC(g_sw_AT_SMS, "new msg indication: Received new text format message, but not report to CNMI");
			return;
		}

		/* dump report MT == 1 */
		else if (gATCurrentAtSMSInfo[nSim].sCnmi.nMt == 1)
		{
			if (pNewMsgNode->nStorage == 1)
			{
				AT_Sprintf(ATAckBuff, "+CMTI: \"ME\",%u", pNewMsgNode->nConcatCurrentIndex);
			}
			else
			{
				AT_Sprintf(ATAckBuff, "+CMTI: \"SM\",%u", pNewMsgNode->nConcatCurrentIndex);
			}
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, (UINT16)AT_StrLen(ATAckBuff), CfwEvent.nUTI,
			                 nSim);
#else
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, (UINT16)AT_StrLen(ATAckBuff), CfwEvent.nUTI);
#endif
			return;

		}

		/* dump report MT == 2 */
		else if (gATCurrentAtSMSInfo[nSim].sCnmi.nMt == 2)
		{
			CFW_SMS_TXT_HRD_V1_IND *pTextWithHead = NULL;
			UINT8 tooa                           = 0, tosca = 0;
			UINT8 nNumber[TEL_NUMBER_MAX_LEN]    = { 0 };
			UINT8 nNumberSca[TEL_NUMBER_MAX_LEN] = { 0 };

			pTextWithHead = (CFW_SMS_TXT_HRD_V1_IND *)(pNewMsgNode->pNode);

			/* just for debug */
			AT_TC(g_sw_AT_SMS, "new msg indication: pTextWithHead->nDataLen = %u", pTextWithHead->nDataLen);
			AT_TC_MEMBLOCK(g_sw_AT_SMS, pTextWithHead->pData, pTextWithHead->nDataLen, 16);

			// change to ascii and get size
			if (0 == SUL_GsmBcdToAscii(pTextWithHead->oa, (pTextWithHead->oa_size), nNumber))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "new msg indication: GsmBcdToAscii 11", CfwEvent.nUTI,
				                  nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "new msg indication: GsmBcdToAscii 11", CfwEvent.nUTI);
#endif
				return;
			}
			/*
			      if (0xf0 == (*(pTextWithHead->oa + pTextWithHead->oa_size - 1) & 0xf0))
			      {
			        pTextWithHead->oa_size = (UINT8)(pTextWithHead->oa_size * 2 - 1);
			      }
			      else
			      {
			        pTextWithHead->oa_size = (UINT8)(pTextWithHead->oa_size * 2);
			      }
			*/
			// sca  change to ascii and get size
			if (0 == SUL_GsmBcdToAscii(pTextWithHead->sca, (pTextWithHead->sca_size), nNumberSca))
			{
#ifdef AT_DUAL_SIM
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "new msg indication: GsmBcdToAscii 22", CfwEvent.nUTI,
				                  nSim);
#else
				AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "new msg indication: GsmBcdToAscii 22", CfwEvent.nUTI);
#endif
				return;
			}
			/*

			if (0xf0 == (*(pTextWithHead->sca + pTextWithHead->sca_size - 1) & 0xf0))
			{
			  pTextWithHead->sca_size = (UINT8)(pTextWithHead->sca_size * 2 - 1);
			}
			else
			{
			  pTextWithHead->sca_size = (UINT8)(pTextWithHead->sca_size * 2);
			}
			*/
			if (CFW_TELNUMBER_TYPE_INTERNATIONAL == pTextWithHead->tooa)
			{
				tooa = '+';
			}
			else
			{
				tooa = '\0';
			}

			if (CFW_TELNUMBER_TYPE_INTERNATIONAL == pTextWithHead->tosca)
			{
				tosca = '+';
			}
			else
			{
				tosca = '\0';
			}

			/*
			 ** CSDH=1 show header
			 */
			if (gATCurrentAtSmsSettingSCSDH_show)
			{
				nDcs = AT_SMS_DCSChange(pTextWithHead->dcs, nDcs);

				UINT8 *str1 = "+CMT: \"%c%s\",,\"%u/%02u/%02u,%02u:%02u:%02u+%02d\",%u,%u,%u,%u,\"%c%s\",%u,%u\r\n";
				UINT8 *str2 = "+CMT: \"%c%s\",,\"%u/%02u/%02u,%02u:%02u:%02u%03d\",%u,%u,%u,%u,\"%c%s\",%u,%u\r\n";
				UINT8 *str  = NULL;

				if (pTextWithHead->scts.iZone < 0)
				{
					str = str2;
				}
				else
				{
					str = str1;
				}

				// output param
				AT_Sprintf(ATAckBuff, str,
				           tooa,
				           nNumber,
				           pTextWithHead->scts.uYear,
				           pTextWithHead->scts.uMonth,
				           pTextWithHead->scts.uDay,
				           pTextWithHead->scts.uHour,
				           pTextWithHead->scts.uMinute,
				           pTextWithHead->scts.uSecond,
				           pTextWithHead->scts.iZone,
				           pTextWithHead->tooa,
				           pTextWithHead->fo,
				           pTextWithHead->pid, nDcs, tosca, nNumberSca, pTextWithHead->tosca, pTextWithHead->nDataLen);

			}

			/*
			 ** CSDH= 0 not show header
			 */
			else
			{
				UINT8 *str1 = "+CMT: \"%c%s\",,\"%u/%02u/%02u,%02u:%02u:%02u+%02d\"\r\n";
				UINT8 *str2 = "+CMT: \"%c%s\",,\"%u/%02u/%02u,%02u:%02u:%02u%03d\"\r\n";
				UINT8 *str  = NULL;

				if (pTextWithHead->scts.iZone < 0)
				{
					str = str2;
				}
				else
				{
					str = str1;
				}

				AT_Sprintf(ATAckBuff, str,
				           tooa,
				           nNumber,
				           pTextWithHead->scts.uYear,
				           pTextWithHead->scts.uMonth,
				           pTextWithHead->scts.uDay,
				           pTextWithHead->scts.uHour,
				           pTextWithHead->scts.uMinute, pTextWithHead->scts.uSecond, pTextWithHead->scts.iZone);

			}

			/* get prompt buffer string length */
			nATBAckLen = AT_StrLen(ATAckBuff);

			// chinese message
			if (pTextWithHead->dcs == 2)
			{
				/* we must transfer the uniform big ending */
				/* to little ending and using */
				//AT_Set_MultiLanguage();

				if (!(AT_UnicodeBigEnd2Unicode((UINT8 *)(pTextWithHead->pData), pUCSLittleEndData, pTextWithHead->nDataLen)))
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "new msg indication: BigEnd to LittleEnd error", CfwEvent.nUTI,
					                  nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "new msg indication: BigEnd to LittleEnd error",
					                  CfwEvent.nUTI);
#endif
					return;
				}

				// //////////////////////////////////////////////
				/* process invalid char in the unicode string                 */
				// //////////////////////////////////////////////
				if (ERR_SUCCESS !=
				        ML_Unicode2LocalLanguage((UINT8 *)pUCSLittleEndData, pTextWithHead->nDataLen, &pUCS2Data, &nGBKDATASize,
				                                 NULL))
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "new msg indication: unicode to local language error",
					                  CfwEvent.nUTI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_ME_FAIL, NULL, 0, "new msg indication: unicode to local language error",
					                  CfwEvent.nUTI);
#endif
					return;
				}

				/* check buffer overflow or not */
				if ((pTextWithHead->nDataLen + nATBAckLen) > sizeof(ATAckBuff))
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0,
					                  "new msg indication: pTextWithHead buffer overflow dcs == 2", CfwEvent.nUTI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0,
					                  "new msg indication: pTextWithHead buffer overflow dcs == 2", CfwEvent.nUTI);
#endif

					return;
				}

				AT_MemCpy(&ATAckBuff[nATBAckLen], pUCS2Data, pTextWithHead->nDataLen);
				nATBAckLen += pTextWithHead->nDataLen;

				// Free inout para resource
				AT_FREE(pUCS2Data);

			}
			else
			{

				/* buffer overflow */
				if ((pTextWithHead->nDataLen + nATBAckLen) > sizeof(ATAckBuff))
				{
#ifdef AT_DUAL_SIM
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0,
					                  "new msg indication: pTextWithHead buffer overflow dcs != 2", CfwEvent.nUTI, nSim);
#else
					AT_SMS_Result_Err(ERR_AT_CMS_INVALID_LEN, NULL, 0,
					                  "new msg indication: pTextWithHead buffer overflow dcs != 2", CfwEvent.nUTI);
#endif

					return;
				}

				if(pTextWithHead->dcs == 0x00)
				{
					UINT8 *pGsm7Bit = (UINT8 *)AT_MALLOC(pTextWithHead->nDataLen);
					UINT16 nGsm7BitLen = 0x00;

					ATConvertGSM7BitDefaultEncodingToAscii(pGsm7Bit, pTextWithHead->pData, pTextWithHead->nDataLen, &nGsm7BitLen);
					AT_MemCpy(&ATAckBuff[nATBAckLen], (UINT8 *)(pGsm7Bit), nGsm7BitLen);
				}
				else
					AT_MemCpy(&ATAckBuff[nATBAckLen], (UINT8 *)(pTextWithHead->pData), pTextWithHead->nDataLen);
				nATBAckLen += pTextWithHead->nDataLen;

			}
#ifdef AT_DUAL_SIM
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI, nSim);
#else
			AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATAckBuff, nATBAckLen, CfwEvent.nUTI);
#endif
		}

		/* MT support 0, 1 and 2, other values not implements */
		else
		{
			AT_TC(g_sw_AT_SMS, "new msg indication: Received text format message, but this type of MT is not implements");
		}

		break;

		// ///////////////////////////////////
		// PDU status report
		// ///////////////////////////////////
	case 0x40:

		/* DS support 0 and 1, other values not implements */
		if (gATCurrentAtSMSInfo[nSim].sCnmi.nDs == 0)
		{
			AT_TC(g_sw_AT_SMS, "new msg indication: Received PDU status message, but not report to CNMI");
		}
		else if (gATCurrentAtSMSInfo[nSim].sCnmi.nDs == 1)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_CDSPDUReport(pNewMsgNode, CfwEvent.nUTI, nSim);
#else
			AT_SMS_CDSPDUReport(pNewMsgNode, CfwEvent.nUTI);
#endif
		}
		else
		{
			AT_TC(g_sw_AT_SMS, "new msg indication: Received PDU status message, but DS of this type not implements");
		}

		break;

		// ///////////////////////////////////
		// text status report
		// ///////////////////////////////////
	case 0x41:

		/* DS support 0 and 1, other values not implements */
		if (gATCurrentAtSMSInfo[nSim].sCnmi.nDs == 0)
		{
			AT_TC(g_sw_AT_SMS, "new msg indication: Received TEXT status message, but not report to CNMI");
		}
		else if (gATCurrentAtSMSInfo[nSim].sCnmi.nDs == 1)
		{
#ifdef AT_DUAL_SIM
			AT_SMS_CDSTextReport(pNewMsgNode, CfwEvent.nUTI, nSim);
#else
			AT_SMS_CDSTextReport(pNewMsgNode, CfwEvent.nUTI);
#endif
		}
		else
		{
			AT_TC(g_sw_AT_SMS, "new msg indication: Received TEXT status message, but DS of this type not implements");
		}

		break;

		// ///////////////////////////////////////////
		/* these are not implements from csw following      */
		// ///////////////////////////////////////////
	case 0x30:
		AT_TC(g_sw_AT_SMS,
		      "new msg indication: CBM PDU format broadcast message received, but nType of this case not implements");
		break;

	case 0x31:
		AT_TC(g_sw_AT_SMS,
		      "new msg indication: CBM TEXT format broadcast message received, but nType of this case not implements");
		break;

	default:

		AT_TC(g_sw_AT_SMS, "new msg indication: Unknown New Message nType");
		break;

	}

	// update the storage3

#ifdef AT_DUAL_SIM
	nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage3, nSim);
#else
	nOperationRet = CFW_CfgGetSmsStorageInfo(&sStorageInfo, gATCurrentAtSMSInfo[nSim].nStorage3);

#endif

	if (ERR_SUCCESS == nOperationRet)
	{
		gATCurrentAtSMSInfo[nSim].nTotal3 = sStorageInfo.totalSlot;
		gATCurrentAtSMSInfo[nSim].nUsed3  = sStorageInfo.usedSlot;
	}

	return;

}

#if 0
/******************************************************************************************
Function			:	AT_SMS_SetSMSParam_rsp
Description		:   	set sms parameters response
Called By			:	At SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	COS_EVENT *pEvent
Output			:
Return			:	VOID
Others			:  	building by wangqunyang 08/07/2008
*******************************************************************************************/
VOID AT_SMS_SetSMSParam_rsp(COS_EVENT *pEvent)
{

	CFW_EVENT CfwEvent   = { 0 };
	UINT32 nOperationRet = ERR_SUCCESS;

	AT_CosEvent2CfwEvent(pEvent, &CfwEvent);

	/* just for debug */
	AT_TC(g_sw_AT_SMS, "csca set param resp: CfwEvent.nType = 0x%x, CfwEvent.nParam1 = 0x%x, CfwEvent.nParam2 = %u",
	      CfwEvent.nType, CfwEvent.nParam1, CfwEvent.nParam2);
	if (0 == CfwEvent.nType)
	{
		/****************************************************************/
		// if cmd is "+CSCA" or "+CSAS" or "CRES", then return OK only
		/****************************************************************/
		AT_SMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, CfwEvent.nUTI);

	}
	else if (0xF0 == CfwEvent.nType)
	{
		nOperationRet = AT_SMS_ERR_Change(CfwEvent.nParam1);
		AT_SMS_Result_Err(nOperationRet, NULL, 0, "csca set param resp: CfwEvent.nType == 0xF0", CfwEvent.nUTI);

	}
	else
	{
		AT_SMS_Result_Err(ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0, "csca set param resp: exception happened", CfwEvent.nUTI);
	}

	return;

}
#endif
/******************************************************************************************
Function                :	AT_SMS_Result_OK
Description            :   	create SMS Successful result code and notify ATE
Called By              :	by SMS module
Data Accessed       :
Data Updated         :
Input                     :   	UINT32 uReturnValue, indication the event type
		                     UINT32 uResultCode, command execute result code
		                     UINT8  nDelayTime, delay time
		                     UINT8* pBuffer, data pointer
		                     UINT16 nDataSize, data length
Output                   :
Return                   :	void
Others                   :	build by unknown     2007.10.18
					modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
#ifdef AT_DUAL_SIM
VOID AT_SMS_Result_OK(UINT32 uReturnValue,
                      UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize, UINT8 nDLCI, UINT8 nSim)
#else
VOID AT_SMS_Result_OK(UINT32 uReturnValue,
                      UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize, UINT8 nDLCI)
#endif
{
	PAT_CMD_RESULT pResult = NULL;

#ifdef AT_DUAL_SIM
	AT_BACKSIMID(nSim);
#endif

	// 填充结果码
	pResult = AT_CreateRC(uReturnValue,
	                      uResultCode, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CMS, nDelayTime, pBuffer, nDataSize, nDLCI);

	AT_TC(g_sw_AT_SMS, "> func = %s, nDLCI = %d", __func__, nDLCI);
	AT_Notify2ATM(pResult, nDLCI);

	if (pResult != NULL)
	{
		AT_FREE(pResult);
		pResult = NULL;
	}

	// Add by wangqunyang 2008.04.09
	AT_TC(g_sw_AT_SMS, "> AT SMS Notify To ATM, Return Value: %s , Result Code: %s, nDLCI = %d,pBuffer= %s",
	      AT_Get_RetureValue_Name(uReturnValue), AT_Get_ResultCode_Name(uResultCode), nDLCI, pBuffer);

	return;
}

/******************************************************************************************
Function			:	AT_SMS_Result_Err
Description		:   	create SMS Error result code and notify ATE
Called By			:	by SMS module
Data Accessed  	:
Data Updated   	:
Input			:   	UINT32 uErrorCode, UINT8* pBuffer, UINT16 nDataSize
Output			:
Return			:	void
Others			:	build by wangqunyang 03/04/2008
*******************************************************************************************/
#ifdef AT_DUAL_SIM
VOID AT_SMS_Result_Err(UINT32 uErrorCode, UINT8 *pBuffer, UINT16 nDataSize, UINT8 *pExtendErrInfo, UINT8 nDLCI,
                       UINT8 nSim)
#else
VOID AT_SMS_Result_Err(UINT32 uErrorCode, UINT8 *pBuffer, UINT16 nDataSize, UINT8 *pExtendErrInfo, UINT8 nDLCI)
#endif
{
	PAT_CMD_RESULT pResult      = NULL;
	UINT8 DefaultExtendInfo[32] = "No Extend Info";

#ifdef AT_DUAL_SIM
	AT_BACKSIMID(nSim);
#endif

	// 填充结果码
	pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, uErrorCode, CMD_ERROR_CODE_TYPE_CMS, 0, pBuffer, nDataSize, nDLCI);

	AT_Notify2ATM(pResult, nDLCI);

	if (pResult != NULL)
	{
		AT_FREE(pResult);
		pResult = NULL;
	}

	// Add by wangqunyang 2008.04.09
	if (NULL == pExtendErrInfo)
	{
		pExtendErrInfo = DefaultExtendInfo;
	}

//	AT_TC(g_sw_AT_SMS, "> AT SMS Notify To ATM, Return Value: CMD_FUNC_FAIL , Error String: %s, Extend Info: %s\n",
//	      AT_GetErrorString(uErrorCode, CMD_ERROR_CODE_TYPE_CMS), pExtendErrInfo);
	AT_TC(g_sw_AT_SMS, "> AT SMS Notify To ATM, Return Value: CMD_FUNC_FAIL , Error code: %d, Extend Info: %s\n",
	      uErrorCode, pExtendErrInfo);
	return;
}

/******************************************************************************************
Function			:   AT_SMS_StatusMacroFlagToStringOrData
Description		:   macro status flag to string or data
Called By			:   AT_SMS_RESULT_OK
Data Accessed  	:
Data Updated   	:
Input			:   UINT8* pSetStatusBuff, UINT8 nFormat
Output			:
Return			:   BOOL
Others			:   build by wangqunyang 09/04/2008
*******************************************************************************************/
BOOL AT_SMS_StatusMacroFlagToStringOrData(UINT8 *pStatusMacroFlagBuff, UINT8 nFormat)
{

	if (nFormat)  /* text mode */
	{

		if (pStatusMacroFlagBuff[0] == CFW_SMS_STORED_STATUS_READ)
		{
			AT_StrCpy(pStatusMacroFlagBuff, "REC READ");
		}
		else if (pStatusMacroFlagBuff[0] == CFW_SMS_STORED_STATUS_UNREAD)
		{
			AT_StrCpy(pStatusMacroFlagBuff, "REC UNREAD");
		}
		else if (pStatusMacroFlagBuff[0] == 8 || pStatusMacroFlagBuff[0] == 0)
		{
			AT_StrCpy(pStatusMacroFlagBuff, "STO SENT");
		}
		else if (pStatusMacroFlagBuff[0] == CFW_SMS_STORED_STATUS_UNSENT)
		{
			AT_StrCpy(pStatusMacroFlagBuff, "STO UNSENT");
		}
		else
		{
			AT_TC(g_sw_AT_SMS, "text mode: get status exception 1");
			return FALSE;
		}
	}
	else  /* pdu mode */
	{

		if (pStatusMacroFlagBuff[0] == CFW_SMS_STORED_STATUS_READ)
		{
			pStatusMacroFlagBuff[0] = 1;
		}
		else if (pStatusMacroFlagBuff[0] == CFW_SMS_STORED_STATUS_UNREAD)
		{
			pStatusMacroFlagBuff[0] = 0;
		}
		else if (pStatusMacroFlagBuff[0] == 8 || pStatusMacroFlagBuff[0] == 0)
		{
			pStatusMacroFlagBuff[0] = 3;
		}
		else if (pStatusMacroFlagBuff[0] == CFW_SMS_STORED_STATUS_UNSENT)
		{
			pStatusMacroFlagBuff[0] = 2;
		}
		else
		{
			AT_TC(g_sw_AT_SMS, "pdu mode: get status exception 2");
			return FALSE;
		}
	}

	return TRUE;

}

/******************************************************************************************
Function			:   AT_SMS_StringOrDataToStatusMacroFlag
Description		:   string or data to macro flag
Called By			:   AT_SMS_RESULT_OK
Data Accessed  	:
Data Updated   	:
Input			:   UINT8* pStatusFlag, UINT8* pGetSaveStatus, UINT8 nFormat
Output			:
Return			:   BOOL
Others			:   build by wangqunyang 09/04/2008
*******************************************************************************************/
BOOL AT_SMS_StringOrDataToStatusMacroFlag(UINT8 *pStatusValue, UINT8 *pStatusFlag, UINT8 nFormat)
{

	if (nFormat)  /* text mode */
	{

		if (!strcmp("REC UNREAD", pStatusValue))
		{
			pStatusFlag[0] = CFW_SMS_STORED_STATUS_UNREAD;
		}
		else if (!strcmp("REC READ", pStatusValue))
		{
			pStatusFlag[0] = CFW_SMS_STORED_STATUS_READ;
		}
		else if (!strcmp("STO UNSENT", pStatusValue))
		{
			pStatusFlag[0] = CFW_SMS_STORED_STATUS_UNSENT;
		}
		else if (!strcmp("STO SENT", pStatusValue))
		{
			pStatusFlag[0] = CFW_SMS_STORED_STATUS_SENT_NOT_SR_REQ;
		}
		else if (!strcmp("ALL", pStatusValue))
		{
			pStatusFlag[0] = CFW_SMS_STORED_STATUS_STORED_ALL;
		}
		else
		{
			AT_TC(g_sw_AT_SMS, "text mode: get status exception 3");
			return FALSE;
		}
	}
	else  /* pdu mode */
	{

		if (pStatusValue[0] == 0)
		{
			pStatusFlag[0] = CFW_SMS_STORED_STATUS_UNREAD;
		}
		else if (pStatusValue[0] == 1)
		{
			pStatusFlag[0] = CFW_SMS_STORED_STATUS_READ;
		}
		else if (pStatusValue[0] == 2)
		{
			pStatusFlag[0] = CFW_SMS_STORED_STATUS_UNSENT;
		}
		else if (pStatusValue[0] == 3)
		{
			pStatusFlag[0] =
			    CFW_SMS_STORED_STATUS_SENT_NOT_SR_REQ | CFW_SMS_STORED_STATUS_SENT_SR_REQ_NOT_RECV |
			    CFW_SMS_STORED_STATUS_SENT_SR_REQ_NOT_STORE | CFW_SMS_STORED_STATUS_SENT_SR_REQ_RECV_STORE;
		}
		else if (pStatusValue[0] == 4)
		{
			pStatusFlag[0] = CFW_SMS_STORED_STATUS_STORED_ALL;
		}
		else
		{
			AT_TC(g_sw_AT_SMS, "pdu mode: get status exception 4");
			return FALSE;
		}
	}

	return TRUE;

}

/******************************************************************************************
Function			:	AT_SMS_CheckPDUIsValid
Description		:   	check pdu is valid or not
Called By			:	by SMS module
Data Accessed  	:
Data Updated    	:
Input			:   	UINT8 * pPDUData,
					UINT8 * nPDULen,
					BOOL bReadMsgFlag
Output			:
Return			:	BOOL
Others			: 	build by wangqunyang 2008.05.13
*******************************************************************************************/
BOOL AT_SMS_CheckPDUIsValid(UINT8 *pPDUData, UINT8 *nPDULen, BOOL bReadOrListMsgFlag)
{
	UINT8 nIndex       = 0;
	UINT8 nUserDataLen = 0;
	UINT8 nDCSFlag     = 0;
	UINT8 nDABytes     = 0;
	BOOL bSubmitFlag   = FALSE;
	UINT8 nDABCDLen    = 0;
	UINT8 nVPLen       = 0;

	/* Input data check */
	if (pPDUData == NULL || * nPDULen == 0)
	{
		AT_TC(g_sw_AT_SMS, "check pdu: PDUData pointer is NULL or PDU len is 0");
		return FALSE;
	}

	/* Get the index following SCA */
	nIndex = pPDUData[0] + 1;

	/********************************************************
	** first , we get the MTI flag,  message or not
	** MTI 00 : deliver mti 01 : submit
	** other bits ,we omit and now implement
	*********************************************************/
	if (0x01 == (pPDUData[nIndex] & 0x03))
	{
		bSubmitFlag = TRUE;
	}

	// /////////////////////////////////////////////////////
	// PDU is to write message or send message
	// /////////////////////////////////////////////////////
	if (bSubmitFlag)
	{

		/* FO flag parse Beginning........
		   ** MTI 00 : deliver mti 01 : submit
		 */

		/* FO is omit parse */

		/* RD is omit parse */

		/* VPF parse and set the VP lenght */
		if ((pPDUData[nIndex] & 0x18) == 0x00)  /* 00 000 */
		{
			nVPLen = 0;
		}
		else if ((pPDUData[nIndex] & 0x18) == 0x08) /* 01 000  reserved */
		{
			nVPLen = 8;
		}
		else if ((pPDUData[nIndex] & 0x18) == 0x10) /* 10 000 */
		{
			nVPLen = 8;
		}
		else  /* 11 000 */
		{
			nVPLen = 4;
		}

		/* SRR is omit parse */

		/* UDHI is omit parse */

		/* RP is omit parse */

		/*
		   ** FO flag parsed completely and increase the index
		 */
		//
		nIndex++;

		/* MR: message reference is omit parse */
		nIndex++;

		/* DA: How many Dial number's */
		if (pPDUData[nIndex] % 2)
		{
			nDABCDLen = pPDUData[nIndex] / 2 + 1; // odd number
		}
		else
		{
			nDABCDLen = pPDUData[nIndex] / 2; // even number
		}

		// All DA area is less than 12 bytes
		if ((1 + 1 + nDABCDLen) > 12)
		{
			AT_TC(g_sw_AT_SMS, "MO check pdu: SCA field octs length is more than 12 ");
			return FALSE;
		}
		nIndex = nIndex + 1 + 1 + nDABCDLen;

		/*
		   ** PID byte index, set default 0x00 for PID
		 */
		if (0x00 != pPDUData[nIndex])
		{
			//pPDUData[nIndex] = 0x00; //Modify by Lixp for GCF test
		}
		nIndex++;

		// /////////////////////////////////////////////
		// here: only parse the encode bits of DCS byte,
		// other bits omit and not implement
		//
		// bit7..bit4 - encode group
		// bit7 - reserved
		// bit6 - reserved
		// bit5 - 0:text uncompress 1: GSM default compress
		// bit4 - 0: bit0 and bit1 no use 1: bit0 and bit1 useful
		//
		// bit0: bit1:
		// 0     0 class1
		// 0     1 class2
		// 1     0 class3
		// 1     1 class4
		//
		// bit2: bit3:
		// 0 0 GSM default 7 bit
		// 0 1 8 bit dcs
		// 1 0 16bit ucs
		// 1 1 reserved
		// ////////////////////////////////////////////
		if (0x00 == (pPDUData[nIndex] & 0x0C))
		{
			nDCSFlag = 7;
		}
		else if (0x04 == (pPDUData[nIndex] & 0x0C))
		{
			nDCSFlag = 8;
		}
		else if (0x08 == (pPDUData[nIndex] & 0x0C))
		{
			nDCSFlag = 16;
		}
		else
		{
			AT_TC(g_sw_AT_SMS, "MO check pdu: DCS field value is not supported by us ");
			return FALSE;
		}

		nIndex++;

		/*
		   ** parse VP is exist or not
		 */
		if (0 == nVPLen)  /* No VP */
		{

		}
		else if (8 == nVPLen) /* one byte */
		{
			nIndex++;
		}
		else  /* half byte */
		{
			nIndex++;

			/* read the spec and make sure which half byte, high or low?
			   continue ...... to do
			   if(0x00!= pPDUData[nIndex] & 0xF0)
			   {
			   return FALSE;
			   } */

		}

		/* UDL parse */
		if (7 == nDCSFlag)
		{
			if (pPDUData[nIndex] > 160)
			{
				AT_TC(g_sw_AT_SMS, "MO check pdu: 7bit encode and user data len more 160 ");
				return FALSE;
			}

			if ((pPDUData[nIndex] * 7) % 8)
			{
				nUserDataLen = (pPDUData[nIndex] * 7) / 8 + 1;
			}
			else
			{
				nUserDataLen = (pPDUData[nIndex] * 7) / 8;

			}

		}
		else
		{
			if (pPDUData[nIndex] > 140)
			{
				AT_TC(g_sw_AT_SMS, "MO check pdu: 8bit or 16bit encode and user data len more than 140 ");
				return FALSE;
			}

			nUserDataLen = pPDUData[nIndex];

		}

		if (bReadOrListMsgFlag)
		{
			/* out parameters of  nOutputPDULen */
			*nPDULen           = nUserDataLen + nIndex + 1;
			pPDUData[*nPDULen] = '\0';

		}
		else
		{

			/* check the input length is valid */
			if ((pPDUData[0] + 1 > * nPDULen) || ((*nPDULen > AT_SMS_BODY_BUFF_LEN)))
			{

				AT_TC(g_sw_AT_SMS, "MO check pdu: PDU len overflow");
				return FALSE;
			}

			/* check the total length */
			if (nUserDataLen + nIndex + 1 != *nPDULen)
			{
				AT_TC(g_sw_AT_SMS, "MO check pdu: length is not match");
				return FALSE;
			}
		}

		return TRUE;

	}

	// /////////////////////////////////////////////////////////////////
	// parse PDU is recv from others
	// ////////////////////////////////////////////////////////////////
	else
	{
		nIndex++;

		/* DA parser */
		if (pPDUData[nIndex] % 2)
		{
			nDABytes = (pPDUData[nIndex] + 1) / 2;
		}
		else
		{
			nDABytes = pPDUData[nIndex] / 2;
		}

		nIndex = nIndex + 1 + 1 + nDABytes; /* length, toda DA */

		/* PID omit parser */
		nIndex++;

		// /////////////////////////////////////////////
		// here: only parse the encode bits of  DCS byte,
		// other bits omit and not implement now,
		// the bit meaning as above description
		// /////////////////////////////////////////////
		if (0x00 == (pPDUData[nIndex] & 0x0C))
		{
			nDCSFlag = 7;
		}
		else if (0x04 == (pPDUData[nIndex] & 0x0C))
		{
			nDCSFlag = 8;
		}
		else if (0x08 == (pPDUData[nIndex] & 0x0C))
		{
			nDCSFlag = 16;
		}
		else
		{
			AT_TC(g_sw_AT_SMS, "MT check pdu: DCS field value is not supported by us ");
			return FALSE;
		}
		nIndex++;

		/* 7 bytes of time stamp */
		nIndex = nIndex + 7;

		/* UDL parse */
		if (7 == nDCSFlag)
		{
			if (pPDUData[nIndex] > 160)
			{
				AT_TC(g_sw_AT_SMS, "MT check pdu: 7bit encode and user data len more 160 ");
				return FALSE;
			}

			if ((pPDUData[nIndex] * 7) % 8)
			{
				nUserDataLen = (pPDUData[nIndex] * 7) / 8 + 1;
			}
			else
			{
				nUserDataLen = (pPDUData[nIndex] * 7) / 8;

			}

		}
		else
		{
			if (pPDUData[nIndex] > 140)
			{
				AT_TC(g_sw_AT_SMS, "MT check pdu: 8bit or 16bit encode and user data len more 140 ");
				return FALSE;
			}

			nUserDataLen = pPDUData[nIndex];

		}

		if (bReadOrListMsgFlag)
		{
			/* check the total length */
			if (nUserDataLen + nIndex + 1 > AT_SMS_BODY_BUFF_LEN)
			{
				AT_TC(g_sw_AT_SMS, "MT check pdu: totol pdu len is overflow ");
				return FALSE;
			}

			/* out parameters of  nOutputPDULen */
			*nPDULen           = nUserDataLen + nIndex + 1;
			pPDUData[*nPDULen] = '\0';

		}
		else
		{
			AT_TC(g_sw_AT_SMS, "nUserDataLen = %u, nIndex = %u, *nPDULen = %u", nUserDataLen, nIndex, *nPDULen);

			/* check the input length is valid */
			if ((pPDUData[0] + 1 > * nPDULen) || ((*nPDULen > AT_SMS_BODY_BUFF_LEN)))
			{
				AT_TC(g_sw_AT_SMS, "MT check pdu: totol pdu len is overflow ");
				return FALSE;
			}

			/* check the total length */
			if (nUserDataLen + nIndex + 1 != *nPDULen)
			{
				AT_TC(g_sw_AT_SMS, "MT check pdu: PDU length is not match ");
				return FALSE;
			}
		}

		return TRUE;

	}

}

/******************************************************************************************
Function			:	AT_SMS_IsValidPhoneNumber
Description		:   	check number copy from pbk module is valid or not
Called By			:	by SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	UINT8 * arrNumber, UINT8 nNumberSize, BOOL * bIsInternational
Output			:
Return			:	BOOL
Others			:   	//[+]2007.11.29 for check number copy from pbk module
					//arrNumber[in]; pNumberSize[in]; bIsInternational[out]
					//legal phone number char: 0-9,*,#,+ (+ can only be the first position)
					modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
BOOL AT_SMS_IsValidPhoneNumber(UINT8 *arrNumber, UINT8 nNumberSize, BOOL *bIsInternational)
{
	UINT8 nTemp = 0;

	if ((arrNumber == NULL) || (0 == nNumberSize))
	{
		AT_TC(g_sw_AT_SMS, "SMS check phone number: pointer is NULL or number size is 0 ");
		return FALSE;
	}

	*bIsInternational = FALSE;

	if (arrNumber[0] == '+')
	{
		*bIsInternational = TRUE;
		nTemp             = 1;
	}

	while (nTemp < nNumberSize)
	{
		if ((arrNumber[nTemp] != '#')
		        && (arrNumber[nTemp] != '*') && ((arrNumber[nTemp] < '0') || (arrNumber[nTemp] > '9')))
		{
			AT_TC(g_sw_AT_SMS, "SMS check phone number: invalid char in the number");
			return FALSE;
		}

		nTemp++;
	}

	return TRUE;

}

/******************************************************************************************
Function			:	AT_SMS_ERR_Change
Description		:   	transfer Error Code between CSW and AT
Called By			:	by SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	UINT32 nInErrcode
Output			:
Return			:	UINT32
Others			:   	//[+]CSW ERROR CODE change to  AT ERROR CODE 2007.10.12-10.16
					modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
UINT32 AT_SMS_ERR_Change(UINT32 nInErrcode)
{

	switch (nInErrcode)
	{
	case ERR_CMS_INVALID_MEMORY_INDEX: // [+]from rsp(param1) return error 2007.10.15
		return ERR_AT_CMS_INVALID_MEM_INDEX;
		break;

	case ERR_CMS_MEMORY_FULL:
		return ERR_AT_CMS_MEM_FULL;
		break;

	case ERR_CMS_TEMPORARY_FAILURE:
		return ERR_AT_CMS_TMEP_FAIL;
		break;

	case ERR_CMS_OPERATION_NOT_ALLOWED:
		return ERR_AT_CMS_OPER_NOT_ALLOWED;
		break;

	case ERR_CMS_MEMORY_CAPACITY_EXCEEDED:
		return ERR_AT_CMS_MEM_CAP_EXCCEEDED;
		break;

	case ERR_CMS_SMSC_ADDRESS_UNKNOWN:
		return ERR_AT_CMS_SCA_ADDR_UNKNOWN;
		break;

	case ERR_CMS_INVALID_CHARACTER_IN_PDU:
		return ERR_AT_CMS_INVALID_PDU_CHAR;
		break;

	case ERR_CMS_INVALID_CHARACTER_IN_ADDRESS_STRING:
		return ERR_AT_CMS_INVALID_ADDR_CHAR;
		break;

	case ERR_CMS_INVALID_PDU_MODE_PARAMETER:
		return ERR_AT_CMS_INVALID_PDU_PARAM;
		break;

	case ERR_CMS_INVALID_TEXT_MODE_PARAMETER:
		return ERR_AT_CMS_INVALID_TXT_PARAM;
		break;

	case ERR_CFW_INVALID_PARAMETER:  // [+]csw function return error 2007.10.15
		return ERR_AT_CMS_INVALID_PARA;
		break;

	case ERR_CMS_TP_VPF_NOT_SUPPORTED:
		return ERR_AT_CMS_TP_VPF_NOT_SUPP;
		break;

	case ERR_CMS_INVALID_STATUS:
		return ERR_AT_CMS_INVALID_STATUS;
		break;

	case ERR_CMS_UNSPECIFIED_TP_PID_ERROR: // csw send() return error
	case ERR_CMS_UNSPECIFIED_TP_DCS_ERROR:
	case ERR_CMS_UNKNOWN_ERROR:
	case ERR_CME_OPERATION_TEMPORARILY_NOT_ALLOWED:
	case ERR_CFW_NOT_EXIST_FREE_UTI: // [+]csw function return error 2007.10.15
	case ERR_CFW_UTI_IS_BUSY:
	default:
		return ERR_AT_CMS_UNKNOWN_ERROR;
		break;
	}

}

/******************************************************************************************
Function			:	SMS_PDUBCDToASCII
Description		:   	transfer PDU BCD Code to ASCII Code
Called By			:	by SMS module
Data Accessed  	:
Data Updated   	:
Input			:   	UINT8 * pBCD,
					UINT16 *pLen,
					UINT8 * pStr
Output			:
Return			:	UINT16
Others			:   	build by unknown and unknown date
					modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
BOOL SMS_PDUBCDToASCII(UINT8 *pBCD, UINT16 *pLen, UINT8 *pStr)
{
	UINT8 Tmp = 0;

	UINT32 i;

	if (pStr == NULL || pBCD == NULL)
	{
		AT_TC(g_sw_AT_SMS, "BCD to ASCII: pointer is NULL");
		return FALSE;
	}

	AT_MemSet(pStr, 0, (*pLen) * 2);

	for (i = 0; i < *pLen; i++)
	{
		// ////////////////////////////
		// high 4 bits
		// ////////////////////////////
		Tmp = pBCD[i] >> 4;
		if (Tmp < 10) // 0~9
		{
			pStr[i * 2] = Tmp + '0';
		}
		else if (Tmp > 9 && Tmp < 16) // 10~15
		{
			pStr[i * 2] = Tmp + 55;
		}
		else
		{
			AT_TC(g_sw_AT_SMS, "BCD to ASCII: high bits some char is more than 'F' of HEX");
			return FALSE;
		}

		// ////////////////////////////
		// low 4 bits
		// ////////////////////////////
		Tmp = pBCD[i] & 0x0f;
		if (Tmp < 10) // 0~9
		{
			pStr[i * 2 + 1] = Tmp + '0';
		}
		else if (Tmp > 9 && Tmp < 16) // 10~15
		{
			pStr[i * 2 + 1] = Tmp + 55;
		}
		else
		{
			AT_TC(g_sw_AT_SMS, "BCD to ASCII: low bits some char is more than 'F' of HEX");
			return FALSE;
		}

	}

	*pLen = i * 2;

	return TRUE;

}

/******************************************************************************************
Function			:	AT_CIND_SMS
Description		:  	CIND Command inner procedure function
Called By			:	AT_GC_CmdFunc_CIND
Data Accessed   	:
Data Updated    	:
Input			:   	UINT8* pNewMsg,UINT8* pMemFull
Output			:
Return			:	BOOL
Others			:   	//[+]2007.10.30 for +cind interface func
					modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
#ifdef AT_DUAL_SIM
BOOL AT_CIND_SMS(UINT8 *pNewMsg, UINT8 *pMemFull , UINT8 nSim)
#else
BOOL AT_CIND_SMS(UINT8 *pNewMsg, UINT8 *pMemFull)
#endif
{
	*pNewMsg = g_SMS_CIND_NewMsg ? 1 : 0;

	/* if ME storage and SM storage are both full, SMSFULL is 1, orthers is 0 */
#ifdef AT_DUAL_SIM
	*pMemFull = ((CFW_SMS_STORAGE_SM == (g_SMS_CIND_MemFull[nSim] & CFW_SMS_STORAGE_SM))
	             && (CFW_SMS_STORAGE_ME == (g_SMS_CIND_MemFull[nSim] & CFW_SMS_STORAGE_ME))) ? 1 : 0;
#else
	*pMemFull = ((CFW_SMS_STORAGE_SM == (g_SMS_CIND_MemFull & CFW_SMS_STORAGE_SM))
	             && (CFW_SMS_STORAGE_ME == (g_SMS_CIND_MemFull & CFW_SMS_STORAGE_ME))) ? 1 : 0;
#endif
	if (*pNewMsg > 1 || *pMemFull > 1)
	{
		AT_TC(g_sw_AT_SMS, "AT_CIND_SMS: new msg or msg full indicator more than 1");
		return FALSE;
	}

	return TRUE;
}

/******************************************************************************************
Function			:	AT_SMS_CDS_TEXT
Description		:   	AT SMS CDS Command inner procedure function
Called By			:	AT_GC_CmdFunc_CIND
Data Accessed  	:
Data Updated    	:
Input			:   	CFW_NEW_SMS_NODE* nParam1ToSmsNode
Output			:
Return			:	VOID
Others			:   	//[+]2007.10.24 for +cds text
					modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
#ifdef AT_DUAL_SIM
VOID AT_SMS_CDSTextReport(CFW_NEW_SMS_NODE *pNewMessageData, UINT8 nUTI, UINT8 nSim)
#else
VOID AT_SMS_CDSTextReport(CFW_NEW_SMS_NODE *pNewMessageData, UINT8 nUTI)
#endif
{

	CFW_SMS_TXT_STATUS_IND *pTextWithHeadSR = NULL; // nType=0x41

	UINT8 ATBAckBuff[128]               = { 0 };
	UINT8 nNumberRa[TEL_NUMBER_MAX_LEN] = { 0 };
	UINT8 nCount                        = 0, nRaSize = 0;
	UINT8 nType[2] = { 0 }, nTypeScts[2] =
	{
		0
	}, nTypeDt[2] =
	{
		0
	};

	pTextWithHeadSR = (CFW_SMS_TXT_STATUS_IND *)(pNewMessageData->pNode);

	/* just for debug */
	AT_TC(g_sw_AT_SMS, "new msg CDSTextReport: pTextWithHeadSR->ra_size = %u", pTextWithHeadSR->ra_size);

	/* ra  change to ascii and get size */
	nCount = SUL_GsmBcdToAscii(pTextWithHeadSR->ra, (pTextWithHeadSR->ra_size), nNumberRa);

	if (0xf0 == (*(pTextWithHeadSR->ra + pTextWithHeadSR->ra_size - 1) & 0xf0))
	{
		nRaSize = (UINT8)(pTextWithHeadSR->ra_size * 2 - 1);
	}
	else
	{
		nRaSize = (UINT8)(pTextWithHeadSR->ra_size * 2);
	}

	/* decide has + or not */
	if (pTextWithHeadSR->tora == CFW_TELNUMBER_TYPE_INTERNATIONAL)
	{
		AT_StrCpy(nType, "+");
	}

	/* scts iZone */
	if (pTextWithHeadSR->scts.iZone >= 0)
	{
		AT_StrCpy(nTypeScts, "+");
	}
	else
	{
		pTextWithHeadSR->scts.iZone = 0 - pTextWithHeadSR->scts.iZone;
		AT_StrCpy(nTypeScts, "-");
	}

	/* dt iZone */
	if (pTextWithHeadSR->dt.iZone >= 0)
	{
		AT_StrCpy(nTypeDt, "+");
	}
	else
	{
		pTextWithHeadSR->dt.iZone = 0 - pTextWithHeadSR->dt.iZone;
		AT_StrCpy(nTypeDt, "-");
	}

	AT_Sprintf(ATBAckBuff,
	           "+CDS: %u,%u,\"%s%s\",%u,\"%u/%02u/%02u,%02u:%02u:%02u%s%02d\",\"%u/%02u/%02u,%02u:%02u:%02u%s%02d\",%u",
	           pTextWithHeadSR->fo, pTextWithHeadSR->mr, nType, nNumberRa, pTextWithHeadSR->tora,
	           pTextWithHeadSR->scts.uYear, pTextWithHeadSR->scts.uMonth, pTextWithHeadSR->scts.uDay,
	           pTextWithHeadSR->scts.uHour, pTextWithHeadSR->scts.uMinute, pTextWithHeadSR->scts.uSecond, nTypeScts,
	           pTextWithHeadSR->scts.iZone, pTextWithHeadSR->dt.uYear, pTextWithHeadSR->dt.uMonth,
	           pTextWithHeadSR->dt.uDay, pTextWithHeadSR->dt.uHour, pTextWithHeadSR->dt.uMinute,
	           pTextWithHeadSR->dt.uSecond, nTypeDt, pTextWithHeadSR->dt.iZone, pTextWithHeadSR->st);

#ifdef AT_DUAL_SIM
	AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATBAckBuff, (UINT16)AT_StrLen(ATBAckBuff), nUTI, nSim);
#else
	AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATBAckBuff, (UINT16)AT_StrLen(ATBAckBuff), nUTI);
#endif

	return;

}

/******************************************************************************************
Function			:	AT_SMS_CDS_PDU
Description		:   	cds pdu execute inner procedure function
Called By			:	AT_SMS_RecieveNew_Indictation
Data Accessed   	:
Data Updated    	:
Input			:   	CFW_NEW_SMS_NODE* nParam1ToSmsNode
Output			:
Return			:	VOID
Others			:   	//[+]2007.10.24 for +cds pdu
					modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
#ifdef AT_DUAL_SIM
VOID AT_SMS_CDSPDUReport(CFW_NEW_SMS_NODE *pNewMessageData, UINT8 nUTI, UINT8 nSim)
#else
VOID AT_SMS_CDSPDUReport(CFW_NEW_SMS_NODE *pNewMessageData, UINT8 nUTI)
#endif
{

	CFW_SMS_PDU_INFO *pPduSR = NULL;
	UINT8 ASCIIBuff[AT_SMS_BODY_BUFF_LEN] = { 0 };
	UINT8 ATBAckBuff[256]                 = { 0 };
	UINT16 nATBAckLen                     = 0;

	pPduSR = (CFW_SMS_PDU_INFO *)(pNewMessageData->pNode);

	/* just for debug */
	AT_TC(g_sw_AT_SMS, "new msg CDSPDUReport: pPduSR->nDataSize = %u", pPduSR->nDataSize);
	AT_TC_MEMBLOCK(g_sw_AT_SMS, pPduSR->pData, pPduSR->nDataSize, 16);

	AT_Sprintf(ATBAckBuff, "+CDS: %u\r\n", pPduSR->nDataSize);
	nATBAckLen = AT_StrLen(ATBAckBuff);

	/* convert PDU BCD to ascii string */
	if (!(SMS_PDUBCDToASCII(pPduSR->pData, &(pPduSR->nDataSize), ASCIIBuff)))
	{
#ifdef AT_DUAL_SIM
		AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "CDSPDUReport: format is not match", nUTI, nSim);
#else
		AT_SMS_Result_Err(ERR_AT_CMS_INVALID_PDU_CHAR, NULL, 0, "CDSPDUReport: format is not match", nUTI);
#endif
		return;
	}

	AT_MemCpy(&ATBAckBuff[nATBAckLen], ASCIIBuff, pPduSR->nDataSize);
	nATBAckLen += pPduSR->nDataSize;
#ifdef AT_DUAL_SIM
	AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATBAckBuff, nATBAckLen, nUTI, nSim);
#else
	AT_SMS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, ATBAckBuff, nATBAckLen, nUTI);
#endif

	return;

}

/******************************************************************************************
Function			:	AT_SMS_DCSChange
Description		:   	csw dcs transfer to AT dcs
Called By			:	unknown
Data Accessed  	:
Data Updated   	:
Input			:   	UINT8 InDCS,UINT8 OutDCS
Output			:
Return			:	UINT8
Others			:   	//[+]csw dcs change to AT dcs 2007.10.10

*******************************************************************************************/
UINT8 AT_SMS_DCSChange(UINT8 InDCS, UINT8 OutDCS)
{

	if (InDCS == 0)
	{
		OutDCS = GSM_7BIT_UNCOMPRESSED;
	}
	else if (InDCS == 1)
	{
		OutDCS = GSM_8BIT_UNCOMPRESSED;
	}
	else if (InDCS == 2)
	{
		OutDCS = GSM_UCS2_UNCOMPRESSED;
	}
	else if (InDCS == 0x10)
	{
		OutDCS = GSM_7BIT_COMPRESSED;
	}
	else if (InDCS == 0x11)
	{
		OutDCS = GSM_8BIT_COMPRESSED;
	}
	else if (InDCS == 0x12)
	{
		OutDCS = GSM_UCS2_COMPRESSED;
	}
	else if (InDCS == 4)
	{
		OutDCS = GSM_8BIT_UNCOMPRESSED;
	}

	return OutDCS;

}

/******************************************************************************************
Function			:	SMS_AddSCA2PDU
Description		:   	add sca to pdu
Called By			:	SMS module
Data Accessed   	:
Data Updated    	:
Input			:   	UINT8 *InPDU, UINT8 *OutPDU, UINT16* pSize
Output			:
Return			:	UINT32
Others			:
				    	modify and add comment by wangqunyang 03/04/2008
*******************************************************************************************/
#ifdef AT_DUAL_SIM
BOOL SMS_AddSCA2PDU(UINT8 *InPDU, UINT8 *OutPDU, UINT16 *pSize, UINT8 nSim)
#else
BOOL SMS_AddSCA2PDU(UINT8 *InPDU, UINT8 *OutPDU, UINT16 *pSize)
#endif
{
	CFW_SMS_PARAMETER sInfo = { 0 };

	if (InPDU == NULL || OutPDU == NULL || * pSize == 0)
	{
		AT_TC(g_sw_AT_SMS, "AddSCA2PDU: pointer is NULL or size is 0");
		return FALSE;
	}

	// SCA not present
	if (InPDU[0] == 0)
	{

#ifdef AT_DUAL_SIM
		if (ERR_SUCCESS != CFW_CfgGetSmsParam(&sInfo, 0, nSim))
#else
		if (ERR_SUCCESS != CFW_CfgGetSmsParam(&sInfo, 0))

#endif
		{
			AT_TC(g_sw_AT_SMS, "AddSCA2PDU: get SMS param error");
			return FALSE;
		}

		AT_MemCpy(OutPDU, sInfo.nNumber, sInfo.nNumber[0] + 1);

		AT_MemCpy(&OutPDU[OutPDU[0] + 1], &InPDU[1], (*pSize) - 1);
		*pSize = OutPDU[0] + *pSize;

	}
	else
	{
		AT_MemCpy(OutPDU, InPDU, *pSize);
	}

	return TRUE;

}

/******************************************************************************************
Function			:	SMS_PDUAsciiToBCD
Description		:   	this function used to check the input PDU has the SCA or not,
                    			if not, add the SCA to the begin of the OUTPDU string.
Called By			:	AT_SMS_CmdFunc_CMGS
                    			AT_SMS_CmdFunc_CMGW
Data Accessed   	:
Data Updated    	:
Input			:   	UINT8 * pNumber, UINT16 nNumberLen, UINT8 * pBCD
Output			:
Return			:	UINT16
Others		  	:   	modify and add comment by wangqunyang 06/04/2008
*******************************************************************************************/
UINT16 SMS_PDUAsciiToBCD(UINT8 *pNumber, UINT16 nNumberLen, UINT8 *pBCD)
{

	UINT8 *pTmp     = pBCD;
	UINT8 Tmp       = 0;
	UINT32 i        = 0;
	UINT16 nBcdSize = 0;

	if (pNumber == NULL || pBCD == NULL)
	{
		AT_TC(g_sw_AT_SMS, "AsciiToBCD: ponter is NULL");
		return FALSE;
	}

	AT_MemSet(pBCD, 0, nNumberLen >> 1);

	for (i = 0; i < nNumberLen; i++)
	{
		if ((*pNumber >= 65) && (*pNumber <= 70))
		{
			Tmp = (INT8)(*pNumber - 55);
		}
		else if ((*pNumber >= 97) && (*pNumber <= 102))
		{
			Tmp = (INT8)(*pNumber - 87);
		}
		else if ((*pNumber >= '0') && (*pNumber <= '9'))
		{
			Tmp = (INT8)(*pNumber - '0');
		}
		else
		{
			AT_TC(g_sw_AT_SMS, "AsciiToBCD: some ascii char is more than 'F' of HEX");
			return FALSE;
		}

		if (i % 2)
		{
			*pTmp++ |= (INT8)(Tmp & 0x0F);
		}
		else
		{
			*pTmp = (Tmp << 4) & 0xF0;
		}

		pNumber++;
	}

	nBcdSize = nNumberLen >> 1;

	if (i % 2)
	{
		*pTmp |= 0xF0;
		nBcdSize += 1;
	}

	return nBcdSize;

}
BOOL AT_SMS_GetPDUNUM(UINT8 *pPDUData, UINT8 *pPDUNUM, UINT8 *pType,UINT8 *nPDULen)
{
	UINT8 nIndex       = 0;

	/* Input data check */
	if (pPDUData == NULL || * pPDUNUM == 0)
	{
		AT_TC(g_sw_AT_SMS, "GetPDUNUM is NULL or PDU len is 0");
		return FALSE;
	}

	/* Get the index following SCA */
	nIndex = pPDUData[0] + 1;
	/* SRR is omit parse */
	/* UDHI is omit parse */
	/* RP is omit parse */
	/*
	** FO flag parsed completely and increase the index
	*/
	//
	nIndex++;

	/* MR: message reference is omit parse */
	nIndex++;

	/* DA: How many Dial number's */
	if (pPDUData[nIndex] % 2)
	{
		*nPDULen = pPDUData[nIndex] / 2 + 1; // odd number
	}
	else
	{
		*nPDULen = pPDUData[nIndex] / 2; // even number
	}
	// All DA area is less than 12 bytes
	if ((1 + 1 + *nPDULen) > 12)
	{
		AT_TC(g_sw_AT_SMS, "GetPDUNUM: SCA field octs length is more than 12 ");
		return FALSE;
	}
	*pType = pPDUData[nIndex+1];

	AT_MemCpy(pPDUNUM, &(pPDUData[nIndex+2]), *nPDULen);
	
	AT_TC(g_sw_AT_SMS, "GetPDUNUM is end\n");
//	AT_TC_MEMBLOCK(g_sw_AT_SMS, pPDUNUM, *nPDULen, 16);
	return TRUE;
}
BOOL AT_SMS_GetSCANUM(UINT8 *pPDUData, UINT8 *pSACNUM, UINT8 *nPDULen)
{
	UINT8 nIndex       = 0;

	/* Input data check */
	if (pPDUData == NULL || * pSACNUM == 0)
	{
		AT_TC(g_sw_AT_SMS, "GetPDUNUM is NULL or PDU len is 0");
		return FALSE;
	}

	/* Get the index following SCA */
	nIndex = 1;

	/* DA: How many Dial number's */
	*nPDULen = pPDUData[0]  -1;
	// All DA area is less than 12 bytes
	if ((1 + 1 + *nPDULen) > 12)
	{
		AT_TC(g_sw_AT_SMS, "GetPDUNUM: SCA field octs length is more than 12 ");
		return FALSE;
	}
	AT_MemCpy(pSACNUM, &(pPDUData[nIndex+1]), *nPDULen);
	AT_TC(g_sw_AT_SMS, "GetSCANUM is end\n");
//	AT_TC_MEMBLOCK(g_sw_AT_SMS, pSACNUM, *nPDULen, 16);
	return TRUE;
}

BOOL AT_GetCfwInitSmsInfo(CFW_EVENT *pCfwEvent)
{
	BOOL ret = FALSE;

	if (cfwInitInfo.sms[pCfwEvent->nFlag].nType == CFW_INIT_STATUS_SMS)
	{
		pCfwEvent->nEventId = cfwInitInfo.sms[pCfwEvent->nFlag].nEventId;
		pCfwEvent->nParam1  = cfwInitInfo.sms[pCfwEvent->nFlag].nParam1;
		pCfwEvent->nParam2  = cfwInitInfo.sms[pCfwEvent->nFlag].nParam2;

		pCfwEvent->nUTI  = cfwInitInfo.sms[pCfwEvent->nFlag].nUTI;
		pCfwEvent->nType = cfwInitInfo.sms[pCfwEvent->nFlag].nType;
		pCfwEvent->nFlag = cfwInitInfo.sms[pCfwEvent->nFlag].nFlag;

		ret = TRUE;
	}

	return ret;
}
// ///////////////////////////////////////////////////////////////////////////////////////////////
// The end of the file
// ///////////////////////////////////////////////////////////////////////////////////////////////

