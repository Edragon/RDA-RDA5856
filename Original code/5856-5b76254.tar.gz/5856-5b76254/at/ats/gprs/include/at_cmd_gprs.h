// //////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002-2012, Coolsand Technologies, Inc.
// All Rights Reserved
//
// This source code is property of Coolsand. The information contained in this
// file is confidential. Distribution, reproduction, as well as exploitation,
// or transmission of any content of this file is not allowed except if
// expressly permitted.Infringements result in damage claims!
//
// FILENAME: at_cmd_gprs.h
//
// DESCRIPTION:
// TODO: ...
//
// REVISION HISTORY:
// NAME              DATE                REMAKS
// Lixp      2012-2-20       Created initial version 1.0
//
// //////////////////////////////////////////////////////////////////////////////
#ifdef CFW_GPRS_SUPPORT
#ifndef __AT_CMD_GPRS_H__
#define __AT_CMD_GPRS_H__

struct COS_EVENT;

struct AT_CMD_PARA;

// GPRS parameter size define.
#define AT_GPRS_APN_MAX_LEN      50
#define AT_GPRS_PDPADDR_MAX_LEN  50
#define AT_GPRS_PDPTYPE_MAX_LEN  50
#define AT_GPRS_USR_MAX_LEN          50
#define AT_GPRS_PAS_MAX_LEN           50

#define AT_PDPCID_MIN 1
#define AT_PDPCID_MAX 7
//#define AT_MAXALLOWEDACTPDP 3
#define AT_MAXALLOWEDACTPDP 8

#define AT_PDPCID_ERROR 0xFF
#define AT_PDPCID_NDEF 0
#define AT_PDP_ACTED    1
#define AT_PDP_DEACTED   0

// [NEW] by yy at 2008-04-21 begin
#define AT_GPRS_DEA    CFW_GPRS_DEACTIVED
#define AT_GPRS_ACT    CFW_GPRS_ACTIVED

#define AT_GPRS_ATT    1
#define AT_GPRS_DAT    0

#define AT_GPRS_ACTIVEDELAY     45
#define AT_GPRS_ATTDELAY     45 // ad by wulc

#define AT_GPRSUTI_BEG        200
#define AT_GPRSUTI_ATT_OFF 0
#define AT_GPRSUTI_ACT_OFF 5
#define AT_GPRSUTI_DEA_OFF 15
#define AT_GPRSUTI_TCPIP_OFF 25
// [NEW] by yy at 2008-04-21 end

#define AT_GPRS_ATT_NOTREG       0
#define AT_GPRS_ATT_HOME_OK     1
#define AT_GPRS_ATT_TRYING        2
#define AT_GPRS_ATT_DNY              3
#define AT_GPRS_ATT_UNKNOWN    4
#define AT_GPRS_ATT_ROAM_OK     5

#define CLASS_TYPE_B 0
#define CLASS_TYPE_CC 1

typedef struct _AT_Gprs_CidInfo
{
	UINT8 uCid;
	UINT8 nDLCI;
	UINT8 uStateStr[15];
	UINT8 uState;

	// UINT8   uAutoRspState;
	UINT8 nPdpType;
	UINT8 nDComp;
	UINT8 nHComp;
	UINT8 pApn[AT_GPRS_APN_MAX_LEN];
	UINT8 pPdpAddr[AT_GPRS_PDPADDR_MAX_LEN];
	UINT8 nApnSize;
	UINT8 nPdpAddrSize;

	// [[ yy [add]  for TCPIP 2008-5-19
	UINT8 uaUsername[AT_GPRS_USR_MAX_LEN];
	UINT8 nUsernameSize;
	UINT8 uaPassword[AT_GPRS_PAS_MAX_LEN];
	UINT8 nPasswordSize;

	// ]] yy [add] for TCPIP 2008-5-19
} AT_Gprs_CidInfo;

/*needed for TCPIP*/
extern UINT8 g_uATTcpipCid[];
extern UINT8 g_uATTcpipActPhase[];
extern UINT8 g_uATTcpipState[];

#ifdef AT_DUAL_SIM
VOID AT_GPRS_Result_OK(UINT32 uReturnValue,
                       UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize, UINT8 nDLCI, UINT8 nSim);
VOID AT_GPRS_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI, UINT8 nSim);
#else
VOID AT_GPRS_Result_OK(UINT32 uReturnValue,
                       UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize, UINT8 nDLCI);
VOID AT_GPRS_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI);
#endif

VOID AT_GPRS_AsyncEventProcess(COS_EVENT *pEvent);
VOID AT_GPRS_CmdFunc_CGDCONT(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGQREQ(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGQMIN(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGATT(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGACT(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGPADDR(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGDATA(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGAUTO(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGANS(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGCLASS(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGEREP(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGREG(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGSMS(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CRC(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGCID(AT_CMD_PARA *pParam);
VOID AT_GPRS_CmdFunc_CGSEND(AT_CMD_PARA *pParam);

VOID AT_GPRS_Att_Rsp(CFW_EVENT *pEvent);
VOID AT_GPRS_Act_Rsp(CFW_EVENT *pCfwEv);
INT32 AT_GPRS_IPAddrAnalyzer(UINT8 *pPdpAddr, UINT8 uSize);

UINT8 AT_Get_ClassType();
VOID AT_Set_ClassType(UINT8 Class);

#endif
#endif
