/*********************************************************
 *
 * File Name
 *        at_cmd_gprs.c
 * Author
 *         Caoxh
 * Date
 *         2008/03/18
 * Descriptions:
 *        Commands specific to MTs supporting the Packet Domain.
 *
 *********************************************************/
#ifdef CFW_GPRS_SUPPORT
#include "stdio.h"
#include "cfw.h"
#include "at_common.h"
#include "at_sa.h"  // caoxh[+]2008-04-19
#include "at_module.h"
#include "at_cmd_gprs.h"
//#include "at_cfg.h"
#include "at_cmd_tcpip.h"
#include "at_cmd_sim.h"

#ifdef AT_FTP_SUPPORT
#ifndef AT_FTP_UPDATE
extern UINT32 AT_FTP_CxtAct(UINT8 *pCid, CFW_SIM_ID nSim);
UINT8 gATFTPState =0;// 0  idle ; 1 att ; 2 act ; 3 connect ;
UINT8 gATFTPUti =0;
#endif
#endif
#define AT_MAX_PPP_ID                   8

#define MAX_DLC_NUM 10
#define AT_TCPIP_CONNECTDELAY     150

#define AT_TCPIP_STATE_IPINITIAL      0
#define AT_TCPIP_STATE_IPSTART        1
#define AT_TCPIP_STATE_IPCONFIG      2
#define AT_TCPIP_STATE_IND               3
#define AT_TCPIP_STATE_GPRSACT       4
#define AT_TCPIP_STATE_IPSTATUS      5
#define AT_TCPIP_STATE_CONNECTING 6
#define AT_TCPIP_STATE_CLOSE            7
#define AT_TCPIP_STATE_CONNECTOK   8
#define AT_TCPIP_STATE_SOCKETOK   9

#define AT_TCPIP_DEFAULTAPN "CMNET"
#define AT_TCPIP_STATE_TURE             1
#define AT_TCPIP_STATE_FAULSE         0


#define AT_BACKSIMID(a)





VOID at_PppEndProcessMux(UINT8 nDLCI);
extern UINT8 ppp_alloc_entity(UINT8 simid, UINT8 cid, UINT8 muxid);
extern void ppp_InitPPPVarsByIdx(UINT8 idx);
UINT32 AT_CFW_GprsAct(UINT8 nState, UINT8 nCid, UINT16 nUTI, CFW_SIM_ID nSimID)
{
#if !defined(AT_NO_GPRS)&&defined(CFW_PPP_SUPPORT)
    UINT8 idx = 0xFF;
    UINT32 ret = 0;
    if (nState)
    {
	idx = ppp_alloc_entity(nSimID, nCid, nUTI);
	if (idx >= AT_MAX_PPP_ID)
	{
	    AT_TC(g_sw_GPRS, "no enough ppp entity!!! %d", nCid);
	    return  ERR_CME_MEMORY_FULL ;
	}
    }

    ret =  CFW_GprsAct(nState, nCid, nUTI, nSimID);
    if((0x00 != ret) && (0xFF != idx))
    {
	ppp_InitPPPVarsByIdx(idx);
    }
    return ret;
#else
    return 0;
#endif
}
struct GPRS_Act_Wait_Att_Rsp_Info
{
    UINT8 wait_state;
    UINT8 act_state;
    UINT8 act_count;
    UINT8 cid[AT_PDPCID_MAX + 1];
    UINT8 nSim;
    UINT8 nDLCI;
};

static struct GPRS_Act_Wait_Att_Rsp_Info g_uGPRS_Act_Wait_Att_Rsp_Info;

// gprs related
static UINT8 gATCurrentu8nURCAuto =3; //gAtCurrentSetting.g_gprs_auto


// Number of cids waiting for response from network for PDP activation
//UINT8 g_uAtWaitActRsp      = 0;
UINT8 g_uAtWaitActRsp[MAX_DLC_NUM]       = {0,};
UINT8 g_Wait_AttRsp_in_Act = 0; // 1-waiting,0-response, 0xff err

extern UINT8 g_uAtURCFmt;

// Attach State
UINT8 g_uAttState = CFW_GPRS_DETACHED;

// Attach State
UINT8 g_uAtGprsAttState = 1;  // +CGATT: <state>
UINT8 g_uAtGprsRegMode  = 0; // +CGREG: <n>

UINT8 g_uAtCgreg = 0; // +CGREG: <n>

UINT8 g_uAtGprsEnterDataMode                 = 0;
UINT8 g_uAtGprsEnterDataModeMux[MAX_DLC_NUM] = { 0 };

UINT8 g_uAtGprsCidNum   = 0;  // yy [add] 2008-6-4 for bug ID 8678
UINT8 g_uATGprsCGEVFlag = 0;  // for control auto report +CGEV to TE

#define AT_MUXSOCKET_NUM                            8

UINT8 g_uATTcpipActPhase[AT_MUXSOCKET_NUM]; // used for CIPSTART, CIICR, C: 0, GPRS; 1, att; 2, act+connect; 3; connect only 4: act only 5: disconnect 6:deactive 7:deactive+disconnect
UINT8 g_uATTcpipCid[AT_MUXSOCKET_NUM];  // cid used for tcp/ip activation
UINT8 g_uATTcpipState[AT_MUXSOCKET_NUM];  // TCP/IP atate: IP INITIAL, IP START, IP CONFIG ... ....


typedef enum
{
    AUTO_RSP_STU_OFF_PDONLY,
    AUTO_RSP_STU_ON_PDONLY,
    AUTO_RSP_STU_MOD_CAP_PDONLY,
    AUTO_RSP_STU_MOD_CAP_PD_CS,
    AUTO_RSP_STATUS_MAX,
} AT_GPRS_AUTO_RSP;

//
// Set the return condition.
//
#define GPRSRETURN(c,r) \
    if ( c ) \
return r;
#ifdef AT_DUAL_SIM

AT_Gprs_CidInfo g_staAtGprsCidInfo_e[4][AT_PDPCID_MAX + 1] = { {{1,},}, };

#else
AT_Gprs_CidInfo g_staAtGprsCidInfo[AT_PDPCID_MAX + 1] = { {1,}, };

#endif
//AT_Gprs_CidInfo g_staAtGprsCidInfo[AT_PDPCID_MAX + 1] = { {0,}, };

extern UINT8 at_GprsGetMatchedPdpCid(CFW_GPRS_PDPCONT_INFO *pPdpInfo);
extern UINT32 at_GprsGetCtxDefStatus(UINT8 cid);

UINT8 DlciGetCid(UINT8 nDLCI)
{
    AT_TC(g_sw_GPRS, "%s, nDLCI = %d,", __func__, nDLCI);
    int i = AT_PDPCID_MIN;
#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(nDLCI);
    AT_Gprs_CidInfo  *g_staAtGprsCidInfo = g_staAtGprsCidInfo_e[nSim];
#endif
    for (i = AT_PDPCID_MIN; i <= AT_PDPCID_MAX; i++)
    {
	#if (0)
	if (bMuxActiveStatus)
	{
	    if (g_staAtGprsCidInfo[i].nDLCI == nDLCI)
	    {
		AT_TC(g_sw_GPRS, "%s, nDLCI = %d,cid=%d", __func__, nDLCI, g_staAtGprsCidInfo[i].uCid);
		return g_staAtGprsCidInfo[i].uCid;
	    }
	}
	else

	#else /*!0*/
	#endif /*0*/


        {
            if (g_staAtGprsCidInfo[i].uState == 1)
            {
                return g_staAtGprsCidInfo[i].uCid;
            }
        }
    }
    return 0;
}
#ifdef AT_DUAL_SIM

#else
UINT8 Cid_GetDLCI(UINT8 uCid)
{
    AT_TC(g_sw_GPRS, "%s, cid= %d,", __func__, uCid);
    int i = AT_PDPCID_MIN;

    for (i = AT_PDPCID_MIN; i <= AT_PDPCID_MAX; i++)
    {
        if (g_staAtGprsCidInfo[i].uCid == uCid)
        {
            AT_TC(g_sw_GPRS, "%s, cid = %d,nDLCI=%d", __func__, g_staAtGprsCidInfo[i].uCid, g_staAtGprsCidInfo[i].nDLCI);
            return g_staAtGprsCidInfo[i].nDLCI;
        }
    }
    return 0;
}
#endif
UINT8 AT_GprsGetPdpAutoStatus(VOID)
{
    return gATCurrentu8nURCAuto;
}

UINT8 AT_RING_GetURCFormat(VOID)
{
    return g_uAtURCFmt;
}

// ---- ------------temp area begin --------------
// [[ yy [del] 2008-7-1 for CSW update
#if 0
UINT32 CFW_GprsGetMinQos(UINT8 nCid, CFW_GPRS_QOS *pQos);

UINT32 CFW_GprsSetMinQos(UINT8 nCid, CFW_GPRS_QOS *pQos);
#endif
// [[ yy [del] 2008-7-1 for CSW update

UINT32 CFW_GprsGetSmsSeviceMode(UINT8 *pnService);

UINT32 CFW_GprsSetSmsSeviceMode(UINT8 nService);

VOID AT_GPRS_AsyncEventProcess(COS_EVENT *pEvent)
{
    CFW_EVENT CfwEv;

    CFW_GPRS_PDPCONT_INFO *pPdpInfo;

    INT32 iResult;

    UINT8 uUIT;
    UINT8 nCid;
    UINT8 nS0Staus;
    TCHAR buffer[100] = { 0 };

#ifdef AT_DUAL_SIM
    UINT8 nSim;
#endif
    AT_CosEvent2CfwEvent(pEvent, &CfwEv);
#ifdef AT_DUAL_SIM
    nSim = CfwEv.nFlag;
#endif

    switch (CfwEv.nEventId)
    {

    case EV_CFW_GPRS_CXT_ACTIVE_IND:

        if (0xF0 == CfwEv.nType)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, CfwEv.nUTI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, CfwEv.nUTI);
#endif
            return;
        }

        pPdpInfo = (CFW_GPRS_PDPCONT_INFO *)(CfwEv.nParam1);

        // Get matching pdp contex.
        nCid = at_GprsGetMatchedPdpCid(pPdpInfo);

        AT_TC(g_sw_GPRS, "KEN :: the mathing cid = %d", nCid);

        if (nCid == AT_PDPCID_ERROR)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, CfwEv.nUTI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, CfwEv.nUTI);
#endif
            return;
        }

        if (AUTO_RSP_STU_OFF_PDONLY == gATCurrentu8nURCAuto)
        {
            SUL_StrPrint(buffer, "A activae request of cid=<%d> has araising\n Please type AT+CGANS=1 accept...\n", nCid);
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_OK, 0, buffer, AT_StrLen(buffer), CfwEv.nUTI, nSim);
#else
            AT_GPRS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_OK, 0, buffer, AT_StrLen(buffer), CfwEv.nUTI);
#endif

        }
        else
        {
#if 0
            iResult = AT_GetFreeUTI(CFW_GPRS_SRV_ID, &uUIT);

            if (ERR_SUCCESS != iResult)
            {
                AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, CfwEv.nUTI);
                return;
            }

#endif
            nS0Staus = AT_GC_CfgGetS0Value();

            if (AUTO_RSP_STU_ON_PDONLY == gATCurrentu8nURCAuto ||
                    (nS0Staus > 0 &&
                     (AUTO_RSP_STU_MOD_CAP_PD_CS == gATCurrentu8nURCAuto || AUTO_RSP_STU_MOD_CAP_PDONLY == gATCurrentu8nURCAuto)))
            {
                uUIT = 200 + 6 + nCid;
#ifdef AT_DUAL_SIM

                iResult = AT_CFW_GprsAct(AT_GPRS_ACT, nCid, CfwEv.nUTI, nSim);
#else
                iResult = AT_CFW_GprsAct(AT_GPRS_ACT, nCid, CfwEv.nUTI);

#endif

                AT_TC(g_sw_GPRS, "KEN :: AUTO_RSP_STU_ON_PDONLY cid = %d, AT_CFW_GprsAct result = 0X%8x", nCid, iResult);

                if (ERR_SUCCESS != iResult)
                {
#ifdef AT_DUAL_SIM
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, CfwEv.nUTI, nSim);
#else
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, CfwEv.nUTI);
#endif
                    return;
                }

                if (g_uAtWaitActRsp[CfwEv.nUTI] > 0)
                {
                    g_uAtWaitActRsp[CfwEv.nUTI]--;
                }

                AT_TC(g_sw_GPRS, "KEN :: Asyn g_uAtWaitActRsp = %d", g_uAtWaitActRsp[CfwEv.nUTI]);
            }
        }

        return;

    case EV_CFW_GPRS_ATT_RSP:
        AT_GPRS_Att_Rsp(&CfwEv);
        return;

    case EV_CFW_GPRS_CXT_DEACTIVE_IND:
        if (g_uATGprsCGEVFlag == 1)
        {
            UINT8 nResp[50] = {0x00,};
            AT_Sprintf(nResp, "+CGEV: NW DEACT  \"IP\", ,%d", CfwEv.nParam1);
            // AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, "+CGEV: ME DETACH ", AT_StrLen("+CGEV: ME DETACH"),
            if (g_uAtWaitActRsp[CfwEv.nUTI] > 0)
            {
                g_uAtWaitActRsp[CfwEv.nUTI]--;
            }
            if(g_uAtGprsCidNum)
                g_uAtGprsCidNum--;
            AT_TC(g_sw_GPRS, "We got EV_CFW_GPRS_CXT_DEACTIVE_IND g_uAtGprsCidNum %d", g_uAtGprsCidNum);

            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, nResp, AT_StrLen(nResp), AT_ASYN_GET_DLCI(nSim), nSim);
        }
        return;
    case EV_CFW_GPRS_ACT_RSP:
        AT_GPRS_Act_Rsp(&CfwEv);
        return;
    case EV_CFW_GPRS_MOD_IND:
    {
        CFW_GprsCtxModifyAcc(AT_ASYN_GET_DLCI(nSim), pEvent->nParam1, nSim);

        UINT8 nResp[30] = {0x00,};
        AT_Sprintf(nResp, "+CGDMODIND:%d", pEvent->nParam1);

        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, nResp, AT_StrLen(nResp),
                          AT_ASYN_GET_DLCI(nSim), nSim);

    }
    return;
    case EV_CFW_GPRS_STATUS_IND:
    {
        UINT8 respond[30] = {0x00,};
        AT_Sprintf(respond, "+CGREG: %d", pEvent->nParam1);
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, respond, AT_StrLen(respond), CfwEv.nUTI, nSim);
#else
        AT_GPRS_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, respond, AT_StrLen(respond), CfwEv.nUTI);
#endif
    }
    return;
    default:

        // AT_SS_EVENT_FAIL_RETURN(ppstResult, ERR_AT_CMS_UNKNOWN_ERROR, NULL, 0);
        return;
    }
}

extern stAT_Tcpip_Paras g_stATTcpipParas;

void _DebugOutPut(UINT8 *pData, UINT16 nLen)
{
    AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, pData, nLen, 2, 1);

}
extern INT32 CFW_FTPGetFile(UINT8 *filename,UINT32 offset);
//#define FTP_DATA_PROCESS
//INT32 AT_FTP_GetTheNewestFile(UINT8 *OFileName);
//#define FTP_FILE_NAME_LEN 100

VOID AT_GPRS_Act_Rsp(CFW_EVENT *pCfwEv)
{
    INT32 iResult;

#ifdef AT_DUAL_SIM
    UINT8 nSim = pCfwEv->nFlag;
#endif

    if (g_uAtWaitActRsp[pCfwEv->nUTI] > 0)
    {
        g_uAtWaitActRsp[pCfwEv->nUTI]--;
    }

    if ((pCfwEv->nType != CFW_GPRS_ACTIVED) && (pCfwEv->nType != CFW_GPRS_DEACTIVED))
    {
        g_uATTcpipActPhase[pCfwEv->nUTI] = 0;
        AT_TC(g_sw_GPRS, "<cid> %d, active/deactive operation failed: %d", pCfwEv->nParam2, pCfwEv->nParam1);
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pCfwEv->nUTI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pCfwEv->nUTI);
#endif
        return;
    }
    else
    {
        if (CFW_GPRS_ACTIVED == pCfwEv->nType)
        {
            if(g_uAtGprsCidNum < AT_PDPCID_MAX)
                g_uAtGprsCidNum++;
            AT_TC(g_sw_GPRS, "<cid> %d, active operation success", pCfwEv->nParam1);
        }
        else
        {
            if(g_uAtGprsCidNum)
                g_uAtGprsCidNum--;
            AT_TC(g_sw_GPRS, "<cid> %d, deactive operation success", pCfwEv->nParam1);

        }


    }
#ifdef AT_FTP_SUPPORT
#ifndef AT_FTP_UPDATE
    AT_TC(g_sw_GPRS, "<cid> %d,gATFTPState:%d", pCfwEv->nParam1,gATFTPState);
    if ((2 == (gATFTPState&0x0f))&&(pCfwEv->nParam1 == (UINT32)((gATFTPState>>4)&0x0f)))
    {
        CFW_FTPInit();
        UINT8 *pFTP = "121.15.154.158";
        //CFW_FTPGetFile("lixp/1.log", pFTP, 21, "public", "Rda!#@");
        //CFW_FTPGetFile("lixp/1.log");
        CFW_FTPLogin(pFTP, 21,  "public", "Rda!#@");
        UINT8 uRegStatus[40];
        SUL_ZeroMemory8(uRegStatus, 40);

        SUL_StrPrint(uRegStatus, "Connecting FTP %s ......\n", pFTP);
        AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, uRegStatus, AT_StrLen(uRegStatus), pCfwEv->nUTI, nSim);
        
        return ;
    }
#endif
#endif
    AT_TC(g_sw_GPRS, " g_uATTcpipActPhase is %d", g_uATTcpipActPhase[pCfwEv->nUTI]);

    // [[ yy [mod]  2008-5-16 for TCPIP
    if (0 == g_uATTcpipActPhase[pCfwEv->nUTI])
    {

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pCfwEv->nUTI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pCfwEv->nUTI);
#endif
#ifdef AT_FTP_SUPPORT
#ifdef AT_FTP_UPDATE


        CFW_FTPInit();
        UINT8 *pFTP = "121.15.154.158";
        //CFW_FTPGetFile("lixp/1.log", pFTP, 21, "public", "Rda!#@");
        //CFW_FTPGetFile("lixp/1.log");
        CFW_FTPLogin(pFTP, 21,  "public", "Rda!#@");
        UINT8 uRegStatus[40];
        SUL_ZeroMemory8(uRegStatus, 40);

        SUL_StrPrint(uRegStatus, "Connecting FTP %s ......\n", pFTP);
        AT_NW_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, uRegStatus, AT_StrLen(uRegStatus), pCfwEv->nUTI, nSim);
#endif
#endif
        return;
    }
    else
    {
        // connection caused by TCPIP
        if (2 == g_uATTcpipActPhase[pCfwEv->nUTI])
        {
//            iResult = AT_TCPIP_Connect(pCfwEv->nUTI);
            if (iResult != ERR_SUCCESS)
            {
                g_uATTcpipActPhase[pCfwEv->nUTI] = 0;
                AT_TC(g_sw_GPRS, "AT_GPRS_Act_Rsp() TCPIP connect failed: %d", iResult);
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pCfwEv->nUTI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pCfwEv->nUTI);
#endif
                return;
            }
            g_uATTcpipActPhase[pCfwEv->nUTI] = 3;
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, AT_TCPIP_CONNECTDELAY, NULL, 0, pCfwEv->nUTI, nSim);
#else
            AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, AT_TCPIP_CONNECTDELAY, NULL, 0, pCfwEv->nUTI);
#endif
            AT_TC(g_sw_TCPIP, "AT_GPRS_Att_Rsp(), abc cccccc, pCfwEv->nUTI = %d", pCfwEv->nUTI);
            return;
        }
        else if (4 == g_uATTcpipActPhase[pCfwEv->nUTI])
        {
            g_uATTcpipActPhase[pCfwEv->nUTI] = 0;
            g_uATTcpipState[pCfwEv->nUTI]    = AT_TCPIP_STATE_GPRSACT;
            if(pCfwEv->nType == CFW_GPRS_ACTIVED)
            {

#ifdef AT_DUAL_SIM
                AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pCfwEv->nUTI, nSim);
#else
                AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pCfwEv->nUTI);
#endif
            }
            // ind event
            if (pCfwEv->nType == CFW_GPRS_DEACTIVED)
            {
                if (g_uATGprsCGEVFlag == 1)
                {
                    //    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, "+CGEV: ME DETACH", AT_StrLen("+CGEV: ME DETACH"),
                    //             AT_ASYN_GET_DLCI(nSim), nSim);
                }
            }
            return;
        }
        else if (6 == g_uATTcpipActPhase[pCfwEv->nUTI])
        {
            g_uATTcpipActPhase[pCfwEv->nUTI] = 0;
            g_uATTcpipState[pCfwEv->nUTI]    = AT_TCPIP_STATE_IPINITIAL;
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pCfwEv->nUTI, nSim);
#else
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pCfwEv->nUTI);
#endif
        }
    }

    // ]] yy [mod]  2008-5-16 for TCPIP
}





// This function to process the AT+CGDCONT command. include set,read and test command.
//
// Set command
// +CGDCONT=[<cid> [,<PDP_type> [,<APN> [,<PDP_addr> [,<d_comp> [,<h_comp>]]]]]]
// Possible response(s)
// OK
// ERROR
//
// Read command
// +CGDCONT?
// Possible response(s)
// +CGDCONT: <cid>, <PDP_type>, <APN>,<PDP_addr>, <d_comp>, <h_comp>
// [<CR><LF>+CGDCONT: <cid>, <PDP_type>, <APN>,<PDP_addr>, <d_comp>, <h_comp>
// [...]]
//
// Test command
// +CGDCONT=?
// Possible response(s)
// +CGDCONT: (range of supported <cid>s), <PDP_type>,,,(list of supported <d_comp>s),
// (list of supported <h_comp>s)[<CR><LF>+CGDCONT: (range of supported <cid>s), <PDP_type>,,,
// (list of supported <d_comp>s),
// (list of supported <h_comp>s)


VOID AT_GPRS_CmdFunc_CGDCONT(AT_CMD_PARA *pParam)
{
    UINT8 *pResp = NULL;
    INT32 iResult;
    UINT8 uCid   = 0;
    UINT8 uDComp = 0;
    UINT8 uHComp = 0;
    UINT8 uSize;
    UINT8 *pPdpType   = NULL;
    UINT8 *pApn       = NULL;
    UINT8 *userName       = NULL;
    UINT8 *passWord       = NULL;
    UINT8 *pPdpAddr   = NULL;
    UINT8 uParamCount = 0;
    UINT32 uErrCode   = ERR_SUCCESS;
    UINT8 uIndex      = 0;
    UINT8 uState      = 0;
    CFW_GPRS_PDPCONT_INFO sPdpCont;
    CFW_GPRS_QOS stTmpQos     = { 0, 0, 0, 0, 0 };
    CFW_GPRS_QOS stTmpNullQos = { 3, 4, 3, 4, 16 };


#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
    AT_Gprs_CidInfo  *g_staAtGprsCidInfo = g_staAtGprsCidInfo_e[nSim];
#endif
    // [[ yy [add] 2008-5-19 for bug ID 8475
    AT_Gprs_CidInfo stCidTemp;

    AT_MemSet(&stCidTemp, 0, SIZEOF(AT_Gprs_CidInfo));

    // ]] yy [add] 2008-5-19 for bug ID 8475

    AT_MemSet(&sPdpCont, 0, SIZEOF(CFW_GPRS_PDPCONT_INFO));

    // input parameter check.

    if (NULL == pParam)
    {
        uErrCode = ERR_AT_CME_PARAM_INVALID;
        AT_TC(g_sw_GPRS, "AT+CGDCONT:NULL == pParam");
        goto _func_fail;
    }

#if 0
    pPdpType = AT_MALLOC(AT_GPRS_PDPTYPE_MAX_LEN + 1);

    pApn = AT_MALLOC(AT_GPRS_APN_MAX_LEN + 1);

    pPdpAddr = AT_MALLOC(AT_GPRS_PDPADDR_MAX_LEN + 1);

    AT_MemSet(pPdpType, 0, AT_GPRS_PDPTYPE_MAX_LEN + 1);

    AT_MemSet(pApn, 0, AT_GPRS_APN_MAX_LEN + 1);

    AT_MemSet(pPdpAddr, 0, AT_GPRS_PDPADDR_MAX_LEN + 1);

    iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);

    uSize = SIZEOF(pPdpType);

    uSize = 1;

    iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uCid, &uSize);

    uSize = AT_GPRS_PDPTYPE_MAX_LEN + 1;

    iResult = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, pPdpType, &uSize);

    AT_TC(g_sw_GPRS, "bbc: %d, rlt11=%d,%s", uCid, iResult, pPdpType);

    uSize = AT_GPRS_APN_MAX_LEN + 1;

    iResult = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_STRING, pApn, &uSize);

    uSize = AT_GPRS_PDPADDR_MAX_LEN + 1;

    iResult = AT_Util_GetParaWithRule(pParam->pPara, 3, AT_UTIL_PARA_TYPE_STRING, pPdpAddr, &uSize);

    AT_TC(g_sw_GPRS, "bbc: %s, %s, %s", pPdpType, pApn, pPdpAddr);

    return;

#endif

    // Process the command. include icommand parameter checking,csw api calling,and responsing...
    // Set command.
    if (AT_CMD_SET == pParam->iType)
    {

        // Get the count of parameters.
        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);

        if (ERR_SUCCESS != iResult)
        {
            AT_TC(g_sw_GPRS, "AT+CGDCONT:Get the parameter cout failed.err code = %d.", iResult);
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        // This command parameter count  largest or equat 1.
        if (0 == uParamCount || 8 < uParamCount)
        {
            AT_TC(g_sw_GPRS, "AT+CGDCONT:Parameter count error. count  = %d.", uParamCount);
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        // Get the parameter list.

        // 1#
        // Get cir
        if (1 <= uParamCount)
        {
            uSize   = 1;
            uIndex  = 0;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &uCid, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;

                goto _func_fail;
            }

            if (uCid < AT_PDPCID_MIN || uCid > AT_PDPCID_MAX)
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;

                goto _func_fail;
            }
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM

            CFW_GprsSetReqQos(uCid, &stTmpNullQos, nSim);
#else
            CFW_GprsSetReqQos(uCid, &stTmpNullQos);
#endif
#endif


            // This case undefine the spicafied cid
            if (1 == uParamCount)
            {
                // [[ yy [add]  2008-5-20 for bug ID 8488
                if (0 == g_staAtGprsCidInfo[uCid].uCid)
                {
                    uErrCode = ERR_AT_CME_PARAM_INVALID;
                    goto _func_fail;
                }
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM

                iResult = CFW_GprsGetReqQos(uCid, &stTmpQos, nSim);
#else
                iResult = CFW_GprsGetReqQos(uCid, &stTmpQos);

#endif
#endif
                if (iResult != ERR_SUCCESS)
                {
                    uErrCode = ERR_AT_CME_EXE_FAIL;
                    goto _func_fail;
                }
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM

                iResult = CFW_GprsSetReqQos(uCid, &stTmpNullQos, nSim);
#else
                iResult = CFW_GprsSetReqQos(uCid, &stTmpNullQos);

#endif
#endif
                if (iResult != ERR_SUCCESS)
                {
                    uErrCode = ERR_AT_CME_EXE_FAIL;
                    goto _func_fail;
                }
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM

                iResult = CFW_GprsSetPdpCxt(uCid, &sPdpCont, nSim);
#else
                iResult = CFW_GprsSetPdpCxt(uCid, &sPdpCont);

#endif
#endif
                if (iResult != ERR_SUCCESS)
                {
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM
                    iResult = CFW_GprsSetReqQos(uCid, &stTmpQos, nSim);
#else
                    iResult = CFW_GprsSetReqQos(uCid, &stTmpQos);
#endif
#endif
                    uErrCode = ERR_AT_CME_EXE_FAIL;
                    goto _func_fail;
                }

                g_staAtGprsCidInfo[uCid].uCid  = 0;
                g_staAtGprsCidInfo[uCid].nDLCI = 0;

                // ]] yy [add] 2008-5-20 for bug ID 8488
                goto _func_success;
            }

#if 0
            else
            {
                if (g_staAtGprsCidInfo[uCid].uCid > 0)
                {
                    if (NULL == pApn)
                    {
                        pApn = AT_MALLOC(AT_GPRS_APN_MAX_LEN + 1);
                    }

                    if (NULL == pPdpAddr)
                    {
                        pPdpAddr = AT_MALLOC(AT_GPRS_PDPADDR_MAX_LEN + 1);
                    }

                    sPdpCont.nPdpType = g_staAtGprsCidInfo[uCid].nPdpType;

                    sPdpCont.nDComp       = g_staAtGprsCidInfo[uCid].nDComp;
                    sPdpCont.nHComp       = g_staAtGprsCidInfo[uCid].nHComp;
                    sPdpCont.nApnSize     = g_staAtGprsCidInfo[uCid].nApnSize;
                    sPdpCont.nPdpAddrSize = g_staAtGprsCidInfo[uCid].nPdpAddrSize;
                    AT_StrCpy(sPdpCont.pPdpAddr, g_staAtGprsCidInfo[uCid].pPdpAddr);
                    AT_StrCpy(sPdpCont.pApn, g_staAtGprsCidInfo[uCid].pApn);
                }
                else
                {

                }
            }

#endif
        }

        // 2#
        // Get PDP_type

        if (2 <= uParamCount)
        {
            uIndex++;

            if (NULL == pPdpType)
            {
                pPdpType = AT_MALLOC(AT_GPRS_APN_MAX_LEN + 1);
            }

            if (NULL == pPdpType)
            {
                uErrCode = ERR_AT_CME_NO_MEMORY;
                goto _func_fail;
            }

            AT_MemSet(pPdpType, 0, AT_GPRS_APN_MAX_LEN + 1);

            uSize = AT_GPRS_PDPTYPE_MAX_LEN;

            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, pPdpType, &uSize);

            // [[ yy [mod] 2008-5-13 for CSW update

            if ((AT_MemCmp(pPdpType, "IP", 2)) && (AT_MemCmp(pPdpType, "IPV6", 4)) && (AT_MemCmp(pPdpType, "PPP", 3)))
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            // ]] yy [mod] 2008-5-13 for CSW update

            if (ERR_SUCCESS != iResult || uSize < 1)
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

#if 0
            if (AT_MemCmp("X.25", pPdpType, SIZEOF("X.25")) == 0)
            {
                sPdpCont.nPdpType = CFW_GPRS_PDP_TYPE_X25;
            }

#endif
            else if (AT_MemCmp("IP", pPdpType, SIZEOF("IP")) == 0)
            {
                sPdpCont.nPdpType = CFW_GPRS_PDP_TYPE_IP;
            }
            else if (AT_MemCmp("IPV6", pPdpType, SIZEOF("IPV6")) == 0)
            {
                sPdpCont.nPdpType = CFW_GPRS_PDP_TYPE_IPV6;
            }

#if 0
            else if (AT_MemCmp("OSPIH", pPdpType, SIZEOF("OSPIH")) == 0)
            {
                sPdpCont.nPdpType = CFW_GPRS_PDP_TYPE_OSPIH;
            }

#endif
            else if (AT_MemCmp("PPP", pPdpType, SIZEOF("PPP")) == 0)
            {
                sPdpCont.nPdpType = CFW_GPRS_PDP_TYPE_PPP;
            }
            else
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }
        }

        // 3#
        // Get APN
        if (3 <= uParamCount)
        {
            uIndex++;

            if (NULL == pApn)
            {
                pApn = AT_MALLOC(AT_GPRS_APN_MAX_LEN + 1);
            }

            if (NULL == pApn)
            {
                uErrCode = ERR_AT_CME_NO_MEMORY;
                goto _func_fail;

            }

            uSize = AT_GPRS_APN_MAX_LEN;

            AT_MemSet(pApn, 0, AT_GPRS_APN_MAX_LEN + 1);
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, pApn, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            if (0 != uSize)
            {
                sPdpCont.pApn     = pApn;
                sPdpCont.nApnSize = uSize;
            }
            else
            {
                sPdpCont.pApn = NULL;
            }
        }

        // 4#
        // Get PDP_addr
        if (4 <= uParamCount)
        {
            uIndex++;

            if (NULL == pPdpAddr)
            {
                pPdpAddr = AT_MALLOC(AT_GPRS_PDPADDR_MAX_LEN + 1);
            }

            if (NULL == pPdpAddr)
            {
                uErrCode = ERR_AT_CME_NO_MEMORY;
                goto _func_fail;

            }

            uSize = AT_GPRS_PDPADDR_MAX_LEN;

            AT_MemSet(pPdpAddr, 0, AT_GPRS_PDPADDR_MAX_LEN + 1);
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, pPdpAddr, &uSize);

            if ((ERR_SUCCESS != iResult) && (ERR_AT_UTIL_CMD_PARA_NULL != iResult)) // add by wulc for IP addr is NULL
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            if (0 != uSize)
            {
                iResult = AT_GPRS_IPAddrAnalyzer(pPdpAddr, uSize);
                AT_TC(g_sw_GPRS, "AT+CGDCONT:AT_GPRS_IPAddrAnalyzer, ret = %d.", iResult);

                if (iResult < 0)
                {
                    //uErrCode = ERR_AT_CME_PARAM_INVALID;
                    // goto _func_fail;
                    sPdpCont.pPdpAddr = NULL;
                    sPdpCont.nPdpAddrSize = 0;
                }
                else
                {

                    sPdpCont.pPdpAddr = NULL;
                    sPdpCont.nPdpAddrSize = 0;
                }
            }
            else
            {
                sPdpCont.pPdpAddr = NULL; // yy [mod] 2008-5-23 for bug ID 8459
                sPdpCont.nPdpAddrSize = 0;
            }
        }

        // 5#
        // Get d_comp
        if (5 <= uParamCount)
        {
            AT_TC(g_sw_GPRS, "AT+CGDCONT:5 <= uParamCount.");

            uSize = 1;
            uIndex++;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &uDComp, &uSize);

            if (ERR_SUCCESS != iResult || uSize < 1)
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            if (CFW_GPRS_PDP_D_COMP_OFF != uDComp &&
                    CFW_GPRS_PDP_D_COMP_ON != uDComp && CFW_GPRS_PDP_D_COMP_V42 != uDComp && CFW_GPRS_PDP_D_COMP_V44 != uDComp)
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            sPdpCont.nDComp = uDComp;
        }

        // 6#
        // Get h_comp
        if (6 <= uParamCount)
        {
            AT_TC(g_sw_GPRS, "AT+CGDCONT:6 <= uParamCount.");

            uSize = 1;
            uIndex++;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &uHComp, &uSize);

            if (ERR_SUCCESS != iResult || uSize < 1)
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            if (CFW_GPRS_PDP_H_COMP_OFF != uHComp &&
                    CFW_GPRS_PDP_H_COMP_ON != uHComp &&
                    CFW_GPRS_PDP_H_COMP_RFC1144 != uHComp &&
                    CFW_GPRS_PDP_H_COMP_RFC2507 != uHComp && CFW_GPRS_PDP_H_COMP_RFC3095 != uHComp)
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            sPdpCont.nHComp = uHComp;
        }
        // 7#
        // Get APN
        if (7 <= uParamCount)
        {
            AT_TC(g_sw_GPRS, "AT+CGDCONT:  7 <= uParamCount.");

            uIndex++;

            if (NULL == userName)
            {
                userName = AT_MALLOC(AT_GPRS_USR_MAX_LEN + 1);
            }

            if (NULL == userName)
            {
                uErrCode = ERR_AT_CME_NO_MEMORY;
                goto _func_fail;

            }

            uSize = AT_GPRS_USR_MAX_LEN;

            AT_MemSet(userName, 0, AT_GPRS_USR_MAX_LEN + 1);
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, userName, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            if (0 != uSize)
            {
                sPdpCont.pApnUser     = userName;
                sPdpCont.nApnUserSize = uSize;
            }
            else
            {
                sPdpCont.pApnUser = NULL;
            }
        }
        // 8#
        // Get APN
        if (8 <= uParamCount)
        {
            AT_TC(g_sw_GPRS, "AT+CGDCONT:8 <= uParamCount.");

            uIndex++;

            if (NULL == passWord)
            {
                passWord = AT_MALLOC(AT_GPRS_PAS_MAX_LEN + 1);
            }

            if (NULL == passWord)
            {
                uErrCode = ERR_AT_CME_NO_MEMORY;
                goto _func_fail;

            }

            uSize = AT_GPRS_PAS_MAX_LEN;

            AT_MemSet(passWord, 0, AT_GPRS_PAS_MAX_LEN + 1);
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, passWord, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            if (0 != uSize)
            {
                sPdpCont.pApnPwd = passWord;
                sPdpCont.nApnPwdSize = uSize;
            }
            else
            {
                sPdpCont.pApnPwd = NULL;
                sPdpCont.nApnPwdSize = 0;
            }
        }

        // [[ yy [add] 2008-5-19 for bug ID 8475
        if (g_staAtGprsCidInfo[uCid].uCid > 0)
        {
            AT_MemCpy(&stCidTemp, &g_staAtGprsCidInfo[uCid], SIZEOF(AT_Gprs_CidInfo));
            g_staAtGprsCidInfo[uCid].uCid         = 0;
            g_staAtGprsCidInfo[uCid].nDLCI        = 0;
            g_staAtGprsCidInfo[uCid].nApnSize     = 0;
            g_staAtGprsCidInfo[uCid].nPdpAddrSize = 0;
            g_staAtGprsCidInfo[uCid].nHComp       = 0;
            g_staAtGprsCidInfo[uCid].nDComp       = 0;
        }

        // ]] yy [add] 2008-5-19 for bug ID 8475

        g_staAtGprsCidInfo[uCid].uCid  = uCid;
        g_staAtGprsCidInfo[uCid].nDLCI = pParam->nDLCI;

        g_staAtGprsCidInfo[uCid].nPdpType = sPdpCont.nPdpType;

        g_staAtGprsCidInfo[uCid].nDComp = sPdpCont.nDComp;

        g_staAtGprsCidInfo[uCid].nHComp = sPdpCont.nHComp;

        if (sPdpCont.nApnSize != 0)
        {
            g_staAtGprsCidInfo[uCid].nApnSize = sPdpCont.nApnSize;
            AT_StrCpy(g_staAtGprsCidInfo[uCid].pApn, sPdpCont.pApn);
        }

        if (sPdpCont.nPdpAddrSize != 0)
        {
            g_staAtGprsCidInfo[uCid].nPdpAddrSize = sPdpCont.nPdpAddrSize;
            AT_StrCpy(g_staAtGprsCidInfo[uCid].pPdpAddr, sPdpCont.pPdpAddr);
        }
        if (sPdpCont.nApnPwdSize != 0)
        {
            g_staAtGprsCidInfo[uCid].nPasswordSize = sPdpCont.nApnPwdSize;
            AT_StrCpy(g_staAtGprsCidInfo[uCid].uaPassword, sPdpCont.pApnPwd);
        }

        if (sPdpCont.nApnUserSize != 0)
        {
            g_staAtGprsCidInfo[uCid].nUsernameSize = sPdpCont.nApnUserSize;
            AT_StrCpy(g_staAtGprsCidInfo[uCid].uaUsername, sPdpCont.pApnUser);
        }

#if 0
        AT_TC(g_sw_GPRS, "params:%s, %s, %s", pPdpType, pApn, pPdpAddr);

        AT_TC(g_sw_GPRS, "uCid: %d", uCid);

        AT_TC(g_sw_GPRS, "nPdpType: %d", sPdpCont.nPdpType);

        AT_TC(g_sw_GPRS, "nDComp: %d", sPdpCont.nDComp);

        AT_TC(g_sw_GPRS, "nHComp: %d", sPdpCont.nHComp);

        AT_TC(g_sw_GPRS, "nApnSize: %d", sPdpCont.nApnSize);

        AT_TC(g_sw_GPRS, "nPdpAddrSize: %d", sPdpCont.nPdpAddrSize);

#endif
#ifndef AT_NO_GPRS

        // Call csw api to set the pdp cxt.
#ifdef AT_DUAL_SIM

        iResult = CFW_GprsSetPdpCxt(uCid, &sPdpCont, nSim);
#else
        iResult = CFW_GprsSetPdpCxt(uCid, &sPdpCont);

#endif
#endif
        if (ERR_SUCCESS != iResult)
        {
            // yy [add] 2008-5-19 for bug ID 8475
            AT_MemCpy(&g_staAtGprsCidInfo[uCid], &stCidTemp, SIZEOF(AT_Gprs_CidInfo));
            uErrCode = ERR_AT_CME_EXE_FAIL;
            goto _func_fail;
        }
        else
        {

            goto _func_success;
        }

    }

    // Read command
    else if (AT_CMD_READ == pParam->iType)
    {
        UINT8 *pTempStr = NULL;

        // pResp

        if (NULL == pResp)
        {
            pResp = AT_MALLOC((AT_GPRS_PDPADDR_MAX_LEN + AT_GPRS_APN_MAX_LEN + AT_GPRS_APN_MAX_LEN + 20) * 2);

            if (NULL == pResp)
            {
                uErrCode = ERR_AT_CME_NO_MEMORY;
                goto _func_fail;

            }
        }

        AT_MemSet(pResp, 0, (AT_GPRS_PDPADDR_MAX_LEN + AT_GPRS_APN_MAX_LEN + AT_GPRS_APN_MAX_LEN + 20) * 2);

        if (NULL == pTempStr)
        {
            pTempStr = AT_MALLOC(AT_GPRS_APN_MAX_LEN + 1);
        }

        if (NULL == pTempStr)
        {
            uErrCode = ERR_AT_CME_NO_MEMORY;
            goto _func_fail;
        }

        for (uCid = AT_PDPCID_MIN; uCid <= AT_PDPCID_MAX; uCid++)
        {
            AT_MemSet(&sPdpCont, 0, SIZEOF(CFW_GPRS_PDPCONT_INFO));
            AT_MemSet(pResp, 0, (AT_GPRS_PDPADDR_MAX_LEN + AT_GPRS_APN_MAX_LEN + AT_GPRS_APN_MAX_LEN + 20) * 2);
            AT_MemSet(pTempStr, 0, AT_GPRS_APN_MAX_LEN);

#ifdef AT_DUAL_SIM

            if ((g_staAtGprsCidInfo[uCid].uCid != 0) && (nSim == AT_SIM_ID(g_staAtGprsCidInfo[uCid].nDLCI)))
#else
            if (g_staAtGprsCidInfo[uCid].uCid != 0)
#endif

            {
#ifdef AT_DUAL_SIM
                CFW_GetGprsActState(g_staAtGprsCidInfo[uCid].uCid, &uState, nSim);
#else
                CFW_GetGprsActState(g_staAtGprsCidInfo[uCid].uCid, &uState);
#endif
                if(AT_GPRS_ACT != uState)
                    continue;

                switch (g_staAtGprsCidInfo[uCid].nPdpType)
                {

                case CFW_GPRS_PDP_TYPE_IP:
                    AT_StrCpy(pTempStr, "\"IP\"");  // yy [mod] 2008-5-19 for bug ID 8458
                    break;

                    /*
                       case CFW_GPRS_PDP_TYPE_IPV6:
                       AT_StrCpy(pTempStr, "\"IPV6\""); // yy [mod] 2008-5-19 for bug ID 8458
                       break;

                       case CFW_GPRS_PDP_TYPE_PPP:
                       AT_StrCpy(pTempStr, "\"PPP\""); // yy [mod] 2008-5-19 for bug ID 8458
                       break;
                       */
                default:
                    pTempStr[0] = 0;  // Should be here
                    break;
                }

                AT_Sprintf(pResp, "+CGDCONT:%d,%s,", g_staAtGprsCidInfo[uCid].uCid, pTempStr);

                if (g_staAtGprsCidInfo[uCid].nApnSize != 0)
                {
                    AT_MemSet(pTempStr, 0, AT_GPRS_APN_MAX_LEN);

                    // yy [mod] 2008-5-19 for bug ID 8458
                    AT_Sprintf(pTempStr, "\"%s\",", g_staAtGprsCidInfo[uCid].pApn);
                    AT_StrCat(pResp, pTempStr);
                }

                // [[ yy [add] for bug ID 8457
                else
                {
                    AT_StrCat(pResp, ",");
                }

                // ]] yy [add] for bug ID 8457

                AT_MemSet(pTempStr, 0, AT_GPRS_APN_MAX_LEN);

                if (g_staAtGprsCidInfo[uCid].nPdpAddrSize != 0)
                {
                    AT_MemSet(pTempStr, 0, AT_GPRS_APN_MAX_LEN);

                    // yy [mod] 2008-5-19 for bug ID 8458
                    AT_Sprintf(pTempStr, "\"%s\",", g_staAtGprsCidInfo[uCid].pPdpAddr);
                    AT_StrCat(pResp, pTempStr);
                }

                // [[ yy [add] for bug ID 8457
                else
                {
                    AT_StrCat(pResp, ",");
                }

                // ]] yy [add] for bug ID 8457

                AT_MemSet(pTempStr, 0, AT_GPRS_APN_MAX_LEN);

                AT_Sprintf(pTempStr, "%d,%d", g_staAtGprsCidInfo[uCid].nDComp, g_staAtGprsCidInfo[uCid].nHComp);

                AT_StrCat(pResp, pTempStr);
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
                AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif
            }
            else
            {
                // The cid of specified is NULL.
                // Do nothing.
            }
        }

        if (NULL == pResp)
        {
            uErrCode = ERR_AT_CME_EXE_FAIL;
            goto _func_fail;
        }
        else
        {
            pResp[0] = 0;
            goto _func_success;
        }
    }

    // Test command.
    else if (AT_CMD_TEST == pParam->iType)
    {
        pResp = AT_MALLOC(128);

        if (NULL == pResp)
        {
            uErrCode = ERR_AT_CME_NO_MEMORY;
            goto _func_fail;

        }
        AT_MemZero(pResp, 128);
        // yy [mod] 2008-5-12 for code reivew
        AT_StrCpy(pResp, "+CGDCONT: (1..7), (IP,IPV6,PPP),(0..3),(0..4)");

        goto _func_success;
    }
    else
    {
        // [[ yy [mod] 2008-6-3 for bug ID
        uErrCode = ERR_AT_CME_OPTION_NOT_SURPORT;
        goto _func_fail;

        // ]] yy [mod] 2008-6-3 for bug ID
    }

_func_success:

#ifdef AT_DUAL_SIM
    if (NULL != pResp)
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
    else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
    if (NULL != pResp)
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
    else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif

    // AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, 20, pParam->nDLCI);

    if (NULL != pApn)
    {
        AT_FREE(pApn);
        pApn = NULL;
    }

    if (NULL != passWord)
    {
        AT_FREE(passWord);
        passWord = NULL;
    }
    if (NULL != userName)
    {
        AT_FREE(userName);
        userName = NULL;
    }
    if (NULL != pPdpType)
    {
        AT_FREE(pPdpType);
        pPdpType = NULL;
    }
    if (NULL != pPdpAddr)
    {
        AT_FREE(pPdpAddr);
        pPdpAddr = NULL;
    }

    if (NULL != pResp)
    {
        AT_FREE(pResp);
        pResp = NULL;
    }

    return;

_func_fail:

#ifdef AT_DUAL_SIM
    AT_GPRS_Result_Err(uErrCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_Err(uErrCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

    if (NULL != pApn)
    {
        AT_FREE(pApn);
        pApn = NULL;
    }
    if (NULL != passWord)
    {
        AT_FREE(passWord);
        passWord = NULL;
    }
    if (NULL != userName)
    {
        AT_FREE(userName);
        userName = NULL;
    }
    if (NULL != pPdpType)
    {
        AT_FREE(pPdpType);
        pPdpType = NULL;
    }
    if (NULL != pPdpAddr)
    {
        AT_FREE(pPdpAddr);
        pPdpAddr = NULL;
    }

    if (NULL != pResp)
    {
        AT_FREE(pResp);
        pResp = NULL;
    }

    return;

}

// This function to process the AT+CGQREQ command. include set,read and test command.
//
// Set command
// +CGQREQ=[<cid> [,<precedence > [,<delay> [,<reliability.> [,<peak> [,<mean>]]]]]]
// Possible response(s)
// OK
// ERROR
//
// Read command
// +CGQREQ?
// Possible response(s)
// +CGQREQ: <cid>, <precedence >, <delay>, <reliability>, <peak>, <mean>
// [<CR><LF>+CGQREQ: <cid>, <precedence >, <delay>, <reliability.>, <peak>, <mean>
// [��]]
//
// Test command
// +CGQREQ=?
// Possible response(s)
// +CGQREQ: <PDP_type>, (list of supported <precedence>s), (list of supported <delay>s),
// (list of supported <reliability>s) , (list of supported <peak>s), (list of supported <mean>s)
// [<CR><LF>+CGQREQ: <PDP_type>, (list of supported <precedence>s), (list of supported
// <delay>s), (list of supported <reliability>s) , (list of supported <peak>s), (list of supported <mean>s)
// [��]]
//
VOID AT_GPRS_CmdFunc_CGQREQ(AT_CMD_PARA *pParam)
{
    INT32 iResult;
    UINT8 *pResp = NULL;
    UINT8 uCid   = 0;
    UINT8 uSize;
    UINT8 uParamCount = 0;
    UINT32 uErrCode   = ERR_SUCCESS;
    UINT8 uIndex      = 0;
    CFW_GPRS_QOS sQos = { 0, 0, 0, 0, 0 };


#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
    AT_Gprs_CidInfo  *g_staAtGprsCidInfo = g_staAtGprsCidInfo_e[nSim];
#endif
    // input parameter check.

    if (NULL == pParam)
    {
        AT_TC(g_sw_GPRS, "AT+CGQREQ:NULL == pParam");
        uErrCode = ERR_AT_CME_PARAM_INVALID;
        goto _func_fail;
    }

    // Process the command. include icommand parameter checking,csw api calling,and responsing...
    // Set command.
    if (AT_CMD_SET == pParam->iType)
    {

        // Get the count of parameters.
        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);

        if (ERR_SUCCESS != iResult)
        {
            AT_TC(g_sw_GPRS, "AT+CGQREQ:NULL == pParam");
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        // This command have 6 parameters.
        if (uParamCount < 1 || uParamCount > 6)
        {
            AT_TC(g_sw_GPRS, "AT+CGQREQ:uParamCount error,uParamCount = %d.", uParamCount);
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        // Get the parameter list.

        // 1#
        // Get cir
        if (uParamCount >= 1)
        {
            uSize   = 1;
            uIndex  = 0;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &uCid, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                AT_TC(g_sw_GPRS, "AT+CGQREQ:Get cir failed,iResult = 0x%x.", iResult);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            // yy [mod] 2008-5-20 for bug ID 8487
            if (uCid < AT_PDPCID_MIN || uCid > AT_PDPCID_MAX || (0 == g_staAtGprsCidInfo[uCid].uCid))
            {
                AT_TC(g_sw_GPRS, "AT+CGQREQ:The param uCid error,uCid = %d.", uCid);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }
        }

        // 2#
        // Get precedence
        if (uParamCount >= 2)
        {
            uSize = 1;
            uIndex++;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &sQos.nPrecedence, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                AT_TC(g_sw_GPRS, "AT+CGQREQ:Get precedence failed,iResult = 0x%x.", iResult);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            // if ignore,set it zero.
            if (0 == uSize)
            {
                sQos.nPrecedence = 0;
            }
            else if (sQos.nPrecedence > 3)
            {
                AT_TC(g_sw_GPRS, "AT+CGQREQ:The param sQos.nPrecedence error,sQos.nPrecedence = %d.", sQos.nPrecedence);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }
        }

        // 3#
        // Get delay
        if (uParamCount >= 3)
        {
            uIndex++;
            uSize   = 1;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &sQos.nDelay, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                AT_TC(g_sw_GPRS, "AT+CGQREQ:Get delay failed,iResult = 0x%x.", iResult);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            // if ignore,set it zero.
            if (0 == uSize)
            {
                sQos.nDelay = 0;
            }
            else if (sQos.nDelay > 4)
            {
                AT_TC(g_sw_GPRS, "AT+CGQREQ:The param sQos.nDelay error,sQos.nDelay = %d.", sQos.nDelay);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }
        }

        // 4#
        // Get reliability
        if (uParamCount >= 4)
        {
            uIndex++;
            uSize   = 1;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &sQos.nReliability, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                AT_TC(g_sw_GPRS, "AT+CGQREQ:Get reliability failed,iResult = 0x%x.", iResult);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            if (0 == uSize)
            {
                sQos.nReliability = 0;
            }
            else if (sQos.nReliability > 5)
            {
                AT_TC(g_sw_GPRS, "AT+CGQREQ:The param sQos.nReliability error,sQos.nReliability = %d.", sQos.nReliability);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }
        }

        // 5#
        // Get peak
        if (uParamCount >= 5)
        {
            uSize = 1;
            uIndex++;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &sQos.nPeak, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                AT_TC(g_sw_GPRS, "AT+CGQREQ:Get peak failed,iResult = 0x%x.", iResult);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            if (0 == uSize)
            {
                sQos.nPeak = 0;
            }
            else if (sQos.nPeak > 9)
            {
                AT_TC(g_sw_GPRS, "AT+CGQREQ:The param sQos.nPeak error,sQos.nPeak = %d.", sQos.nPeak);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

        }

        // 6#
        // Get mean
        if (uParamCount >= 6)
        {
            uSize = 1;
            uIndex++;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &sQos.nMean, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                AT_TC(g_sw_GPRS, "AT+CGQREQ:Get mean failed,iResult = 0x%x.", iResult);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            if (0 == uSize)
            {
                sQos.nMean = 0;
            }
            else if (18 < sQos.nMean && 31 != sQos.nMean)
            {
                AT_TC(g_sw_GPRS, "AT+CGQREQ:The param sQos.nMean error,sQos.nMean = %d.", sQos.nMean);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }
        }
#ifndef AT_NO_GPRS
        // Call csw api to set the Req QOS.
#ifdef AT_DUAL_SIM

        iResult = CFW_GprsSetReqQos(uCid, &sQos, nSim);
#else
        iResult = CFW_GprsSetReqQos(uCid, &sQos);

#endif
#endif
        if (ERR_SUCCESS != iResult)
        {
            AT_TC(g_sw_GPRS, "AT+CGQREQ:CFW_GprsSetReqQos() failed,iResult = 0x%x.", iResult);
            uErrCode = ERR_AT_CME_EXE_FAIL;
            goto _func_fail;
        }
        else
        {
            pResp = AT_MALLOC((AT_GPRS_PDPADDR_MAX_LEN + AT_GPRS_APN_MAX_LEN + AT_GPRS_APN_MAX_LEN + 20) * 2);
            if (NULL == pResp)
            {
                uErrCode = ERR_AT_CME_NO_MEMORY;
                goto _func_fail;

            }
            AT_MemSet(pResp, 0, SIZEOF(pResp));

            // +CGQREQ: <cid>, <precedence >, <delay>, <reliability>, <peak>, <mean>
            AT_Sprintf(pResp, "+CGQREQ:%d,%d,%d,%d,%d,%d",
                       uCid, sQos.nPrecedence, sQos.nDelay, sQos.nReliability, sQos.nPeak, sQos.nMean);
            goto _func_success;
        }

    }

    // Read command
    else if (AT_CMD_READ == pParam->iType)
    {
        for (uCid = AT_PDPCID_MIN; uCid <= AT_PDPCID_MAX; uCid++)
        {
#ifndef AT_NO_GPRS

#ifdef AT_DUAL_SIM
            iResult = CFW_GprsGetReqQos(uCid, &sQos, nSim);
#else
            iResult = CFW_GprsGetReqQos(uCid, &sQos);

#endif
#endif
            if (ERR_SUCCESS == iResult)
            {
                if (NULL == pResp)
                {
                    pResp = AT_MALLOC((AT_GPRS_PDPADDR_MAX_LEN + AT_GPRS_APN_MAX_LEN + AT_GPRS_APN_MAX_LEN + 20) * 2);

                    if (NULL == pResp)
                    {
                        uErrCode = ERR_AT_CME_NO_MEMORY;
                        goto _func_fail;

                    }
                }

                AT_MemSet(pResp, 0, SIZEOF(pResp));

                // +CGQREQ: <cid>, <precedence >, <delay>, <reliability>, <peak>, <mean>
                AT_Sprintf(pResp, "+CGQREQ:%d,%d,%d,%d,%d,%d",
                           uCid, sQos.nPrecedence, sQos.nDelay, sQos.nReliability, sQos.nPeak, sQos.nMean);
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
                AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif
            }
            else
            {
                AT_TC(g_sw_GPRS, "AT+CGQREQ:CFW_GprsGetReqQos() failed,iResult = 0x%x,uCid = %d.", iResult, uCid);

                // The cid of specified is NULL.
                // Do nothing.
            }
        }

        if (NULL == pResp)
        {
            uErrCode = ERR_AT_CME_EXE_FAIL;
            goto _func_fail;
        }
        else
        {
            pResp[0] = 0;
            goto _func_success;
        }
    }

    // Test command.
    else if (AT_CMD_TEST == pParam->iType)
    {
        pResp = AT_MALLOC(128);

        if (NULL == pResp)
        {
            uErrCode = ERR_AT_CME_NO_MEMORY;
            goto _func_fail;

        }

        // [[ yy [mod] 2008-5-13 for bug ID 8472
        AT_MemSet(pResp, 0, 128);

        AT_StrCpy(pResp, "+CGQREQ: IP, (0..3), (0..4), (0..5) , (0..9), (0..18,31)");

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif

        AT_MemSet(pResp, 0, 128);

        AT_StrCpy(pResp, "+CGQREQ: IPV6, (0..3), (0..4), (0..5) , (0..9), (0..18,31)");

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif

        AT_MemSet(pResp, 0, 128);

        AT_StrCpy(pResp, "+CGQREQ: PPP, (0..3), (0..4), (0..5) , (0..9), (0..18,31)");

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif

        AT_FREE(pResp);

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif

        return;

        // ]] yy [mod] 2008-5-13 for bug ID 8472
    }
    else
    {
        // [[ yy [mod] 2008-6-3 for bug ID
        uErrCode = ERR_AT_CME_OPTION_NOT_SURPORT;
        goto _func_fail;

        // ]] yy [mod] 2008-6-3 for bug ID
        return;
    }

_func_success:

    // AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, (UINT16)AT_StrLen(pResp), pParam->nDLCI);
#ifdef AT_DUAL_SIM
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif

    if (NULL != pResp)
    {
        AT_FREE(pResp);
        pResp = NULL;
    }

    return;

_func_fail:

#ifdef AT_DUAL_SIM
    AT_GPRS_Result_Err(uErrCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_Err(uErrCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

    if (NULL != pResp)
    {
        AT_FREE(pResp);
        pResp = NULL;
    }

    return;
}

// This function to process the AT+CGQMIN command. include set,read and test command.
//
// Set command
// +CGQMIN=[<cid> [,<precedence > [,<delay> [,<reliability.> [,<peak> [,<mean>]]]]]]
// Possible response(s)
// OK
// ERROR
//
// Read command
// +CGQMIN?
// Possible response(s)
// +CGQMIN: <cid>, <precedence >, <delay>, <reliability>, <peak>, <mean>
// [<CR><LF>+CGQMIN: <cid>, <precedence >, <delay>, <reliability.>, <peak>, <mean>
// [��]]
//
// Test command
// +CGQMIN=?
// Possible response(s)
// +CGQMIN: <PDP_type>, (list of supported <precedence>s), (list of supported <delay>s),
// (list of supported <reliability>s) , (list of supported <peak>s), (list of supported <mean>s)
// [<CR><LF>+CGQMIN: <PDP_type>, (list of supported <precedence>s), (list of supported <delay>s),
// (list of supported <reliability>s) , (list of supported <peak>s), (list of supported <mean>s)
// [��]]
VOID AT_GPRS_CmdFunc_CGQMIN(AT_CMD_PARA *pParam)
{
    INT32 iResult;
    UINT8 *pResp = NULL;
    UINT8 uCid   = 0;
    UINT8 uSize;
    UINT8 uParamCount = 0;
    UINT32 uErrCode   = ERR_SUCCESS;
    UINT8 uIndex      = 0;
    CFW_GPRS_QOS sQos = { 0, 0, 0, 0, 0 };

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
    // input parameter check.

    if (NULL == pParam)
    {
        AT_TC(g_sw_GPRS, "AT+CGQMIN:NULL == pParam");
        uErrCode = ERR_AT_CME_PARAM_INVALID;
        goto _func_fail;
    }

    // Process the command. include icommand parameter checking,csw api calling,and responsing...
    // Set command.
    if (AT_CMD_SET == pParam->iType)
    {
        if (NULL == pParam->pPara)
        {
            AT_TC(g_sw_GPRS, "AT+CGQMIN:NULL == pParam->pPara");
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        // Get the count of parameters.
        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);

        if (ERR_SUCCESS != iResult)
        {
            AT_TC(g_sw_GPRS, "AT+CGQMIN:AT_Util_GetParaCount() failed,iResult = 0x%x.", iResult);
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        // This command have 6 parameters.
        if (uParamCount < 1 || uParamCount > 6)
        {
            AT_TC(g_sw_GPRS, "AT+CGQMIN:uParamCount error,uParamCount = %d.", uParamCount);
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        // Get the parameter list.
        // 1#
        // Get cir
        if (uParamCount >= 1)
        {
            uSize   = 1;
            uIndex  = 0;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &uCid, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                AT_TC(g_sw_GPRS, "AT+CGQMIN:Get the cir param failed,iResult= 0x%x.", iResult);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            if (uCid < AT_PDPCID_MIN || uCid > AT_PDPCID_MAX)
            {
                AT_TC(g_sw_GPRS, "AT+CGQMIN:The cir param is invalid,cir = %d.", uCid);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }
        }

        // 2#
        // Get precedence
        if (uParamCount >= 2)
        {
            uSize = 1;
            uIndex++;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &sQos.nPrecedence, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                AT_TC(g_sw_GPRS, "AT+CGQMIN:Get the precedence param failed,iResult= 0x%x.", iResult);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            // if ignore,set it zero.
            if (0 == uSize)
            {
                sQos.nPrecedence = 0;
            }
            else if (sQos.nPrecedence > 3)
            {
                AT_TC(g_sw_GPRS, "AT+CGQMIN:The precedence param is invalid,cir = %d.", sQos.nPrecedence);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }
        }

        // 3#
        // Get delay
        if (uParamCount >= 3)
        {
            uIndex++;
            uSize = 1;

            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &sQos.nDelay, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                AT_TC(g_sw_GPRS, "AT+CGQMIN:Get the delay param failed,iResult= 0x%x.", iResult);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            // if ignore,set it zero.
            if (0 == uSize)
            {
                sQos.nDelay = 0;
            }
            else if (sQos.nDelay > 4)
            {
                AT_TC(g_sw_GPRS, "AT+CGQMIN:The delay param is invalid,cir = %d.", sQos.nDelay);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }
        }

        // 4#
        // Get reliability
        if (uParamCount >= 4)
        {
            uIndex++;
            uSize   = 1;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &sQos.nReliability, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                AT_TC(g_sw_GPRS, "AT+CGQMIN:Get the reliability param failed,iResult= 0x%x.", iResult);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            if (0 == uSize)
            {
                sQos.nReliability = 0;
            }
            else if (sQos.nReliability > 5)
            {
                AT_TC(g_sw_GPRS, "AT+CGQMIN:The reliability param is invalid,cir = %d.", sQos.nReliability);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }
        }

        // 5#
        // Get peak
        if (uParamCount >= 5)
        {
            uSize = 1;
            uIndex++;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &sQos.nPeak, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                AT_TC(g_sw_GPRS, "AT+CGQMIN:Get the peak param failed,iResult= 0x%x.", iResult);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            if (0 == uSize)
            {
                sQos.nPeak = 0;
            }
            else if (sQos.nPeak > 9)
            {
                AT_TC(g_sw_GPRS, "AT+CGQMIN:The peak param is invalid,cir = %d.", sQos.nPeak);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

        }

        // 6#
        // Get mean
        if (uParamCount == 6)
        {
            uSize = 1;
            uIndex++;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &sQos.nMean, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                AT_TC(g_sw_GPRS, "AT+CGQMIN:Get the mean param failed,iResult= 0x%x.", iResult);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }

            if (0 == uSize)
            {
                sQos.nMean = 0;
            }
            else if (18 < sQos.nMean && 31 != sQos.nMean)
            {
                AT_TC(g_sw_GPRS, "AT+CGQMIN:The mean param is invalid,cir = %d.", sQos.nMean);
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }
        }
#ifndef AT_NO_GPRS
        // Call csw api to set the Min QOS.
#ifdef AT_DUAL_SIM
        iResult = CFW_GprsSetMinQos(uCid, &sQos, nSim);
#else
        iResult = CFW_GprsSetMinQos(uCid, &sQos);

#endif
#endif
        if (ERR_SUCCESS != iResult)
        {
            AT_TC(g_sw_GPRS, "AT+CGQMIN:CFW_GprsSetMinQos() failed,iResult = 0x%x.", iResult);
            uErrCode = ERR_AT_CME_EXE_FAIL;
            goto _func_fail;
        }
        else
        {
            if (NULL == pResp)
            {
                pResp = AT_MALLOC(AT_GPRS_PDPADDR_MAX_LEN + AT_GPRS_APN_MAX_LEN + AT_GPRS_APN_MAX_LEN + 20);

                if (NULL == pResp)
                {
                    uErrCode = ERR_AT_CME_NO_MEMORY;
                    goto _func_fail;

                }
                AT_MemSet(pResp, 0, SIZEOF(pResp));

                // +CGQREQ: <cid>, <precedence >, <delay>, <reliability>, <peak>, <mean>
                AT_Sprintf(pResp, "+CGQMIN:%d,%d,%d,%d,%d,%d",
                           uCid, sQos.nPrecedence, sQos.nDelay, sQos.nReliability, sQos.nPeak, sQos.nMean);
            }
            goto _func_success;
        }
    }

    // Read command
    else if (AT_CMD_READ == pParam->iType)
    {
        for (uCid = AT_PDPCID_MIN; uCid <= AT_PDPCID_MAX; uCid++)
        {
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM
            iResult = CFW_GprsGetMInQos(uCid, &sQos, nSim);
#else
            iResult = CFW_GprsGetMInQos(uCid, &sQos);

#endif
#endif
            if (ERR_SUCCESS == iResult)
            {
                if (NULL == pResp)
                {
                    pResp = AT_MALLOC(AT_GPRS_PDPADDR_MAX_LEN + AT_GPRS_APN_MAX_LEN + AT_GPRS_APN_MAX_LEN + 20);

                    if (NULL == pResp)
                    {
                        uErrCode = ERR_AT_CME_NO_MEMORY;
                        goto _func_fail;

                    }
                }

                AT_MemSet(pResp, 0, SIZEOF(pResp));

                // +CGQMIN: <cid>, <precedence >, <delay>, <reliability>, <peak>, <mean>
                AT_Sprintf(pResp, "+CGQMIN:%d,%d,%d,%d,%d,%d",
                           uCid, sQos.nPrecedence, sQos.nDelay, sQos.nReliability, sQos.nPeak, sQos.nMean);
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
                AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif
            }
            else
            {
                // The cid of specified is NULL.
                // Do nothing.
            }
        }

        if (NULL == pResp)
        {
            uErrCode = ERR_AT_CME_EXE_FAIL;
            goto _func_fail;
        }
        else
        {
            pResp[0] = 0;
            goto _func_success;
        }
    }

    // Test command.
    else if (AT_CMD_TEST == pParam->iType)
    {

        pResp = AT_MALLOC(128);

        if (NULL == pResp)
        {
            uErrCode = ERR_AT_CME_NO_MEMORY;
            goto _func_fail;

        }

        // [[ yy [mod] for Bug ID:8178

        AT_MemSet(pResp, 0, 128);

        AT_StrCpy(pResp, "+CGQMIN: IP, (0..3), (0..4), (0..5) , (0..9), (0..18,31)");

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif

        AT_MemSet(pResp, 0, 128);

        AT_StrCpy(pResp, "+CGQMIN: PPP, (0..3), (0..4), (0..5) , (0..9), (0..18,31)");

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif

        AT_MemSet(pResp, 0, 128);

        AT_StrCpy(pResp, "+CGQMIN: IPV6, (0..3), (0..4), (0..5) , (0..9), (0..18,31)");

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif

        AT_FREE(pResp);

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif

        return;

        // [[ yy [mod] for Bug ID:8178

    }
    else
    {
        // parser error.
        // do nothing.
        return;
    }

_func_success:

#ifdef AT_DUAL_SIM
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif
    if (NULL != pResp)
    {
        AT_FREE(pResp);
        pResp = NULL;
    }

    return;

_func_fail:

#ifdef AT_DUAL_SIM
    AT_GPRS_Result_Err(uErrCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_Err(uErrCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

    if (NULL != pResp)
    {
        AT_FREE(pResp);
        pResp = NULL;
    }

    return;
}

// This function to process the AT+CGATT command. include set,read and test command.
//
// Set command
// +CGATT= [<state>]
// Possible response(s)
// OK
// ERROR
//
// Read command
// +CGATT?
// Possible response(s)
// +CGATT: <state>
//
// Test command
// +CGATT=?
// Possible response(s)
// +CGATT: (list of supported <state>s)
//

VOID AT_GPRS_CmdFunc_CGATT(AT_CMD_PARA *pParam)
{
    INT32 iResult;
    UINT8 *pResp = NULL;
    UINT8 uUIT   = 0;
    UINT8 uState = 0;
    UINT8 uSize;
    UINT8 uParamCount = 0;
    UINT32 uErrCode   = ERR_SUCCESS;
    UINT8 uIndex      = 0;
    UINT8 gState      = 0;

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

    if(CLASS_TYPE_CC == AT_Get_ClassType())
    {
        //class cc mode,can not attech

        AT_TC(g_sw_GPRS, "Gprs in class cc mode,can not attach");
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;

    }

    // input parameter check.
    if (NULL == pParam)
    {
        AT_TC(g_sw_GPRS, "AT+CGATT:NULL == pParam");
        uErrCode = ERR_AT_CME_PARAM_INVALID;
        goto _func_fail;
    }

    // Process the command. include icommand parameter checking,csw api calling,and responsing...
    // Set command.
    AT_TC(g_sw_GPRS, "cmd type = %d.", pParam->iType);

    if (AT_CMD_SET == pParam->iType)
    {
        // this comman have parameter.
        if (NULL == pParam->pPara)
        {
            AT_TC(g_sw_GPRS, "AT+CGATT:NULL == pParam->pPara");
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        // Get the count of parameters.
        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);
        AT_TC(g_sw_GPRS, "uParamCount = %d. ", uParamCount);

        if (ERR_SUCCESS != iResult)
        {
            AT_TC(g_sw_GPRS, "GetParaCount,iResult = %d. ", iResult);
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        // This command have 1 parameters.
        if (1 != uParamCount)
        {
            AT_TC(g_sw_GPRS, "uParamCount = %d. ", uParamCount);
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        // Get the parameter list.
        // 1#
        // Get state.
        uSize = 1;

        uIndex = 0;

        iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &uState, &uSize);

        if (ERR_SUCCESS != iResult)
        {
            AT_TC(g_sw_GPRS, "Get state failed,iResult = %d. ", iResult);
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        if (uState > 1)
        {
            AT_TC(g_sw_GPRS, "uState > 1,uState = %d. ", uState);
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM
        iResult = CFW_GetGprsAttState(&gState, nSim);
#else
        iResult = CFW_GetGprsAttState(&gState);
#endif
#endif
        if ((ERR_SUCCESS != iResult) || ((0 != gState) && (1 != gState)))
        {
            AT_TC(g_sw_GPRS, "CFW_GetGprsAttState() failed,iResult = 0x%x. ", iResult);
            uErrCode = ERR_AT_CME_EXE_FAIL;
            goto _func_fail;
        }
        else
        {
            g_uAttState = gState;

            // AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
            // return;
        }

        // [[ yy [add] 2008-5-12 for code review
        if (g_uAttState == uState)
        {
            pResp = AT_MALLOC(16);
            AT_MemSet(pResp, 0, 16);
            if (NULL == pResp)
            {
                uErrCode = ERR_AT_CME_NO_MEMORY;
                goto _func_fail;
            }

            // AT_Sprintf(pResp, "+CGATT:%d", uState);
            goto _func_success;
        }

        // ]] yy [add] 2008-5-12 for code reivew

        // Call csw api to set the pdp cxt.
        iResult = AT_GetFreeUTI(CFW_GPRS_SRV_ID, &uUIT);

        if (ERR_SUCCESS != iResult)
        {
            AT_TC(g_sw_GPRS, "AT_GetFreeUTI failed,iResult = 0x%x. ", iResult);
            uErrCode = ERR_AT_CME_EXE_FAIL;
            goto _func_fail;
        }

        uUIT += 1;
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM

        iResult = CFW_GprsAtt(uState, pParam->nDLCI, nSim);
#else
        iResult = CFW_GprsAtt(uState, pParam->nDLCI);

#endif
#endif
        AT_TC(g_sw_GPRS, "CFW_GprsAtt,iResult = 0x%x. ", iResult);

        if (ERR_SUCCESS != iResult)
        {
            AT_TC(g_sw_GPRS, "CFW_GprsAtt failed,iResult = 0x%x. ", iResult);

            if (ERR_CME_OPERATION_NOT_ALLOWED == iResult)
            {
                uErrCode = ERR_AT_CME_GPRS_SVR_NOT_ALLOWED;
            }
            else if (ERR_MENU_ALLOC_MEMORY == iResult)
            {
                uErrCode = ERR_AT_CME_MEMORY_FULL;
            }
            else
            {
                uErrCode = ERR_AT_CME_EXE_FAIL;
            }

            goto _func_fail;
        }
        else
        {
            pResp = AT_MALLOC(16);
            AT_MemSet(pResp, 0, 16);
            if (NULL == pResp)
            {
                uErrCode = ERR_AT_CME_NO_MEMORY;
                goto _func_fail;
            }

            // AT_Sprintf(pResp, "+CGATT:%d", uState);
            // g_uAttState = uState; /* yy [del] 2008-6-24 for bug ID 8765 */
            goto _func_success_asyn;
        }

    }

    // Read command
    else if (AT_CMD_READ == pParam->iType)
    {
        uState = 0;
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM
        iResult = CFW_GetGprsAttState(&uState, nSim);
#else
        iResult = CFW_GetGprsAttState(&uState);

#endif
#endif
        if ((ERR_SUCCESS != iResult) || ((0 != uState) && (1 != uState)))
        {
            AT_TC(g_sw_GPRS, "CFW_GetGprsAttState() failed,iResult = 0x%x. ", iResult);
            uErrCode = ERR_AT_CME_EXE_FAIL;
            goto _func_fail;
        }

        pResp = AT_MALLOC(16);

        AT_MemSet(pResp, 0, 16);

        if (NULL == pResp)
        {
            uErrCode = ERR_AT_CME_NO_MEMORY;
            goto _func_fail;
        }

        AT_Sprintf(pResp, "+CGATT:%d", uState);
        goto _func_success;
    }

    // Test command.
    else if (AT_CMD_TEST == pParam->iType)
    {
        pResp = AT_MALLOC(16);
        AT_MemZero(pResp, sizeof(pResp));
        if (NULL == pResp)
        {
            uErrCode = ERR_AT_CME_NO_MEMORY;
            goto _func_fail;
        }

        AT_StrCpy(pResp, "+CGATT:(0-1)"); // yy [mod] 2008-5-20 for bug ID:8466

        goto _func_success;
    }
    else
    {
        // [[ yy [mod] 2008-6-3 for bug ID
        uErrCode = ERR_AT_CME_OPTION_NOT_SURPORT;
        goto _func_fail;

        // ]] yy [mod] 2008-6-3 for bug ID
        return;
    }

_func_success:

#ifdef AT_DUAL_SIM
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif

    if (NULL != pResp)
    {
        AT_FREE(pResp);
        pResp = NULL;
    }

    return;

_func_success_asyn:
#ifdef AT_DUAL_SIM
    AT_GPRS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, AT_GPRS_ATTDELAY, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, AT_GPRS_ATTDELAY, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif

    if (NULL != pResp)
    {
        AT_FREE(pResp);
        pResp = NULL;
    }

    return;

_func_fail:

#ifdef AT_DUAL_SIM
    AT_GPRS_Result_Err(uErrCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_Err(uErrCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

    if (NULL != pResp)
    {
        AT_FREE(pResp);
        pResp = NULL;
    }

    return;
}

VOID AT_GPRS_Act_Get_Att_Rsp(UINT8 att_state)
{
    INT32 iResult;
    UINT8 i = 0;

    UINT8 nSim = g_uGPRS_Act_Wait_Att_Rsp_Info.nSim;
#ifdef AT_DUAL_SIM

    AT_Gprs_CidInfo  *g_staAtGprsCidInfo = g_staAtGprsCidInfo_e[nSim];
#endif

    AT_TC(g_sw_GPRS, "get AT_GPRS_Act_Get_Att_Rsp");
    if (att_state != CFW_GPRS_ATTACHED)
    {
        AT_TC(g_sw_GPRS, "AT_GPRS_Act_Get_Att_Rsp err");
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME,
                           g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME,
                           g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI);
#endif
        return;
    }

    // clean wait state
    g_uGPRS_Act_Wait_Att_Rsp_Info.wait_state = 0;

    for (i = 0; i < g_uGPRS_Act_Wait_Att_Rsp_Info.act_count; i++)
    {

#ifdef AT_DUAL_SIM
        iResult = AT_CFW_GprsAct(g_uGPRS_Act_Wait_Att_Rsp_Info.act_state, g_uGPRS_Act_Wait_Att_Rsp_Info.cid[i],
                                 g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI, g_uGPRS_Act_Wait_Att_Rsp_Info.nSim);
#else
        iResult = AT_CFW_GprsAct(g_uGPRS_Act_Wait_Att_Rsp_Info.act_state, g_uGPRS_Act_Wait_Att_Rsp_Info.cid[i],
                                 g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI);
#endif
        AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGACT,  iResult=%d", iResult);

        // if(( iResult != CFW_GPRS_ACTIVED ) && (iResult != CFW_GPRS_DEACTIVED))
        if (iResult != ERR_SUCCESS)
        {
            if (ERR_CFW_INVALID_PARAMETER == iResult)
            {
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI,
                                   nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI);
#endif
            }
            else if (ERR_CFW_NOT_EXIST_FREE_UTI == iResult)
            {
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME,
                                   g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME,
                                   g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI);
#endif
            }
            else if (ERR_CFW_UTI_IS_BUSY == iResult)
            {
                AT_TC(g_sw_GPRS, "UTI busy in exe       in AT_GPRS_CmdFunc_CGACT\n");

                // yy [mod] 2008-5-20 for bug ID 8477
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME,
                                   g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME,
                                   g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI);
#endif
            }
            else
            {
                // yy [mod] 2008-5-20 for bug ID 8477
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME,
                                   g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME,
                                   g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI);
#endif
                AT_TC(g_sw_GPRS, "unknown return value in exe       in AT_GPRS_CmdFunc_CGACT\n");
            }

            // [MOD] by yy  at 2008-04-21 end
            return;
        }
        else
        {
            g_uAtWaitActRsp[g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI]++;

            // AT_TC(g_sw_GPRS,  "exe       in AT_GPRS_CmdFunc_CGACT, success(cid):%d\n",uCid);
        }
        g_staAtGprsCidInfo[g_uGPRS_Act_Wait_Att_Rsp_Info.cid[i]].uState = g_uGPRS_Act_Wait_Att_Rsp_Info.act_state;
        g_uATTcpipCid[g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI]              = g_uGPRS_Act_Wait_Att_Rsp_Info.cid[i];
        g_uATTcpipActPhase[g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI]         = 4;
    }
}
#ifdef AT_FTP_SUPPORT
#ifdef AT_FTP_UPDATE
#define FTP_UPDATE_CID 1
#define FTP_UPDATE_UTI 21
UINT32  _FTPActivePDP(CFW_SIM_ID nSimID)
{
    CFW_GPRS_PDPCONT_INFO pdp_cont;
    pdp_cont.nApnSize = 5;
    pdp_cont.pApn = "CMNET";

    pdp_cont.nApnUserSize = 3;
    pdp_cont.pApnUser = "wap";
    pdp_cont.nApnPwdSize = 3;
    pdp_cont.pApnPwd = "wap";


    pdp_cont.nPdpAddrSize = 0;
    pdp_cont.pPdpAddr = NULL;
    pdp_cont.nDComp = 0;
    pdp_cont.nHComp = 0;
    pdp_cont.nPdpType = CFW_GPRS_PDP_TYPE_IP;
#ifdef CFW_MULTI_SIM
    UINT32 nRet = CFW_GprsSetPdpCxt(FTP_UPDATE_CID, &pdp_cont, nSimID);
#else
    UINT32 nRet = CFW_GprsSetPdpCxt(FTP_UPDATE_CID, &pdp_cont);
#endif
    AT_TC(g_sw_GPRS, "CFW_GprsSetPdpCxt= %x\n", nRet);

    nRet = CFW_GprsAct(CFW_GPRS_ACTIVED, FTP_UPDATE_CID, FTP_UPDATE_UTI, nSimID);
    AT_TC(g_sw_GPRS, "CFW_GprsAct= %x\n", nRet);

}
#endif
#endif
VOID AT_GPRS_Att_Rsp(CFW_EVENT *pEvent)
{
    UINT8 uErrCode;
    UINT8 respond[80] = { 0 };
    UINT32 nRet = ERR_SUCCESS;
    CFW_NW_STATUS_INFO sStatus;

#ifdef AT_DUAL_SIM
    UINT8 nSim = pEvent->nFlag;
#endif
    AT_TC(g_sw_GPRS, "Recv:EV_CFW_GPRS_ATT_RSP,nParam1 =0x%x,nType =0x%x.pEvent->nUTI = %d\n", pEvent->nParam1,
          pEvent->nType, pEvent->nUTI);

    if (pEvent->nParam1 != ERR_SUCCESS)
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pEvent->nUTI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pEvent->nUTI);
#endif
        return;
    }

    if ((pEvent->nType != CFW_GPRS_ATTACHED) && (pEvent->nType != CFW_GPRS_DETACHED))
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_CME_UNKNOWN, CMD_ERROR_CODE_TYPE_CME, pEvent->nUTI, nSim);
#else
        AT_GPRS_Result_Err(ERR_CME_UNKNOWN, CMD_ERROR_CODE_TYPE_CME, pEvent->nUTI);
#endif
        return;
    }

    if ((g_uGPRS_Act_Wait_Att_Rsp_Info.wait_state == 1) && (g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI == pEvent->nUTI))
    {
        AT_GPRS_Act_Get_Att_Rsp(pEvent->nType);
        return;
    }

    /*
    #ifdef AT_DUAL_SIM
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pEvent->nUTI, nSim);
    #else
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pEvent->nUTI);
    #endif
    */
#ifdef AT_FTP_SUPPORT
#ifdef AT_FTP_UPDATE
    nRet = _FTPActivePDP(nSim);
    AT_TC(g_sw_GPRS, "_FTPActivePDP= %d\n", nRet);
#else
    AT_TC(g_sw_GPRS, "FTP_CxtAct ftp UTI:%d,UTI:%d,ftp state:%d\n", gATFTPUti,pEvent->nUTI,gATFTPState);

    if(((UINT16)gATFTPUti == pEvent->nUTI)&&(1 ==gATFTPState ))
    {
        UINT8 nCid = 0;
        nRet = AT_FTP_CxtAct(&nCid,nSim);
        if(nRet != ERR_SUCCESS)
        {
            AT_TC(g_sw_GPRS, "Refresh CxtAct ERROR nRet:%d", nRet);
            return nRet;
        }

        gATFTPState = 2|(nCid<<4);
        return;
    }

#endif
#endif
#ifndef AT_NO_GPRS

#ifdef AT_DUAL_SIM
    uErrCode = CFW_GprsGetstatus(&sStatus, nSim);
#else
    uErrCode = CFW_GprsGetstatus(&sStatus);

#endif
#endif
    if (ERR_SUCCESS == uErrCode)
    {

        UINT8 uAttStat = 0;

        if (CFW_GPRS_ATTACHED == pEvent->nType)
        {
            // csw_SetResourceActivity(CSW_LP_RESOURCE_UNUSED_1, CSW_SYS_FREQ_78M);
            g_uAttState = CFW_GPRS_ATTACHED;

            if (1 == sStatus.nStatus) // home
            {
                uAttStat = AT_GPRS_ATT_HOME_OK;
            }
            else if (5 == sStatus.nStatus)  // roaming
            {
                uAttStat = AT_GPRS_ATT_ROAM_OK;
            }
        }
        else
        {
            // csw_SetResourceActivity(CSW_LP_RESOURCE_UNUSED_1, CSW_SYS_FREQ_39M);
            g_uAttState = CFW_GPRS_DETACHED;

            uAttStat = AT_GPRS_ATT_NOTREG;  // detached
        }

        AT_MemSet(respond, 0, sizeof(respond));

        switch (g_uAtCgreg)
        {

        case 1:
            AT_Sprintf(respond, "+CGREG: %d", uAttStat);
            break;  // yy [mod] 2008-5-20 for bug ID 8491

        case 2:

            if (CFW_GPRS_ATTACHED == pEvent->nType)
            {
                // AT_Sprintf(respond, "+CGREG: %d,%d,\"%2.2X%2.2X\",\"%2.2X%2.2X\"",
                AT_Sprintf(respond, "+CGREG: %d,\"%X%X\",\"%X%X\"", // yy [mod] 2008-5-20 for bug ID 8493
                           uAttStat, sStatus.nAreaCode[0], sStatus.nAreaCode[1], sStatus.nCellId[0], sStatus.nCellId[1]);
            }
            else
            {
                AT_Sprintf(respond, "+CGREG: %d", uAttStat);  // yy [mod] 2008-5-20 for bug ID 8493
            }

            break;  // yy [mod] 2008-5-20 for bug ID 8491
        }
        if (0 == g_uATTcpipActPhase[pEvent->nUTI])
        {

            if (1 == g_uAtCgreg || 2 == g_uAtCgreg)
            {
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, respond, AT_StrLen(respond), pEvent->nUTI, nSim);
#else
                AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, respond, AT_StrLen(respond), pEvent->nUTI);
#endif

            }
            else
            {
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pEvent->nUTI, nSim);
#else
                AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pEvent->nUTI);
#endif
            }
            return;
        }
        else
        {
            // attach caused by TCP/IP connection
            INT8 iResult = 0;
            UINT16 uUTI  = 0;

            uUTI = AT_GPRSUTI_BEG + AT_GPRSUTI_TCPIP_OFF + 2;
#ifdef AT_DUAL_SIM

            iResult = AT_CFW_GprsAct(AT_GPRS_ACT, g_uATTcpipCid[pEvent->nUTI], pEvent->nUTI, nSim);
#else
            iResult = AT_CFW_GprsAct(AT_GPRS_ACT, g_uATTcpipCid[pEvent->nUTI], pEvent->nUTI);

#endif

            if (iResult != ERR_SUCCESS)
            {
                g_uATTcpipActPhase[pEvent->nUTI] = 0;
                AT_TC(g_sw_TCPIP, "Activate PDP error while TCP/IP connection");
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pEvent->nUTI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pEvent->nUTI);
#endif
                return;
            }
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, NULL, 0, pEvent->nUTI, nSim);
#else
            AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, NULL, 0, pEvent->nUTI);
#endif
            return;
        }

        // ]] yy [mod]  2008-5-16 for TCPIP
    }
    else
    {
        AT_TC(g_sw_GPRS, "Get GPRS status error");
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pEvent->nUTI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pEvent->nUTI);
#endif
        return;
    }

}

VOID AT_GPRS_CmdFunc_CGACT(AT_CMD_PARA *pParam)
{
    UINT8 uParamCount          = 0;
    INT32 iResult              = 0;
    UINT8 uState               = 0;
    UINT8 uSize                = 0;
    UINT8 uCidState            = 0;
    UINT8 uNumCidToBeAct       = 0;
    UINT8 uaCid[AT_PDPCID_MAX] = { 0 };
    UINT8 uaUTI[AT_PDPCID_MAX] = { 0 };
    UINT8 gState               = 0;
    UINT8 AtRet[100]           = { 0 }; /* max 20 charactors per cid */
    UINT8 n                    = 0;
    UINT8 i                    = 0;
    UINT8 j                    = 0;

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
    AT_Gprs_CidInfo  *g_staAtGprsCidInfo = g_staAtGprsCidInfo_e[nSim];
    AT_TC(g_sw_GPRS, "+CGACT: nSim= %d; nDLCI= 0x%x", nSim, pParam->nDLCI);

#endif
    if (NULL == pParam)
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    if(CLASS_TYPE_CC == AT_Get_ClassType())
    {
        //class cc mode,can not active

        AT_TC(g_sw_GPRS, "Gprs in class cc mode,can not active");
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;

    }
#ifndef AT_NO_GPRS
    // get gprs att state
    iResult = CFW_GetGprsAttState(&gState, nSim);
#endif
    if ((ERR_SUCCESS != iResult) || ((0 != gState) && (1 != gState)))
    {
        AT_TC(g_sw_GPRS, "CFW_GetGprsAttState() failed,iResult = 0x%x. ", iResult);
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
        return;
    }
    else
    {
        g_uAttState = gState;
    }

    if (AT_CMD_SET == pParam->iType)
    {
        // check paracount
        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);

        if ((iResult != ERR_SUCCESS) || (uParamCount < 1))
        {
            // the param "<state>" become a must
            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGACT, parameters error or no parameters offered \n");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        if (g_uAtWaitActRsp[pParam->nDLCI] != 0)
        {
            AT_TC(g_sw_GPRS, "PDP activation process is waiting network response");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        if (uParamCount > AT_PDPCID_MAX + 1 /* "1" refs to uState */ )
        {
            // uplimit of maxium PDP allowed to be activated
            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGACT, exceed num of maxium allowed active PDP \n");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // get <state>
        uSize = 1;

        iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uState, &uSize);

        if ((iResult != ERR_SUCCESS) || (uState > 1))
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // [[ yy [add] 2008-6-4 for bug ID 8678
        if ((AT_GPRS_ACT == uState) && (g_uAtGprsCidNum > AT_PDPCID_MAX))
        {


            AT_TC(g_sw_GPRS, "PDP activation exceed maximum limitation.");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // ]] yy [add] 2008-6-4 for bug ID 8678

        if (uParamCount > 1)
        {
            // get&check the specified <cid>
            i = 0;
            j = 1;

            while (j < uParamCount)
            {
                uSize   = 1;
                iResult = AT_Util_GetParaWithRule(pParam->pPara, j, AT_UTIL_PARA_TYPE_UINT8, &uaCid[i], &uSize);

                if (iResult != ERR_SUCCESS)
                {
#ifdef AT_DUAL_SIM
                    AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM
                CFW_GetGprsActState(uaCid[i], &uCidState, nSim);
#else
                CFW_GetGprsActState(uaCid[i], &uCidState);
#endif
#endif
                if (uCidState != uState)
                {
                    // if the state of the cid  is not what we want,then save the cid, else ignore it.
                    i++;
                    uNumCidToBeAct++;
                }

                j++;
            }
        }
        else
        {
            // check all defined cids
            j = 0;

            for (i = 1; i <= AT_PDPCID_MAX; i++)  // yy [mod] 2008-5-16
            {
#ifdef AT_DUAL_SIM

                if ((g_staAtGprsCidInfo[i].uCid != 0) && (nSim == AT_SIM_ID(g_staAtGprsCidInfo[i].nDLCI)))
#else
                if (g_staAtGprsCidInfo[i].uCid != 0)
#endif

                {
                    // [[ yy [mod] 2008-5-21 for bug ID 8463
#ifndef AT_NO_GPRS

#ifdef AT_DUAL_SIM
                    CFW_GetGprsActState(g_staAtGprsCidInfo[i].uCid, &uCidState, nSim);
#else
                    CFW_GetGprsActState(g_staAtGprsCidInfo[i].uCid, &uCidState);
#endif
#endif
                    // AT_TC(g_sw_GPRS, "11111 uaCid[%d]: %d, uCidState is %d", i, g_staAtGprsCidInfo[i].uCid, uCidState);
                    // ]] yy [mod] 2008-5-21 for bug ID 8463
                    if (uCidState != uState)
                    {
                        // if the cid state is not what we want,then save the cid, else ignore it.
                        uaCid[j++] = g_staAtGprsCidInfo[i].uCid;

                        uNumCidToBeAct++;
                    }
                }
            }
        }

        // if not attach, Attach GPRS. lijingyu Fri Nov 30 13:55:14 CST 2012
        if ((g_uAttState == 0) && (uState == 1) && (uNumCidToBeAct != 0))
        {
            AT_TC(g_sw_GPRS, "CFW_GprsAtt state = 0. ");
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM
            iResult = CFW_GprsAtt(uState, pParam->nDLCI, nSim);
#else
            iResult = CFW_GprsAtt(uState, pParam->nDLCI);
#endif
#endif
            if (ERR_SUCCESS != iResult)
            {
                AT_TC(g_sw_GPRS, "CFW_GprsAtt failed,iResult = 0x%x. ", iResult);
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
                return;
            }
            else
            {
                g_uGPRS_Act_Wait_Att_Rsp_Info.wait_state = 1;
                g_uGPRS_Act_Wait_Att_Rsp_Info.act_state  = uState;
                g_uGPRS_Act_Wait_Att_Rsp_Info.act_count  = uNumCidToBeAct;
                g_uGPRS_Act_Wait_Att_Rsp_Info.nSim       = nSim;
                g_uGPRS_Act_Wait_Att_Rsp_Info.nDLCI      = pParam->nDLCI;
                for (i = 0; i < uNumCidToBeAct; i++)
                {
                    g_uGPRS_Act_Wait_Att_Rsp_Info.cid[i] = uaCid[i];
                }
            }
            AT_TC(g_sw_GPRS, "wait AT_GPRS_Act_Get_Att_Rsp");
            return;
        }

        AT_TC(g_sw_GPRS,
              "exe       in AT_GPRS_CmdFunc_CGACT,  %d need to execute:%d, %d, the state of the rest is already satisfied",
              uNumCidToBeAct, uaCid[0], uaCid[1]);

        // begin execute ...
        if ((uParamCount > 1) && (uNumCidToBeAct != 0)) // yy [mod] 2008-5-16  for bug ID 8477
        {
            // active/deactive specified <cid>
            for (i = 0; i < uNumCidToBeAct; i++)
            {
                // active/deactive PDP
                AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGACT,  uState:%d, uaCid[%d]:%d, uaUTI[%d]:%d", uState, i,
                      uaCid[i], i, uaUTI[i]);
#ifdef AT_DUAL_SIM
                iResult = AT_CFW_GprsAct(uState, uaCid[i], pParam->nDLCI, nSim);
#else
                iResult = AT_CFW_GprsAct(uState, uaCid[i], pParam->nDLCI);
#endif
                AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGACT,  iResult=%d", iResult);

                // [MOD] by yy  at 2008-04-21 begin
                // yy [mod] 2008-5-6 code review
                // if(( iResult != CFW_GPRS_ACTIVED ) && (iResult != CFW_GPRS_DEACTIVED))

                if (iResult != ERR_SUCCESS)
                {
                    if (ERR_CFW_INVALID_PARAMETER == iResult)
                    {
#ifdef AT_DUAL_SIM
                        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    }
                    else if (ERR_CFW_NOT_EXIST_FREE_UTI == iResult)
                    {
#ifdef AT_DUAL_SIM
                        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    }
                    else if (ERR_CFW_UTI_IS_BUSY == iResult)
                    {
                        AT_TC(g_sw_GPRS, "UTI busy in exe       in AT_GPRS_CmdFunc_CGACT\n");

                        // yy [mod] 2008-5-20 for bug ID 8477
#ifdef AT_DUAL_SIM
                        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    }
                    else
                    {
                        // yy [mod] 2008-5-20 for bug ID 8477
#ifdef AT_DUAL_SIM
                        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                        AT_TC(g_sw_GPRS, "unknown return value in exe       in AT_GPRS_CmdFunc_CGACT\n");
                    }

                    // [MOD] by yy  at 2008-04-21 end
                    AT_TC(g_sw_GPRS,
                          "exe       in AT_GPRS_CmdFunc_CGACT, fail at(cid):%d, but still %d activation requestion is on the fly\n",
                          uaCid[i], g_uAtWaitActRsp[pParam->nDLCI]);
                    return;
                }
                else
                {
                    g_uAtWaitActRsp[pParam->nDLCI]++;

                    // AT_TC(g_sw_GPRS,  "exe       in AT_GPRS_CmdFunc_CGACT, success(cid):%d\n",uCid);
                }
                g_staAtGprsCidInfo[uaCid[i]].uState = uState;
                g_uATTcpipCid[pParam->nDLCI]        = uaCid[i];

                g_staAtGprsCidInfo[ uaCid[i]].uCid = uaCid[i];
                g_uATTcpipActPhase[pParam->nDLCI]   = 4;
            }

            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGACT,  %d cid is waiting for network response", g_uAtWaitActRsp[pParam->nDLCI]);
#ifdef AT_DUAL_SIM
            if(AT_GPRS_DEA == uState)
                AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, AT_GPRS_ACTIVEDELAY, NULL, 0, pParam->nDLCI, nSim);

            else
                AT_GPRS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, AT_GPRS_ACTIVEDELAY, NULL, 0, pParam->nDLCI, nSim);
#else
            if(AT_GPRS_DEA == uState)
                AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, AT_GPRS_ACTIVEDELAY, NULL, 0, pParam->nDLCI);
            else
                AT_GPRS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, AT_GPRS_ACTIVEDELAY, NULL, 0, pParam->nDLCI);
#endif
            return;

        }
        else if ((uParamCount > 1) && (0 == uNumCidToBeAct))  // yy [mod] 2008-5-16  for bug ID 8477
        {
            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGACT, the state of all specified cid is already satified");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, AT_GPRS_ACTIVEDELAY, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, AT_GPRS_ACTIVEDELAY, NULL, 0, pParam->nDLCI);
#endif
            return;
        }
        else if ((1 == uParamCount) && (0 != uNumCidToBeAct)) // yy [mod] 2008-5-16 for bug ID 8477
        {
            // active/deactive all <cid>, this can be merged with the first branch
            for (i = 0; ((i < uNumCidToBeAct) && (i < AT_PDPCID_MAX)); i++) // yy [mod] 2008-5-26 for reivew
            {
                // active/deactive PDP
                // yy [add] 2008-5-16
                AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGACT,  uState:%d, uaCid[%d]:%d, uaUTI[%d]:%d", uState, i,
                      uaCid[i], i, uaUTI[i]);
#ifdef AT_DUAL_SIM

                iResult = AT_CFW_GprsAct(uState, uaCid[i], pParam->nDLCI, nSim);
#else
                iResult = AT_CFW_GprsAct(uState, uaCid[i], pParam->nDLCI);
#endif
                // yy [mod] 2008-5-6 code review

                if (iResult != ERR_SUCCESS)
                {
                    if (ERR_CFW_INVALID_PARAMETER == iResult)
                    {
#ifdef AT_DUAL_SIM
                        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    }
                    else if (ERR_CFW_NOT_EXIST_FREE_UTI == iResult)
                    {
                        // yy [mod] 2008-5-20 for bug ID 8477
#ifdef AT_DUAL_SIM
                        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    }
                    else if (ERR_CFW_UTI_IS_BUSY == iResult)
                    {
                        AT_TC(g_sw_GPRS, "UTI busy in exe       in AT_GPRS_CmdFunc_CGACT\n");

                        // yy [mod] 2008-5-20 for bug ID 8477
#ifdef AT_DUAL_SIM
                        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    }
                    else
                    {
                        // yy [mod] 2008-5-20 for bug ID 8477
#ifdef AT_DUAL_SIM
                        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                        AT_GPRS_Result_Err(ERR_AT_CME_GPRS_UNSPECIFIED_GPRS_ERROR, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                        AT_TC(g_sw_GPRS, "unknown return value in exe       in AT_GPRS_CmdFunc_CGACT\n");
                    }

                    // [MOD] by yy  at 2008-04-21 end
                    AT_TC(g_sw_GPRS,
                          "exe       in AT_GPRS_CmdFunc_CGACT, fail at(cid):%d, but still %d activation requestion is on the fly\n",
                          uaCid[i], g_uAtWaitActRsp[pParam->nDLCI]);

                    return;
                }
                else
                {
                    g_uAtWaitActRsp[pParam->nDLCI]++;
                }
                g_uATTcpipCid[pParam->nDLCI]        = uaCid[i];
                g_uATTcpipActPhase[pParam->nDLCI]   = 4;
                g_staAtGprsCidInfo[uaCid[i]].uState = uState;
            }

            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGACT,  %d cid is waiting for network response", g_uAtWaitActRsp[pParam->nDLCI]);
#ifdef AT_DUAL_SIM
            if(AT_GPRS_DEA == uState)
                AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, AT_GPRS_ACTIVEDELAY, NULL, 0, pParam->nDLCI, nSim);

            else
                AT_GPRS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, AT_GPRS_ACTIVEDELAY, NULL, 0, pParam->nDLCI, nSim);
#else
            if(AT_GPRS_DEA == uState)
                AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, AT_GPRS_ACTIVEDELAY, NULL, 0, pParam->nDLCI);

            else
                AT_GPRS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, AT_GPRS_ACTIVEDELAY, NULL, 0, pParam->nDLCI);
#endif
            return;

        }
        else if ((1 == uParamCount) && (0 == uNumCidToBeAct)) // yy [mod] 2008-5-16  for bug ID 8477
        {
            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGACT, the state of all defined cid is already satified");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, AT_GPRS_ACTIVEDELAY, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, AT_GPRS_ACTIVEDELAY, NULL, 0, pParam->nDLCI);
#endif
            return;
        }
    }
    else if (AT_CMD_READ == pParam->iType)
    {
        // AT_Gprs_CidInfo staAT_Gprs_CidState[AT_PDPCID_MAX];

        n = 0;

        for (i = 1; i <= AT_PDPCID_MAX; i++)  // yy [mod] 2008-5-26 for bug ID 8588
        {

#ifdef AT_DUAL_SIM
            AT_TC(g_sw_GPRS, "+CGACT: i= %d; nSim= %d; nDLCI= 0x%x", i, nSim, g_staAtGprsCidInfo[i].nDLCI);
            if ((g_staAtGprsCidInfo[i].uCid != 0) && (nSim == AT_SIM_ID(g_staAtGprsCidInfo[i].nDLCI)))
#else
            if (g_staAtGprsCidInfo[i].uCid != 0)
#endif

            {
#ifndef AT_NO_GPRS

#ifdef AT_DUAL_SIM
                iResult = CFW_GetGprsActState(g_staAtGprsCidInfo[i].uCid, &uState, nSim);
#else
                iResult = CFW_GetGprsActState(g_staAtGprsCidInfo[i].uCid, &uState);
                AT_TC(g_sw_GPRS, "+CGACT: i= %d; nSim= %d; nDLCI= 0x%x, Cid =%d; state = %d", i, nSim, g_staAtGprsCidInfo[i].nDLCI, g_staAtGprsCidInfo[i].uCid, uState);

#endif
#endif
                if (iResult != ERR_SUCCESS)
                {
                    continue;
                }
                else
                {
                    // if (CFW_GPRS_ACTIVED == uState || CFW_GPRS_DEACTIVED == uState)
                    if (CFW_GPRS_ACTIVED == uState )
                    {
                        g_staAtGprsCidInfo[i].uState = uState;
                        AT_MemSet(AtRet, 0, SIZEOF(AtRet));
                        AT_Sprintf(AtRet, "+CGACT: %d, %d", g_staAtGprsCidInfo[i].uCid, g_staAtGprsCidInfo[i].uState);
#ifdef AT_DUAL_SIM
                        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, AtRet, (UINT16)AT_StrLen(AtRet), pParam->nDLCI, nSim);
#else
                        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, AtRet, (UINT16)AT_StrLen(AtRet), pParam->nDLCI);
#endif
                        n++;
                    }
                }
            }
            else
            {
                AT_TC(g_sw_GPRS, "+CGACT: g_staAtGprsCidInfo[%d].uCid == 0", i);
            }
        }

        if (0 == n)
        {
            AT_MemSet(AtRet, 0, SIZEOF(AtRet));
            AT_Sprintf(AtRet, "+CGACT: 0,0");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI);
#endif
        }
        else
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
        }

        return;
    }
    else if (AT_CMD_TEST == pParam->iType)
    {
        AT_MemSet(AtRet, 0, SIZEOF(AtRet));
        AT_Sprintf(AtRet, "+CGACT: (0,1)");
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI);
#endif
        return;
    }
    else
    {
        // AT_TC(g_sw_GPRS,  "111111"); [DEL] by yy  at 2008-04-21
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

}



VOID AT_GPRS_CmdFunc_CGSEND(AT_CMD_PARA *pParam)
{
    UINT8 uSize = 1;
    UINT8 uCid;
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
    INT32 iResult = 0;
    UINT32 uRet, uDataLen;

    CFW_GPRS_DATA *pGprsData = NULL;

    iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uCid, &uSize);
    if (ERR_SUCCESS != iResult)
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }
    uSize = 4;
    iResult = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT32, &uDataLen, &uSize);
    if (ERR_SUCCESS != iResult )
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    pGprsData = CSW_TCPIP_MALLOC(uDataLen + 4);
    pGprsData->nDataLength = uDataLen;
    SUL_ZeroMemory8(pGprsData->pData, uDataLen);

#ifdef AT_DUAL_SIM
    uRet = CFW_GprsSendData(uCid, pGprsData, nSim);
#else
    uRet = CFW_GprsSendData(uCid, pGprsData);
#endif
    if(ERR_SUCCESS != uRet)
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }


    if(NULL != pGprsData)
    {
        CSW_TCPIP_FREE(pGprsData);
    }

#ifdef AT_DUAL_SIM
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
    return;

}

// ----------------------------------------------------------------------------------------------
// Set command                               |   Test command                          |
// AT+CGPADDR=[<cid>,[                     |     AT+ CGPADDR =?                      |
// <cid>, [                     |                                         |
// <cid>,                       |                                         |
// [,...]]]]                    |                                         |
// Response(s)                               |   Response(s)                           |
// Success:                              |     Success:                            |
// +CGPADDR: <cid>,<PDP_addr>[<CR><LF>   |       +CGPADDR: (list of defined <cid>s)|
// +CGPADDR: <cid>,<PDP_addr>[...]]      |       OK                                |
// OK                                    |                                         |
// Fail:                                 |                                         |
// ERROR                             |     Fail:                               |
// |       ERROR                             |
// ----------------------------------------------------------------------------------------------
// [[ yy [mod] 2008-4-28 for no "\r\n" in string, which is send to the serial port.
// [MOD] by yy  at 2008-04-21 begin
VOID AT_GPRS_CmdFunc_CGPADDR(AT_CMD_PARA *pParam)
{
    INT32 iResult;

    UINT8 uParamCount;
    UINT8 uCid;
    UINT8 uSize;
    UINT8 uIndex = 0;
    UINT8 i      = 0;

    UINT8 uCnt;
    UINT8 uT;

    UINT8 n     = 0;
    UINT8 uFlag = 0;

    CFW_GPRS_PDPCONT_INFO stPdpCtxInfo;
    UINT8 pApn[100]    = { 0 };
    UINT8 pPdpAddr[18] = { 0 };
    UINT8 pApnUser[20] = { 0 };
    UINT8 pApnPwd[20]  = { 0 };

    stPdpCtxInfo.pApn     = pApn;
    stPdpCtxInfo.pPdpAddr = pPdpAddr;
    stPdpCtxInfo.pApnUser = pApnUser;
    stPdpCtxInfo.pApnPwd  = pApnPwd;

    UINT8 uaTempStr[3] = { 0 };

#define OUTSTR_LEN 25 // yy [mod] 2008-4-29
    UINT8 uaOutputStr[OUTSTR_LEN] = { 0 };


#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
    AT_Gprs_CidInfo  *g_staAtGprsCidInfo = g_staAtGprsCidInfo_e[nSim];
#endif
    // input parameter check.

    if (NULL == pParam)
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    switch (pParam->iType)
    {

    case AT_CMD_SET:

        // check whether the parameter is the valid parameter...
        // TODO...
        // [[ yy [del] 2008-5-21 for bug ID 8467
#if 0

        if (FALSE == AT_Util_CheckValidateU8(pParam->pPara))
        {
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
            return;
        }

#endif
        // ]] yy [del] 2008-5-21 for bug ID 8467

        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);

        if (uParamCount > AT_PDPCID_MAX)
        {
            // do something...
            // whether we can trim the redunced cid in tail..?
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // will return all the PDP ctx defined,now csw has defined 7 items[1-7].
        if (uParamCount == 0)
        {
            uIndex = 0;
            AT_MemSet(uaOutputStr, 0, sizeof(uaOutputStr));

            for (i = AT_PDPCID_MIN; i <= AT_PDPCID_MAX; i++)  // yy [del] 2008-5-26 for code review
            {

                // Do not clear the uState defination...?
                if (0 == g_staAtGprsCidInfo[i].uCid)
                {
                    continue;
                }
                else
                {
                    n++;
                }

                AT_MemSet(&stPdpCtxInfo, 0, SIZEOF(CFW_GPRS_PDPCONT_INFO));

                AT_MemSet(pApn, 0, 100);
                AT_MemSet(pPdpAddr, 0, 18);
                AT_MemSet(pApnUser, 0, 20);
                AT_MemSet(pApnPwd, 0, 20);
                stPdpCtxInfo.pApn     = pApn;
                stPdpCtxInfo.pPdpAddr = pPdpAddr;
                stPdpCtxInfo.pApnUser = pApnUser;
                stPdpCtxInfo.pApnPwd  = pApnPwd;
#ifndef AT_NO_GPRS

#ifdef AT_DUAL_SIM

                iResult = CFW_GprsGetPdpCxt(g_staAtGprsCidInfo[i].uCid, &stPdpCtxInfo, nSim);
#else
                iResult = CFW_GprsGetPdpCxt(g_staAtGprsCidInfo[i].uCid, &stPdpCtxInfo);

#endif
#endif
                if (ERR_SUCCESS != iResult)
                {
                    AT_TC(g_sw_GPRS, "Query PDP context err");
#ifdef AT_DUAL_SIM
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
                else
                {

                    if (0 == stPdpCtxInfo.nPdpAddrSize)
                    {
                        // yy [mod] for bug ID: 8456
                        AT_Sprintf(uaOutputStr, "+CGPADDR: %d,\"0.0.0.0\"", g_staAtGprsCidInfo[i].uCid);
#ifdef AT_DUAL_SIM
                        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, uaOutputStr, AT_StrLen(uaOutputStr), pParam->nDLCI,
                                          nSim);
#else
                        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, uaOutputStr, AT_StrLen(uaOutputStr), pParam->nDLCI);
#endif
                    }
                    else
                    {
                        uT = 0;

                        // yy [mod] for bug ID: 8456
                        AT_Sprintf(uaOutputStr, "+CGPADDR: %d,\"", g_staAtGprsCidInfo[i].uCid);

                        for (uCnt = 0; uCnt < stPdpCtxInfo.nPdpAddrSize; uCnt++)
                        {
                            AT_MemSet(uaTempStr, 0, sizeof(uaTempStr));
                            AT_Sprintf(uaTempStr, "%d.",
                                       (stPdpCtxInfo.pPdpAddr[uCnt] >> 4) * 16 + ((stPdpCtxInfo.pPdpAddr[uCnt]) & 0x0F));
                            AT_StrCat(uaOutputStr, uaTempStr);
                        }
                        AT_MemCpy(&uaOutputStr[AT_StrLen(uaOutputStr) - 1], "\"", 1);
#ifdef AT_DUAL_SIM
                        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, uaOutputStr, AT_StrLen(uaOutputStr), pParam->nDLCI,
                                          nSim);
#else
                        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, uaOutputStr, AT_StrLen(uaOutputStr), pParam->nDLCI);
#endif
                    }
                }
            }

#ifdef AT_DUAL_SIM
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif

            return;
        }
        else
        {
            // disp specified cids
            AT_MemSet(uaOutputStr, 0, sizeof(uaOutputStr));

            for (i = 0; i < uParamCount; i++)
            {
                uSize   = 1;
                iResult = AT_Util_GetParaWithRule(pParam->pPara, i, AT_UTIL_PARA_TYPE_UINT8, &uCid, &uSize);

                if (ERR_SUCCESS != iResult)
                {
#ifdef AT_DUAL_SIM
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }

                if (g_staAtGprsCidInfo[uCid].uCid == 0)
                {
                    // [[ yy [mod] 2008-6-4 for bug ID 8680
#if 0
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                    return;
#endif
                    continue;

                    // ]] yy [mod] 2008-6-4 for bug ID 8680
                }

                AT_MemSet(&stPdpCtxInfo, 0, SIZEOF(CFW_GPRS_PDPCONT_INFO));
                AT_MemSet(pApn, 0, 100);
                AT_MemSet(pPdpAddr, 0, 18);
                AT_MemSet(pApnUser, 0, 20);
                AT_MemSet(pApnPwd, 0, 20);
                stPdpCtxInfo.pApn     = pApn;
                stPdpCtxInfo.pPdpAddr = pPdpAddr;
                stPdpCtxInfo.pApnUser = pApnUser;
                stPdpCtxInfo.pApnPwd  = pApnPwd;
#ifndef AT_NO_GPRS

#ifdef AT_DUAL_SIM

                iResult = CFW_GprsGetPdpCxt(uCid, &stPdpCtxInfo, nSim);
#else
                iResult = CFW_GprsGetPdpCxt(uCid, &stPdpCtxInfo);
#endif
#endif
                if (ERR_SUCCESS == iResult)
                {
                    if (0 == stPdpCtxInfo.nPdpAddrSize)
                    {
                        AT_Sprintf(uaOutputStr, "+CGPADDR: %d,\"0.0.0.0\"", uCid);  // yy [mod] for bug ID: 8456
#ifdef AT_DUAL_SIM
                        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, uaOutputStr, AT_StrLen(uaOutputStr), pParam->nDLCI,
                                          nSim);
#else
                        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, uaOutputStr, AT_StrLen(uaOutputStr), pParam->nDLCI);
#endif
                    }
                    else
                    {
                        uT = 0;
                        AT_MemSet(uaOutputStr, 0, sizeof(uaOutputStr));
                        AT_Sprintf(uaOutputStr, "+CGPADDR: %d,\"", uCid); // yy [mod] for bug ID: 8456

                        for (uCnt = 0; uCnt < stPdpCtxInfo.nPdpAddrSize; uCnt++)
                        {
                            AT_MemSet(uaTempStr, 0, sizeof(uaTempStr));
                            AT_Sprintf(uaTempStr, "%d.",
                                       (stPdpCtxInfo.pPdpAddr[uCnt] >> 4) * 16 + ((stPdpCtxInfo.pPdpAddr[uCnt]) & 0x0F));
                            AT_StrCat(uaOutputStr, uaTempStr);
                        }
                        AT_MemCpy(&uaOutputStr[AT_StrLen(uaOutputStr) - 1], "\"", 1);
#ifdef AT_DUAL_SIM
                        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, uaOutputStr, AT_StrLen(uaOutputStr), pParam->nDLCI,
                                          nSim);
#else
                        AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, uaOutputStr, AT_StrLen(uaOutputStr), pParam->nDLCI);
#endif
                    }
                }
                else
                {
#ifdef AT_DUAL_SIM
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

                    return;
                }

            }

#ifdef AT_DUAL_SIM
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif

            return;
        }

        break;

    case AT_CMD_TEST:
        // [[ yy [mod] 2008-04-23 for bug ID:8183
    {
        UINT16 uLen = SIZEOF("+CGPADDR:(");

        AT_MemSet(uaOutputStr, 0, OUTSTR_LEN);

        AT_MemCpy(uaOutputStr, "+CGPADDR:(", uLen);
        uLen -= 1;

        for (uIndex = AT_PDPCID_MIN; uIndex <= AT_PDPCID_MAX; uIndex++)
        {
            if (g_staAtGprsCidInfo[uIndex].uCid)
            {
                AT_Sprintf(&uaOutputStr[uLen], "%d,", g_staAtGprsCidInfo[uIndex].uCid);
                uLen += 2;
                uFlag = 1;
            }
        }

        if (uFlag)
        {
            uaOutputStr[uLen - 1] = ')';
            uaOutputStr[uLen] = '\0';
        }
        else
        {
            AT_MemCpy(uaOutputStr, "+CGPADDR:()", sizeof("+CGPADDR:()"));
        }
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)uaOutputStr, uLen + 1, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)uaOutputStr, uLen + 1, pParam->nDLCI);
#endif

        break;
    }

    // ]] yy [mod] 2008-04-23 for bug ID:8183

    default:
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        break;
    }

    return;

}

// ]] yy [mod] 2008-4-28 for no "\r\n" in string, which is send to the serial port.
#if 0
VOID AT_GPRS_CmdFunc_CGPADDR(AT_CMD_PARA *pParam)
{
    INT32 iResult;

    UINT8 uParamCount;
    UINT8 uCid;
    UINT8 uSize;
    UINT8 uIndex;

    UINT8 uCnt;
    UINT8 uT;

    UINT8 uDot = 0x2E;
    UINT8 uPot = 0x2C;

    CFW_GPRS_PDPCONT_INFO stPdpCtxInfo;

    UINT8 *pTemp = NULL;

    UINT8 pOutputStr[18] = { 0 };

    // input parameter check.

    if (NULL == pParam)
    {
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
        return;
    }

    switch (pParam->iType)
    {

    case AT_CMD_SET:

        // check whether the parameter is the valid parameter...
        // TODO...

        if (FALSE == AT_Util_CheckValidateU8(pParam->pPara))
        {
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
            return;
        }

        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);

        if (uParamCount > AT_PDPCID_MAX)
        {
            // do something...
            // whether we can trim the redunced cid in tail..?
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
            return;
        }

        // will return all the PDP ctx defined,now csw has defined 7 items[1-7].
        if (uParamCount == 0)
        {
            for (uIndex = AT_PDPCID_MIN; uIndex < AT_PDPCID_MAX; uIndex++)
            {
                // Do not clear the uState defination...?
                if (0 == g_staAtGprsCidInfo[uIndex].uCid)
                {
                    AT_TC(g_sw_GPRS, "KEN :: CGPADDR >> Set uIndex = %d continue...", uIndex);
                    continue;
                }

                iResult = CFW_GprsGetPdpCxt(uIndex, &stPdpCtxInfo);

                AT_TC(g_sw_GPRS, "KEN :: CGPADDR >> Set uIndex = %d return code = %d", uIndex, iResult);

                if (ERR_SUCCESS != iResult)
                {
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                    return;
                }
                else
                {
                    pTemp = pOutputStr;
                    uT    = 0;
                    pTemp[uT++] = uIndex + 1;
                    pTemp[uT++] = uPot;

                    AT_TC(g_sw_GPRS, "KEN :: before uT = %d", uT);

                    for (uCnt = 0; uCnt < stPdpCtxInfo.nPdpAddrSize; uCnt++)
                    {
                        pTemp[uT++] = stPdpCtxInfo.pPdpAddr[uCnt];
                        pTemp[uT++] = uDot;
                    }

                    pTemp[uT - 1] = '\0';

                    AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, pOutputStr, SUL_Strlen(pOutputStr), pParam->nDLCI);
                    pTemp = NULL;
                }

                SUL_ZeroMemory8(pOutputStr, 18);

                SUL_ZeroMemory32(&stPdpCtxInfo, SIZEOF(CFW_GPRS_PDPCONT_INFO));
            }

            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
        }
        else
        {
            uSize = 1;

            // get every cid that defined and actived..

            for (uIndex = 0; uIndex < uParamCount; uIndex++)
            {
                iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &uCid, &uSize);

                if (ERR_SUCCESS != iResult)
                {
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                    return;
                }

                // In this place, May be have some problem:
                // For uCid has not been defined, but I just continue the loop,
                // we should take TE may be need raising the error information from MT into consider..
                // Does we need define some type of error infomation?
                //
                if (ERR_CFW_GPRS_INVALID_CID == at_GprsGetCtxDefStatus(uCid))
                {
                    continue;
                }

                iResult = CFW_GprsGetPdpCxt(uCid, &stPdpCtxInfo);

                if (ERR_SUCCESS == iResult)
                {
                    // AT_TC(g_sw_GPRS,"KEN :: CGPADDR >> uIndex = %d PdpAddr = %s,pApnUser = %s,pApnPwd = %s,pApn = %s",
                    // uIndex,stPdpCtxInfo.pPdpAddr,stPdpCtxInfo.pApnUser,stPdpCtxInfo.pApnPwd,stPdpCtxInfo.pApn);
                    pTemp = pOutputStr;
                    uT    = 0;

                    for (uCnt = 0; uCnt < stPdpCtxInfo.nPdpAddrSize; uCnt++)
                    {
                        pTemp[uT++] = stPdpCtxInfo.pPdpAddr[uCnt];
                        pTemp[uT++] = uDot;
                    }

                    pTemp[uT - 1] = '\0';

                    AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, pOutputStr, SUL_Strlen(pOutputStr), pParam->nDLCI);
                }
                else
                {
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                    return;
                }

                SUL_ZeroMemory8(pOutputStr, 18);

                SUL_ZeroMemory32(&stPdpCtxInfo, SIZEOF(CFW_GPRS_PDPCONT_INFO));
            }

            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);

        }

        break;

    case AT_CMD_TEST:

        // Get every ctx data...

        for (uIndex = AT_PDPCID_MIN; uIndex <= AT_PDPCID_MAX; uIndex++)
        {
            if (ERR_CFW_GPRS_INVALID_CID == at_GprsGetCtxDefStatus(uIndex))
            {
                continue;
            }

            // ken adjust uIndex --> &uIndex
            // 2008-04-08
            AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, &uIndex, 1, pParam->nDLCI);

#  if 0
            iResult = CFW_GprsGetPdpCxt(uIndex, &stPdpCtxInfo);

            if (ERR_SUCCESS != iResult)
            {
                AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                return;
            }
            else
            {
                AT_GPRS_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, stPdpCtxInfo.pPdpAddr, (UINT16)stPdpCtxInfo.nPdpAddrSize,
                                  pParam->nDLCI);
            }

            SUL_ZeroMemory32(&stPdpCtxInfo, SIZEOF(CFW_GPRS_PDPCONT_INFO));

#endif
        }

        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);

        break;

    default:
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
        break;
    }

    return;
}

#endif
// [MOD] by yy  at 2008-04-21 end

// [[ yy [mod] 2008-4-28 for ATE test
#if defined(TEST_STUB_1) || defined(TEST_STUB_2)

VOID AT_GPRS_CmdFunc_CGDATA(AT_CMD_PARA *pParam)
{
#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
#ifdef AT_DUAL_SIM
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif

    // Force to enter PS mode.

    if (bMuxActiveStatus)
        SA_SetSysStatusMux(SA_ATCMD_CGDATA_RESULT, SA_ATCMD_CGDATA_OK, pParam->nDLCI);
    else
        SA_SetSysStatus(SA_ATCMD_CGDATA_RESULT, SA_ATCMD_CGDATA_OK);

}
#else
// ]] yy [mod] 2008-4-28 for ATE test
VOID AT_GPRS_CmdFunc_CGDATA(AT_CMD_PARA *pParam)
{

    UINT8 uParamCount          = 0;
    INT32 iResult              = 0;
    UINT8 uState               = 0;
    UINT8 uSize                = 0;
    UINT8 uCidState            = 0;
    UINT8 uNumCidToBeAct       = 0;
    UINT8 uaCid[AT_PDPCID_MAX] = { 0 };
    UINT8 uaUTI[AT_PDPCID_MAX] = { 0 };
    UINT8 AtRet[100]           = { 0 }; /* max 20 charactors per cid */
    UINT8 uL2p                 = 0;
    UINT8 i                    = 0;
    UINT8 j                    = 0;


#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
    AT_Gprs_CidInfo  *g_staAtGprsCidInfo = g_staAtGprsCidInfo_e[nSim];
#endif
    if (NULL == pParam)
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    // ??? what if either <cid> specified nor defined PDPs exist

    if (AT_CMD_SET == pParam->iType)
    {
        AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGDATA\n");

        if (g_uAtWaitActRsp[pParam->nDLCI] != 0)
        {
            AT_TC(g_sw_GPRS, "PDP activation process is waiting network response");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

        }

        // check paracount
        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);

        if (iResult != ERR_SUCCESS) // yy [mod] 2008-4-28  //Caoxh [Mod] 2008-4-17
        {
            // the param "<L2P>,<cid>" implemented as necessory parameters.
            AT_TC(g_sw_GPRS,
                  "exe       in AT_GPRS_CmdFunc_CGDATA, parameters error or parameters <L2P>, <cid> not offered \n");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        if (uParamCount > AT_PDPCID_MAX + 1 /* "1" refs to uState */ )
        {
            // uplimit of maxium PDP allowed to be activated
            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGDATA, exceed num of maxium allowed active PDP \n");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // [[ yy [mod] 2008-4-28 for the condition when no parameters offered
        if (uParamCount > 0)
        {
            // ]] yy [mod] 2008-4-28 for the condition when no parameters offered
            // get <L2P>
            uSize   = 1;
            iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uL2p, &uSize);

            if ((iResult != ERR_SUCCESS) || (uL2p != CFW_GPRS_PDP_TYPE_PPP))
            {
                AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGDATA, <L2P> error or not support \n");
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
        } // yy [add] 2008-4-28 for the condition when no parameters offered

        if (uParamCount > 1)
        {
            // get&check the specified <cid>
            i = 0;
            j = 1;

            while (j < uParamCount)
            {
                uSize   = 1;
                iResult = AT_Util_GetParaWithRule(pParam->pPara, j, AT_UTIL_PARA_TYPE_UINT8, &uaCid[i], &uSize);

                if (iResult != ERR_SUCCESS)
                {
#ifdef AT_DUAL_SIM
                    AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }

                // check existance
                if (0 == g_staAtGprsCidInfo[uaCid[i]].uCid)
                {
                    AT_TC(g_sw_GPRS, "request <cid> not defined ");
#ifdef AT_DUAL_SIM
                    AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }

                // check current state
#ifndef AT_NO_GPRS

#ifdef AT_DUAL_SIM
                CFW_GetGprsActState(uaCid[i], &uCidState, nSim);
#else
                CFW_GetGprsActState(uaCid[i], &uCidState);
#endif
#endif
                if (uCidState != uState)
                {
                    // if the state of the cid  is not what we want,then save the cid, else ignore it.
                    i++;
                    uNumCidToBeAct++;
                }

                j++;
            }

            // get UTIs
            i = 0;

            while (i < uNumCidToBeAct)
            {
                // Caoxh[modify] 2008-4-17
                uaUTI[i] = 200 + 5 + i;

                // Caoxh[Add] 2008-4-17
                i++;
            }
        }
        else
        {
            // only activated the first available cid. This is implementation dependent.
            j = 0;

            // [[ yy [mod] 2008-4-28 for the condition when no parameters offered

            for (i = 0; i < AT_PDPCID_MAX; i++)
            {
                if (g_staAtGprsCidInfo[i].uCid != 0)
                {
#ifndef AT_NO_GPRS

#ifdef AT_DUAL_SIM
                    CFW_GetGprsActState(uaCid[i], &uCidState, nSim);
#else
                    CFW_GetGprsActState(uaCid[i], &uCidState);

#endif
#endif
                    if (uCidState != CFW_GPRS_ACTIVED)
                    {
                        uaCid[j] = g_staAtGprsCidInfo[i].uCid;
                        uNumCidToBeAct++;
                        break;
                    }
                    else
                    {
#ifdef AT_DUAL_SIM
                        at_PppProcess(pParam->nDLCI, nSim);
#else
                        at_PppProcess();
#endif
                    }

                    return;
                }
            }

            if (AT_PDPCID_MAX == i)
            {
                AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGDATA, no cid defined.\n");
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }

            // ]] yy [mod] 2008-4-28 for the condition when no parameters offered
            i = 0;

            while (i < uNumCidToBeAct)
            {
                // [[caoxh [mod] 2008-04-19:ppp
                uaUTI[i] = 200 + 5 + i;

                // ]]caoxh [mod] 2008-04-19
                i++;
            }

        }

        AT_TC(g_sw_GPRS,
              "exe       in AT_GPRS_CmdFunc_CGDATA,  %d need to execute, the state of the rest is already satisfied",
              uNumCidToBeAct);

        // begin execute ...
        // if(((uParamCount>1) ||(uNumCidToBeAct!=0)) ||((1==uParamCount) ||(uNumCidToBeAct!=0)))
        // [[ yy [mod] 2008-4-28 for the condition when no parameters offered
#  if 0

        if (uNumCidToBeAct != 0)
        {
            // active/deactive specified  or all<cid>

            for (i = 0; i < uNumCidToBeAct; i++)
            {

                // active/deactive PDP
                AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGDATA,  uState:%d, uaCid[%d]:%d, uaUTI[%d]:%d", uState, i,
                      uaCid[i], i, uaUTI[i]);
                iResult = AT_CFW_GprsAct(uState, uaCid[i], uaUTI[i]);
                AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGDATA,  iResult=%d", iResult);

                if ((iResult != CFW_GPRS_ACTIVED) || (iResult != CFW_GPRS_ACTIVED))
                {
                    if (ERR_CFW_INVALID_PARAMETER == iResult)
                    {
                        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                    }
                    else if (ERR_CFW_NOT_EXIST_FREE_UTI == iResult)
                    {
                        AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                    }
                    else
                    {
                        AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                        AT_TC(g_sw_GPRS, "unknown return value in exe       in AT_GPRS_CmdFunc_CGDATA\n");
                    }

                    AT_TC(g_sw_GPRS,
                          "exe       in AT_GPRS_CmdFunc_CGDATA, fail at(cid):%d, but still %d activation requestion is on the fly\n",
                          uaCid[i], g_uAtWaitActRsp);

                    return;
                }
                else
                {
                    g_uAtWaitActRsp++;

                    // AT_TC(g_sw_GPRS,  "exe       in AT_GPRS_CmdFunc_CGDATA, success(cid):%d\n",uCid);
                }

            }

            // [[ caoxh [Mod] 2008-4-17
            // Change to data staues.
            at_PppProcess();

            // ]]caoxh [mod] 2008-4-17
            return;

        }

        // else if(((uParamCount>1) ||(0==uNumCidToBeAct)) || ((1==uParamCount) ||(0==uNumCidToBeAct)))
        else if (0 == uNumCidToBeAct)
        {
            // caoxh [Mod] 2008-4-17
            // Change to data staues.
            at_PppProcess();

            // caoxh [mod] 2008-4-17
            return;
        }

#endif
        if (uNumCidToBeAct != 0)
        {
#ifdef AT_DUAL_SIM
            at_PppProcess(pParam->nDLCI, nSim);
#else
            at_PppProcess();
#endif
        }

        return;

        // ]] yy [mod] 2008-4-28 for the condition when no parameters offered
    }
    else if (AT_CMD_TEST == pParam->iType)
    {
        AT_MemSet(AtRet, 0, SIZEOF(AtRet));
        AT_Sprintf(AtRet, "+CGDATA: (\"PPP\")");
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI);
#endif
        return;
    }
    else
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

}

#endif // yy [mod] 2008-4-28 for ATE test
// ------------------------------------------------------------------------------------------
// Set command         |   Read command          |   Test command                          |
// AT+CGAUTO=[<n>]   |     AT+ CGAUTO?         |     AT+ CGAUTO =?                       |
// Response(s)         |   Response(s)           |   Response(s)                           |
// Success:        |     Success:            |     Success:                            |
// OK          |       +CGAUTO: <n>      |       +CGAUTO: (list of supported <n>s) |
// Fail:           |       OK                |       OK                                |
// ERROR       |     Fail:               |     Fail:                               |
// |       ERROR             |       ERROR                             |
// ------------------------------------------------------------------------------------------
VOID AT_GPRS_CmdFunc_CGAUTO(AT_CMD_PARA *pParam)
{
    UINT32 iResult;

    UINT8 uParamCount;
    UINT8 uStatus;
    UINT8 uSize;
    UINT8 attState;

    UINT8 pOutPutBuff[20] = { 0 };

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
    // input parameter check.

    if (NULL == pParam)
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    switch (pParam->iType)
    {

    case AT_CMD_SET:

        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);

        if (uParamCount > 1)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        if (FALSE == AT_Util_CheckValidateU8(pParam->pPara))
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        uSize = 1;

        iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uStatus, &uSize);

        if (ERR_SUCCESS != iResult)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

            return;
        }

        // [[ yy [mod] 2008-4-23 for Bug ID:8186
        if (uStatus > 3)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // ]] yy [mod ] 2008-4-23 for Bug ID:8186

        // Set the status of the auto response..
        gATCurrentu8nURCAuto = uStatus;

        if (uStatus == AUTO_RSP_STU_ON_PDONLY)
        {
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM
            iResult = CFW_GetGprsAttState(&attState, nSim);
#else
            iResult = CFW_GetGprsAttState(&attState);

#endif
#endif
            if (ERR_SUCCESS != iResult)
            {
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

                return;
            }

            if (attState == CFW_GPRS_DETACHED)
            {
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM
                iResult = CFW_GprsAtt(CFW_GPRS_ATTACHED, pParam->nDLCI, nSim);
#else
                iResult = CFW_GprsAtt(CFW_GPRS_ATTACHED, nParam->nDLCI);

#endif
#endif
                if (ERR_SUCCESS != iResult)
                {
#ifdef AT_DUAL_SIM
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

                    return;
                }
            }
        }

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif

        break;

    case AT_CMD_READ:

        // To do...
        // May be famat the string output...
        SUL_StrPrint(pOutPutBuff, "+CGAUTO: %d \0", gATCurrentu8nURCAuto);
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pOutPutBuff, AT_StrLen(pOutPutBuff), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pOutPutBuff, AT_StrLen(pOutPutBuff), pParam->nDLCI);
#endif

        break;

    case AT_CMD_TEST:

        SUL_StrPrint(pOutPutBuff, "+CGAUTO: (0-3)\0");

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pOutPutBuff, AT_StrLen(pOutPutBuff), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pOutPutBuff, AT_StrLen(pOutPutBuff), pParam->nDLCI);
#endif
        break;

    default:
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

        break;
    }

    return;

}

VOID AT_GPRS_CmdFunc_CGANS(AT_CMD_PARA *pParam)
{
    INT8 iResult      = 0;
    UINT8 uParamCount = 0;
    UINT8 uResponse   = 0;
    UINT8 uaL2P[10]   = { 0 };
    UINT8 uCidState   = 0;
    UINT8 uCid        = 0;
    UINT8 uUTI        = 0;
    UINT8 uParamLen   = 0;

    // INT8         i=0;
    UINT8 AtRet[100] = { 0 }; /* max 20 charactors per cid */
    CFW_GPRS_PDPCONT_INFO PdpCont_Info = {0,}; // yy [mod] 2008-6-27 for bug ID 8887


#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
    AT_Gprs_CidInfo  *g_staAtGprsCidInfo = g_staAtGprsCidInfo_e[nSim];
#endif

    if (NULL == pParam)
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    if (AT_CMD_SET == pParam->iType)
    {
        if (NULL == pParam->pPara)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // pPdpCont_Info = (CFW_GPRS_PDPCONT_INFO *)pParam->pPara;

        AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGANS\n");

        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);

        if ((iResult != ERR_SUCCESS) || (0 == uParamCount) || (uParamCount > 3))
        {
            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGANS, parameters error or no parameters offered \n");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // <response>
        uParamLen = 1;

        iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uResponse, &uParamLen);

        if ((iResult != ERR_SUCCESS) || (uResponse > 1))
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // <L2P>  ??? not supported, do nothing.
        if (uParamCount > 1)
        {
            uParamLen = sizeof(uaL2P);
            iResult   = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, uaL2P, &uParamLen);

            if (iResult != ERR_SUCCESS)
            {
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
        }

        // <cid>
        if (uParamCount > 2)
        {
            uParamLen = 1;
            iResult   = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_UINT8, &uCid, &uParamLen);

            if ((iResult != ERR_SUCCESS) || (uCid > AT_PDPCID_MAX))
            {
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
        }

        // [[ yy [add] 2008-6-27 for bug ID 8887
        // PDP type check
        if (!AT_MemCmp(uaL2P, "PPP", 3))
        {
            PdpCont_Info.nPdpType = CFW_GPRS_PDP_TYPE_PPP;  // yy [mod] 2008-6-27 for bug ID 8887
        }
        else if (!AT_MemCmp(uaL2P, "IP", 2))
        {
            PdpCont_Info.nPdpType = CFW_GPRS_PDP_TYPE_IP; // yy [mod] 2008-6-27 for bug ID 8887
        }
        else if (!AT_MemCmp(uaL2P, "IPV6", 4))
        {
            PdpCont_Info.nPdpType = CFW_GPRS_PDP_TYPE_IPV6; // yy [mod] 2008-6-27 for bug ID 8887
        }
        else
        {
            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGANS, PDP type error\n");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // ]] yy [add] 2008-6-27 for bug ID 8887
#ifndef AT_NO_GPRS

#ifdef AT_DUAL_SIM

        iResult = CFW_GetGprsActState(uCid, &uCidState, nSim);
#else
        iResult = CFW_GetGprsActState(uCid, &uCidState);

#endif
#endif
        if (iResult != ERR_SUCCESS)
        {
            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGANS, get PDP state error.");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }
        if (CFW_GPRS_ACTIVED == uCidState)
        {
            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGANS, the speicified PDP is alread activated");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        if (PdpCont_Info.nPdpType != g_staAtGprsCidInfo[uCid].nPdpType) // yy [mod] 2008-6-27 for bug ID 8887
        {
            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGANS, PDP type not match: %d, %d\n", PdpCont_Info.nPdpType, g_staAtGprsCidInfo[uCid].nPdpType); // yy [mod] 2008-6-27 for bug ID 8887
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // PDP address check
        if (g_staAtGprsCidInfo[uCid].nPdpAddrSize != 0)
        {
            // yy [mod] 2008-6-27 for bug ID 8887
            if (AT_MemCmp(PdpCont_Info.pPdpAddr, g_staAtGprsCidInfo[uCid].pPdpAddr, g_staAtGprsCidInfo[uCid].nPdpAddrSize))
            {
                AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGANS, PDP address not match\n");
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
        }

        iResult = AT_GetFreeUTI(CFW_GPRS_SRV_ID, &uUTI);

        if (iResult != ERR_SUCCESS)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

            return;
        }

        // execute ...
        if (0 == uResponse)
        {
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM
            iResult = CFW_GprsManualRej(uUTI, uCid, nSim);
#else
            iResult = CFW_GprsManualRej(uUTI, uCid,);

#endif
#endif
            if (iResult != ERR_SUCCESS)
            {
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

                return;
            }
        }
        else
        {
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM
            iResult = CFW_GprsManualAcc(uUTI, uCid, nSim);
#else
            iResult = CFW_GprsManualAcc(uUTI, uCid);

#endif
#endif
            if (iResult != ERR_SUCCESS)
            {
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

                return;
            }
        }

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
    }
    else if (AT_CMD_TEST == pParam->iType)
    {
        AT_MemSet(&AtRet, 0, SIZEOF(AtRet));

        // yy [mod] 2008-5-20 for bug ID 8468
        AT_MemCpy(AtRet, "+CGANS: (0,1) (\"PPP\")", AT_StrLen("+CGANS: (0,1) (\"PPP\")"));
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI);
#endif
        return;
    }
    else
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

        return;
    }

}

UINT8 g_uClassType = 0;
UINT8 AT_Get_ClassType()
{
    return g_uClassType;
}
VOID AT_Set_ClassType(UINT8 Class)
{
    g_uClassType = Class;
}
VOID AT_GPRS_CmdFunc_CGCLASS(AT_CMD_PARA *pParam)
{
    UINT8 iResult     = 0;
    UINT8 uParamCount = 0;
    UINT8 uSize = 0;

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

    UINT8 arrCharacterSet[5] = { 0 };
    UINT8 AtRet[50]   = { 0X00, };



    if (AT_CMD_SET == pParam->iType)
    {
        if (NULL == pParam->pPara)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);
        if ((iResult != ERR_SUCCESS) || (uParamCount != 1))
        {
            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGEREP, parameters error or no parameters offered \n");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }
        uSize   = SIZEOF(arrCharacterSet);
        iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, &arrCharacterSet, &uSize);


        if (iResult != ERR_SUCCESS)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        if (AT_StrCmp(arrCharacterSet, "A") == 0)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }
        else if (AT_StrCmp(arrCharacterSet, "B") == 0)
        {
            AT_Set_ClassType(CLASS_TYPE_B);
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
            return;
        }
        else if (AT_StrCmp(arrCharacterSet, "CG") == 0)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }
        else if (AT_StrCmp(arrCharacterSet, "CC") == 0)
        {

            AT_Set_ClassType(CLASS_TYPE_CC);
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
            return;
        }


    }

    else if (AT_CMD_READ == pParam->iType)
    {
        if(CLASS_TYPE_B == AT_Get_ClassType())
        {
            AT_Sprintf(AtRet, "+CGCLASS: B");
        }
        else if(CLASS_TYPE_CC == AT_Get_ClassType())
        {
            AT_Sprintf(AtRet, "+CGCLASS: CC");
        }
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI);
#endif
        return;
    }
    else if (AT_CMD_TEST == pParam->iType)
    {
        AT_Sprintf(AtRet, "+CGCLASS: B,CC,CG(NO SUPPORT),A(NO SUPPORT)");
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI);
#endif
        return;
    }
    else
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }
    return;

}

VOID AT_GPRS_CmdFunc_CGEREP(AT_CMD_PARA *pParam)
{
    UINT8 iResult     = 0;
    UINT8 uParamCount = 0;
    UINT8 uSize       = 0;
    UINT8 uState      = 0;
    UINT8 AtRet[20]   = { 0X00, };

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
    // pParam = pParam;
    // #ifdef DEBUG_AT
    if (NULL == pParam)
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    if (AT_CMD_SET == pParam->iType)
    {
        if (NULL == pParam->pPara)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);
        if ((iResult != ERR_SUCCESS) || (uParamCount != 1))
        {
            AT_TC(g_sw_GPRS, "exe       in AT_GPRS_CmdFunc_CGEREP, parameters error or no parameters offered \n");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        // get <state>
        uSize = 1;

        iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uState, &uSize);

        if ((iResult != ERR_SUCCESS) || ((uState != 1) && (uState != 0)))
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }
        if (uState == 1)
        {
            g_uATGprsCGEVFlag = 1;
        }
        else
        {
            g_uATGprsCGEVFlag = 0;
        }
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
        return;
    }
    else if (AT_CMD_READ == pParam->iType)
    {
        if (g_uATGprsCGEVFlag == 1)
        {
            AT_Sprintf(AtRet, "+CGEREP:1");
        }
        else if (g_uATGprsCGEVFlag == 0)
        {
            AT_Sprintf(AtRet, "+CGEREP:0");
        }
        else
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI);
#endif
        return;
    }
    else if (AT_CMD_TEST == pParam->iType)
    {
        AT_Sprintf(AtRet, "+CGEREP: (0,1)");
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, AtRet, AT_StrLen(AtRet), pParam->nDLCI);
#endif
        return;
    }
    else
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }
    return;

    // #endif
}

// This function to process the AT+CGREG command. include set,read and test command.
//
// Set command
// +CGREG= [<n>]
// Possible response(s)
// OK
// ERROR
//
// Read command
// +CGREG?
// Possible response(s)
// +CGREG: <n>,<stat>[,<lac>,<ci>]
// +CME ERROR: <err>
// Test command
// +CGREG=?
// Possible response(s)
// +CGREG: (list of supported <n>s)
//

VOID AT_GPRS_CmdFunc_CGREG(AT_CMD_PARA *pParam)
{
    UINT8 respond[80] = { 0 };
    INT32 iResult;
    UINT8 n = 0;
    UINT8 uSize;
    UINT8 uParamCount = 0;
    UINT32 uErrCode   = ERR_SUCCESS;
    UINT8 uIndex      = 0;
    CFW_NW_STATUS_INFO sStatus;

    // "CDMA-IS95B  5","LTE 14"
#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
    // input parameter check.

    if (NULL == pParam)
    {
        AT_TC(g_sw_GPRS, "AT+CGREG:NULL == pParam");
        uErrCode = ERR_AT_CME_PARAM_INVALID;
        goto _func_fail;
    }

    // Process the command. include icommand parameter checking,csw api calling,and responsing...
    if (AT_CMD_SET == pParam->iType)  // Set command.
    {
        // this comman have parameter.
        if (NULL == pParam->pPara)
        {
            AT_TC(g_sw_GPRS, "AT+CGREG:NULL == pParam->pPara");
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        // Get the count of parameters. This command have 1 parameters.
        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);

        if (iResult != ERR_SUCCESS || uParamCount != 1)
        {
            AT_TC(g_sw_GPRS, "AT+CGREG:Get Param count failed,iResult = 0x%x", iResult);
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        // Get the parameter list.
        // 1#
        // Get @n
        uSize = SIZEOF(n);

        uIndex = 0;

        iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &n, &uSize);

        if (ERR_SUCCESS != iResult)
        {
            AT_TC(g_sw_GPRS, "AT+CGREG:Get n failed,iResult = 0x%x.", iResult);
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        if (n > 2)
        {
            AT_TC(g_sw_GPRS, "AT+CGREG:The Prama n is error,n = 0x%x.", n);
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        g_uAtCgreg = n;

        goto _func_success;
    }
    else if (AT_CMD_READ == pParam->iType)  // Read command
    {
        UINT8  g_uAttState_t = 0;
#ifdef AT_DUAL_SIM

        CFW_GetGprsAttState(&g_uAttState_t, nSim);
#else
        CFW_GetGprsAttState(&g_uAttState_t);
#endif

#if 1
        if(CFW_GPRS_ATTACHED == g_uAttState_t )
        {

#ifdef AT_DUAL_SIM
            uErrCode = CFW_GprsGetstatus(&sStatus, nSim);
#else
            uErrCode = CFW_GprsGetstatus(&sStatus);

#endif
        }
        else
        {

#ifdef AT_DUAL_SIM

            uErrCode = CFW_NwGetStatus(&sStatus, nSim);
#else
            uErrCode = CFW_NwGetStatus(&sStatus);

#endif
            //  sStatus.nStatus = 1;
            sStatus.PsType = 0;
        }
#else

        // Modify for Android issue.
        // Because we make the power optimization for GPRS att. So we return CS status directly.
        // By Lixp 20121130

#ifdef AT_DUAL_SIM
        iResult = CFW_NwGetStatus(&sStatus, nSim);
#else
        iResult = CFW_NwGetStatus(&sStatus);
#endif
#endif

        if (uErrCode != ERR_SUCCESS)
        {
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }

        AT_TC(g_sw_GPRS, "nCellId[0]:%d, nCellId[1]:%d", sStatus.nCellId[0], sStatus.nCellId[1]);

        if ((0x00 != sStatus.nStatus) && (0x01 != sStatus.nStatus) && (0x05 != sStatus.nStatus))
        {
            sStatus.nStatus = 0;
        }

        // Looks like Android only needs 7 parameters
        // (CFW_GPRS_ATTACHED == g_uAttState)
        if (1 == 1)
        {
            // AT_Sprintf(respond, "+CGREG: %d,%d,\"%2.2X%2.2X\",\"%2.2X%2.2X\"",
            AT_Sprintf(respond, "+CGREG: %d,%d,\"%X%X\",\"%X%X\",%d",
                       g_uAtCgreg,
                       sStatus.nStatus,
                       sStatus.nAreaCode[0], sStatus.nAreaCode[1], sStatus.nCellId[0], sStatus.nCellId[1], sStatus.PsType);
        }
        else
        {
            AT_Sprintf(respond, "+CGREG: %d,%d", g_uAtCgreg, sStatus.nStatus);
        }

        // ]] yy [mod] 2008 -5-6 for Bug ID 8176
        goto _func_success;
    }

    // [[ yy[mod] at 2008-6-4 for bug ID 8676
    else if (AT_CMD_TEST == pParam->iType)
    {
        AT_StrCpy(respond, "+CGREG: (0-2)");
        goto _func_success;
    }
    else
    {
        uErrCode = ERR_AT_CME_OPTION_NOT_SURPORT;
        goto _func_fail;
    }

    // ]] yy[mod] at 2008-6-4 for bug ID 8676
_func_success:

#ifdef AT_DUAL_SIM
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, respond, AT_StrLen(respond), pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, respond, AT_StrLen(respond), pParam->nDLCI);
#endif

    return;

_func_fail:

#ifdef AT_DUAL_SIM
    AT_GPRS_Result_Err(uErrCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_Err(uErrCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

    return;

}

// This function to process the AT+CGSMS command. include set,read and test command.
//
// Set command
// +CGSMS= [<service>]
// Possible response(s)
// OK
// ERROR
//
// Read command
// +CGSMS?
// Possible response(s)
// +CGSMS: <service>
// +CME ERROR: <err>
// Test command
// +CGSMS=?
// Possible response(s)
// +CGSMS: (list of currently available <service>s)
//
VOID AT_GPRS_CmdFunc_CGSMS(AT_CMD_PARA *pParam)
{
    UINT8 *pResp = NULL;
    INT32 iResult;
    UINT8 uService = 1;
    UINT8 uSize;
    UINT8 uParamCount = 0;
    UINT32 uErrCode   = ERR_SUCCESS;

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
    // input parameter check.

    if (NULL == pParam)
    {
        uErrCode = ERR_AT_CME_PARAM_INVALID;
        goto _func_fail;
    }

    // Process the command. include icommand parameter checking,csw api calling,and responsing...
    if (AT_CMD_SET == pParam->iType)  // Set command.
    {

        // Get the count of parameters. This command have 1 parameters.
        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCount);

        if (iResult != ERR_SUCCESS || uParamCount > 1)
        {
            uErrCode = ERR_AT_CME_PARAM_INVALID;
            goto _func_fail;
        }
        else if (1 == uParamCount)
        {
            // Get the parameter list.
            // 1#
            // Get @Service
            uSize   = SIZEOF(uService);
            iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uService, &uSize);

            if (ERR_SUCCESS != iResult)
            {
                uErrCode = ERR_AT_CME_PARAM_INVALID;
                goto _func_fail;
            }
        }

        iResult = CFW_GprsSetSmsSeviceMode(uService);

        if (ERR_SUCCESS == iResult)
        {
            goto _func_success;
        }
        else
        {
            uErrCode = ERR_AT_CME_EXE_FAIL;
            goto _func_fail;
        }

    }
    else if (AT_CMD_READ == pParam->iType)  // Read command
    {

        iResult = CFW_GprsGetSmsSeviceMode(&uService);

        if (ERR_SUCCESS == iResult)
        {
            pResp = AT_MALLOC(16);

            if (NULL == pResp)
            {
                uErrCode = ERR_AT_CME_NO_MEMORY;
                goto _func_fail;
            }

            AT_MemSet(pResp, 0, SIZEOF(pResp));

            switch (uService)
            {

            case 0:
                AT_StrCpy(pResp, "+CGSMS:1");
                break;

            case 1:
                AT_StrCpy(pResp, "+CGSMS:0");
                break;

            case 2:
                AT_StrCpy(pResp, "+CGSMS:3");
                break;

            case 3:
                AT_StrCpy(pResp, "+CGSMS:2");
                break;

            default:
                uErrCode = ERR_AT_CME_EXE_NOT_SURPORT;
                goto _func_fail;
                break;
            }

            goto _func_success;
        }
        else
        {
            uErrCode = ERR_AT_CME_EXE_FAIL;
            goto _func_fail;
        }

    }
    else  // Test command.
    {
        pResp = AT_MALLOC(128);

        if (NULL == pResp)
        {
            uErrCode = ERR_AT_CME_NO_MEMORY;
            goto _func_fail;

        }
        AT_MemZero(pResp, 128);
        AT_StrCpy(pResp, "+CGSMS:0..3");

        goto _func_success;
    }

_func_success:

#ifdef AT_DUAL_SIM
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif

    if (NULL != pResp)
    {
        AT_FREE(pResp);
        pResp = NULL;
    }

    return;

_func_fail:

#ifdef AT_DUAL_SIM
    AT_GPRS_Result_Err(uErrCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
    AT_GPRS_Result_Err(uErrCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

    if (NULL != pResp)
    {
        AT_FREE(pResp);
        pResp = NULL;
    }

    return;

}

// -------------------------------------------------------------------------
// Set command         |   Read command          |   Test command
// AT+CRC=[<mode>]   |     AT+ CRC?            |     AT+ CRC =?
// Response(s)         |   Response(s)           |   Response(s)
// Success:        |     Success:            |     Success:
// OK          |       +CRC: <mode>      |       +CRC: (list of supported <mode>s)
// Fail:           |       OK                |       OK
// ERROR       |     Fail:               |     Fail:
// |       ERROR             |       ERROR
// --------------------------------------------------------------------
VOID AT_GPRS_CmdFunc_CRC(AT_CMD_PARA *pParam)
{
    INT32 iResult;
    UINT8 uParamCnt;

    UINT8 uSize;
    UINT8 uMode;

#define STR_LEN 20

    UINT8 pOutbuff[STR_LEN] = { 0 };

    // input parameter check.
#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
    if (NULL == pParam)
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    switch (pParam->iType)
    {

    case AT_CMD_SET:
        iResult = AT_Util_GetParaCount(pParam->pPara, &uParamCnt);

        if (uParamCnt > 1)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        if (FALSE == AT_Util_CheckValidateU8(pParam->pPara))
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        uSize = 1;

        iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uMode, &uSize);

        if (ERR_SUCCESS != iResult)
        {
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

            return;
        }

        if (uMode > 1)
        {
            AT_TC(g_sw_GPRS, "KEN :: +CRC set Mode invalide!!!");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
        }

        g_uAtURCFmt = uMode;

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
        break;

    case AT_CMD_TEST:

        SUL_ZeroMemory8(pOutbuff, STR_LEN);
        SUL_StrPrint(pOutbuff, "+CRC: (0,1)");  // yy [mod] for Bug ID: 8193
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pOutbuff, AT_StrLen(pOutbuff), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pOutbuff, AT_StrLen(pOutbuff), pParam->nDLCI);
#endif
        break;

    case AT_CMD_READ:

        SUL_ZeroMemory8(pOutbuff, STR_LEN);
        SUL_StrPrint(pOutbuff, "+CRC: %d", g_uAtURCFmt);

#ifdef AT_DUAL_SIM
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pOutbuff, AT_StrLen(pOutbuff), pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pOutbuff, AT_StrLen(pOutbuff), pParam->nDLCI);
#endif
        break;

    default:
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

        break;
    }

    return;
}

VOID AT_GPRS_CmdFunc_CGCID(AT_CMD_PARA *pParam)
{
    UINT8 nRet            = 0;
    UINT8 nCID            = 0;
    UINT8 pResp[20]       = { 0x00, };
    UINT8 uHelpString[30] = { 0X00, };

#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

    if (NULL == pParam)
    {
#ifdef AT_DUAL_SIM
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }
    else
    {
        switch (pParam->iType)
        {
        case AT_CMD_EXE:

            if (pParam->pPara == NULL)
            {
#ifdef AT_DUAL_SIM
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                return;
            }
            else
            {
#ifndef AT_NO_GPRS
#ifdef AT_DUAL_SIM
                nRet = CFW_GetFreeCID(&nCID, nSim);
#else
                nRet = CFW_GetFreeCID(&nCID);
#endif
#endif
                AT_TC(g_sw_GPRS, "AT+CGCID: Free CID = %d\n\r", nCID);

                if (ERR_SUCCESS == nRet)
                {

                    AT_Sprintf(pResp, "+CGCID:%d", nCID);

#ifdef AT_DUAL_SIM
                    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI, nSim);
#else
                    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pResp, AT_StrLen(pResp), pParam->nDLCI);
#endif
                    return;
                }

                else
                {
#ifdef AT_DUAL_SIM
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
                    AT_GPRS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
                    return;
                }
            }
            break;

        case AT_CMD_TEST:
            AT_StrCpy(uHelpString, "+CGCID: (1-7)");
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uHelpString, AT_StrLen(uHelpString), pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uHelpString, AT_StrLen(uHelpString), pParam->nDLCI);
#endif
            break;

        default:
#ifdef AT_DUAL_SIM
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
            AT_GPRS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
            return;
            break;
        }
    }
    return;
}

#ifdef AT_DUAL_SIM
VOID AT_GPRS_Result_OK(UINT32 uReturnValue,
                       UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize, UINT8 nDLCI, UINT8 nSim)
#else
VOID AT_GPRS_Result_OK(UINT32 uReturnValue,
                       UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize UINT8 nDLCI)
#endif
{
    PAT_CMD_RESULT pResult = NULL;

    // �������
    pResult = AT_CreateRC(uReturnValue,
                          uResultCode, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, nDelayTime, pBuffer, nDataSize, nDLCI);

    AT_Notify2ATM(pResult, nDLCI);

    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}

#ifdef AT_DUAL_SIM
VOID AT_GPRS_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI, UINT8 nSim)
#else
VOID AT_GPRS_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI)
#endif
{
    PAT_CMD_RESULT pResult = NULL;

#ifdef AT_DUAL_SIM
    AT_BACKSIMID(nSim);
#endif

    // �������
    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, uErrorCode, nErrorType, 0, 0, 0, nDLCI);

    AT_Notify2ATM(pResult, nDLCI);

    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}

VOID AT_GPRS_PPP_Terminate_Ind(UINT8 nDLCI)
{
    AT_TC(g_sw_GPRS, "AT_GPRS_PPP_Terminate_Ind nDLCI = %d", nDLCI);

    at_PppEndProcessMux(nDLCI); // wait for nDLCI parameter
}

UINT8 at_GprsGetMatchedPdpCid(CFW_GPRS_PDPCONT_INFO *pPdpInfo)
{
#if 0
    UINT8 uCnt;

    GPRSRETURN((pPdpInfo == NULL), AT_PDPCID_ERROR);

    for (uCnt = AT_PDPCID_MIN; uCnt <= AT_PDPCID_MAX; uCnt++) // yy [mod] 2008-5-26 for code review
    {
        if ((pPdpInfo->nPdpType == g_staAtGprsCidInfo[uCnt].nPdpType) && 1

                // (0 == SUL_StrCompare(g_staAtGprsCidInfo[uCnt].pPdpAddr, pPdpInfo->pPdpAddr))
           )
            return (uCnt);
    }
#endif
    return AT_PDPCID_ERROR;
}

UINT32 at_GprsGetCtxDefStatus(UINT8 cid)
{
#if 0
    UINT8 iCnt;

    for (iCnt = AT_PDPCID_MIN; iCnt <= AT_PDPCID_MAX; iCnt++) // yy [mod] 2008-5-26 for code review
    {
        if (g_staAtGprsCidInfo[iCnt].uCid == cid)
        {
            return cid;
        }
    }
#endif
    return (ERR_CFW_GPRS_INVALID_CID);
}

// [[ yy [del] 2008-7-1 for CSW update
#if 0
UINT32 CFW_GprsGetMinQos(UINT8 nCid, CFW_GPRS_QOS *pQos)
{
    nCid = 0;
    pQos = pQos;
    return 0;
}
#endif
// ]] yy [del] 2008-7-1 for CSW update

UINT32 CFW_GprsGetSmsSeviceMode(UINT8 *pnService)
{
    pnService = pnService;

    return 0;
}

UINT32 CFW_GprsSetSmsSeviceMode(UINT8 nService)
{
    nService = nService;
    return 0;
}

// [[caoxh [+] 2008-4-17
// This function response "CONNECT" and change to data staues.
#ifdef AT_DUAL_SIM
VOID at_PppProcess(UINT8 nDLCI, UINT8 nSim)
#else
VOID at_PppProcess()
#endif
{
    AT_TC(g_sw_GPRS, "________________-", 1);
#ifdef AT_DUAL_SIM
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_CONNECT, 0, NULL, 0, nDLCI, nSim);
#else
    AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_CONNECT, 0, NULL, 0, nDLCI);
#endif
    /*
    if (bMuxActiveStatus)
    {
        AT_TC(g_sw_GPRS, "________________-", 1);
        SA_SetSysStatusMux(SA_ATCMD_CGDATA_RESULT, SA_ATCMD_CGDATA_OK, nDLCI);
        g_uAtGprsEnterDataModeMux[nDLCI] = 1;
    }
    else
      */
    {
        SA_SetSysStatus(SA_ATCMD_CGDATA_RESULT, SA_ATCMD_CGDATA_OK);
        g_uAtGprsEnterDataMode = 1;
    }
}

// ]]caoxh [+] 2008-04-19

// [[ yy [add] 2008-5-14 for PPP
VOID at_PppEndProcess()
{
    //SA_SetSysStatus(SA_ATCMD_3PLUS_RESULT, SA_ATCMD_3PLUS_OK);
    SA_SetSysStatus(SA_ATCMD_ATH_RESULT, SA_ATCMD_ATH_OK);
    g_uAtGprsEnterDataMode = 0;
}

// ]] yy [add] 2008-5-14 for PPP

VOID at_PppEndProcessMux(UINT8 nDLCI)
{
    // SA_SetSysStatusMux(SA_ATCMD_3PLUS_RESULT, SA_ATCMD_3PLUS_OK, nDLCI);
    SA_SetSysStatusMux(SA_ATCMD_ATH_RESULT, SA_ATCMD_ATH_OK, nDLCI);
    g_uAtGprsEnterDataModeMux[nDLCI] = 0;
}

INT32 AT_GPRS_IPAddrAnalyzer(UINT8 *pPdpAddr, UINT8 uSize)
{
    UINT8 i       = 0;
    UINT8 j       = 0;
    UINT8 m       = 0;
    UINT8 uBuf[4] = { 0 };
    UINT8 uIpNum  = 0;

    AT_TC(g_sw_GPRS, "pPdpAddr: %s, uSize: %d", pPdpAddr, uSize);

    if ((NULL == pPdpAddr) || (0 == uSize))
    {
        return - 1;
    }

    for (i = 0; i < 4; i++)
    {
        m = 0;

        while ((pPdpAddr[j] != '.') && (j < uSize))
        {
            uBuf[m++] = pPdpAddr[j++];
        }

        uIpNum = atoi(uBuf);

        AT_TC(g_sw_GPRS, "uBuf: %s, uIpNum: %d, j: %d", uBuf, uIpNum, j);

        if ((uBuf[0] != '0') && (uIpNum < 1 || uIpNum > 254))
        {
            return - 1;
        }

        AT_MemSet(uBuf, 0, 4);

        j++;
    }

    return 1;
}
extern  UINT8 PPP_findIdxByMuxid(UINT8 Muxid );
VOID PPP_SetInvoidByMuxid(UINT8 Muxid );
VOID AT_CLearGprsCtx(UINT8 nDLCI)
{
    g_uAtWaitActRsp[nDLCI] = 0;
    if(g_uAtGprsCidNum)
        g_uAtGprsCidNum--;

    PPP_SetInvoidByMuxid(nDLCI);
    // ppp_InitPPPVarsByIdx( PPP_findIdxByMuxid(nDLCI));
}
#ifdef AT_FTP_SUPPORT
#ifdef FTP_FLASH_TST
UINT8 g_FTPTstData[0x1000]={
0,
};
#endif
#define FTP_FILE_NAME_LEN 100
#define FTP_FILE_NUM_LEN 5
#define FTP_FILE_RECEIVE_NUM 1024*10
extern UINT8 gFileData[] ;
UINT32 gFileReceiveSize = 0;
UINT8 gFileName[FTP_FILE_NAME_LEN]={0,};
UINT8 gFileReceiveNum[FTP_FILE_RECEIVE_NUM] = {0,};
char* AT_FTP_strstr(const char *s1,const char *s2) 
{ 
    UINT8 len2;
    if(!(len2=AT_StrLen(s2)))   // ���������s2����ָ��գ�����strlen�޷�������ȣ����������� 
        return (char*)s1; 

    for(;*s1;++s1)
    {
        if(*s1==*s2&&AT_StrNCmp(s1, s2,len2))
            return (char*)s1;
    }
    return NULL;
}

static INT32 AT_FTP_GetLine(UINT8 *OLine)
{
    static UINT8 *pData =gFileData;
//  static UINT8 *pData =g_FTPTstData;

    UINT8 *pLineHead = pData;
    
    AT_TC(g_sw_GPRS, "AT_FTP_GetLine start!");

    if( NULL == OLine )
    {
        AT_TC(g_sw_GPRS, "AT_FTP_GetLine para error!");
        return  -1;
    }
    while(1)
    {
        if(0 == *pData )
            return 1; // 1: means we have pocess all FTP data

        if( (0x0D == *pData) && (0x0A == *(pData+1) ))
        {
            if(pData > pLineHead)
                AT_MemCpy(OLine,pLineHead,pData -pLineHead);
            pData = pData +2;//go to the next line
            break;
        }
        pData++;
    }
    //0:means we have other data need to pocess
    return 0;
}
static INT32 AT_FTP_DiscardInvalidLine(UINT8 *ILine)
{
    UINT8 *pData = ILine;
    UINT8 nSize =AT_StrLen(ILine);
    
    if( NULL == ILine)
    {
        AT_TC(g_sw_GPRS, "DiscardInvalidLine para error!");
        return  -1;
    }

    if( *pData != '-' )
    {
        return 1; // isn't file
    }

    if(AT_MemCmp(pData+nSize-4, ".lod", 4) != 0 )
    {
        return 2; // isn't .lod file
    }
    
    return 0;
}
static INT32 AT_FTP_CompareWithProductStr(UINT8 *IName)
{
    UINT8 *pData = IName;
    UINT8 nProductStr[20]={0,};
    
    AT_Sprintf(nProductStr, "%s", tgt_GetBuildVerNo());
    
    if( NULL == IName)
    {
        AT_TC(g_sw_GPRS, "CompareWithProductStr para error!");
        return  -1;
    }

    if( 0 == AT_StrLen(nProductStr))
        return 1; //no define CT_PRODUCT

    if( (NULL == AT_FTP_strstr(IName,nProductStr) ))
        return 2; // isn't sub str
        
    return 0;
}

static INT32 AT_FTP_FindFileName(UINT8 *ILine,UINT8 *OName)
{
    UINT8 *pLineDate = ILine;
    UINT8 index =0;
    UINT8 SegmentNum= 0;
    UINT8 nNameSize = 0;
    
    if( NULL == ILine || NULL == OName)
    {
        AT_TC(g_sw_GPRS, "AT_FTP_FindFileName para error!");
        return  -1;
    }
    
    AT_TC(g_sw_GPRS, "AT_FTP_FindFileName IlINE:%s",ILine);
    //-rwxrw-rw-  1 root root 70 Dec 4 13:56 1.log
    while(1)
    {
        if( 32 == *pLineDate )
        {
            if(pLineDate[1] != 32)
            SegmentNum++;   
        }
        pLineDate++;
        if(8 == SegmentNum)
            break;
    }

    AT_StrCpy(OName, pLineDate);
    return 0;
}
INT32 AT_FTP_GetTheNewestFile(UINT8 *OFileName)
{
    INT32 iRet = 0;
    UINT8 *pFileList = gFileData;
//  UINT8 *pFileList = g_FTPTstData;
    UINT8 *pFileName = OFileName;
    UINT8 index = 0;
    UINT8 *pTemp= NULL;
    UINT8 *pNewest = NULL;
    UINT8 nTempName[FTP_FILE_NAME_LEN] ={0,};
    UINT8 nTheNewestName[FTP_FILE_NAME_LEN] ={0,};
    UINT8 nTempLine[FTP_FILE_NAME_LEN*2] ={0,};
    UINT8 nTmpSize = 0;
    UINT8 nNewestSize = 0;
    
    if(NULL == OFileName )
    {
        AT_TC(g_sw_GPRS, "FTP_GetNewFile para error!");
        return -1;
    }
    while(1)
    {
        AT_MemZero(nTempLine, FTP_FILE_NAME_LEN*2);
        iRet = AT_FTP_GetLine(nTempLine);
        if(-1 == iRet) return -2; //para is error
        if(1 == iRet) break;//we have process all data
        if(0 == iRet)
        {
            iRet = AT_FTP_DiscardInvalidLine(nTempLine);
            if(-1 == iRet ) return -3; //para is error
            if(0 == iRet )
            {
                AT_MemZero(nTempName, FTP_FILE_NAME_LEN);
                iRet = AT_FTP_FindFileName(nTempLine,nTempName);
                if(iRet != 0) return -4; //para is error
                iRet = AT_FTP_CompareWithProductStr(nTempName);
                if(-1 == iRet ) return -5; //para is error
                if(0 == iRet )
                {
                    //Compare the file name
                    if( 0 ==( nNewestSize = AT_StrLen(nTheNewestName)))
                        AT_StrCpy(nTheNewestName, nTempName);
                    nTmpSize = AT_StrLen(nTempName);
                    pTemp   = nTempName;
                    pNewest = nTheNewestName;
                    if(nTmpSize > 9 && nNewestSize >9
                        &&AT_MemCmp(pNewest+nNewestSize -9, pTemp +nTmpSize -9 ,FTP_FILE_NUM_LEN) < 0)
                    {
                        AT_MemZero(nTheNewestName, FTP_FILE_NAME_LEN);
                        AT_StrCpy(nTheNewestName, nTempName);
                    }
                }
            }
        }

    }

    AT_StrCpy(OFileName, nTheNewestName);
    return 0;
}
VOID AT_FTP_AsyncEventProcess(COS_EVENT *pEvent)
{
    CFW_EVENT CFWev;
    CFW_EVENT *pcfwEv = &CFWev;
    UINT8 OutStr[50];
    INT32 iRet = 0;
    INT32 iRcvRet = 0;
    memset(OutStr, 0, 50);
    AT_CosEvent2CfwEvent(pEvent, pcfwEv);
#ifdef AT_DUAL_SIM
    UINT8 nSim = pcfwEv->nFlag;
#endif

    AT_TC(g_sw_GPRS, "AT_FTP_AsyncEventProcess eventID: %d", pEvent->nEventId);
    switch (pEvent->nEventId)
    {
    case EV_CFW_FTP_LONGIN_RSP:
    {
        //UINT8 nRsp[20]={0,};
        //AT_Sprintf(nRsp, "%s", tgt_GetBuildVerNo());
        //AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, nRsp, AT_StrLen(nRsp), pcfwEv->nUTI, nSim);
        //AT_TC(g_sw_GPRS, "EV_CFW_FTP_LONGIN_RSP %s", nRsp);
#ifdef FTP_FLASH_TST
        UINT32 i,j;
        UINT8 value = 0x0;

        hal_HstSendEvent(0xfa122501);
        UINT32 cri_status;
//      cri_status = hal_SysEnterCriticalSection();
        for(i = 0; i <0x1a0; i++)
        {
            for(j = 0; j < 0x1000; j++)
            {
                g_FTPTstData[j] = value;
                if(value < 0xff)
                {
                    value ++;
                }
                else
                {
                    value = 0;
                }
            }
        
            iRet= UPG_WriteFlash(g_FTPTstData, 0x1000);
            if(iRet != 0)
            AT_TC(g_sw_GPRS, "UPG_WriteFlash ERROR iRet: %d", iRet);
              hal_HstSendEvent(0xfa122505);
           hal_HstSendEvent(iRet);

        }
//      hal_SysExitCriticalSection(cri_status);
#else
        //CFW_FTPGetFile("lixp/1.log");
        CFW_FTPchangeDir("lixp");
#endif
        break;
    }
    case EV_CFW_FTP_FILE_DOWNLOAD_RSP:
    {
//      AT_TC_MEMBLOCK(g_sw_GPRS, gFileData, 1024, 16);
//      COS_Sleep(200);
//      AT_TC(g_sw_GPRS, "FTP_FILE_DOWNLOAD_RSP: %s", gFileData);
//      COS_Sleep(200);
        //size just for test,we need get from wuys!
        if(0x0f == pEvent->nParam1)
        {
            //maybe we need close conect,
            AT_TC(g_sw_GPRS, "FTP transfer file ERROR iRet:%d", iRet);
            break ;
        }
              //write the last data
              UINT32 nRcvNum = gFileReceiveSize;
        while(nRcvNum > 0)
        {   
            AT_MemZero(gFileReceiveNum, FTP_FILE_RECEIVE_NUM);
            if(nRcvNum > FTP_FILE_RECEIVE_NUM)
            {
                iRcvRet = ftp_ReadRxDataFromBuffer(gFileReceiveNum, FTP_FILE_RECEIVE_NUM);
                if( iRcvRet > 0 )
                {
                    iRet= UPG_WriteFlash(gFileReceiveNum, iRcvRet);
                    if(iRet != 0)
                    {
                        AT_TC(g_sw_GPRS, "WriteFlash ERROR iRet:%d", iRet);
                    }
                    else
                    {
                        nRcvNum -=iRcvRet;
                    }
                }
                else
                {
                    AT_TC(g_sw_GPRS, "DATA_IND ReadRxData ERROR iRet:%d", iRcvRet);
                }
            }
            else
            {
                iRcvRet = ftp_ReadRxDataFromBuffer(gFileReceiveNum, nRcvNum);
                if( iRcvRet > 0 )
                {
                    iRet= UPG_WriteFlash(gFileReceiveNum, iRcvRet);
                    if(iRet != 0)
                    {
                        AT_TC(g_sw_GPRS, "WriteFlash ERROR iRet:%d", iRet);
                    }
                    else
                    {
                        nRcvNum -=iRcvRet;
                    }
                }
                else
                {
                    AT_TC(g_sw_GPRS, "DATA_IND ReadRxData ERROR iRet:%d", iRcvRet);
                }
            }
        }

        hal_HstSendEvent(0xfa122505);
        hal_HstSendEvent(iRet);

        break;
    }
    case EV_CFW_FTP_LIST_RSP:
    {
        UINT8 nNewestNmae[FTP_FILE_NAME_LEN]={0,};
        AT_TC_MEMBLOCK(g_sw_GPRS, gFileData, 1024, 16);
//      COS_Sleep(200);
//      AT_TC(g_sw_GPRS, "FTP_LIST_RSP: %s", gFileData);
//      COS_Sleep(200);
        AT_FTP_GetTheNewestFile(nNewestNmae);
        AT_TC(g_sw_GPRS, "FTP_LIST_RSP: %s", nNewestNmae);
        hal_HstSendEvent(0xfa122503);
        hal_HstSendEvent(nNewestNmae[0]);

        if(0 == nNewestNmae[0])
        {
            AT_TC(g_sw_GPRS, "FTP_LIST_RSP: ERROR! NO the newest file");
        }
        else
        {
            UINT32 nOffset= 0;
            UINT8 nFlshFileSize = 0;
            UINT8 nFlshFileNmae[200]= {0x0,};
            if(UPG_GetLodInfo(nFlshFileNmae,&nFlshFileSize))
            {
                AT_TC(g_sw_GPRS, "FTP_LIST_RSP: ERROR! GetLodInfo");
                break;
            }
#ifdef AT_FTP_UPDATE
            //have get file
            if((nFlshFileSize > 0)&&(nFlshFileNmae[0] != 0))
            {
                nOffset = UPG_GetCurrentPos();
                AT_TC(g_sw_GPRS, "FTP_LIST_RSP: nOffset:%d", nOffset);
            }

            iRet = CFW_FTPGetFile(nNewestNmae,nOffset);
            if(ERR_SUCCESS != iRet)
                AT_TC(g_sw_GPRS, "FTP_LIST_RSP: ERROR! FTPGetFile");
#else
            //have get file
            if((nFlshFileSize > 0)&&(nFlshFileNmae[0] != 0))
            {
                UINT8 nTmpSize = AT_StrLen(nFlshFileNmae);
                UINT8 nNewestSize = AT_StrLen(nNewestNmae);
                UINT8 *pTemp= nFlshFileNmae;
                UINT8 *pNewest = nNewestNmae;
                AT_TC(g_sw_GPRS, "FTP_LIST_RSP: nTmpSize:%d", nTmpSize);
                if(nTmpSize > 9 && nNewestSize >9
                    &&AT_MemCmp(pNewest+nNewestSize -9, pTemp +nTmpSize -9 ,FTP_FILE_NUM_LEN) > 0)
                {
                    iRet = UPG_SetLodInfo(nNewestNmae, nNewestSize);
                    if(ERR_SUCCESS != iRet)
                        AT_TC(g_sw_GPRS, "FTP_LIST_RSP: ERROR! SetLodInfo");

                    iRet = UPG_SetUpgEnable();
                    if(ERR_SUCCESS != iRet)
                        AT_TC(g_sw_GPRS, "FTP_LIST_RSP: ERROR! SetUpgEnable");

                }

            }
#endif
        }
        break;
    }
    case EV_CFW_FTP_CHANGEDIR_RSP:
    {
        hal_HstSendEvent(0xfa122502);
        CFW_FTPListDir();
        //AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, AT_ASYN_GET_DLCI(nSim), nSim);
        break;
    }
    case EV_CFW_FTP_REC_DATA_IND:
    {
        static UINT32 nReceiveNum = 0;
        if(0 == nReceiveNum)
        {
            UINT32 nFileSize = CFW_FTPGetFileSize();
            if(!UPG_CheckSize(nFileSize))
            {
                hal_HstSendEvent(0xfa122504);
                hal_HstSendEvent(nFileSize);
                AT_TC(g_sw_GPRS, "REC_DATA_IND ERROR ,lod file is too bigger:%d", nFileSize);
                AT_ASSERT(0);
                return ;
            }
        }
        hal_HstSendEvent(0xfa122506);
        if( pEvent->nParam1 > FTP_FILE_RECEIVE_NUM)
        {
            nReceiveNum += pEvent->nParam1;
            while(nReceiveNum > 0)
            {   
                AT_MemZero(gFileReceiveNum, FTP_FILE_RECEIVE_NUM);
                if(nReceiveNum > FTP_FILE_RECEIVE_NUM)
                {
                    iRcvRet = ftp_ReadRxDataFromBuffer(gFileReceiveNum, FTP_FILE_RECEIVE_NUM);
                    if( iRcvRet > 0 )
                    {
                        iRet= UPG_WriteFlash(gFileReceiveNum, iRcvRet);
                        if(iRet != 0)
                        {
                            AT_TC(g_sw_GPRS, "WriteFlash ERROR iRet:%d", iRet);
                        }
                        else
                        {
                            nReceiveNum -=iRcvRet;
                        }
                    }
                    else
                    {
                        AT_TC(g_sw_GPRS, "DATA_IND ReadRxData ERROR iRet:%d", iRcvRet);
                    }
                }
                else
                {
                    iRcvRet = ftp_ReadRxDataFromBuffer(gFileReceiveNum, nReceiveNum);
                    if( iRcvRet > 0 )
                    {
                        iRet= UPG_WriteFlash(gFileReceiveNum, iRcvRet);
                        if(iRet != 0)
                        {
                            AT_TC(g_sw_GPRS, "WriteFlash ERROR iRet:%d", iRet);
                        }
                        else
                        {
                            nReceiveNum -=iRcvRet;
                        }
                    }
                    else
                    {
                        AT_TC(g_sw_GPRS, "DATA_IND ReadRxData ERROR iRet:%d", iRcvRet);
                    }
                }
            }
        }
        else if(nReceiveNum + pEvent->nParam1 > FTP_FILE_RECEIVE_NUM)
        {
            AT_MemZero(gFileReceiveNum, FTP_FILE_RECEIVE_NUM);
            iRcvRet = ftp_ReadRxDataFromBuffer(gFileReceiveNum, nReceiveNum);
            if( iRcvRet > 0 )
            {
                iRet= UPG_WriteFlash(gFileReceiveNum, iRcvRet);
                if(iRet != 0)
                {
                    AT_TC(g_sw_GPRS, "WriteFlash ERROR iRet:%d", iRet);
                }
                else
                {
                    nReceiveNum -=iRcvRet;
                }
            }
            else
            {
                AT_TC(g_sw_GPRS, "DATA_IND ReadRxData ERROR iRet:%d", iRcvRet);
            }
            nReceiveNum += pEvent->nParam1;

            hal_HstSendEvent(0xfa122505);
            hal_HstSendEvent(iRet);
        }
        else
        {
            nReceiveNum += pEvent->nParam1;
        }
        gFileReceiveSize = nReceiveNum;

        //AT_GPRS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, AT_ASYN_GET_DLCI(nSim), nSim);
        break;
    }

    default :
        break;

    }

}
#ifndef  AT_FTP_UPDATE
UINT32 AT_FTP_CxtAct(UINT8 *pCid, CFW_SIM_ID nSim)
{   
    UINT32 nRet = ERR_SUCCESS;
    CFW_GPRS_PDPCONT_INFO pdp_cont;
    UINT8 nCid = 0;
    
    pdp_cont.nApnSize = 5;
    pdp_cont.pApn = "CMNET";

    pdp_cont.nApnUserSize = 3;
    pdp_cont.pApnUser = "wap";
    pdp_cont.nApnPwdSize = 3;
    pdp_cont.pApnPwd = "wap";

    pdp_cont.nPdpAddrSize = 0;
    pdp_cont.pPdpAddr = NULL;
    pdp_cont.nDComp = 0;
    pdp_cont.nHComp = 0;
    pdp_cont.nPdpType = CFW_GPRS_PDP_TYPE_IP;
    
    nRet = CFW_GetFreeCID(&nCid, nSim);
    if(nRet != ERR_SUCCESS)
    {
        AT_TC(g_sw_GPRS, "CxtAct GetFreeCID ERROR nRet:%d", nRet);
        return nRet;
    }
    *pCid  = nCid;

    nRet = CFW_GprsSetPdpCxt(nCid, &pdp_cont, nSim);
    if(nRet != ERR_SUCCESS)
    {
        AT_TC(g_sw_GPRS, "CxtAct SetPdpCxt ERROR nRet:%d", nRet);
        return nRet;
    }
    AT_GetFreeUTI(0, &gATFTPUti);
    nRet = CFW_GprsAct(CFW_GPRS_ACTIVED, nCid, gATFTPUti, nSim);
    if(nRet != ERR_SUCCESS)
    {
        AT_TC(g_sw_GPRS, "CxtAct GprsAct ERROR nRet:%d", nRet);
        return nRet;
    }

    return ERR_SUCCESS;
}
UINT32 AT_FTP_Refresh(CFW_SIM_ID nSim)
{
    UINT32 nRet = ERR_SUCCESS;
    UINT8   nState = 0;
    nRet = CFW_GetGprsAttState(&nState, nSim);
    if(nRet != ERR_SUCCESS)
    {
        AT_TC(g_sw_GPRS, "Refresh GprsAttState ERROR nRet:%d", nRet);
        return nRet;
    }

    if(1 == nState)
    {
        UINT8 nCid = 0;
        nRet = AT_FTP_CxtAct(&nCid,nSim);
        if(nRet != ERR_SUCCESS)
        {
            AT_TC(g_sw_GPRS, "Refresh CxtAct ERROR nRet:%d", nRet);
            return nRet;
        }

        gATFTPState = 2|(nCid<<4);
    }
    else
    {
        UINT8 nUti =0;
        nRet=CFW_GetFreeUTI(0, &nUti);
        if(nRet != ERR_SUCCESS)
        {
            AT_TC(g_sw_GPRS, "Refresh GprsAtt ERROR nRet:%d", nRet);
            return nRet;
        }
        nRet = CFW_GprsAtt(1, nUti, nSim);
        if(nRet != ERR_SUCCESS)
        {
            AT_TC(g_sw_GPRS, "Refresh GprsAtt ERROR nRet:%d", nRet);
            return nRet;
        }
        gATFTPUti = nUti;
        gATFTPState = 1;
    }
    
    return ERR_SUCCESS;
}
#endif
#endif //AT_FTP_SUPPORT

#endif //CFW_GPRS_SUPPORT

