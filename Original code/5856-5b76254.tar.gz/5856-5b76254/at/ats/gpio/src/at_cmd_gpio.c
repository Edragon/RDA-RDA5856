/*
 * Copyright (c) 2006-2016 RDA Microelectronics, Inc.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#include "at_common.h"


#if defined(__AT_MOD_GPIO__)
#include "hal_gpio.h"

VOID AT_GPIO_Result_OK(UINT32 uReturnValue, UINT32 uResultCode,
			UINT8 nDelayTime, UINT8* pBuffer, UINT16 nDataSize, UINT8 nDLCI)

{
	PAT_CMD_RESULT pResult = NULL;

	pResult = AT_CreateRC(uReturnValue, uResultCode, CMD_ERROR_CODE_OK,
		CMD_ERROR_CODE_TYPE_CME, nDelayTime, pBuffer, nDataSize, nDLCI);

	AT_Notify2ATM(pResult, nDLCI);

	if (pResult != NULL) {
		AT_FREE(pResult);
		pResult = NULL;
	}

	return;
}

VOID AT_GPIO_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI)
{
	PAT_CMD_RESULT pResult = NULL;

	pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, uErrorCode, nErrorType, 0, 0, 0, nDLCI);

	AT_Notify2ATM(pResult, nDLCI);

	if (pResult != NULL) {
		AT_FREE(pResult);
		pResult = NULL;
	}

	return;
}

VOID AT_GPIO_CmdFunc_SetMode(AT_CMD_PARA* pParam)
{
	if (NULL == pParam) {
		goto iOpen_ERROR;
	} else {
		if (NULL == pParam->pPara) {
			goto iOpen_ERROR;
		}

		switch (pParam->iType) {
			case AT_CMD_SET: {
				UINT8 value = 0;
				UINT16 Len = 0;
				UINT8 uNumOfParam = 0;
				HAL_GPIO_GPIO_ID_T gpio;
				HAL_GPIO_ALTFUNC_CFG_ID_T cfg;

				if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam)) {
					goto iOpen_ERROR;
				}

				if (2 != uNumOfParam) {
					goto iOpen_ERROR;
				}

				// get gpio.
				Len = 1;
				AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &value, &Len);
				gpio = (HAL_GPIO_GPIO_ID_T) (HAL_GPIO_0_0 + value);
				if ((gpio < HAL_GPIO_0_0) || (gpio > HAL_GPIO_4_7)) {
					goto iOpen_ERROR;
				}

				// get mode.
				Len = 1;
				AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &value, &Len);
				if ((value < HAL_GPIO_ALTFUNC_CFG_0) || (value >= HAL_GPIO_ALTFUNC_CFG_QTY)) {
					goto iOpen_ERROR;
				}
				cfg = (HAL_GPIO_ALTFUNC_CFG_ID_T) (value);

				hal_GpioSetPinMux(gpio, cfg);

				AT_TC(g_sw_SA, "AT_GPIO_CmdFunc_SetMode, gpio=0x%x, value=%d", gpio, value);

				AT_GPIO_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
				return;
			}
			default: {
				goto iOpen_ERROR;
			}
		}
	}

iOpen_ERROR:
		AT_GPIO_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
}

VOID AT_GPIO_CmdFunc_SetDir(AT_CMD_PARA* pParam)
{
	if (NULL == pParam) {
		goto iOpen_ERROR;
	} else {
		if (NULL == pParam->pPara) {
			goto iOpen_ERROR;
		}

		switch (pParam->iType) {
			case AT_CMD_SET: {
				UINT8 value = 0;
				UINT16 Len = 0;
				UINT8 uNumOfParam = 0;
				HAL_GPIO_GPIO_ID_T gpio;
				//HAL_GPIO_ALTFUNC_CFG_ID_T cfg;

				if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam)) {
					goto iOpen_ERROR;
				}

				if (2 != uNumOfParam) {
					goto iOpen_ERROR;
				}

				// get gpio.
				Len = 1;
				AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &value, &Len);
				gpio = (HAL_GPIO_GPIO_ID_T) (HAL_GPIO_0_0 + value);
				if ((gpio < HAL_GPIO_0_0) || (gpio > HAL_GPIO_4_7)) {
					goto iOpen_ERROR;
				}

				// get direction value and set.
				Len = 1;
				AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &value, &Len);
				if (value == 0) {
					hal_GpioSetOut(gpio);
				} else {
					hal_GpioSetIn(gpio);
				}
				AT_TC(g_sw_SA, "AT_GPIO_CmdFunc_SetDir, gpio=0x%x, value=%d", gpio, value);

				AT_GPIO_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
				return;
			}
			default: {
				goto iOpen_ERROR;
			}
		}
	}

iOpen_ERROR:
		AT_GPIO_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
}

VOID AT_GPIO_CmdFunc_SetValue(AT_CMD_PARA* pParam)
{
	if (NULL == pParam) {
		goto iOpen_ERROR;
	} else {
		if (NULL == pParam->pPara) {
			goto iOpen_ERROR;
		}

		switch (pParam->iType) {
			case AT_CMD_SET: {
				UINT8 value = 0;
				UINT16 Len = 0;
				UINT8 uNumOfParam = 0;
				HAL_GPIO_GPIO_ID_T gpio;

				if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam)) {
					goto iOpen_ERROR;
				}

				if (2 != uNumOfParam) {
					goto iOpen_ERROR;
				}

				// get gpio.
				Len = 1;
				AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &value, &Len);
				gpio = (HAL_GPIO_GPIO_ID_T) (HAL_GPIO_0_0 + value);
				if ((gpio < HAL_GPIO_0_0) || (gpio > HAL_GPIO_4_7)) {
					goto iOpen_ERROR;
				}

				// get value and set.
				HAL_APO_ID_T apo = { .gpioId= gpio};
				Len = 1;
				AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &value, &Len);
				if (value == 0) {
					hal_GpioClr(apo);
				} else {
					hal_GpioSet(apo);
				}

				AT_TC(g_sw_SA, "AT_GPIO_CmdFunc_SetValue, gpio=0x%x, value=%d", gpio, value);

				AT_GPIO_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
				return;
			}
			default: {
				goto iOpen_ERROR;
			}
		}
	}

iOpen_ERROR:
		AT_GPIO_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
}

VOID AT_GPIO_CmdFunc_GetValue(AT_CMD_PARA* pParam)
{
	if (NULL == pParam) {
		goto iOpen_ERROR;
	} else {
		if (NULL == pParam->pPara) {
			goto iOpen_ERROR;
		}

		switch (pParam->iType) {
			case AT_CMD_SET: {
				UINT8 value = 0;
				UINT16 Len = 0;
				UINT8 uNumOfParam = 0;
				HAL_GPIO_GPIO_ID_T gpio;

				if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam)) {
					goto iOpen_ERROR;
				}

				if (1 != uNumOfParam) {
					goto iOpen_ERROR;
				}

				// get gpio.
				Len = 1;
				AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &value, &Len);
				gpio = (HAL_GPIO_GPIO_ID_T) (HAL_GPIO_0_0 + value);
				if ((gpio < HAL_GPIO_0_0) || (gpio > HAL_GPIO_4_7)) {
					goto iOpen_ERROR;
				}

				// get gpio value and return.
				UINT8 str_value[8] = {0};

				value = hal_GpioGet(gpio);
				memset(str_value, 0, sizeof(str_value));
				sprintf(str_value, "%d", value);

				AT_TC(g_sw_SA, "AT_GPIO_CmdFunc_GetValue, gpio=0x%x, value=%d", gpio, value);

				AT_GPIO_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, str_value, strlen(str_value), pParam->nDLCI);
				return;
			}
			default: {
				goto iOpen_ERROR;
			}
		}
	}

iOpen_ERROR:
		AT_GPIO_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
}

#endif
