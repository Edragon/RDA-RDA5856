/*********************************************************
 *
 * File Name
 *	?
 * Author
 * 	?
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 *
 *********************************************************/

#include "at_common.h"
#include "at_module.h"
#include "at_cmd_id.h"
#include "cfw.h"

UINT8 arrModuleID[] = "RDA MODULE ID";
UINT8 nModuleIDSize = sizeof(arrModuleID) - 1;  // not include the null-terminated char.

// UINT8 arrVersion[] = "VERSION 1.0";
UINT8 arrVersion[]   = "20120707";
UINT8 nVersionSize   = sizeof(arrVersion) - 1;  // not include the null-terminated char.
UINT8 arrFactoryID[] = "RDA";
UINT8 nFactoryIDSize = sizeof(arrFactoryID) - 1;  // not include the null-terminated char.
UINT32 CFW_EmodGetBaseBandVersion(void);

VOID AT_ID_AsyncEventProcess(COS_EVENT *pEvent)
{
	CFW_EVENT CfwEvent;

#ifdef AT_DUAL_SIM
	UINT8 nSim;
#endif
	if (pEvent == NULL)
	{
		return;
	}

	AT_CosEvent2CfwEvent(pEvent, &CfwEvent);
#ifdef AT_DUAL_SIM
	nSim = CfwEvent.nFlag;
#endif
	if (CfwEvent.nEventId == EV_CFW_SIM_GET_PROVIDER_ID_RSP)
	{
		AT_TC(g_sw_ID, "b    pCfwEvent->nType = %x\n", CfwEvent.nType);

		if (CfwEvent.nType == 0)
		{
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)CfwEvent.nParam1, (UINT16)CfwEvent.nParam2, CfwEvent.nUTI,
			             nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, (UINT8 *)CfwEvent.nParam1, (UINT16)CfwEvent.nParam2, CfwEvent.nUTI);
#endif
			return;
		}
		else if (CfwEvent.nType == 0xF0)
		{
			UINT32 nErrorCode = AT_SetCmeErrorCode(CfwEvent.nParam1, FALSE);

			AT_TC(g_sw_ID, "EV_CFW_SIM_GET_PROVIDER_ID_RSP: error!!!\
							errorcode--0x%x\n\r", nErrorCode);
#ifdef AT_DUAL_SIM
			AT_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, CfwEvent.nUTI, nSim);
#else
			AT_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, CfwEvent.nUTI);
#endif
			return;
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, CfwEvent.nUTI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, CfwEvent.nUTI);
#endif
			return;
		}
	}

}

VOID AT_ID_CmdFunc_CGMM(AT_CMD_PARA *pParam)
{
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	AT_TC(g_sw_ID, "pParam->iType = %d \n", pParam->iType);

	switch (pParam->iType)
	{

	case AT_CMD_EXE:

		AT_TC(g_sw_ID, "1\n");
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrModuleID, nModuleIDSize, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrModuleID, nModuleIDSize, pParam->nDLCI);
#endif
		break;

	case AT_CMD_TEST:
		AT_TC(g_sw_ID, "2\n");
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
		break;

	default:
		AT_TC(g_sw_ID, "3\n");
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		break;
	}

	return;
}

VOID AT_ID_CmdFunc_GMM(AT_CMD_PARA *pParam)
{
	AT_ID_CmdFunc_CGMM(pParam);
}

VOID AT_ID_CmdFunc_CGMR(AT_CMD_PARA *pParam)
{
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{

	case AT_CMD_EXE:
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrVersion, nVersionSize, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrVersion, nVersionSize, pParam->nDLCI);
#endif
		break;

	case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

		break;
	}

	return;

}

VOID AT_ID_CmdFunc_GMR(AT_CMD_PARA *pParam)
{
	AT_ID_CmdFunc_CGMR(pParam);
}

VOID AT_ID_CmdFunc_CGMI(AT_CMD_PARA *pParam)
{
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{

	case AT_CMD_EXE:
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrFactoryID, nFactoryIDSize, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrFactoryID, nFactoryIDSize, pParam->nDLCI);
#endif
		break;

	case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

		break;

	}

	return;
}

VOID AT_ID_CmdFunc_GMI(AT_CMD_PARA *pParam)
{
	AT_ID_CmdFunc_CGMI(pParam);
}

VOID AT_ID_CmdFunc_CGSN(AT_CMD_PARA *pParam)
{
	UINT8 nImei[15];
	UINT8 nImeiLen;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{

	case AT_CMD_EXE:

#ifdef AT_DUAL_SIM
		CFW_EmodGetIMEI(nImei, &nImeiLen, nSim);
#else
		CFW_EmodGetIMEI(nImei, &nImeiLen);

#endif
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, nImei, nImeiLen, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, nImei, nImeiLen, pParam->nDLCI);
#endif
		break;

	case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		break;
	}

	return;
}

VOID AT_ID_CmdFunc_GSN(AT_CMD_PARA *pParam)
{
	AT_ID_CmdFunc_CGSN(pParam);
}

VOID AT_ID_CmdFunc_I(AT_CMD_PARA *pParam)
{
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{

	case AT_CMD_EXE:

		if (pParam->pPara != NULL)
		{
			INT32 iRet      = 0;
			UINT8 paraCount = 0;

			iRet = AT_Util_GetParaCount(pParam->pPara, &paraCount);

			if (iRet != ERR_SUCCESS || paraCount > 1)
			{
				AT_TC(g_sw_ID, "ATI:AT_Util_GetParaCount ERROR---0x%x\n", iRet);
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}

			UINT8 nParam = 0;

			UINT8 nParamLen = 1;

			if (paraCount == 1)
			{
				iRet = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &nParam, &nParamLen);

				if (iRet != ERR_SUCCESS)
				{
					AT_TC(g_sw_ID, "ATI:AT_Util_GetParaWithRule ERROR\n");
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}

			}

			if (nParam == 0)
			{
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, arrFactoryID, nFactoryIDSize, pParam->nDLCI, nSim);
				AT_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, arrModuleID, nModuleIDSize, pParam->nDLCI, nSim);
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrVersion, nVersionSize, pParam->nDLCI, nSim);

#else
				AT_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, arrFactoryID, nFactoryIDSize, pParam->nDLCI);
				AT_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, arrModuleID, nModuleIDSize, pParam->nDLCI);
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrVersion, nVersionSize, pParam->nDLCI);
#endif
			}
			else
			{
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
			}
		}

		// COS_Sleep(10);
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

		break;
	}

	return;

}

VOID AT_ID_CmdFunc_CIMI(AT_CMD_PARA *pParam)
{
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{

	case AT_CMD_EXE:
	{
		// AT_20071225_CAOW_B for bug#7160
#if 0
		UINT32 nResult = AT_GetFreeUTI(CFW_SIM_SRV_ID, &nUTI);

		if (nResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_ID, "AT_ID_CmdFunc_CIMI: AT_GetFreeUTI: error!!!\n\r");
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
			return;
		}

#else
		UINT32 nResult = 0;

#endif
		// AT_20071225_CAOW_E
#ifdef AT_DUAL_SIM

		nResult = CFW_SimGetProviderId(pParam->nDLCI, nSim);
#else
		nResult = CFW_SimGetProviderId(pParam->nDLCI);

#endif

		if (ERR_SUCCESS == nResult)
		{
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
#endif
		}
		else
		{
			UINT32 nErrorCode = AT_SetCmeErrorCode(nResult, FALSE);

#ifdef AT_DUAL_SIM
			AT_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(nErrorCode, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

			return;
		}

		break;
	}

	case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		break;
	}

	return;
}
/*****************************************************************************
* Name			: 	AT_ID_CmdFunc_CGBV
* Description		: 	AT+CGBV command,get baseband version
* Parameter		:  	AT_CMD_PARA *pParam
* Return			:	VOID
* Remark		:	add for android RIL_REQUEST_BASEBAND_VERSION
* Author			:	wulc
* Data			:     2013-2-1
******************************************************************************/

VOID AT_ID_CmdFunc_CGBV(AT_CMD_PARA *pParam)
{
	UINT8 OutStr[15];
	UINT32 basebandVersion;
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{

	case AT_CMD_EXE:

		memset(OutStr, 0, 15);
		basebandVersion = CFW_EmodGetBaseBandVersion();
		AT_Sprintf(OutStr, "+CGBV: RDA%x", basebandVersion);

#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, OutStr, AT_StrLen(OutStr), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, OutStr, AT_StrLen(OutStr), pParam->nDLCI);
#endif
		break;

	case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
		break;

	default:
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		break;
	}

	return;
}

