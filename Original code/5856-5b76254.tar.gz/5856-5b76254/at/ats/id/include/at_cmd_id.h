/*********************************************************
 *
 * File Name
 *	at_cmd_id.h
 * Author
 * 	Felix
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 *
 *********************************************************/

#ifndef __AT_CMD_OTHER_H__
#define __AT_CMD_OTHER_H__

struct COS_EVENT;

struct AT_CMD_PARA;

#ifdef AT_DUAL_SIM
extern VOID AT_Result_OK(UINT32 uReturnValue, UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize,
                         UINT8 nDLCI, UINT8 nSim);
extern VOID AT_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI, UINT8 nSim);
#else
extern VOID AT_Result_OK(UINT32 uReturnValue, UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize,
                         UINT8 nDLCI);
extern VOID AT_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI);
#endif
UINT32 AT_SetCmeErrorCode(UINT32 nCfwErrorCode, BOOL bSetParamValid);

VOID AT_ID_CmdFunc_CGMM(AT_CMD_PARA *pParam);
VOID AT_ID_CmdFunc_GMM(AT_CMD_PARA *pParam);
VOID AT_ID_CmdFunc_CGMR(AT_CMD_PARA *pParam);
VOID AT_ID_CmdFunc_GMR(AT_CMD_PARA *pParam);
VOID AT_ID_CmdFunc_CGMI(AT_CMD_PARA *pParam);
VOID AT_ID_CmdFunc_GMI(AT_CMD_PARA *pParam);

#ifndef AT_USER_DBS
VOID AT_ID_CmdFunc_CGSN(AT_CMD_PARA *pParam);
#endif
VOID AT_ID_CmdFunc_GSN(AT_CMD_PARA *pParam);

VOID AT_ID_CmdFunc_I(AT_CMD_PARA *pParam);

VOID AT_ID_CmdFunc_CIMI(AT_CMD_PARA *pParam);

VOID AT_ID_CmdFunc_CGBV(AT_CMD_PARA *pParam);
VOID AT_ID_AsyncEventProcess(COS_EVENT *pEvent);

#endif

