/*********************************************************
 *
 * File Name
 *	at_util_dfms.c
 * Author
 * 	d.dubey
 * Date
 * 	2013/07/13
 * Descriptions:
 *	Public functions definition
 *
 *********************************************************/
#include "at_common.h"
#include "tgt_m.h"
#include "at_cmd_dfms.h"



#ifndef WIN32

#ifdef __NGUX_PLATFORM__

/*****************************************************************************/
// 	Description : Write MSL Address and Code.
//	Note: used by at command write data in factry area
//Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_WriteMSLSECUR(uint8 *mslsecure_num)
{
	//NVITEM_ERROR_E result;
	int length;
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = FALSE;

	if(0x0 == mslsecure_num)
	{
		return FALSE;
	}

	length = strlen((char *)mslsecure_num);
	if(length > MSLSECURE_LENGTH)
	{
		length = MSLSECURE_LENGTH;
	}

	// get  factory settings
	factorySettings = *tgt_GetFactorySettings();
	memcpy((uint8 *) & (factorySettings.at_param.mslsecure),  mslsecure_num,  MSLSECURE_LENGTH);
	// Update factory settings
	status =  tgt_SetFactorySettings(&factorySettings);
	if(status == TRUE)
	{
		// AT_TC("WRITE MSLSECUR OK\n");
		return TRUE;
	}
	else
	{
		// AT_TC("WRITE MSLSECUR WRONG\n");
		return FALSE;
	}
}
/*****************************************************************************/
// 	Description : Read MSL Address and Code.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_ReadMSLSECUR(uint8 *mslsecure_num)
{
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = TRUE;
	factorySettings = *tgt_GetFactorySettings();

	if(0x0 == mslsecure_num )
		return FALSE;

	memcpy(mslsecure_num, (uint8 *) & (factorySettings.at_param.mslsecure),  MSLSECURE_LENGTH);
	// AT_TC("mslsecure_num %s", mslsecure_num);

	return TRUE;
}
/*****************************************************************************/
// 	Description :Write Serial Number.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_WriteSERIALNO(uint8 *serialno_num)
{

	int length;
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = FALSE;

	if(0x0 == serialno_num)
	{
		return FALSE;
	}

	length = strlen((char *)serialno_num);
	if(length > SERIALNO_LENGTH)
	{
		length = SERIALNO_LENGTH;
	}

	// get  factory settings
	factorySettings = *tgt_GetFactorySettings();
	memcpy((uint8 *) & (factorySettings.at_param.serialno),  serialno_num,  SERIALNO_LENGTH);
	// Update factory settings
	status =  tgt_SetFactorySettings(&factorySettings);
	if(status == TRUE)
	{

		return TRUE;
	}
	else
	{
		return FALSE;
	}
}


/*****************************************************************************/
// 	Description :Read Serial Number.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_ReadSERIALNO(uint8 *serialno_num)
{
	//NVITEM_ERROR_E	result;
	//uint16 length;
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = TRUE;

	if(0x0 == serialno_num )
		return FALSE;


	factorySettings = *tgt_GetFactorySettings();


	if(status == TRUE)
	{
		memcpy(serialno_num, (uint8 *) & (factorySettings.at_param.serialno),  SERIALNO_LENGTH);
		// AT_TC("serialno_num %s", serialno_num);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*****************************************************************************/
// 	Description :Write Product Code.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_WriteProductCode(uint8 *productcode_num)
{
	//NVITEM_ERROR_E result;
	uint16 length;
	//uint8 *g_ptr= NULL;
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = FALSE;

	if(0x0 == productcode_num )
		return FALSE;

	length = (uint16)(strlen(productcode_num));
	if(length > PRODUCTCODE_LENGTH)
		length = PRODUCTCODE_LENGTH;

	factorySettings = *tgt_GetFactorySettings();
	memcpy((uint8 *) & (factorySettings.at_param.productcode),  productcode_num,  PRODUCTCODE_LENGTH);
	status =  tgt_SetFactorySettings(&factorySettings);
	if(status == TRUE)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*****************************************************************************/
// 	Description :Read Product Code.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_ReadProductCode(uint8 *productcode_num)
{
	// NVITEM_ERROR_E	result;
	//uint16 length;
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = TRUE;

	if(0x0 == productcode_num )
		return FALSE;

	factorySettings = *tgt_GetFactorySettings();

	if(status == TRUE)
	{
		memcpy(productcode_num, (uint8 *) & (factorySettings.at_param.productcode),  PRODUCTCODE_LENGTH);
		// AT_TC("productcode_num %s", productcode_num);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*****************************************************************************/
// 	Description :Write Restore factory flag.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_WriteRestoreFactoryFlag(		// TRUE: read success; FALSE: read failure
    BOOL	flag
)
{
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = FALSE;

	factorySettings = *tgt_GetFactorySettings();
	factorySettings.at_param.restorefact_flag = flag;
	status =  tgt_SetFactorySettings(&factorySettings);
	if(status == TRUE)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
	return status;
}
/*****************************************************************************/
// 	Description :Read Restore factory flag.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_ReadRestoreFactoryFlag(		// TRUE: read success; FALSE: read failure
    BOOL	*flag	// out--- save sim first true or false.
)
{
	TGT_FACTORY_SETTINGS_T factorySettings;

	if(0x0 == flag)
		return FALSE;

	factorySettings = *tgt_GetFactorySettings();
	*flag = factorySettings.at_param.restorefact_flag;

	return TRUE;
}

/*****************************************************************************/
// 	Description :Write KeyString Block flag.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/

extern void AT_SetStringBlockState(BOOL state);

BOOL AT_FactorySettings_WriteKeyStringBlockFlag(		// TRUE: read success; FALSE: read failure
    BOOL	flag
)
{
	//NVITEM_ERROR_E result;
	BOOL  kstring_flag;
	BOOL status = FALSE;
	//uint8 *g_ptr= NULL;
	TGT_FACTORY_SETTINGS_T factorySettings;


	kstring_flag = flag;
	factorySettings = *tgt_GetFactorySettings();
	factorySettings.at_param.keystring_flag = kstring_flag;
	status =  tgt_SetFactorySettings(&factorySettings);
	if(status == TRUE)
	{
		AT_SetStringBlockState(flag);
		// AT_TC("WRITE KEYSTRING OK\n");
		return TRUE;
	}
	else
	{
		// AT_TC("WRITE KEYSTRING WRONG\n");
		return FALSE;
	}
}
/*****************************************************************************/
// 	Description :Read Restore factory flag.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_ReadKeyStringBlockFlag(		// TRUE: read success; FALSE: read failure
    BOOL	*flag	// out--- save sim first true or false.
)
{
	//NVITEM_ERROR_E	result;
	//uint16 length;
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = TRUE;
	if(0x0 == flag )
		return FALSE;


	factorySettings = *tgt_GetFactorySettings();


	if(status == TRUE)
	{
		*flag = factorySettings.at_param.keystring_flag;
		// AT_TC("keystringblockflag %c", *flag);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}
/*****************************************************************************/
// 	Description :Write Test NV.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_WriteTestNV(uint16 *testnv_num)
{
	//NVITEM_ERROR_E result;
	int length;
	BOOL status = FALSE;
	//uint8 *g_ptr= NULL;
	TGT_FACTORY_SETTINGS_T factorySettings;

	if(0x0 == testnv_num )
	{
		return FALSE;
	}

	length = strlen((char *)testnv_num);
	if(length > TESTNV_LENGTH)
	{
		length = TESTNV_LENGTH;
	}

	factorySettings = *tgt_GetFactorySettings();
	memcpy((uint8 *)&factorySettings.at_param.testnv,  (uint8 *)testnv_num,  TESTNV_LENGTH);
	status =  tgt_SetFactorySettings(&factorySettings);

	if(status == TRUE)
	{
		// AT_TC("WRITE TEST NV OK\n");

		//tgt_FlushFactorySettings();
		return TRUE;
	}
	else
	{
		//tgt_FlushFactorySettings();
		// AT_TC("WRITE TEST NV wrong\n");
		return FALSE;
	}
}


/*****************************************************************************/
// 	Description :Read Test NV.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_ReadTestNV(uint16 *testnv_num)
{
	//NVITEM_ERROR_E	result;
	//uint16 length;
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = TRUE;
	if(0x0 == testnv_num )
		return FALSE;


	factorySettings = *tgt_GetFactorySettings();


	if(status == TRUE)
	{
		memcpy((uint8 *)testnv_num, (uint8 *)&factorySettings.at_param.testnv,  TESTNV_LENGTH);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}
/*****************************************************************************/
// 	Description :Write Hist NV.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
#include "sxs_io.h"
BOOL AT_FactorySettings_WriteHistNV(uint16 *histnv_num)
{
	//NVITEM_ERROR_E result;
	uint16 length;
	//uint8 *g_ptr= NULL;
	TGT_FACTORY_SETTINGS_T *factorySettings;
	BOOL status = FALSE;
	if(0x0 == histnv_num )
	{
		return FALSE;
	}

	length = (uint16)(strlen((char *)histnv_num));
	if(length > HISTNV_LENGTH)
	{
		length = HISTNV_LENGTH;
	}

	factorySettings = tgt_GetFactorySettings();
	memcpy((uint8 *) & (factorySettings->at_param.histnv),  histnv_num,  HISTNV_LENGTH);

	status =  tgt_SetFactorySettings(factorySettings);
	//tgt_FlushFactorySettings();
	if(status == TRUE)
	{
		// AT_TC("WRITE HIST NV OK\n");
		return TRUE;
	}
	else
	{
		// AT_TC("WRITE TEST NV WRONG\n");
		return FALSE;
	}
}


/*****************************************************************************/
// 	Description :Read Hist NV.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_ReadHistNV(uint16 *histnv_num)
{
	//NVITEM_ERROR_E	result;
	//uint16 length;
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = TRUE;
	if(0x0 == histnv_num )
		return FALSE;


	factorySettings = *tgt_GetFactorySettings();


	if(status == TRUE)
	{
		memcpy(histnv_num, (uint8 *) & (factorySettings.at_param.histnv),  HISTNV_LENGTH);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}


/*****************************************************************************/
// 	Description :Write DetaLock NV.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_WriteDetaLock(MN_SIM_LOCK_DETAL_DATA_T *deta_lock)
{
	//NVITEM_ERROR_E result;
	//uint16 length;
	//uint8 *g_ptr= NULL;
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = FALSE;
	if(0x0 == deta_lock )
		return FALSE;

	factorySettings = *tgt_GetFactorySettings();
	memcpy((uint8 *) & (factorySettings.at_param.detalock),  deta_lock,  sizeof(MN_SIM_LOCK_DETAL_DATA_T));
	status =  tgt_SetFactorySettings(&factorySettings);
	if(status == TRUE)
	{
		// AT_TC("WRITE DETALOCK NV OK\n");
		return TRUE;
	}
	else
	{
		// AT_TC("WRITE TEST DETALOCK WRONG\n");
		return FALSE;
	}
}


/*****************************************************************************/
// 	Description :Read DetaLock.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_ReadDetaLock(MN_SIM_LOCK_DETAL_DATA_T *deta_lock)
{
	//NVITEM_ERROR_E	result;
	//uint16 length;
	TGT_FACTORY_SETTINGS_T factorySettings = {0};

	BOOL status = TRUE;
	if(0x0 == deta_lock )
		return FALSE;


	factorySettings = *tgt_GetFactorySettings();


	if(status == TRUE)
	{
		memcpy(deta_lock, (uint8 *) & (factorySettings.at_param.detalock),  sizeof(MN_SIM_LOCK_DETAL_DATA_T));
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}
/*****************************************************************************/
// 	Description :Write Fact Record Data.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_WriteFactData(		// TRUE: read success; FALSE: read failure
    AT_FACT_RECD_PARAM	*fact_record	// out--- HW version number.
)
{
	uint16 length;
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = FALSE;
	if(0x0 == fact_record )
	{
		return FALSE;
	}
	length = (uint16)strlen((char *)fact_record);
	if(length > sizeof(AT_FACT_RECD_PARAM))
	{
		length = sizeof(AT_FACT_RECD_PARAM);
	}

	factorySettings = *tgt_GetFactorySettings();
	memcpy((uint8 *) & (factorySettings.at_param.fact_recd),  fact_record,  sizeof(AT_FACT_RECD_PARAM));
	status =  tgt_SetFactorySettings(&factorySettings);
	if(status == TRUE)
	{
		// AT_TC("WRITE FACTORY RECORD OK\n");
		return TRUE;
	}
	else
	{
		// AT_TC("WRITE FACTORY RECORD WRONG\n");
		return FALSE;
	}

}



/*****************************************************************************/
// 	Description :Read Fact Record Data.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_ReadFactData(		// TRUE: read success; FALSE: read failure
    AT_FACT_RECD_PARAM	*fact_record	// out--- HW version number.
)
{
	//	NVITEM_ERROR_E	result;
	// uint16 length;
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = TRUE;
	if(0x0 == fact_record )
		return FALSE;


	factorySettings = *tgt_GetFactorySettings();


	if(status == TRUE)
	{
		memcpy(fact_record, (uint8 *) & (factorySettings.at_param.fact_recd),  sizeof(AT_FACT_RECD_PARAM));
		if(fact_record->fail_record == 0xff && fact_record->retry == 0xff &&
		        fact_record->dummy11 == 0xff && fact_record->dummy12 == 0xff)
			return FALSE;
		// AT_TC("fact_record %s", fact_record);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}
/*****************************************************************************/
// 	Description :Write History NV data Data.
//	Note: used by at command read data from factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_WriteHistTestNV(uint16 *testnv_num, uint16 *histnv_num)
{
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = FALSE;
	if(0x0 == testnv_num )
		return FALSE;
	if(0x0 == histnv_num )
		return FALSE;

	factorySettings = *tgt_GetFactorySettings();
	memcpy((uint8 *)&factorySettings.at_param.testnv,  (uint8 *)testnv_num,  TESTNV_LENGTH);
	memcpy((uint8 *)&factorySettings.at_param.histnv,  (uint8 *)histnv_num,  HISTNV_LENGTH);
	status =  tgt_SetFactorySettings(&factorySettings);

	if(status == TRUE)
	{
		// AT_TC("WRITE FACTORY RECORD OK\n");
		return TRUE;
	}
	else
	{
		// AT_TC("WRITE FACTORY RECORD WRONG\n");
		return FALSE;
	}

}


/*****************************************************************************/
// 	Description :Write HW Version.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_WriteHWVersion(		// TRUE: read success; FALSE: read failure
    uint8	*hw_version_num	// out--- HW version number.
)
{
	//NVITEM_ERROR_E	result;
	uint16 length;
	BOOL status = FALSE;
	//uint8 *g_ptr= NULL;
	TGT_FACTORY_SETTINGS_T factorySettings;

	if(0x0 == hw_version_num )
		return FALSE;

	length = (uint16)(strlen(hw_version_num));
	if(length > HW_VERSION_LENGTH)
		length = HW_VERSION_LENGTH;

	factorySettings = *tgt_GetFactorySettings();
	memcpy((uint8 *) & (factorySettings.at_param.hwversion),  hw_version_num,  HW_VERSION_LENGTH);
	status =  tgt_SetFactorySettings(&factorySettings);
	if(status == TRUE)
	{
		// AT_TC("WRITE HW VERSION OK\n");
		return TRUE;
	}
	else
	{
		// AT_TC("WRITE HW VERSION WRONG\n");
		return FALSE;
	}

}

/*****************************************************************************/
// 	Description :Read HW Version.
//	Note: used by at command read data from factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_ReadHWVersion(		// TRUE: read success; FALSE: read failure
    uint8	*hw_version_num	// out--- HW version number.
)
{
	//NVITEM_ERROR_E	result;
	//  uint16 length;
	TGT_FACTORY_SETTINGS_T factorySettings;
	BOOL status = TRUE;
	if(0x0 == hw_version_num )
		return FALSE;


	factorySettings = *tgt_GetFactorySettings();


	if(status == TRUE)
	{
		memcpy(hw_version_num, (uint8 *) & (factorySettings.at_param.hwversion),  HW_VERSION_LENGTH);
		// AT_TC("hw_version_num %s", hw_version_num);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*****************************************************************************/
// 	Description :Write TestNV.
//	Note: used by at command write data in factry area
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_FactorySettings_WriteSETTestNV(uint16 *testnv_num)
{
	//NVITEM_ERROR_E result= NVERR_NONE;
	uint16 length;
	uint8 *g_ptr = NULL;
	BOOL status = FALSE;
	TGT_FACTORY_SETTINGS_T factorySettings;

	if(0x0 == testnv_num )
		return FALSE;
	length = (uint16)(strlen(testnv_num));
	if(length > TESTNV_LENGTH)
		length = TESTNV_LENGTH;

	factorySettings = *tgt_GetFactorySettings();
	memcpy((uint8 *)&factorySettings.at_param.testnv,  (uint8 *)testnv_num,  TESTNV_LENGTH);
	status =  tgt_SetFactorySettings(&factorySettings);
	//   EFS_NvitemWrite(NV_AT_COMMAND,  sizeof(AT_NV_PARAM),  &at_param,TRUE) ;
	if(status == TRUE)
	{
		// AT_TC("WRITE TEST NV OK\n");
		return TRUE;
	}
	else
	{
		// AT_TC("WRITE TEST NV wrong\n");
		return FALSE;
	}
}

/*****************************************************************************/
//  Description : This function handle Record History test NV
//  Author:d.dubey
/*****************************************************************************/
void ATC_RecordHistoryNV(ATC_FACTORY_ITEM_T hist_nv)
{
	ATC_FACTORY_ITEM_T        hist_nv_buf[61] = {0};
	uint8                              i = 0;
	uint8                              j = 0;

	memset(hist_nv_buf, 0x0, sizeof(hist_nv_buf));

	if(!AT_FactorySettings_ReadHistNV((uint16 *)hist_nv_buf))
	{
		memset((char *)hist_nv_buf, 0xff, sizeof(hist_nv_buf));

		if(!AT_FactorySettings_WriteHistNV((uint16 *)hist_nv_buf))
		{
			// AT_TC(g_sw_DFMS,"ATC: write his NV fail");
			return;
		}
	}

	// search for available space in history NV
	for(i = 0; i < 60; i++)
	{
		if((hist_nv_buf[i].id >> 7) == 1)
		{
			//AT_TC(g_sw_DFMS,"ATC: available space, i=%d", i);
			break;
		}
	}

	// history NV record has been full
	if(i >= 60)
	{
		for(j = 0; j < 60; j++)
		{
			hist_nv_buf[j].id = hist_nv_buf[j].id | 0x80;
		}

		hist_nv_buf[0].id = hist_nv.id;
		hist_nv_buf[0].result_code = hist_nv.result_code;

		if(!AT_FactorySettings_WriteHistNV((uint16 *)hist_nv_buf))
		{
			// AT_TC(g_sw_DFMS,"ATC: write his NV fail");
			return;
		}
	}
	else
	{
		hist_nv_buf[i].id = hist_nv.id;
		hist_nv_buf[i].result_code = hist_nv.result_code;
	}
#if 0
	hist_nv_buf[0].id = 1;
	hist_nv_buf[0].result_code = 'p';
#endif
	if(AT_FactorySettings_WriteHistNV((uint16 *)hist_nv_buf))
	{
		//AT_TC(g_sw_DFMS,"ATC: write hist nv success");
	}
	else
	{
		//AT_TC(g_sw_DFMS,"ATC: write hist nv fail");
	}
}

void  AT_SendBootupMessages()
{
	uint8 booting_string1[22] = {"BOOTING COMPLETED"};
	uint8 reset_string1[22] = {"RESET COMPLETED"};
	uint8 reset_flag = FALSE;

	AT_WriteUart(booting_string1, strlen(booting_string1));
	AT_FactorySettings_ReadRestoreFactoryFlag(&reset_flag);
	if (reset_flag == 2)
	{
		AT_WriteUart("\r\n", strlen("\r\n"));
		AT_WriteUart(reset_string1, strlen(reset_string1));
		reset_flag--;
		AT_FactorySettings_WriteRestoreFactoryFlag(reset_flag);
	}
}


VOID AT_DFMS_RDADOWNLOAD(AT_CMD_PARA *pParam)
{

	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;

	UINT8 *pRsp = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 1))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_RDADOWNLOAD, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_RDADOWNLOAD, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	if( 0x01 == param1 )
	{
		pRsp = AT_MALLOC(100);
		SUL_MemSet8(pRsp, 0x00, 100);

		AT_Sprintf(pRsp, "+RDADOWNLOAD:0,OK");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);

		flash_UartMonitor_WriteFlagandRestart();

	}
	else if( 0x00 == param1 )
	{
		TGT_FACTORY_SETTINGS_T factorySettings;
		factorySettings = *tgt_GetFactorySettings();

		pRsp = AT_MALLOC(100);
		SUL_MemSet8(pRsp, 0x00, 100);

		AT_Sprintf(pRsp, "+RDADOWNLOAD:0,OK 0x%x", factorySettings.bForceMonitorFlag);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);

	}
	else
	{
		pRsp = AT_MALLOC(100);
		SUL_MemSet8(pRsp, 0x00, 100);
		AT_Sprintf(pRsp, "+RDADOWNLOAD:Not support Parameter %d", param1);

		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);

	}
	// Add code here
}

#endif
#endif
// ///////////////////////////////////////////////////////////////////////////////////////////////
// The end of the file
// ///////////////////////////////////////////////////////////////////////////////////////////////

