
#ifdef __NGUX_PLATFORM__

#include "at_common.h"
#include "at_sa.h"
#include "sul.h"

#include "key_defs.h"
#include "hal_key.h"
#include "adp_event_timer.h"
#include <stack_config.h>
#include "kal_non_specific_general_types.h"
#include "device.h"
#include "dm_audio.h"
#include "reg.h"
#include "cfw_prv.h"
#include "gsm.h"
#include "itf_api.h"
#include "at_cmd_dfms.h"
#include "tgt_m.h"
#include "at_sha1.h"
#include "pmd_m.h"
#include "at_common.h"
#include "cos_startup.h"
#include "csw_ver.h"
typedef struct
{
	UINT8 header_code[4];  // magic number   // {0x7F,0xAA,0xAF,0x7E}
	UINT8 model[20];       // modelname
	UINT8 nature[40];      // sales country     {0xAA, 0x55}
	UINT8 custt_code[8];   // customer {0xAA, 0x55}
	UINT8 date[14];        // released date {0xAA, 0x55}
	UINT8 charger[24];     // charger {0xAA, 0x55}
	UINT8 version[20];     // sw version
	UINT8 Manufacturer_ID[10];    // Manufacturer ID(4byte)
	UINT8 Device_ID[10];          // Device ID(4byte)
	UINT8 unique_Number[20];      // UN number(16byte)
	UINT8 mem_name[20];    //  {0xAA, 0x55}
	UINT8 sec_code[20];    // code {0xAA, 0x55}
	UINT8 etc[46];         //  {0xAA, 0x55}
} HEAD_INFO;

UINT32 g_DfmsADMSFSMode = 0; // For command ADMSFS.
BOOL Atc_SysCrHashSHA1(UINT8 *szIn, UINT8 *szOut);
extern 	BOOL key_check(UINT8 *keys, UINT16  key_len);
extern BOOL hal_GetKeyStatus();
extern U8 GetHandsetInPhone();
extern BOOL hal_LpsIsUserResourceInactive(VOID);
//extern void GetPhoneBookCount(UINT16 *nTotal, UINT16 *nUsedPhoneTotalCnt);
extern void Calllog_Get_SpaceInfo(UINT32 *total, UINT32 *used);
extern UINT32 CFW_CfgGetSmsStorageInfo (CFW_SMS_STORAGE_INFO *pStorageInfo, UINT16 nStorage, CFW_SIM_ID nSimID);
extern int NGGetUnReadSmsCount( int simId);
extern void memoryResetAT();
extern void AT_KeyLock();
extern void AT_KeyUnLock();
extern S8 *ftoa(float value, S8 *s);
extern double atof(const char *pcStr1);

#define HEADSET_MIC_TEST 1
// Static was removed, need to check once

BOOL msl_verified               = FALSE;
BOOL ak_seed_no_verified  = FALSE;

#define MULTIPLIER      0x015a4e35L
#define INCREMENT       1
static unsigned int Seed = MULTIPLIER + INCREMENT; /* A sensible initial value */

//For getdisplay
int v_seqnum;
uint32 v_GetDisplayStart = 0;
uint32 v_BufferIndex = 0;
uint8 *v_GetDisplaySendData;
uint8 *v_pGetMainLCDBuffer;
#define LCD_NB_LINES 127
#define LCD_NB_COLUMNS  127
#define GET_DISPLAY_SEND_MORE                                    1
#define GET_DISPLAY_SEND_NO_MORE                             0
#define GET_DISPLAY_DATA_STREAM_START                   0x22
#define GET_DISPLAY_SIZE_OF_SEND_DATA		      4111
#define GET_DISPLAY_DATA_STREAM_END                       0x7E
#define LCD_BIT                                                       16
#define GET_DISPLAY_SIZE_OF_LCD_DATA                      4096
#define GET_DISPLAY_MAIN_LCD_BUFF_SIZE                                   (LCD_NB_COLUMNS * LCD_NB_LINES *sizeof(uint16))
#define MAIN_LCD_LAST_SEQ_QUOTIENT                                  ((LCD_NB_COLUMNS * LCD_NB_LINES *LCD_BIT)/(GET_DISPLAY_SIZE_OF_LCD_DATA*8))
#define MAIN_LCD_LAST_REMAINDER                                 ( (LCD_NB_COLUMNS * LCD_NB_LINES *LCD_BIT)%(GET_DISPLAY_SIZE_OF_LCD_DATA*8))
#define MAIN_LCD_LAST_SEQ_NUM                            (MAIN_LCD_LAST_REMAINDER?MAIN_LCD_LAST_SEQ_QUOTIENT:(MAIN_LCD_LAST_SEQ_QUOTIENT-1))
#define GET_DISPLAY_LAST_DATA_SIZE                          (LCD_NB_COLUMNS * LCD_NB_LINES *LCD_BIT) - (MAIN_LCD_LAST_SEQ_NUM*GET_DISPLAY_SIZE_OF_LCD_DATA*8)

BOOL keytrace_flag = FALSE;

uint16 get_dis_crc_table[256]
=
{
	0x0000, 0x1189, 0x2312, 0x329b, 0x4624, 0x57ad, 0x6536, 0x74bf,
	0x8c48, 0x9dc1, 0xaf5a, 0xbed3, 0xca6c, 0xdbe5, 0xe97e, 0xf8f7,
	0x1081, 0x0108, 0x3393, 0x221a, 0x56a5, 0x472c, 0x75b7, 0x643e,
	0x9cc9, 0x8d40, 0xbfdb, 0xae52, 0xdaed, 0xcb64, 0xf9ff, 0xe876,
	0x2102, 0x308b, 0x0210, 0x1399, 0x6726, 0x76af, 0x4434, 0x55bd,
	0xad4a, 0xbcc3, 0x8e58, 0x9fd1, 0xeb6e, 0xfae7, 0xc87c, 0xd9f5,
	0x3183, 0x200a, 0x1291, 0x0318, 0x77a7, 0x662e, 0x54b5, 0x453c,
	0xbdcb, 0xac42, 0x9ed9, 0x8f50, 0xfbef, 0xea66, 0xd8fd, 0xc974,
	0x4204, 0x538d, 0x6116, 0x709f, 0x0420, 0x15a9, 0x2732, 0x36bb,
	0xce4c, 0xdfc5, 0xed5e, 0xfcd7, 0x8868, 0x99e1, 0xab7a, 0xbaf3,
	0x5285, 0x430c, 0x7197, 0x601e, 0x14a1, 0x0528, 0x37b3, 0x263a,
	0xdecd, 0xcf44, 0xfddf, 0xec56, 0x98e9, 0x8960, 0xbbfb, 0xaa72,
	0x6306, 0x728f, 0x4014, 0x519d, 0x2522, 0x34ab, 0x0630, 0x17b9,
	0xef4e, 0xfec7, 0xcc5c, 0xddd5, 0xa96a, 0xb8e3, 0x8a78, 0x9bf1,
	0x7387, 0x620e, 0x5095, 0x411c, 0x35a3, 0x242a, 0x16b1, 0x0738,
	0xffcf, 0xee46, 0xdcdd, 0xcd54, 0xb9eb, 0xa862, 0x9af9, 0x8b70,
	0x8408, 0x9581, 0xa71a, 0xb693, 0xc22c, 0xd3a5, 0xe13e, 0xf0b7,
	0x0840, 0x19c9, 0x2b52, 0x3adb, 0x4e64, 0x5fed, 0x6d76, 0x7cff,
	0x9489, 0x8500, 0xb79b, 0xa612, 0xd2ad, 0xc324, 0xf1bf, 0xe036,
	0x18c1, 0x0948, 0x3bd3, 0x2a5a, 0x5ee5, 0x4f6c, 0x7df7, 0x6c7e,
	0xa50a, 0xb483, 0x8618, 0x9791, 0xe32e, 0xf2a7, 0xc03c, 0xd1b5,
	0x2942, 0x38cb, 0x0a50, 0x1bd9, 0x6f66, 0x7eef, 0x4c74, 0x5dfd,
	0xb58b, 0xa402, 0x9699, 0x8710, 0xf3af, 0xe226, 0xd0bd, 0xc134,
	0x39c3, 0x284a, 0x1ad1, 0x0b58, 0x7fe7, 0x6e6e, 0x5cf5, 0x4d7c,
	0xc60c, 0xd785, 0xe51e, 0xf497, 0x8028, 0x91a1, 0xa33a, 0xb2b3,
	0x4a44, 0x5bcd, 0x6956, 0x78df, 0x0c60, 0x1de9, 0x2f72, 0x3efb,
	0xd68d, 0xc704, 0xf59f, 0xe416, 0x90a9, 0x8120, 0xb3bb, 0xa232,
	0x5ac5, 0x4b4c, 0x79d7, 0x685e, 0x1ce1, 0x0d68, 0x3ff3, 0x2e7a,
	0xe70e, 0xf687, 0xc41c, 0xd595, 0xa12a, 0xb0a3, 0x8238, 0x93b1,
	0x6b46, 0x7acf, 0x4854, 0x59dd, 0x2d62, 0x3ceb, 0x0e70, 0x1ff9,
	0xf78f, 0xe606, 0xd49d, 0xc514, 0xb1ab, 0xa022, 0x92b9, 0x8330,
	0x7bc7, 0x6a4e, 0x58d5, 0x495c, 0x3de3, 0x2c6a, 0x1ef1, 0x0f78
};

static const uint16 a_PrimeNumber[350] =
{
	2,	  3,	 5, 	7,	  11,	 13,	17,    19,	  23,	 29,
	31,	 37,	41,    43,	  47,	 53,	59,    61,	  67,	 71,
	73,	 79,	83,    89,	  97,	101,   103,   107,	 109,	113,
	127,	131,   137,   139,	 149,	151,   157,   163,	 167,	173,
	179,	181,   191,   193,	 197,	199,   211,   223,	 227,	229,
	233,	239,   241,   251,	 257,	263,   269,   271,	 277,	281,
	283,	293,   307,   311,	 313,	317,   331,   337,	 347,	349,
	353,	359,   367,   373,	 379,	383,   389,   397,	 401,	409,
	419,	421,   431,   433,	 439,	443,   449,   457,	 461,	463,
	467,	479,   487,   491,	 499,	503,   509,   521,	 523,	541,
	547,	557,   563,   569,	 571,	577,   587,   593,	 599,	601,
	607,	613,   617,   619,	 631,	641,   643,   647,	 653,	659,
	661,	673,   677,   683,	 691,	701,   709,   719,	 727,	733,
	739,	743,   751,   757,	 761,	769,   773,   787,	 797,	809,
	811,	821,   823,   827,	 829,	839,   853,   857,	 859,	863,
	877,	881,   883,   887,	 907,	911,   919,   929,	 937,	941,
	947,	953,   967,   971,	 977,	983,   991,   997,	1009,  1013,
	1019,  1021,  1031,  1033,	1039,  1049,  1051,  1061,	1063,  1069,
	1087,  1091,  1093,  1097,	1103,  1109,  1117,  1123,	1129,  1151,
	1153,  1163,  1171,  1181,	1187,  1193,  1201,  1213,	1217,  1223,
	1229,  1231,  1237,  1249,	1259,  1277,  1279,  1283,	1289,  1291,
	1297,  1301,  1303,  1307,	1319,  1321,  1327,  1361,	1367,  1373,
	1381,  1399,  1409,  1423,	1427,  1429,  1433,  1439,	1447,  1451,
	1453,  1459,  1471,  1481,	1483,  1487,  1489,  1493,	1499,  1511,
	1523,  1531,  1543,  1549,	1553,  1559,  1567,  1571,	1579,  1583,
	1597,  1601,  1607,  1609,	1613,  1619,  1621,  1627,	1637,  1657,
	1663,  1667,  1669,  1693,	1697,  1699,  1709,  1721,	1723,  1733,
	1741,  1747,  1753,  1759,	1777,  1783,  1787,  1789,	1801,  1811,
	1823,  1831,  1847,  1861,	1867,  1871,  1873,  1877,	1879,  1889,
	1901,  1907,  1913,  1931,	1933,  1949,  1951,  1973,	1979,  1987,
	1993,  1997,  1999,  2003,	2011,  2017,  2027,  2029,	2039,  2053,
	2063,  2069,  2081,  2083,	2087,  2089,  2099,  2111,	2113,  2129,
	2131,  2137,  2141,  2143,	2153,  2161,  2179,  2203,	2207,  2213,
	2221,  2237,  2239,  2243,	2251,  2267,  2269,  2273,	2281,  2287,
	2293,  2297,  2309,  2311,	2333,  2339,  2341,  2347,	2351,  2357

};

VOID AT_DFMS_Result_OK(UINT32 uReturnValue, UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize)
{

	PAT_CMD_RESULT pResult = NULL;

	// �������

	//

	pResult = AT_CreateRC(uReturnValue,
	                      uResultCode, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, nDelayTime, pBuffer, nDataSize, 0);
	AT_Notify2ATM(pResult, 0);
	if (pResult != NULL)

	{

		AT_FREE(pResult);

		pResult = NULL;
	}

	return;

}

VOID AT_DFMS_Result_NA()
{
	TCHAR *pRsp = NULL;

	pRsp = AT_MALLOC(100);
	AT_Sprintf(pRsp, "+CME ERROR:NA\n");
	AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	AT_FREE(pRsp);
}

#if 1 // d.dubey
#ifndef WIN32

double atc_fmod(double denominator, double numerator)
{

	if (numerator < 0.001)
	{
		return denominator;
	}

	double ret = denominator;
	while (ret >= numerator)
		ret = ret - numerator;
	return ret;
}

LOCAL int  atc_rand( void )
{
	Seed = MULTIPLIER * Seed + INCREMENT;
	return ( ( int ) ( ( Seed ) >> 16 ) & 0x7fff );
}

LOCAL void  atc_srand( unsigned int seed )
{
	Seed = seed;
	atc_rand(  );                    /* primes the seed by using the first number which is
                                        usually not as random as the subsequent numbers are. */
}

#endif

LOCAL unsigned long Round( double Jj )
{
	unsigned long Ff;

	Ff = (unsigned long)Jj;

	if ( (Jj - (double)Ff) >= 0.5 )	Ff++;

	return Ff;
}

/*****************************************************************************/
// Description : This function final encrypts the random number.
//  Global resource dependence : none
//  Author: a.sonal
//  Note:
//  Parameters:
//		   1) i/o - Ask_String - random number
//		   2) i/o - Enc_Str - encoded no
/*****************************************************************************/

LOCAL double Encrypt( double Mm, double Ee, double Nn )
{
	double Ff, Cc, Ii;

	if ( atc_fmod( Ee, 2 ) == 0 )
	{
		Cc = 1;

		for( Ii = 1; Ii <= Ee / 2; Ii++ )
		{
			Ff = atc_fmod(( Mm * Mm ), Nn );
			Cc = atc_fmod(( Ff * Cc ), Nn );
		}
	}
	else
	{
		Cc = Mm;

		for( Ii = 1; Ii <= Ee / 2; Ii++ )
		{
			Ff = atc_fmod(( Mm * Mm ), Nn );
			Cc = atc_fmod(( Ff * Cc ), Nn );
		}
	}

	return( Cc );
}

LOCAL void STR_CPY( char *dest, char *source, int dest_start, int source_start, int count )
{
	int i;

	for( i = 0; i < count; i ++ ) dest[ i + dest_start ] = source[ i + source_start ];
}

LOCAL  int instr( char *str, char find, int pos )
{
	int ret = 0;
	str = str + pos;
	ret = pos;

	while( *str )
	{
		if ( *str == find ) return ret;

		ret++;
		str++;
	}

	return 0;
}

/*****************************************************************************/
// Description : This function adds separator('-') to Random number and encrypts the hyphen separated number.
//  Global resource dependence : none
//  Author: a.sonal
//  Note:
//  Parameters:
//		   1) i/o - Ask_String - random number
//		   2) i/o - Enc_Str - encoded no
/*****************************************************************************/

LOCAL  void Encrypt_Number( char *Ask_String, char *Enc_Str)
{
	unsigned long pos, pos_1;
	unsigned long log1, log2;
	double Nn, Mm, Ee, Ll;
	char temp[100];
	char s1[64], s2[64], s3[64];

	pos = pos_1 = log1 = log2 = 0;
	pos = instr( Ask_String, '-', 0 );
	STR_CPY( temp, Ask_String, 0, 0, pos );
	temp[ pos ] = '\0';
	Nn = atof( temp );
	pos_1 = pos + 1;
	temp[ 0 ] = '\0';
	pos = instr( Ask_String, '-', pos_1 );
	STR_CPY( temp, Ask_String, 0, pos_1, pos - pos_1 );
	temp[ pos - pos_1 ] = '\0';
	Mm = atof( temp );
	pos_1 = pos + 1;
	temp[ 0 ] = '\0';
	STR_CPY( temp, Ask_String, 0, pos_1, strlen( Ask_String ) - pos);
	temp[strlen( Ask_String ) - pos ] = '\0';
	Ee = atof( temp );

	/*Here need check by india engineer ,as it too slow*/
	//Ll = Encrypt( Mm, Ee, Nn );
	//log1 = Round(atc_fmod( Nn * 98789, log( Nn )));

	log1 =  (unsigned long)Nn;
	log2 = Round((( Mm * Nn ) / Nn) / log( Mm ));

	Ll = Ll + 89;
	log1 = log1 + 89;
	log2 = log2 + 89;
	ftoa(Ll, s1);
	ftoa(log1, s2);
	ftoa(log2, s3);

	sprintf( temp, "%s%c%s%c%s", s1, '-', s2, '-', s3 );

	strcpy( Enc_Str, temp );
}

LOCAL double extend( double Ee, double PIpi )
{
	double t1, t2, t3, u1, u2, u3, v1, v2, v3, Qq, Zz, uu, vv, inverse;

	u1 = 1;
	u2 = 0;
	u3 = PIpi;
	v1 = 0;
	v2 = 1;
	v3 = Ee;
	Qq = 0;
	Zz = 0;
	uu = 0;
	vv = 0;

	while( v3 != 0 )
	{
		Qq = floor( u3 / v3 );
		t1 = u1 - Qq * v1;
		t2 = u2 - Qq * v2;
		t3 = u3 - Qq * v3;

		u1 = v1;
		u2 = v2;
		u3 = v3;

		v1 = t1;
		v2 = t2;
		v3 = t3;
		Zz = 1;
	}

	uu = u1;
	vv = u2;

	if ( vv < 0 )
	{
		inverse = vv + PIpi;
	}
	else
	{
		inverse = vv;
	}

	return( inverse );
}

LOCAL double GCD( double Ee, double PIpi )
{
	double Aa, great;

	Aa = 0;
	great = 0;

	if ( Ee > PIpi )
	{
		while( atc_fmod( Ee, PIpi ) != 0 )
		{
			Aa = atc_fmod( Ee, PIpi );
			Ee = PIpi;
			PIpi = Aa;
		}

		great = PIpi;
	}
	else
	{
		while( atc_fmod( PIpi, Ee ) != 0 )
		{
			Aa = atc_fmod( PIpi, Ee );
			PIpi = Ee;
			Ee = Aa;
		}

		great = Ee;
	}

	return great;
}

LOCAL double tofindE( double PIpi, double Pp, double Qq )
{
	double great, aa, bb, cc, rm, se;

	great = aa = bb = cc = rm = se = 0;
	aa = log( PIpi ) / log( 10.0 );
	bb = floor( aa );
	cc = pow( 10, bb );
	atc_srand(time(NULL));
	rm = ( atc_rand() * cc ) / 10000 ;
	se = Round( rm );

	while( great != 1 )
	{
		se++;
		great = GCD( se, PIpi );
		PIpi = ( Pp - 1 ) * ( Qq - 1 );
	}

	return( se );
}

LOCAL double Prime( long Num )
{
	float Arr[ 10100 ];
	long Cc, Ii, Jj, Flag;

	Arr[ 0 ] = 2;
	Arr[ 1 ] = 3;
	Arr[ 2 ] = 5;
	Cc = 3;

	for( Ii = 7; Cc <= Num ; Ii += 2 )
	{
		Flag = 1;
		if (!( atc_fmod( Ii, 6.0 ) == 1 || atc_fmod( Ii, 6.0 ) == 5 ))	continue;

		for( Jj = 2; Jj < Cc; Jj++ )
		{
			if ( Arr[Jj] * Arr[Jj] > (float)Ii )	break;

			if ( atc_fmod( (float)Ii, Arr[Jj] ) == 0 )
			{
				Flag = 0;
				break;
			}
		} //end of for Jj

		if ( Flag )
		{
			Arr[Cc] = (float)Ii;
			Cc++;
		}
	}

	return ( Arr[Num]);
}

/*****************************************************************************/
// Description : This function generates & encodes the Random number.
//  Global resource dependence : none
//  Author: a.sonal
//  Note:
//  Parameters:
//		   1) i/o - Enc_Num - random no
//		   2) i/o - Ak - encoded no
/*****************************************************************************/
LOCAL void Get_Number( char *Enc_Num, char *Ak)
{
	double My_P, My_Q;
	double Pp, Qq, PIpi, Ee, Dd, Nn, Mm;
	char temp[200];
	char s1[64], s2[64], s3[64];

	atc_srand(time(NULL));		// get the number of ticks to set seed for random number generation
	My_P = atc_rand() % 50; //to reduce output time
	atc_srand(time(NULL));
	do
	{
		My_Q = atc_rand() % 50; //to reduce output time
	}
	while( My_P == My_Q );

	/*
	   random number is generated by using the above generated numbers as indexes to prime no array.
	   those prime numbers are further encrypted to generate final random number
	   */

	Pp = a_PrimeNumber[(long)My_P];
	Qq = a_PrimeNumber[(long)My_Q];

	PIpi = ( Pp - 1 ) * ( Qq - 1 );
	Ee = tofindE( PIpi, Pp, Qq );
	Dd = extend( Ee, PIpi );
	Nn = Pp * Qq;
	atc_srand(time(NULL));
	do
	{
		Mm = (double)(atc_rand() % ((long)Nn - 1));
	}
	while( Mm >= Nn || Mm <= 0 );

	/*---------------------------------------------------------
	 *D_number = D;
	 *E_number = E;
	 *N_number = N;
	 *M_number = M;
	 -----------------------------------------------------------*/
	/*
	ftoa(Nn, s1);
	ftoa(Mm, s2);
	ftoa(Ee, s3);
	*/

	/* here need to do better*/
	UINT32 N, M, E;
	N = Nn;
	M = Mm;
	E = Ee;
	sprintf(Enc_Num, "%d%c%d%c%d", N, '-', M, '-', E);

	//sprintf( Enc_Num, "%s%c%s%c%s", s1, '-', s2, '-', s3);
	Encrypt_Number( Enc_Num, temp);	//encode the Random number to Ak
	strcpy( Ak, temp );
}
#endif

VOID AT_DFMS_Result_Err(UINT32 uErrorCode, UINT8 nErrorType)
{
	PAT_CMD_RESULT pResult = NULL;

	pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, uErrorCode, nErrorType, 0, 0, 0, 0);
	AT_Notify2ATM(pResult, 0);
	if (pResult != NULL)
	{
		AT_FREE(pResult);
		pResult = NULL;
	}
	return;
}

VOID AT_DFMS_info_GetHeadin(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8  version = 0;
	UINT8  subversion = 0;
	TCHAR *pRsp = NULL;
	HEAD_INFO head_info;
	UINT8 magicbuf[4] = {0x7F, 0xAA, 0xAF, 0x7E};
	UINT8 magicStr[4] = "7FAAAF7E";

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_info_GetHeadin, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(version);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &version, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_info_GetHeadin, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize   = SIZEOF(subversion);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &subversion, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_info_GetHeadin, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	pRsp = AT_MALLOC(1024);
	SUL_MemSet8(pRsp, 0, 1024);
	SUL_MemSet8(&head_info, 0, SIZEOF(HEAD_INFO));

	SUL_StrNCopy(head_info.header_code, (TCHAR *)magicbuf, 4);
	SUL_StrNCopy(head_info.model, (TCHAR *)"GT-I9000", 8);
	SUL_StrNCopy(head_info.nature, (TCHAR *)"A", 1);
	SUL_StrNCopy(head_info.custt_code, (TCHAR *)"A", 1);
	SUL_StrNCopy(head_info.date, (TCHAR *)"2013-08-13", 10);
	SUL_StrNCopy(head_info.charger, (TCHAR *)"A", 1);
	SUL_StrNCopy(head_info.version, (TCHAR *)"A", 1);
	SUL_StrNCopy(head_info.Manufacturer_ID, (TCHAR *)"BB01", 4);
	SUL_StrNCopy(head_info.Device_ID, (TCHAR *)"BEFE", 4);
	SUL_StrNCopy(head_info.unique_Number, (TCHAR *)"12340000003032", 14);
	SUL_StrNCopy(head_info.mem_name, (TCHAR *)"KAC007021M(I9000)", 17);
	SUL_StrNCopy(head_info.sec_code, (TCHAR *)"A", 1);
	SUL_StrNCopy(head_info.etc, (TCHAR *)"A", 1);

	if((version == 1) && (subversion == 0))
	{
		AT_Sprintf(pRsp, "AT+HEADINFO=1,0 \n");
		SUL_StrCat(pRsp, (const TCHAR *)"\r\n+HEADINFO:1,");

#if 0
		SUL_StrNCat(pRsp, &head_info, sizeof(HEAD_INFO)); //can notdue to '\0'
#else
		//To meet the need of samsung, must put each byte to pRsp, even the value is '0' or'\0'

		UINT8 str_tmp[40];
		//put header_code to pRsp
		for(int i = 0;  i < 4; i++)
		{
			memset(str_tmp, 0, sizeof(str_tmp));
			sprintf(str_tmp, "%02X", head_info.header_code[i]);
			strcat(pRsp, str_tmp);

		}//put model to pRsp
		for(int i = 0;  i < 20; i++)
		{
			memset(str_tmp, 0, sizeof(str_tmp));
			sprintf(str_tmp, "%02X", head_info.model[i]);
			strcat(pRsp, str_tmp);

		}//put nature to pRsp
		for(int i = 0;  i < 40; i++)
		{
			memset(str_tmp, 0, sizeof(str_tmp));
			sprintf(str_tmp, "%02X", head_info.nature[i]);
			strcat(pRsp, str_tmp);

		}//put custt_code to pRsp
		for(int i = 0;  i < 8; i++)
		{
			memset(str_tmp, 0, sizeof(str_tmp));
			sprintf(str_tmp, "%02X", head_info.custt_code[i]);
			strcat(pRsp, str_tmp);

		}//put date to pRsp
		for(int i = 0;  i < 14; i++)
		{
			memset(str_tmp, 0, sizeof(str_tmp));
			sprintf(str_tmp, "%02X", head_info.date[i]);
			strcat(pRsp, str_tmp);
		}//put charger to pRsp
		for(int i = 0;  i < 24; i++)
		{
			memset(str_tmp, 0, sizeof(str_tmp));
			sprintf(str_tmp, "%02X", head_info.charger[i]);
			strcat(pRsp, str_tmp);

		}//put version to pRsp
		for(int i = 0;  i < 20; i++)
		{
			memset(str_tmp, 0, sizeof(str_tmp));
			sprintf(str_tmp, "%02X", head_info.version[i]);
			strcat(pRsp, str_tmp);

		}//put Manufacturer_ID to pRsp
		for(int i = 0;  i < 10; i++)
		{
			memset(str_tmp, 0, sizeof(str_tmp));
			sprintf(str_tmp, "%02X", head_info.Manufacturer_ID[i]);
			strcat(pRsp, str_tmp);

		}//put Device_ID to pRsp
		for(int i = 0;  i < 10; i++)
		{
			memset(str_tmp, 0, sizeof(str_tmp));
			sprintf(str_tmp, "%02X", head_info.Device_ID[i]);
			strcat(pRsp, str_tmp);

		}//put unique_Number to pRsp
		for(int i = 0;  i < 20; i++)
		{
			memset(str_tmp, 0, sizeof(str_tmp));
			sprintf(str_tmp, "%02X", head_info.unique_Number[i]);
			strcat(pRsp, str_tmp);

		}//put mem_name to pRsp
		for(int i = 0;  i < 20 ; i++)
		{
			memset(str_tmp, 0, sizeof(str_tmp));
			sprintf(str_tmp, "%02X", head_info.mem_name[i]);
			strcat(pRsp, str_tmp);

		}//put sec_code to pRsp
		for(int i = 0;  i < 20; i++)
		{
			memset(str_tmp, 0, sizeof(str_tmp));
			sprintf(str_tmp, "%02X", head_info.sec_code[i]);
			strcat(pRsp, str_tmp);

		}//put etc to pRsp
		for(int i = 0;  i < 46; i++)
		{
			memset(str_tmp, 0, sizeof(str_tmp));
			sprintf(str_tmp, "%02X", head_info.etc[i]);
			strcat(pRsp, str_tmp);

		}
#endif

		int len = AT_StrLen(pRsp);
		for(int i = 0;  i < len; i++)
		{
			if(pRsp[i] == 'a')
				pRsp[i] = 'A';
			else if(pRsp[i] == 'b')
				pRsp[i] = 'B';
			else if(pRsp[i] == 'c')
				pRsp[i] = 'C';
			else if(pRsp[i] == 'd')
				pRsp[i] = 'D';
			else if(pRsp[i] == 'e')
				pRsp[i] = 'E';
			else if(pRsp[i] == 'f')
				pRsp[i] = 'F';
		}

		//AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, SIZEOF(HEAD_INFO)+len);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_info_GetHeadin v1.0, sucees\n");
		return;
	}
	else if((version == 1) && (subversion == 1))
	{

		AT_Sprintf(pRsp, "at+headinfo=1,1\r\nReadHeadInfo:");
		SUL_StrCat(pRsp, (const TCHAR *)"\r\nHeaderCode:");
		SUL_StrNCat(pRsp, "7FAAAF7E", 8);
		SUL_StrCat(pRsp, (const TCHAR *)"\r\nModelName:");
		SUL_StrNCat(pRsp, head_info.model, sizeof(head_info.model));
		SUL_StrCat(pRsp, (const TCHAR *)"\r\nCountry:");
		SUL_StrNCat(pRsp, head_info.nature, sizeof(head_info.nature));
		SUL_StrCat(pRsp, (const TCHAR *)"\r\nCountryCode:");
		SUL_StrNCat(pRsp, head_info.custt_code, sizeof(head_info.custt_code));
		SUL_StrCat(pRsp, (const TCHAR *)"\r\nDate:");
		SUL_StrNCat(pRsp, head_info.date, sizeof(head_info.date));
		SUL_StrCat(pRsp, (const TCHAR *)"\r\nCharger");
		SUL_StrNCat(pRsp, head_info.charger, sizeof(head_info.charger));
		SUL_StrCat(pRsp, (const TCHAR *)"\r\nSWVer:");
		SUL_StrNCat(pRsp, head_info.version, sizeof(head_info.version));
		SUL_StrCat(pRsp, (const TCHAR *)"\r\nManufactureID:");
		SUL_StrNCat(pRsp, head_info.Manufacturer_ID, sizeof(head_info.Manufacturer_ID));
		SUL_StrCat(pRsp, (const TCHAR *)"\r\nDeviceID:");
		SUL_StrNCat(pRsp, head_info.Device_ID, sizeof(head_info.Device_ID));
		SUL_StrCat(pRsp, (const TCHAR *)"\r\nUniqueNumber:");
		SUL_StrNCat(pRsp, head_info.unique_Number, sizeof(head_info.unique_Number));
		SUL_StrCat(pRsp, (const TCHAR *)"\r\nMemoryName:");
		SUL_StrNCat(pRsp, head_info.mem_name, sizeof(head_info.mem_name));
		SUL_StrCat(pRsp, (const TCHAR *)"\r\nSEC_Code:");
		SUL_StrNCat(pRsp, head_info.sec_code, sizeof(head_info.sec_code));
		SUL_StrCat(pRsp, (const TCHAR *)"\r\nOthers:");
		SUL_StrNCat(pRsp, head_info.etc, sizeof(head_info.etc));
		//		 SUL_StrCat(pRsp,(const TCHAR *)"\nOK:");

		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_info_GetHeadin v1.1, sucees\n");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		return;
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_info_GetHeadin, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	AT_FREE(pRsp);
	return;

}

VOID AT_DFMS_Radio_FM(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2 = 0;
	UINT8 param3 = 0;
	UINT16 frequency;
	INT32 signaldb = 0;
	UINT8 db;

	UINT8 *pRsp = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 4))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_Radio_FM, parameter erroru:ParaCount=%d\n", uParaCount);
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_Radio_FM, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex++;
	uSize   = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_Radio_FM, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex++;
	uSize   = SIZEOF(param3);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param3, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_Radio_FM, get parameter error3\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize   = SIZEOF(frequency);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT16, &frequency, &uSize);

	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_Radio_FM, get parameter error4\n");
		AT_DFMS_Result_NA();
		return;
	}

	if( (param1  == 0) && (param2  == 0))
	{

		FMR_PowerOn();
		MCI_FmPlay();
		FMR_SetFreq(frequency);
		FMR_SetOutputDevice(AUDIO_DEVICE_SPEAKER_BOTH);
		if(param3 == 1)
		{
			FMR_SetOutputDevice(AUDIO_DEVICE_LOUDSPEAKER);
		}
		else
		{
			FMR_SetOutputDevice(AUDIO_DEVICE_SPEAKER2);
		}
		GpioSpeakerModeStart();
		FMR_SetOutputVolume(7, 7);

		pRsp = AT_MALLOC(100);

		AT_Sprintf(pRsp, "AT+FCFMTEST=0,0, %d, %d", param3, frequency);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));

		AT_FREE(pRsp);
	}
	else if( (param1  == 0) && (param2  == 1))
	{
		FMR_PowerOff();
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "AT+FCFMTEST=0,1,0,0\r\n+FCFMTST:0");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if( (param1  == 1) && (param2  == 0))
	{
		if(FMR_IsActive())
			db = FMR_GetSignalLevel(frequency);
		else
		{
			FMR_PowerOn();
			MCI_FmPlay();
			FMR_SetFreq(frequency);
			FMR_SetOutputDevice(AUDIO_DEVICE_SPEAKER_BOTH);
			FMR_SetOutputDevice(AUDIO_DEVICE_SPEAKER2);
			GpioSpeakerModeStart();
			FMR_SetOutputVolume(7, 7);
			db = FMR_GetSignalLevel(frequency);
		}
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+FCFMTST:1, %d", db - 120);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_Radio_FM, get parameter error3\n");
		AT_DFMS_Result_NA();
		return;
	}

}

VOID AT_DFMS_EarSW_FCEPTEST(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 param3  = 0;
	UINT8 param4  = 0;
	UINT8 *pRsp = NULL;
	UINT8 earModeStatus;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 4))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_EarSW_FCEPTEST, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_EarSW_FCEPTEST, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_EarSW_FCEPTEST, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param3);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param3, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_EarSW_FCEPTEST, get parameter error3\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param4);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param4, &uSize);
	if (iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_EarSW_FCEPTEST, get parameter error4\n");
		AT_DFMS_Result_NA();
		return;
	}

	if((param1  == 0) && (param2  == 0) && (param3  == 0) && (param4  == 0))
	{

		// FM_SendStopAudioReq( 0 );
		//   Media_Stop();
		DM_StopTone();
#if (HEADSET_MIC_TEST)
		/* open loopback */
		CFW_EmodAudioTestStart(AUD_MODE_HEADSET);
#else
		DM_PlayTone(24, 1, HEADSET_DURATION, 4);
#endif

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "AT+FCEPTEST=1,0\r\n+FCEPTEST:0");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 0) && (param3  == 1) && (param4  == 0))
	{
#if (HEADSET_MIC_TEST)
		CFW_EmodAudioTestEnd();
#else
		DM_StopTone();
#endif
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "AT+FCEPTEST=1,0\r\n+FCEPTEST:0");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 1) && (param2  == 0) && (param3  == 0) && (param4  == 0))
	{

		pRsp = AT_MALLOC(100);
		earModeStatus = pmd_GetEarModeStatus();
		if(earModeStatus == 3)
		{
			if(GetHandsetInPhone() == 1)
			{
				AT_Sprintf(pRsp, "AT+FCESTEST=1,0\r\n+FCESTEST:FOUND");
			}
			else
			{
				AT_Sprintf(pRsp, "AT+FCESTEST=1,0\r\n+FCESTEST:NOT FOUND");
			}
		}
		else
		{
			AT_Sprintf(pRsp, "AT+FCESTEST=1,0\r\n+FCESTEST:NOT FOUND");
		}

		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 1) && (param2  == 0) && (param3  == 2) && (param4  == 0))
	{
		pRsp = AT_MALLOC(100);
		earModeStatus = pmd_GetEarModeStatus();
		if(earModeStatus == 3)
		{
			AT_Sprintf(pRsp, "AT+FCESTEST=1,0\r\n+FCESTEST:NOT FOUND");
		}
		else if(earModeStatus == 1)
		{
			AT_Sprintf(pRsp, "AT+FCESTEST=1,0\r\n+FCESTEST:FOUND");
		}
		else
		{
			AT_Sprintf(pRsp, "AT+FCESTEST=1,0\r\n+FCESTEST:NOT FOUND");
		}

		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_EarSW_FCEPTEST, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

}

VOID AT_DFMS_EarSW_FCESTEST(AT_CMD_PARA *pParam)
{

	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 *pRsp = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 1))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_EarSW_FCESTEST, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex  = 0;

	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_EarSW_FCESTEST, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(param1  == 1)
	{
		pRsp = AT_MALLOC(100);
		if(GetHandsetInPhone() == 1)
			AT_Sprintf(pRsp, "+FCESTEST:ON");
		else
			AT_Sprintf(pRsp, "+FCESTEST:OFF");

		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));

		AT_FREE(pRsp);
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_EarSW_FCEPTEST, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}


}

VOID AT_DFMS_ForceSleep(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;

	UINT8 *pRsp = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_ForceSleep, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex  = 0;

	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_ForceSleep, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS || (param2 != 0))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_ForceSleep, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	if( (param1  == 0) && (param2  == 0))
	{
		pRsp = AT_MALLOC(64);
		memset(pRsp, 0x0, 64);
		//if(hal_LpsIsUserResourceInactive())
		AT_Sprintf(pRsp, "\r\n+SYSSLEEP:0\n\r");
		//else
		//	 AT_Sprintf(pRsp, "+SYSSLEEP:0");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
		// Now call the DEEP sleep API
		COS_Sleep(5);
		hal_LpsEnterDeepSleep();
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_ForceSleep, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

}

VOID AT_DFMS_BandSelection(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 param3  = 0;
	UINT8 param4  = 0;
	UINT8 *pRsp = NULL;
	UINT8 earModeStatus;
	UINT8 arrCharacterSet[15] = { 0 };
	UINT8 CSDBand_Auto = 0;
	UINT32 ret = 0;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BandSelection, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BandSelection, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	CSDBand_Auto = 0;
	if(param1 == 1)
	{
		uIndex++;
		uSize  = SIZEOF(param2);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
		if(iResult != ERR_SUCCESS || (param2 != 0))
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BandSelection, get parameter error2\n");
			AT_DFMS_Result_NA();
			return;
		}

		CFW_CfgNwGetFrequencyBand(&CSDBand_Auto, CFW_SIM_0);
		pRsp = AT_MALLOC(64);
		memset(pRsp, 0x0, 64);

		if(CFW_NW_BAND_GSM_850 & CSDBand_Auto) // GSM 850
			AT_Sprintf(pRsp, "\r\n+BANSELCT:1,GSM850\n\r");
		else if(CFW_NW_BAND_GSM_900E & CSDBand_Auto) // EGSM
			AT_Sprintf(pRsp, "\r\n+BANSELCT:1,EGSM900\n\r");
		else if(CFW_NW_BAND_DCS_1800 & CSDBand_Auto) // DCS
			AT_Sprintf(pRsp, "\r\n+BANSELCT:1,DCS1800\n\r");
		else if(CFW_NW_BAND_PCS_1900 & CSDBand_Auto) // PCS
			AT_Sprintf(pRsp, "\r\n+BANSELCT:1,PCS1900\n\r");
		else
			AT_Sprintf(pRsp, "\r\n+BANSELCT:1,NO\n\r");

		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if(param1 == 2)
	{
		uIndex++;
		uSize   = SIZEOF(arrCharacterSet);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &arrCharacterSet, &uSize);
		if(iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BandSelection, get parameter error1\n");
			AT_DFMS_Result_NA();
			return;
		}

		if(AT_StrCmp(arrCharacterSet, "EGSM") == 0)
			CSDBand_Auto = CFW_NW_BAND_GSM_900P | CFW_NW_BAND_GSM_900E;
		else if (AT_StrCmp(arrCharacterSet, "DCS1800") == 0)
			CSDBand_Auto = CFW_NW_BAND_DCS_1800;
		else if(AT_StrCmp(arrCharacterSet, "EGSMDCS1800") == 0)
			CSDBand_Auto = CFW_NW_BAND_GSM_900P | CFW_NW_BAND_GSM_900E | CFW_NW_BAND_DCS_1800;
		else if (AT_StrCmp(arrCharacterSet, "AUTO") == 0)
			CSDBand_Auto = 0;
		else if (AT_StrCmp(arrCharacterSet, "AUTO_2G") == 0)
			CSDBand_Auto = 0;
		else
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BandSelection, get parameter error1\n");
			AT_DFMS_Result_NA();
			return;
		}

#ifdef __ADP_MULTI_SIM__

#ifdef ADP_CFW_DUALSIM_SIMULATOR_SUPPORT

		ret = UT_CFW_NwSetFrequencyBand(CSDBand_Auto, ADP_GetFreeUti(), CFW_SIM_0);
#else
		ret = CFW_NwSetFrequencyBand(CSDBand_Auto, ADP_GetFreeUti(), CFW_SIM_0);
#endif
#else
		ret = CFW_NwSetFrequencyBand(CSDBand_Auto, ADP_GetFreeUti());
#endif

		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BandSelection setfrequency ret=%d\n,", ret);

		if(ret != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BandSelection setfrequency Err, ret=%d\n,", ret);

			pRsp = AT_MALLOC(100);
			pRsp[20] = ret;
			AT_Sprintf(pRsp, "+CME ERROR:NA\n");

			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));

			AT_FREE(pRsp);
		}
		else
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+BANSELCT:2,OK\n");

			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));

			AT_FREE(pRsp);
		}
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BandSelection, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
}

VOID AT_DFMS_Motor(AT_CMD_PARA *pParam)
{
	INT32 iResult       = 0;
	UINT8 uParaCount    = 0;
	UINT8 uIndex        = 0;
	UINT8 uSize         = 0;
	UINT8 param1        = 0;
	UINT8 param2        = 0;
	UINT8 *pRsp         = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_Motor, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize   = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_Motor, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize   = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_Motor, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	if((param1  == 0) && (param2  == 0))
	{
		vibrator_open_API();

		pRsp = AT_MALLOC(128);

		AT_Sprintf(pRsp, "\r\n+VIBRTEST:0\n\r");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));

		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 1))
	{
		vibrator_Close_API();
		pRsp = AT_MALLOC(128);
		AT_Sprintf(pRsp, "\r\n+VIBRTEST:0\n\r");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_Motor, get parameter error3\n");
		AT_DFMS_Result_NA();
		return;
	}
}

extern UINT32 GetShortKeyStatus();
VOID AT_DFMS_KeyShort(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2 = 0;
	UINT8 *pRsp = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex++;
	uSize   = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	if( (param1  == 1) && (param2  == 0))
	{
		pRsp = AT_MALLOC(1024);
		UINT32 shortKeyStatus = GetShortKeyStatus();

		if(shortKeyStatus == 1)
		{
			//long press
			AT_Sprintf(pRsp, "AT+KEYSHORT=1,0\r\n+KEYSHORT:1,LONGPRESS");
		}
		else if (shortKeyStatus == EV_KEY_DOWN)
		{
			AT_Sprintf(pRsp, "AT+KEYSHORT=1,0\r\n+KEYSHORT:1,PRESS");
		}
		else
		{
			AT_Sprintf(pRsp, "AT+KEYSHORT=1,0\r\n+KEYSHORT:1,RELEASE");
		}
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

}

VOID AT_DFMS_SperakerReveiver(AT_CMD_PARA *pParam)
{
	UINT8 *pRsp         = NULL;
	UINT8 uSize         = 0;
	UINT8 param1        = 0;
	UINT8 param2        = 0;
	UINT8 param3        = 0;
	UINT8 uIndex        = 0;
	INT32 iResult       = 0;
	UINT8 uParaCount    = 0;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if((iResult != ERR_SUCCESS) || (uParaCount != 3))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SperakerReveiver, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize   = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SperakerReveiver, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize   = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SperakerReveiver, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize   = SIZEOF(param3);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param3, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SperakerReveiver, get parameter error3\n");
		AT_DFMS_Result_NA();
		return;
	}

	if((param1 == 0) && (param2 == 0) && (param3 == 0))
	{
		DM_StopTone();
		ATplayRing(101, 1, 10, 3);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+SPKSTEST:0");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1 == 0) && (param2 == 0) && (param3 == 1))
	{
		DM_StopTone();
		ATplayRing(101, 1, 4, 3);

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+SPKSTEST:0");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1 == 0) && (param2 == 3) && (param3  == 0))
	{
		DM_StopTone();
		ATplayRing(101, 1, 3, 0);

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+SPKSTEST:0");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1 == 0) && (param2 == 3) && (param3 == 1))
	{
		DM_StopTone();
		ATplayRing(101, 1, 1, 0);

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+SPKSTEST:0");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1 == 0) && (param2 == 4) && (param3 == 0))
	{
		DM_AudStreamStop();
		ATstopRing();
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+SPKSTEST:0");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1 == 0) && (param2 == 5) && (param3 == 0))
	{
		DM_StopTone();
		ATplayRing(134, 1, 10, 0);

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+SPKSTEST:0");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SperakerReveiver, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
}
VOID AT_DFMS_SimTest_Detec(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 *pRsp = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SimTest_Detec, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SimTest_Detec, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SimTest_Detec, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	if((param1  == 1) && (param2  == 1))
	{

		pRsp = AT_MALLOC(100);

		if(CFW_GetSimStatus(CFW_SIM_0) == CFW_SIM_NORMAL)
			AT_Sprintf(pRsp, "+SIMDETEC:1, SIM");
		else
			AT_Sprintf(pRsp, "+SIMDETEC:1, NOS");

		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 1) && (param2  == 2))
	{

		pRsp = AT_MALLOC(100);
		if(CFW_GetSimStatus(CFW_SIM_1) == CFW_SIM_NORMAL)
			AT_Sprintf(pRsp, "+SIMDETEC:1, SIM");
		else
			AT_Sprintf(pRsp, "+SIMDETEC:1, NOS");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 1))
	{

		UINT8 *pICCID = GetICCIDNumber(0);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+SIMDETEC:%s", pICCID);

		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}

	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SimTest_Detec, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}


}

VOID AT_DFMS_SerialNumber(AT_CMD_PARA *pParam)
{
	UINT8 len           = 0;
	UINT8 *pRsp         = NULL;
	UINT8 uSize         = 0;
	UINT8 uIndex        = 0;
	UINT8 param1        = 0;
	UINT8 param2        = 0;
	INT32 iResult       = 0;
	UINT8 uParaCount    = 0;
	char serialNum[12]  = {0,};
	UINT8 arrCharacterSet[52] = {0,};

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SerialNumber, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize   = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SerialNumber, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(param1 == 1)
	{
		uIndex++;
		uSize   = SIZEOF(param2);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
		if(iResult != ERR_SUCCESS || (param2 != 0))
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SerialNumber, get parameter error1\n");
			AT_DFMS_Result_NA();
			return;
		}

		CFW_EmodGetSN(arrCharacterSet, &len);
		strncpy(serialNum, arrCharacterSet, 11);
		serialNum[11] = '\0';
		pRsp = AT_MALLOC(128);
		AT_Sprintf(pRsp, "\r\n+SERIALNO:1,%s\r\n", serialNum);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if(param1 == 2)
	{
		uIndex++;
		uSize   = SIZEOF(arrCharacterSet);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &arrCharacterSet, &uSize);
		if(iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
			AT_DFMS_Result_NA();
			return;
		}
		CFW_EmodSaveSN(arrCharacterSet, AT_StrLen(arrCharacterSet));
		if(!isInCall())
		{
			/*
			// !!! if we find a few blocks to flush, we flush!
			// if many, we do NOT flush because it will cause ui blocking.
			// The block numbers to flush is a experience value.

			if (VDS_CacheGetBlkCnt() < 20) {
			while(VDS_CacheGetBlkCnt() > 0) {
			COS_Sleep(5);
			VDS_FlushCache();
			}
			}
			*/
			// -1 means, just flush as much as system can
			VDS_SyncFlush(-1);
		}

		pRsp = AT_MALLOC(64);
		AT_Sprintf(pRsp, "\r\n+SERIALNO:2,OK\r\n");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
}



#define HW_DFMS_VERSION 	1
#define HW_PROJECT_NAME 	2
#define HW_CHIP_TYPE 		3
#define HW_SW_VERSION 		4
#define HW_ED22 			5


UINT32 DFMS_SetHWVersion(INT8 *version)
{
	UINT32 ret = ERR_SUCCESS;
	HANDLE hkey;
	REG_OpenKey(REG_HKEY_CURRENT_COMM, "DFMS", &hkey);
	if(version == NULL)
	{
		return ERR_EMPTY_PRI_DNSSERVER_IP;
	}
	ret = REG_SetValue(hkey, "HW_VER", REG_TYPE_STRING, (PVOID) version, strlen(version));
	REG_CloseKey(hkey);
	return ret;

}

UINT32 DFMS_GetHWVersion(INT8 *version, UINT8 type)
{
	UINT32 ret = ERR_SUCCESS;
	HANDLE hkey = 0;
	UINT8 uType = REG_TYPE_STRING;
	UINT8 pPwdSize = 63;

	REG_OpenKey(REG_HKEY_CURRENT_COMM, "DFMS", &hkey);

	switch(type)
	{
	case 1:
		ret = REG_GetValue(hkey, "HW_VER", &uType, (PVOID) version, &pPwdSize);
		break;
	case 2:
		ret = REG_GetValue(hkey, "PRJ_NAME", &uType, (PVOID) version, &pPwdSize);
		break;
	case 3:
		ret = REG_GetValue(hkey, "CHIP", &uType, (PVOID) version, &pPwdSize);
		break;
	case 4:
		ret = REG_GetValue(hkey, "SW_VER", &uType, (PVOID) version, &pPwdSize);
		break;
	case 5:
		ret = REG_GetValue(hkey, "ED", &uType, (PVOID) version, &pPwdSize);
		break;
	default:
		break;

	}
	//ret = REG_GetValue(hkey, "HW_VER", &uType,(PVOID) version, &pPwdSize);

	REG_CloseKey(hkey);

	return ret;

}

VOID AT_DFMS_SWversion(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 param3  = 0;
	UINT8 *pRsp = NULL;
	UINT8 arrCharacterSet[15] = { 0 };

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 3))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SWversion, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SWversion, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SWversion, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(param1  == 2)
	{

		uIndex++;
		uSize  = SIZEOF(arrCharacterSet);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &arrCharacterSet, &uSize);
		if (iResult != ERR_SUCCESS )
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SWversion, get parameter error3\n");
			AT_DFMS_Result_NA();
			return;
		}
	}
	else
	{
		uIndex++;
		uSize  = SIZEOF(param3);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param3, &uSize);
		if (iResult != ERR_SUCCESS )
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SWversion, get parameter error3\n");
			AT_DFMS_Result_NA();
			return;
		}
	}

	if((param1  == 1) && (param2  == 1) && (param3  == 0))
	{

		DFMS_GetHWVersion(arrCharacterSet, HW_DFMS_VERSION);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+VERSNAME:1, %s", arrCharacterSet);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 1) && (param2  == 2) && (param3  == 0))
	{
		DFMS_GetHWVersion(arrCharacterSet, HW_PROJECT_NAME);
		pRsp = AT_MALLOC(100);
		//AT_Sprintf(pRsp, "+VERSNAME:1, GT_E2230");//To do
		AT_Sprintf(pRsp, "+VERSNAME:1, %s", arrCharacterSet);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 1) && (param2  == 3) && (param3  == 0))
	{
		//DFMS_GetHWVersion(arrCharacterSet,HW_CHIP_TYPE);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+VERSNAME:1, RDA8809");//To do
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 1) && (param2  == 8) && (param3  == 0))
	{

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+VERSNAME:1, %s", tgt_GetBuildVerNo());
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 1) && (param2  == 9) && (param3  == 0))
	{
		// DFMS_GetHWVersion(arrCharacterSet,HW_SW_VERSION);
		char *version = NULL;
		version = csw_VerGetString(CSW_VER_MODULE_ID_MMI);
		//char* ver = version;
		pRsp = AT_MALLOC(100);
		if(strcmp(version, "CoolMMI (-1)") == 0)
		{
			AT_Sprintf(pRsp, "+VERSNAME:1, %s", tgt_GetBuildVerNo());
		}
		else
		{
			AT_Sprintf(pRsp, "+VERSNAME:1, %s", version);
		}

		//AT_Sprintf(pRsp, "+VERSNAME:1, %s",tgt_GetBuildVerNo());
		//AT_Sprintf(pRsp, "+VERSNAME:1, E1200SJPMH1");//TO do
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 3) && (param2  == 0) && (param3  == 0))
	{
		DFMS_GetHWVersion(arrCharacterSet, HW_ED22);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+VERSNAME:1, %s", arrCharacterSet);
		//AT_Sprintf(pRsp, "+VERSNAME:1,ED22");//TO do
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 2) && (param2  == 1))
	{
		DFMS_SetHWVersion(arrCharacterSet);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+VERSNAME:2, %s", arrCharacterSet); //TO do
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SWversion, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
}

VOID AT_DFMS_RTC(AT_CMD_PARA *pParam)
{
	INT32 iResult       = 0;
	UINT8 uParaCount    = 0;
	UINT8 uIndex        = 0;
	UINT8 uSize         = 0;
	UINT8 param1        = 0;
	UINT8 *pRsp         = NULL;
	UINT16 Y;
	UINT8 M, D, H, I, S, W;
	TM_SYSTEMTIME systemTime = {0,};

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if((iResult != ERR_SUCCESS) || ((uParaCount != 1) && (uParaCount != 8)))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize   = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(param1 == 1)
	{
		TM_GetSystemTime(&systemTime);

		pRsp = AT_MALLOC(1024);
		AT_Sprintf(pRsp, "\r\n+RTCCTEST:1,%d%d%d%d%d%d%d\r\n",
		           systemTime.uYear, systemTime.uMonth, systemTime.uDay, systemTime.uHour, systemTime.uMinute, systemTime.uSecond, systemTime.uDayOfWeek);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if(param1 == 2)
	{
		uIndex++;
		uSize   = SIZEOF(Y);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT16, &Y, &uSize);
		if(iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
			AT_DFMS_Result_NA();
			return;
		}
		uIndex++;
		uSize   = SIZEOF(M);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &M, &uSize);
		if(iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
			AT_DFMS_Result_NA();
			return;
		}
		uIndex++;
		uSize   = SIZEOF(D);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &D, &uSize);
		if(iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
			AT_DFMS_Result_NA();
			return;
		}
		uIndex++;
		uSize   = SIZEOF(H);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &H, &uSize);
		if(iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
			AT_DFMS_Result_NA();
			return;
		}
		uIndex++;
		uSize   = SIZEOF(I);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &I, &uSize);
		if(iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
			AT_DFMS_Result_NA();
			return;
		}
		uIndex++;
		uSize   = SIZEOF(S);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &S, &uSize);
		if(iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
			AT_DFMS_Result_NA();
			return;
		}
		uIndex++;
		uSize   = SIZEOF(W);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &W, &uSize);
		if(iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
			AT_DFMS_Result_NA();
			return;
		}

		systemTime.uYear    = Y;
		systemTime.uMonth   = M;
		systemTime.uDay     = D;
		systemTime.uHour    = H;
		systemTime.uMinute  = I;
		systemTime.uSecond  = S;
		systemTime.uDayOfWeek = W;

		TM_SetSystemTime(&systemTime);
		pRsp = AT_MALLOC(128);
		AT_Sprintf(pRsp, "\r\n+RTCCTEST=2,\r\n");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_TCPIP_CmdFunc_NETAPN, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
}

VOID AT_DFMS_TEMPTEST(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 param3  = 0;
	UINT16 tempvalue = 0;
	UINT8 *pRsp = NULL;
	UINT8 arrCharacterSet[15] = { 0 };

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 3))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_TEMPTEST, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_TEMPTEST, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_TEMPTEST, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param3);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param3, &uSize);
	if (iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_TEMPTEST, get parameter error3\n");
		AT_DFMS_Result_NA();
		return;
	}

	if((param1  == 1) && (param2  == 0) && (param3  == 0))
	{

		tempvalue = pmd_GetVbatTemperature();
		AdcToTemperature(tempvalue);

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+TEMPTEST:1, %d", AdcToTemperature(tempvalue));
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 1) && (param2  == 0) && (param3  == 1))
	{

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+TEMPTEST:1, Don't support");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 1) && (param2  == 1) && (param3  == 0))
	{

		tempvalue = pmd_GetVbatTemperature();

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+TEMPTEST:1, %d", tempvalue);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 1) && (param2  == 1) && (param3  == 1))
	{

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+TEMPTEST:1, Don't support");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}

	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_TEMPTEST, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}


}

VOID AT_DFMS_MAXPOWER(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 param3  = 0;
	UINT8 *pRsp = NULL;
	int16 maxpower = 0;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 3))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_MAXPOWER, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_MAXPOWER, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_MAXPOWER, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param3);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param3, &uSize);
	if (iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_MAXPOWER, get parameter error3\n");
		AT_DFMS_Result_NA();
		return;
	}

	if((param1  == 0) && (param2  == 0) && (param3  == 0))
	{

		maxpower = rfd_GetMaxPower(GSM_BAND_GSM850);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "\r\n+MAXPOWER:0 %d\n\r", maxpower);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 0) && (param3  == 1))
	{
		maxpower	 = 3330;
		rfd_SetMaxPower(GSM_BAND_GSM850, maxpower);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "\r\n+MAXPOWER:0\n\r");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 1) && (param3  == 0))
	{

		maxpower = rfd_GetMaxPower(GSM_BAND_DCS1800);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "\r\n+MAXPOWER:0 %d\n\r", maxpower);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 1) && (param3  == 1))
	{
		maxpower = 3300;
		rfd_SetMaxPower(GSM_BAND_DCS1800, maxpower);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "\r\n+MAXPOWER:0\n\r");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 2) && (param3  == 0))
	{

		maxpower = rfd_GetMaxPower(GSM_BAND_PCS1900);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "\r\n+MAXPOWER:0 %d\n\r", maxpower);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 2) && (param3  == 1))
	{

		maxpower = 3300;
		rfd_SetMaxPower(GSM_BAND_PCS1900, maxpower);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "\r\n+MAXPOWER:0\n\r");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 3) && (param3  == 0))
	{

		maxpower = rfd_GetMaxPower(GSM_BAND_GSM900);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "\r\n+MAXPOWER:0 %d\n\r", maxpower);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 3) && (param3  == 1))
	{

		maxpower	 = 3330;
		rfd_SetMaxPower(GSM_BAND_GSM900, maxpower);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "\r\n+MAXPOWER:0\n\r");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 9) && (param3  == 9))
	{

		pRsp = AT_MALLOC(100);
		// TODO:   NEED API for TX OFF
		AT_Sprintf(pRsp, "\r\n+MAXPOWER:0\n\r");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}

	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_MAXPOWER, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}


}
VOID AT_DFMS_READRSSI(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 param3  = 0;
	UINT8 *pRsp = NULL;
	int16 maxpower = 0;
	int16 channel = 0;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 3))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_READRSSI, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_READRSSI, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_READRSSI, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param3);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param3, &uSize);
	if (iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_READRSSI, get parameter error3\n");
		AT_DFMS_Result_NA();
		return;
	}

	if((param1  == 0) && (param2  == 0) && (param3  == 0))
	{

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+READRSSI:0,  %d", maxpower);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 1) && (param3  == 0))
	{
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+READRSSI:0,  %d", maxpower);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 2) && (param3  == 0))
	{

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+READRSSI:0,  %d", maxpower);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 0) && (param2  == 3) && (param3  == 0))
	{
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+READRSSI:0,  %d", maxpower);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 1) && (param2  == 0) && (param3  == 0))
	{

		maxpower = rfd_GetMaxPower(GSM_BAND_PCS1900);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+READRSSI:1, %d %d", channel, maxpower);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+Not support");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
		return;
	}


}

#define KEYCMD_AT 1
#define KEYCOMD_NUM 69

#ifdef KEYCMD_DM
const char DM_KEYCMD_map[KEYCOMD_NUM] =
{
	0x31,
	0x32,
	0x33,
	0x34,
	0x35,
	0x36,
	0x37,
	0x38,
	0x39,
	0x30,
	0x50,
	0x51,
	0x23,
	0x2a,
	0x52,
	0x54,
	0x55,
	0x63,
	0x64,
	0x65,
	0x66,
	0x8d,
	0x8c,
	0x5b,
	0x5c,
	0x95,
	0x97,
	0x98,
	0xde,
	0x96,
	0x9b,
	0xb5,
	0xb6,
	0x9d,
	0xe3,
	0xf1,
	0xef,
	0xe5,
	0xf8,
	0xe6,
	0xe7,
	0xe8,
	0xc4,
	0xe9,
	0xea,
	0xeb,
	0xf3,
	0xf2,
	0xc5,
	0xc6,
	0xc0,
	0xec,
	0xe4,
	0xc1,
	0xc3,
	0xf0,
	0xc7,
	0xee,
	0xc2,
	0xed,
	0xf7,
	0xe1,
	0xf4,
	0xf5,
	0xf6,
	0xc8,
	0xca,
	0xf3,
	0x0b,
};

#endif

#ifdef KEYCMD_AT
const char AT_KEYCMD_map[KEYCOMD_NUM] =
{
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10,
	11,
	12,
	13,
	14,
	15,
	22,
	23,
	18,
	20,
	24,
	25,
	26,
	27,
	28,
	29,
	30,
	31,
	32,
	33,
	16,
	38,
	108,
	109,
	110,
	65,
	66,
	67,
	68,
	69,
	70,
	71,
	72,
	73,
	74,
	75,
	76,
	77,
	78,
	79,
	80,
	81,
	82,
	83,
	84,
	85,
	86,
	87,
	88,
	89,
	90,
	97,
	99,
	100,
	101,
	102,
	103,
	105,
	106,
	107,
};
#endif

#ifdef KEYCMD_PTE
const char PTE_KEYCMD_map[KEYCOMD_NUM] =
{
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10,
	11,
	12,
	13,
	14,
	15,
	22,
	23,
	18,
	20,
	24,
	25,
	26,
	27,
	28,
	29,
	30,
	31,
	32,
	33,
	16,
	38,
	108,
	109,
	110,
	65,
	66,
	67,
	68,
	69,
	70,
	71,
	72,
	73,
	74,
	75,
	76,
	77,
	78,
	79,
	80,
	81,
	82,
	83,
	84,
	85,
	86,
	87,
	88,
	89,
	90,
	97,
	99,
	100,
	101,
	102,
	103,
	105,
	106,
	107,
};
#endif

#ifdef KEYCMD_RAPI
const char RAPI_KEYCMD_map[KEYCOMD_NUM] =
{
	0x31,
	0x32,
	0x33,
	0x34,
	0x35,
	0x36,
	0x37,
	0x38,
	0x39,
	0x30,
	0x78,
	0x77,
	0x72,
	0x73,
	0x1b,
	0x75,
	0x76,
	0x26,
	0x28,
	0x25,
	0x27,
	0xff,
	0x8c,
	0x70,
	0x71,
	0xff,
	0xff,
	0x5b,
	0x85,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0x41,
	0x42,
	0x43,
	0x45,
	0x46,
	0x47,
	0x48,
	0x49,
	0x4a,
	0x4b,
	0x4c,
	0x4d,
	0x4e,
	0x4f,
	0x50,
	0x51,
	0x52,
	0x53,
	0x54,
	0x55,
	0x56,
	0x57,
	0x58,
	0x59,
	0x5a,
	0x20,
	0xc6,
	0x0d,
	0x6e,
	0x08,
	0xbc,
	0x10,
	0xbe,
	0xe2,

};
#endif

#ifdef KEYCMD_ETS
const char ETS_KEYCMD_map[KEYCOMD_NUM] =
{
	0x01,
	0x02,
	0x03,
	0x04,
	0x05,
	0x06,
	0x07,
	0x08,
	0x09,
	0x00,
	0x0c,
	0x0d,
	0x0a,
	0x0b,
	0x0e,
	0x1a,
	0x1b,
	0x11,
	0x12,
	0x15,
	0x14,
	0x17,
	0x16,
	0x19,
	0x18,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
	0xff,
};
#endif

unsigned char KeyMapChst[] =
{
	KP_1        ,  /* '1' */
	KP_2        ,  /* '2' */
	KP_3        ,  /* '3' */
	KP_4        ,  /* '4' */
	KP_5        ,  /* '5' */
	KP_6        ,  /* '6' */
	KP_7        ,  /* '7' */
	KP_8        ,  /* '8' */
	KP_9        ,  /* '9' */
	KP_0        ,  /* '0' */
	KP_SND      ,  /* 'S' */
	KP_END, //KP_END      ,  /* 'E' */
	KP_POUND    ,  /* '#' */
	KP_STAR     ,  /* '*' */
	KP_SR      ,  /* 'Y' */
	KP_VD       ,  /* 'D' */
	KP_VU       ,  /* 'U' */
	KP_UP       ,  /* '^' */
	KP_DW       ,  /* 'V' */
	KP_LT       ,  /* '<' */
	KP_RT       ,  /* '>' */
	KP_UNMAPPED ,  /* 'M' */
	KP_OK, //KP_SC       ,  /* '-' */
	KP_SL       ,  /* '[' */
	KP_SR       ,  /* ']' */
	KP_PWR      ,  /* 'P' */
	KP_UNMAPPED ,  /* ' ' */
	KP_END ,  /* ' ' */
	KP_UNMAPPED ,  /* ' ' */
	KP_UNMAPPED ,  /* ' ' */
	KP_UNMAPPED ,  /* ' ' */
	KP_UNMAPPED ,  /* ' ' */
	KP_SHIFT    ,  /* '}' */
	KP_UNMAPPED ,  /* ' ' */
	KP_A        ,  /* 'a' */
	KP_B        ,  /* 'b' */
	KP_C        ,  /* 'c' */
	KP_D        ,  /* 'd' */
	KP_E        ,  /* 'e' */
	KP_F        ,  /* 'f' */
	KP_G        ,  /* 'g' */
	KP_H        ,  /* 'h' */
	KP_I        ,  /* 'i' */
	KP_J        ,  /* 'j' */
	KP_K        ,  /* 'k' */
	KP_L        ,  /* 'l' */
	KP_M        ,  /* 'm' */
	KP_N        ,  /* 'n' */
	KP_O        ,  /* 'o' */
	KP_P        ,  /* 'p' */
	KP_Q        ,  /* 'q' */
	KP_R        ,  /* 'r' */
	KP_S        ,  /* 's' */
	KP_T        ,  /* 't' */
	KP_U        ,  /* 'u' */
	KP_V        ,  /* 'v' */
	KP_W        ,  /* 'w' */
	KP_X        ,  /* 'x' */
	KP_Y        ,  /* 'y' */
	KP_Z        ,  /* 'z' */
	KP_SPACE    ,  /* ' ' */
	KP_UNMAPPED ,  /* ' ' */
	KP_OK, //KP_ENTER    ,  /* '\n'*/
	KP_STOP     ,  /* '.' */
	KP_BACK     ,  /* 'C' */
	KP_COMMA    ,  /* ',' */
	KP_UNMAPPED ,  /* ' ' */
	KP_QUES     ,  /* '?' */
	KP_SMS      ,  /* '$' */
};
#define LONGPRESS_TIME (2000)

typedef struct AT_KEY_TIMER_EVT
{

	UINT32 timer_id;
	UINT32 Key;

} AT_KEY_TIMER_EVT;

AT_KEY_TIMER_EVT g_keytimerEvnt;

unsigned char GetKeyFromKeycode( unsigned char keycode)
{

	int index = 0;
	AT_TC(g_sw_DFMS, "exe       In GetKeyFromKeycode keycode =%d\n", keycode);
	for(index = 0; index < KEYCOMD_NUM; index++)
	{
		if(AT_KEYCMD_map[index] == keycode)
			break;
	}
	AT_TC(g_sw_DFMS, "exe       In GetKeyFromKeycode index =%d\n", index);
	if(index < KEYCOMD_NUM)
		return       KeyMapChst[index];
	else
		return KP_UNMAPPED;
}

VOID AT_KEYLONG_timer()
{
	hal_KeyRemoteHandler(g_keytimerEvnt.Key, HAL_KEY_UP);

}
typedef struct
{
	short nKeyCode;     //From Key Pad Driver
	short nMMIKeyCode;  //Key code mapped from MMI perspective
} atKeyPadMap;

static const atKeyPadMap nkeymap[] =
{
	{KP_0,              KEYCODE_0},
	{KP_1,              KEYCODE_1},
	{KP_2,              KEYCODE_2},
	{KP_3,              KEYCODE_3},
	{KP_4,              KEYCODE_4},
	{KP_5,              KEYCODE_5},
	{KP_6,              KEYCODE_6},
	{KP_7,              KEYCODE_7},
	{KP_8,              KEYCODE_8},
	{KP_9,              KEYCODE_9},
	{KP_STAR,           KEYCODE_STAR},
	{KP_POUND,          KEYCODE_POUND},
	{KP_SL,             KEYCODE_SL},
	{KP_SR,             KEYCODE_SR},
	{KP_UP,             KEYCODE_UP},
	{KP_DW,             KEYCODE_DOWN},
	{KP_LT,             KEYCODE_LEFT},
	{KP_RT,             KEYCODE_RIGHT},
	{KP_OK,             KEYCODE_ENTER},
#ifdef __SENDKEY2_SUPPORT__
	{KP_BACK,           KEYCODE_CALL},
	{KP_DEL,            KEYCODE_CALL2},
#else
	{KP_SND,            KEYCODE_CALL},
#endif
#ifdef __PROJECT_GT_VER__
	{KP_PWR,            KEYCODE_POWER},
	{KP_END,            KEYCODE_END},
#else
	{KP_PWR,            KEYCODE_END},
#endif
	{KP_VD,             KEYCODE_VOL_DOWN},
	{KP_VU,             KEYCODE_VOL_UP},
	{KP_SMS,            KEYCODE_SMS},
	{KP_MUSIC,          KEYCODE_MUSIC},
	{KP_FM,             KEYCODE_FM},
	{KP_F0,             KEYCODE_CAMERA},
	{KP_NB,             KEYCODE_INVALID}
};

static short keycodeConvertScancode (short key_code)
{
	short i = 0;
	short size = (sizeof(nkeymap)) / (sizeof (atKeyPadMap));
	for (i = 0; i < size; i++)
	{
		if (nkeymap[i].nKeyCode == key_code)
		{
			return nkeymap[i].nMMIKeyCode;
		}
	}

	return KEYCODE_INVALID;
}
//extern void postLongPressForAt(short keyCode);
extern bool PostAtKeyMessage(unsigned int  keyTypes, unsigned int  keyCode);
extern void setAtShutDown(void);

VOID AT_KEYHOLDCOMMAND(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 *pRsp = NULL;
	unsigned char key = KP_UNMAPPED;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount > 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_KEYCOMMAND, parameter error\n");
		//		AT_DFMS_Result_NA();
		return;
	}

	if(uParaCount == 1)
	{
		uIndex  = 0;
		uSize  = SIZEOF(param1);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
		if (iResult != ERR_SUCCESS )
		{
			AT_TC(g_sw_DFMS, "exe in AT_KEYCOMMAND, get parameter error:param1= %d\n", param1);
			return;
		}

		key = GetKeyFromKeycode(param1);

		if(key == KP_PWR)
			setAtShutDown();
		else
			StartLongPressTimerSimulator(key);

		pRsp = AT_MALLOC(120);
		AT_Sprintf(pRsp, "+AT+KEYHOLD=key%d\n",   key   );
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_KEYCOMMAND, get parameter error:No match the presss, release...\n");
		//    AT_DFMS_Result_NA();
		return;
	}

}

VOID AT_KEYCOMMAND(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 *pRsp = NULL;
	UINT8 arrCharacterSet[15] = { 0 };
	UINT8 nParamLen           = sizeof(arrCharacterSet);
	unsigned char key = KP_UNMAPPED;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount > 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_KEYCOMMAND, parameter error\n");
		//		AT_DFMS_Result_NA();
		return;
	}

	if(uParaCount == 1)
	{
		uIndex  = 0;
		uSize  = SIZEOF(param1);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
		AT_TC(g_sw_DFMS, "exe       in AT_KEYCOMMAND, get parameter :param1= %d\n", param1);
		if (iResult != ERR_SUCCESS )
		{
			AT_TC(g_sw_DFMS, "exe       in AT_KEYCOMMAND, get parameter error:param1= %d\n", param1);
			//   AT_DFMS_Result_NA();
			return;
		}

		key = GetKeyFromKeycode(param1);

		if(key == KP_VD)
		{
			if(isInCall() || isInCalling())
			{
				hal_KeyRemoteHandler((UINT32)KP_UP, HAL_KEY_DOWN);
				COS_Sleep(5);
				hal_KeyRemoteHandler((UINT32)KP_UP, HAL_KEY_UP);
			}
			else
			{
				PostAtKeyMessage(0x10, keycodeConvertScancode(KP_VU));//22:KEYCODE_VOL_UP, 0x10:MSG_KEYDOWN
				COS_Sleep(5);
				PostAtKeyMessage(0x12, keycodeConvertScancode(KP_VU));//22:KEYCODE_VOL_UP,0x12:MSG_KEYUP
			}
		}
		else if(key == KP_VU)
		{
			if(isInCall() || isInCalling() /*|| getLauncherForAt()*/)
			{
				hal_KeyRemoteHandler((UINT32)KP_DW, HAL_KEY_DOWN);
				COS_Sleep(5);
				hal_KeyRemoteHandler((UINT32)KP_DW, HAL_KEY_UP);
			}
			else
			{
				PostAtKeyMessage(0x10, keycodeConvertScancode(KP_VD));//23:KEYCODE_VOL_DOWN, 0x10:MSG_KEYDOWN
				COS_Sleep(5);
				PostAtKeyMessage(0x12, keycodeConvertScancode(KP_VD));//23:KEYCODE_VOL_DOWN, 0x12:MSG_KEYUP
			}
		}
		else
		{
			hal_KeyRemoteHandler((UINT32)key, HAL_KEY_DOWN);
			COS_Sleep(5);
			hal_KeyRemoteHandler((UINT32)key, HAL_KEY_UP);
		}

		pRsp = AT_MALLOC(1024);
		AT_Sprintf(pRsp, "+AT+KEY=%d\n",  key   );
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if(uParaCount == 2)
	{

		uIndex  = 0;
		uSize  = SIZEOF(param1);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
		if (iResult != ERR_SUCCESS )
		{
			AT_TC(g_sw_DFMS, "exe       in AT_KEYCOMMAND, get parameter error:param1= %d\n", param1);
			AT_DFMS_Result_NA();
			return;
		}

		uIndex++;
		AT_MemZero(arrCharacterSet, sizeof(arrCharacterSet));
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, arrCharacterSet, &nParamLen);

		if (iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "exe       in AT_KEYCOMMAND, get parameter error:iResult = %d,arrCharacterSet = %x\n", iResult, arrCharacterSet);
			AT_DFMS_Result_NA();
			return;
		}

		if((AT_StrCmp(arrCharacterSet, "press") == 0) || (AT_StrCmp(arrCharacterSet, "PRESS") == 0))
		{
			key = GetKeyFromKeycode(param1);
			hal_KeyRemoteHandler((UINT32)key, HAL_KEY_DOWN);
		}
		else if  ((AT_StrCmp(arrCharacterSet, "release") == 0) || (AT_StrCmp(arrCharacterSet, "RELEASE") == 0))
		{
			key = GetKeyFromKeycode(param1);
			COS_KillTimerEX(GetMmiTaskHandle(MOD_ADP), ADP_AT_KEYLONG_TIMER_ID);
			hal_KeyRemoteHandler((UINT32)key, HAL_KEY_UP);
		}
		else if  ((AT_StrCmp(arrCharacterSet, "longpress") == 0) || (AT_StrCmp(arrCharacterSet, "LONGPRESS") == 0))
		{
			g_keytimerEvnt.Key = key;
			g_keytimerEvnt.timer_id = ADP_AT_KEYLONG_TIMER_ID;

			COS_KillTimerEX(GetMmiTaskHandle(MOD_ADP), ADP_AT_KEYLONG_TIMER_ID);
			COS_SetTimerEX(GetMmiTaskHandle(MOD_ADP), ADP_AT_KEYLONG_TIMER_ID, 0, LONGPRESS_TIME);
		}
		else
		{
			AT_TC(g_sw_DFMS, "exe       in AT_KEYCOMMAND, get parameter error:No match the presss, release...\n");
			AT_DFMS_Result_NA();
			return;
		}

		pRsp = AT_MALLOC(1024);
		AT_Sprintf(pRsp, "+AT+KEY=%d,%s\n",  key, arrCharacterSet   );
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_TC(g_sw_DFMS, "exe       in AT_KEYCOMMAND, get parameter error:No match the presss, release...\n");
		AT_DFMS_Result_NA();
		return;
	}
}

VOID AT_DFMS_CmdFunc_ADMSFS(AT_CMD_PARA *pParam)
{
	UINT32 i;
	INT32 iResult;
	UINT8 iCount = 0;
	UINT8 iLen;
	UINT8 iMode;
	const UINT8 *pTestResp = "AT+ADMSFS=0,1";
	UINT8  szResp[32];

	if (pParam == NULL)
	{
		AT_DFMS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
		return;
	}
	if(AT_CMD_SET == pParam->iType)
	{
		iResult = AT_Util_GetParaCount(pParam->pPara, &iCount);
		if (iResult != ERR_SUCCESS)
		{
			AT_DFMS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
			return;
		}
		if(iCount != 1)
		{
			AT_DFMS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
			return;
		}
		iLen = 1;

		iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &iMode, &iLen);
		if(iResult != ERR_SUCCESS)
		{
			AT_DFMS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
			return;
		}
		// UART
		if(iMode == 0)
		{
			g_DfmsADMSFSMode = 0;
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0);
		}
		// USB
		else if(iMode == 1)
		{
			g_DfmsADMSFSMode = 1;
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0,  NULL, 0);
		}
		else
		{
			AT_DFMS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
			return;
		}
	}

	// Read command.
	else if(AT_CMD_READ == pParam->iType)
	{
		AT_Sprintf(szResp, "AT+ADMSFS=%d\n", g_DfmsADMSFSMode);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, szResp, AT_StrLen(szResp));
		return;
	}

	// Test command.
	else if(AT_CMD_TEST == pParam->iType)
	{
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pTestResp, AT_StrLen(pTestResp));
		return;
	}
	else
	{
		AT_DFMS_Result_Err(ERR_AT_CME_INVALID_COMMAND_LINE, CMD_ERROR_CODE_TYPE_CME);
		return;
	}
}

VOID AT_DFMS_CmdFunc_ADGFS(AT_CMD_PARA *pParam)
{
	UINT32 i;
	INT32 iResult;
	UINT8 iCount = 0;
	UINT8 iLen;
	UINT8 iFun;
	UINT32 iFunBmp = 0;
	const UINT8 *pTestResp = "+ADGFS:0,1,5,6";
	UINT8  szResp[32];
	UINT32 iTotal = 0;
	UINT32 iUsed = 0;
	CFW_SMS_STORAGE_INFO sStorageInfo;

	if (pParam == NULL)
	{
		AT_DFMS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
		return;
	}
	if(AT_CMD_SET == pParam->iType)
	{
		iResult = AT_Util_GetParaCount(pParam->pPara, &iCount);
		if (iResult != ERR_SUCCESS)
		{
			AT_DFMS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
			return;
		}
		if(iCount != 1)
		{
			AT_DFMS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
			return;
		}
		iLen = 1;

		iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &iFun, &iLen);
		if(iResult != ERR_SUCCESS)
		{
			AT_DFMS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
			return;
		}
		if(iFun == 0)
		{
			// [No External Memory Support]Check all of fun 1-6.
			iFunBmp |=   (0x1 << 1);
			iFunBmp |=  (0x1 << 4);
			iFunBmp |=  (0x1 << 5);
		}
		else if(iFun <= 6)
		{
			iFunBmp =  (0x1 << iFun);
		}
		else
		{
			AT_DFMS_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
			return;
		}
		// fun 1: [No External Memory Support] Call log, Contact, SMS/MMS,
		// Schedule/Calendar/Task and Memo should be generated in
		// the device until memory is full.
		if(iFunBmp & (0x1 << 1))
		{
			// Call log.
			Calllog_Get_SpaceInfo(&iTotal, &iUsed);
			if(iTotal != iUsed)
			{
				AT_TC(g_sw_DFMS, "DFMS_DEBUG:Calllog_Get_SpaceInfo iTotal= %d,iUsed = %d.", iTotal, iUsed);
				AT_DFMS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME);
				return;
			}
			// Phone book
			PB_GetPhoneBookCount(&iTotal, &iUsed);

			if(iTotal != iUsed)
			{
				AT_TC(g_sw_DFMS, "DFMS_DEBUG:PB_GetPhoneBookCount iTotal= %d,iUsed = %d.", iTotal, iUsed);
				AT_DFMS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME);
				return;
			}

			// SMS
			// NGGetSmsStorageInfoSyn
			iResult = CFW_CfgGetSmsStorageInfo(&sStorageInfo, CFW_SMS_STORAGE_ME, 0);
			if(iResult != ERR_SUCCESS || sStorageInfo.totalSlot != sStorageInfo.usedSlot)
			{
				AT_TC(g_sw_DFMS, "DFMS_DEBUG:CFW_CfgGetSmsStorageInfo iTotal= %d,iUsed = %d.", sStorageInfo.totalSlot, sStorageInfo.usedSlot);
				AT_DFMS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME);
				return;
			}

			// Schedule/Calendar/Task
			CAL_GetRecordListCount(&iTotal, &iUsed);
			if(iTotal != iUsed)
			{
				AT_TC(g_sw_DFMS, "DFMS_DEBUG:CAL_GetRecordListCount iTotal= %d,iUsed = %d.", iTotal, iUsed);
				AT_DFMS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME);
				return;
			}

			// Memo
			Note_GetRecordListCount(&iTotal, &iUsed);
			if(iTotal != iUsed)
			{
				AT_TC(g_sw_DFMS, "DFMS_DEBUG:Note_GetRecordListCount iTotal= %d,iUsed = %d.", iTotal, iUsed);
				//AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pErrorResp, AT_StrLen(pErrorResp));
				AT_DFMS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME);
				return;
			}
		}

		// All alarms should be off.
		if(iFunBmp & (0x1 << 5))
		{
			Alarm_GetActiveCount(&iTotal);
			if(iTotal != 0)
			{
				AT_TC(g_sw_DFMS, "DFMS_DEBUG:Alarm_GetActiveCount iTotal= %d.", iTotal);
				AT_DFMS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME);
				return;
			}
		}

		// All message status should be READ.
		if(iFunBmp & (0x1 << 6))
		{
			iResult = CFW_CfgGetSmsStorageInfo(&sStorageInfo, CFW_SMS_STORAGE_ME, 0);
			if (iResult != ERR_SUCCESS)
			{
				AT_TC(g_sw_DFMS, "DFMS_DEBUG:Alarm_GetActiveCount result = %d.", iResult);
				AT_DFMS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME);
				return;
			}
			if (sStorageInfo.unReadRecords != 0)
			{
				AT_TC(g_sw_DFMS, "DFMS_DEBUG:Alarm_GetActiveCount unReadRecords = %d.", sStorageInfo.unReadRecords);
				AT_DFMS_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME);
				return;
			}
		}
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0);
		return;
	}
	else if(AT_CMD_READ == pParam->iType)
	{
		AT_DFMS_Result_Err(ERR_AT_CME_INVALID_COMMAND_LINE, CMD_ERROR_CODE_TYPE_CME);
	}
	else if(AT_CMD_TEST == pParam->iType)
	{
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pTestResp, AT_StrLen(pTestResp));
	}
	else
	{
		AT_DFMS_Result_Err(ERR_AT_CME_INVALID_COMMAND_LINE, CMD_ERROR_CODE_TYPE_CME);
	}
}

PRIVATE BOOL AT_Get_Charger_Status()
{
	BOOL status = FALSE;

	switch(pmd_GetChargerStatus())
	{
	case PMD_CHARGER_PLUGGED           :
	case PMD_CHARGER_PRECHARGE         :
	case PMD_CHARGER_FAST_CHARGE       :
	case PMD_CHARGER_PULSED_CHARGE     :
	case PMD_CHARGER_PULSED_CHARGE_WAIT:
	case PMD_CHARGER_FULL_CHARGE       :
		status = TRUE;
		break;
	default:
		status = FALSE;
	}
	return status;
}

VOID AT_BATT_TEST(AT_CMD_PARA *pParam)
{
	PM_BATTERY_INFO batInfo = {0,};
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 *pRsp = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BATTTEST, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BATTTEST, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BATTTEST, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	pRsp = AT_MALLOC(100);
	memset(pRsp, 0x0, 100);

	if(param1 == 1 && param2 == 1) //read status
	{
		if(AT_Get_Charger_Status())
		{
			AT_Sprintf((char *)pRsp, "+BATTTEST:%d,CHAR", param1);
		}
		else
		{
			AT_Sprintf((char *)pRsp, "+BATTTEST:%d,BAOK", param1);
		}
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	}
	else if(param1 == 1 && param2 == 2) // read voltage
	{
		char cVoltage[16] = {0,};
		PM_GetBatteryState(&batInfo);
		ftoa((float)(batInfo.nBatteryVoltage) / 1000, cVoltage);
		AT_Sprintf((char *)pRsp, "+BATTTEST:%d,%s", param1, cVoltage);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	}
	else if(param1 == 1 && param2 == 3) // read real time voltage
	{
		char cRTVoltage[16] = {0,};
		PM_GetBatteryState(&batInfo);
		ftoa((float)batInfo.nBatteryRealTimeVoltage / 1000, cRTVoltage);
		AT_Sprintf((char *)pRsp, "+BATTTEST:%d,%s", param1, cRTVoltage);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	}
	else // not supported
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BATTTEST, parameters are not supported \n");
		AT_DFMS_Result_NA();
	}
	AT_FREE(pRsp);
}
#if 0

// Abhishek Sonal

VOID AT_BATT_TEST(AT_CMD_PARA *pParam)
{
	CHGMNG_STATE_INFO_T *p_chgmng_info = NULL;
	char str_tmp[14]        = {0};
	uint32 jigo_status = 0;
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 *pRsp = NULL;

	/*+ BUG98382 */ /*- BUG98382 */

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BATTTEST, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BATTTEST, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_BATTTEST, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	jigo_status = ADC_GetJIGConnectStatus();

	p_chgmng_info = CHGMNG_GetModuleState();

	if(NULL == p_chgmng_info)
	{
		return S_ATC_FAIL;
	}
	// read status

	if((param1  == 1) && (param2  == 1))
	{
		if(1 == jigo_status)
		{
			pRsp = AT_MALLOC(100);
			sprintf((char *)pRsp, "+BATTTEST:%d,JIGO", param1);
		}
		else if(CHGMNG_STARTING == p_chgmng_info->chgmng_state
		        || CHGMNG_CHARGING == p_chgmng_info->chgmng_state
		        || CHGMNG_PULSECHARGING == p_chgmng_info->chgmng_state)
		{
			pRsp = AT_MALLOC(100);
			sprintf((char *)pRsp, "+BATTTEST:%d,CHAR", param1);
		}
		else
		{
			pRsp = AT_MALLOC(100);
			sprintf((char *)pRsp, "+BATTTEST:%d,BAOK", param1);
		}
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}

	else if(1 == param1 && 2 == param2)
	{
		pRsp = AT_MALLOC(100);

		// BATTTEST is not showing proper results
		sprintf(str_tmp, "%2.2f", (double)p_chgmng_info->bat_cur_vol / 1000);
		//sprintf(str_tmp, "%d.%2d", (p_chgmng_info->bat_cur_vol)/1000, (p_chgmng_info->bat_cur_vol)%1000/10);
		sprintf((char *)pRsp, "+BATTTEST:%d,%s", param1, str_tmp);

		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_DFMS_Result_NA();
	}

}

#endif

#define MCC_LEN 3
#define MNC_LEN 2
VOID AT_SIM_TEST(AT_CMD_PARA *pParam)
{
	UINT8 *pRsp = NULL;
	pRsp = AT_MALLOC(1024);

	if(CFW_GetSimStatus(CFW_SIM_0) == CFW_SIM_ABSENT)
	{
		AT_Sprintf(pRsp, "+SIMTEST:1, no SIM Card\n");
	}
	else
	{
		UINT8 tmp[16] = {0,};
		UINT8 data[16] = {0,};
		UINT8 outLen = 0;
		UINT8 mcc[MCC_LEN + 1] = {0,};
		UINT8 mnc[MCC_LEN + 1] = {0,};
		UINT8 msin[11] = {0,};
		CFW_NW_STATUS_INFO info = {0,};

		CFW_CfgGetIMSI(tmp, CFW_SIM_0);
		cfw_IMSItoASC(tmp, data, &outLen);
		CFW_NwGetStatus(&info, CFW_SIM_0);

		strncpy(mcc, (char *)data, MCC_LEN);
		strncpy(mnc, (char *)(&(data[MCC_LEN])), MNC_LEN);
		strncpy(msin, (char *)(&(data[MCC_LEN + MNC_LEN])), outLen - (MCC_LEN + MNC_LEN));
		if(info.nStatus == API_NW_FULL_SVCE)
			AT_Sprintf(pRsp, "+SIMTEST:1, Connect NetWork: Yes\nMCC: %s\nMNC: %s\nMSIN: %s\n", mcc, mnc, msin);
		else
			AT_Sprintf(pRsp, "+SIMTEST:1, Connect NetWork: No\nMCC: %s\nMNC: %s\nMSIN: %s\n", mcc, mnc, msin);
	}
	AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	AT_FREE(pRsp);
}

extern bool checkDataScreenState(void);
extern void getCallLogInfo(int *pCur, int *pMax);
extern void getReceivedCallsInfo(int *pCount);
extern void getDialledCallsInfo(int *pCount);
extern void getMissedCallsInfo(int *pCount);
extern void getMessageInfo(int *pCur, int *pMax);
extern void getInboxInfo(int *pCount);
extern void getOutboxInfo(int *pCount);
extern void getSentboxInfo(int *pCount);
extern void getDraftInfo(int *pCount);
extern void getContactsInfo(int *pCur, int *pMax);
extern void getCalendarInfo(int *pCur, int *pMax);
extern void getMemoInfo(int *pCur, int *pMax);
extern void getRingtoneInfo(char **pStr);
extern void getWallpaperInfo(char **ppStr);
extern void getIMEIInfo(char *pStr);
extern void getErrorInfo(char *pStr);
extern bool checkCallLog(int cur, int max, char *pStrRet);
extern bool checkReceivedCalls(int count, char *pStrRet);
extern bool checkDialledCalls(int count, char *pStrRet);
extern bool checkMissedCalls(int count, char *pStrRet);
extern bool checkMessage(int cur, int max, char *pStrRet);
extern bool checkInbox(int count, char *pStrRet);
extern bool checkOutbox(int count, char *pStrRet);
extern bool checkSentbox(int count, char *pStrRet);
extern bool checkDraft(int count, char *pStrRet);
extern bool checkContacts(int cur, int max, char *pStrRet);
extern bool checkCalendar(int cur, int max, char *pStrRet);
extern bool checkMemo(int cur, int max, char *pStrRet);
extern bool checkRingtone(char *pStr, char *pStrRet);
extern bool checkWallpaper(char *pStr, char *pStrRet);
extern bool checkIMEI(char *pStr, char *pStrRet);
extern bool checkError(char *pStr, char *pStrRet);

VOID AT_DATASCREEN_TEST(AT_CMD_PARA *pParam)
{
	UINT8 *pRsp = NULL;
	int callLogCur      = 0;
	int callLogMax      = 0;
	int receivedCalls   = 0;
	int dialledCalls    = 0;
	int missedCalls     = 0;
	int messageCur      = 0;
	int messageMax      = 0;
	int inbox           = 0;
	int outbox          = 0;
	int sentbox         = 0;
	int draft           = 0;
	int contactsCur     = 0;
	int contactsMax     = 0;
	int calendarCur     = 0;
	int calendarMax     = 0;
	int memoCur         = 0;
	int memoMax         = 0;
	char *pRingtone     = NULL;
	char *pWallpaper    = NULL;
	char cIMEI[20] = {0,};
	char cError[4] = {0,};
	pRsp = AT_MALLOC(1024);

	getCallLogInfo(&callLogCur, &callLogMax);
	getReceivedCallsInfo(&receivedCalls);
	getDialledCallsInfo(&dialledCalls);
	getMissedCallsInfo(&missedCalls);
	getMessageInfo(&messageCur, &messageMax);
	getInboxInfo(&inbox);
	getOutboxInfo(&outbox);
	getSentboxInfo(&sentbox);
	getDraftInfo(&draft);
	getContactsInfo(&contactsCur, &contactsMax);
	getCalendarInfo(&calendarCur, &calendarMax);
	getMemoInfo(&memoCur, &memoMax);
	getRingtoneInfo(&pRingtone);
	getWallpaperInfo(&pWallpaper);
	getIMEIInfo(cIMEI);
	getErrorInfo(cError);

	if(checkDataScreenState())
	{
		AT_Sprintf(pRsp, "error: DataScreen don't open!\n CallLog: [%d/%d] Fail\n Received Call: [%d] Fail \
                \n Dialled Call: [%d] Fail\n Missed Call: [%d] Fail \
                \n Message: [%d/%d] Fail\n InBox: [%d] Fail \
                \n OutBox: [%d] Fail\n SentBox: [%d] Fail \
                \n Draft: [%d] Fail\n Contacts: [%d/%d] Fail \
                \n Calendar: [%d/%d] Fail\n Memo: [%d/%d] Fail \
                \n RingTone: [%s] Fail\n Wallpaper: [%s] Fail \
                \n IMEI: [%s] Fail\n Erro: [%s] Fail\n", \
		           callLogCur, callLogMax, receivedCalls, \
		           dialledCalls, missedCalls, \
		           messageCur, messageMax, inbox, \
		           outbox, sentbox, \
		           draft, contactsCur, contactsMax, \
		           calendarCur, calendarMax, memoCur, memoMax, \
		           pRingtone, pWallpaper, \
		           cIMEI, cError);
	}
	else
	{
		char pCallLogRet[5]       = {0,};
		char pReceivedCallsRet[5] = {0,};
		char pDialledCallsRet[5]  = {0,};
		char pMissedCallsRet[5]   = {0,};
		char pMessageRet[5]       = {0,};
		char pInboxRet[5]         = {0,};
		char pOutboxRet[5]        = {0,};
		char pSentboxRet[5]       = {0,};
		char pDraftRet[5]         = {0,};
		char pContactsRet[5]      = {0,};
		char pCalendarRet[5]      = {0,};
		char pMemoRet[5]          = {0,};
		char pRingtoneRet[5]      = {0,};
		char pWallpaperRet[5]     = {0,};
		char pIMEIRet[5]          = {0,};
		char pErrorRet[5]         = {0,};

		checkCallLog(callLogCur, callLogMax, pCallLogRet);
		checkReceivedCalls(receivedCalls, pReceivedCallsRet);
		checkDialledCalls(dialledCalls, pDialledCallsRet);
		checkMissedCalls(missedCalls, pMissedCallsRet);
		checkMessage(messageCur, messageMax, pMessageRet);
		checkInbox(inbox, pInboxRet);
		checkOutbox(outbox, pOutboxRet);
		checkSentbox(sentbox, pSentboxRet);
		checkDraft(draft, pDraftRet);
		checkContacts(contactsCur, contactsMax, pContactsRet);
		checkCalendar(calendarCur, calendarMax, pCalendarRet);
		checkMemo(memoCur, memoMax, pMemoRet);
		checkRingtone(pRingtone, pRingtoneRet);
		checkWallpaper(pWallpaper, pWallpaperRet);
		checkIMEI(cIMEI, pIMEIRet);
		checkError(cError, pErrorRet);

		AT_Sprintf(pRsp, "\n CallLog: [%d/%d] %s\n Received Call: [%d] %s \
                \n Dialled Calls: [%d] %s\n Missed Call: [%d] %s \
                \n Message: [%d/%d] %s\n InBox: [%d] %s \
                \n OutBox: [%d] %s\n SentBox: [%d] %s \
                \n Draft: [%d] %s\n Contacts: [%d/%d] %s \
                \n Calendar: [%d/%d] %s\n Memo: [%d/%d] %s \
                \n RingTone: [%s] %s\n Wallpaper: [%s] %s \
                \n IMEI: [%s] %s\n Erro: [%s] %s\n", \
		           callLogCur, callLogMax, pCallLogRet, receivedCalls, pReceivedCallsRet, \
		           dialledCalls, pDialledCallsRet, missedCalls, pMissedCallsRet, \
		           messageCur, messageMax, pMessageRet, inbox, pInboxRet, \
		           outbox, pOutboxRet, sentbox, pSentboxRet, \
		           draft, pDraftRet, contactsCur, contactsMax, pContactsRet, \
		           calendarCur, calendarMax, pCalendarRet, memoCur, memoMax, pMemoRet, \
		           pRingtone, pRingtoneRet, pWallpaper, pWallpaperRet, \
		           cIMEI, pIMEIRet, cError, pErrorRet);
	}
	AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	AT_FREE(pRsp);
}

VOID AT_DFMS_LOOPTEST(AT_CMD_PARA *pParam)
{

	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 param3  = 0;

	UINT8 *pRsp = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 3))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_LOOPTEST, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_LOOPTEST, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex++;
	uSize   = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_LOOPTEST, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex++;
	uSize   = SIZEOF(param3);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param3, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_LOOPTEST, get parameter error3\n");
		AT_DFMS_Result_NA();
		return;
	}

	if( param1  == 0)
	{
		if(param2 == 0)
		{

			if(param3 == 2)
			{
				//MIC ?Receiver Loopback On  //TODO BY AUDIO TEAM
				DM_StopTone();
				/* open loopback */
				CFW_EmodAudioTestStart(AUD_MODE_NORMAL);

				pRsp = AT_MALLOC(100);

				AT_Sprintf(pRsp, "+LOOPTEST:0");
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));

				AT_FREE(pRsp);
			}
			else if(param3 == 3)
			{
				//MIC ?Loud SPK Loopback On  //TODO BY AUDIO TEAM
				DM_StopTone();
				/* open loopback */
				CFW_EmodAudioTestStart(AUD_MODE_LOUDSPK);

				pRsp = AT_MALLOC(100);

				AT_Sprintf(pRsp, "+LOOPTEST:0");
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));

				AT_FREE(pRsp);
			}
			/*  else if(param3 ==5)  //Not application to Eider
			    {
			//MIC 2 ?Loud SPK Loopback On  //TODO BY AUDIO TEAM

			pRsp = AT_MALLOC(100);

			AT_Sprintf(pRsp, "+LOOPTEST:0");
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));

			AT_FREE(pRsp);
			}*/
			/* else if(param3 ==6)  //Not application to Eider
			   {
			//VoIP Loopback On  //TODO BY AUDIO TEAM

			pRsp = AT_MALLOC(100);

			AT_Sprintf(pRsp, "+LOOPTEST:0");
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));

			AT_FREE(pRsp);
			}*/
			else if(param3 == 7)
			{
				//MIC ?Ear SPK Loopback On  //TODO BY AUDIO TEAM

				DM_StopTone();
#if (HEADSET_MIC_TEST)
				/* open loopback */
				CFW_EmodAudioTestStart(AUD_MODE_HEADSET);
#else
				DM_PlayTone(24, 1, HEADSET_DURATION, 4);
#endif
				pRsp = AT_MALLOC(100);

				AT_Sprintf(pRsp, "+LOOPTEST:0");
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));

				AT_FREE(pRsp);
			}
			else
			{
				AT_DFMS_Result_NA();
			}
		}

		else if(param2 == 1 && param3 == 0)
		{
			//TODO BY AUDIO TEAM

			//MIC ?SPK Loopback Off

#if (HEADSET_MIC_TEST)
			CFW_EmodAudioTestEnd();
#else
			DM_StopTone();
#endif

			pRsp = AT_MALLOC(100);

			AT_Sprintf(pRsp, "+LOOPTEST:0");
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));

			AT_FREE(pRsp);
		}
		else
		{
			AT_DFMS_Result_NA();
		}

	}

	else
	{
		AT_DFMS_Result_NA();
	}

}// END OF LOOPTEST

VOID AT_DFMS_KEYULOCK(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 *pRsp = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);

	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_KEYULOCK, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_KEYULOCK, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex++;
	uSize   = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_KEYULOCK, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(param1 == 0 && param2 == 0)
	{
		//Key Lock   MMISET_SetAutoBoardKey(0);  //todo by setting team API to enable/disable keyauto lock
		AT_KeyLock();

		COS_Sleep(5);
		pRsp = AT_MALLOC(64);
		memset(pRsp, 0x0, 64);
		AT_Sprintf(pRsp, "\r\n+KEYULOCK:0,OK\n\r");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if (param1 == 0 && param2 == 1)
	{
		//Key unLock   MMISET_SetAutoBoardKey(1);// todo by setting team API to enable/disable keyauto lock
		AT_KeyUnLock();

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+KEYULOCK:0,OK");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_DFMS_Result_NA();
	}

}

VOID AT_DFMS_CALIDATE(AT_CMD_PARA *pParam)
{
	INT32 iResult       = 0;
	UINT8 uParaCount    = 0;
	UINT8 uIndex        = 0;
	UINT8 uSize         = 0;
	UINT16 param1       = 0;
	UINT16 param2       = 0;
	UINT16 param3       = 0;
	UINT16 param4       = 0;
	UINT8 *pRsp         = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if((iResult != ERR_SUCCESS) || (uParaCount != 4))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_CALIDATE, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize   = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT16, &param1, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_CALIDATE, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize   = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT16, &param2, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_CALIDATE, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize   = SIZEOF(param3);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT16, &param3, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_CALIDATE, get parameter error3\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize   = SIZEOF(param4);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT16, &param4, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_CALIDATE, get parameter error4\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(param1 == 1 && param2 == 0 && param3 == 0 && param4 == 0)
	{
		TM_SYSTEMTIME systemTime = {0,};
		if(TM_GetSystemTime(&systemTime))
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+CALIDATE:1, %d %d %d", systemTime.uYear, systemTime.uMonth, systemTime.uDay);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+CME ERROR:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
	}
	else if(param1 == 2)
	{
		TM_SYSTEMTIME systemTime = {0,};
		if(TM_GetSystemTime(&systemTime))
		{
			systemTime.uYear    = param2;
			systemTime.uMonth   = param3;
			systemTime.uDay     = param4;
			if(TM_SetSystemTime(&systemTime))
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf(pRsp, "+CALIDATE:2");
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			else
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf(pRsp, "+CME ERROR:NG\n");
				AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
		}
		else
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+CME ERROR:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
	}
	else
	{
		AT_DFMS_Result_NA();
	}
}

VOID AT_DFMS_IMEITEST(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 len;
	UINT8 arrCharacterSet[16] = { 0 }; //TODO DATA TEAM
	UINT8 nImeiLen;
	UINT8 nSim = 0; //AT_SIM_ID;
	UINT8 *pRsp = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_IMEITEST, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_IMEITEST, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	if(param1 == 0 || param1 == 1)
	{
		uIndex++;
		uSize   = SIZEOF(param2);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
		if (iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_IMEITEST, get parameter error2\n");
			AT_DFMS_Result_NA();
			return;
		}
		if(param1 == 0 && param2 == 0)
		{
			//imei erase
		}
		else if(param1 == 1)
		{
			if(param2 == 0)
			{
				//imei read

				//DFMS_GetIMEI(arrCharacterSet); TODO    FileSytem

				//#ifdef CFW_MULTI_SIM
				//CFW_EmodGetIMEI(UINT8* pImei,UINT8* pImeiLen,CFW_SIM_ID nSimID)
				//#elseCFW_EmodGetIMEI(nImei, &nImeiLen, nSim);
				CFW_EmodGetIMEI(arrCharacterSet, &nImeiLen, nSim);
				//#endif

				pRsp = AT_MALLOC(100);
				AT_Sprintf(pRsp, "+IMEITEST:1,%.15s", arrCharacterSet);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			else if(param2 == 1)
			{
				//meid read
				//DFMS_GetMEID(arrCharacterSet);   TODO    FileSytem

				pRsp = AT_MALLOC(100);
				AT_Sprintf(pRsp, "+IMEITEST:1, %s", arrCharacterSet);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			else
			{
				AT_DFMS_Result_NA();
			}
		}
	}
	else if(param1 == 2 || param1 == 3)
	{
		uIndex++;
		uSize   = SIZEOF(arrCharacterSet);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &arrCharacterSet, &uSize);
		if (iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_IMEITEST, get parameter error1\n");
			// AT_DFMS_Result_NA(); //TODO DATA TEAM
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+IMEITEST:input error ,%d", uSize);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);

			return;
		}

		if(0/* !msl_verified*/ )//TODO DATA TEAM
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+IMEITEST:NG NEEDMSLAUTH");
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
			return;
		}

		if(0/*!ak_seed_no_verified*/)//TODO DATA TEAM
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+IMEITEST:NG NEEDAKSEEDAUTH");
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
			return;
		}

		if(param1 == 2)
		{
			//imei write
			//DFMS_SetIMEI(arrCharacterSet);  TODO    FileSytem
			nImeiLen = 15; //TODO DATA TEAM
			CFW_EmodSaveIMEI(arrCharacterSet, nImeiLen, nSim);
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+IMEITEST:2, %s", arrCharacterSet);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else
		{
			//meid write

			//DFMS_SetMEID(arrCharacterSet);  TODO    FileSytem

			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+IMEITEST:2, %s", arrCharacterSet);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
	}
	else
	{
		AT_DFMS_Result_NA();
	}
}

VOID AT_DFMS_KSTRINGB(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 *pRsp = NULL;
	BOOL  key_string_flag = FALSE;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_KSTRINGB, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_KSTRINGB, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex++;
	uSize   = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_KSTRINGB, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}
	if(param1 == 0 && param2 == 0)
	{
		if(!AT_FactorySettings_WriteKeyStringBlockFlag(FALSE))
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+CME ERROR:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
			return;
		}
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+KSTRINGB:0,OK");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if(param1 == 0 && param2 == 1)
	{
		if(!AT_FactorySettings_WriteKeyStringBlockFlag(TRUE))
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+CME ERROR:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
			return;
		}
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+KSTRINGB:0,OK");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1 == 1 && param2 == 0))
	{
		if(!AT_FactorySettings_ReadKeyStringBlockFlag(&key_string_flag))                    //!DMNV_ReadKeyStringBlockFlag(&key_string_flag)  TODO BY FileSytem     Key String Block Status Read

		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+CME ERROR:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
			return;
		}

		// key string block on
		pRsp = AT_MALLOC(100);

		if(key_string_flag)
		{
			AT_Sprintf(pRsp, "+KSTRINGB:1,ON");
		}
		else
		{
			AT_Sprintf(pRsp, "+KSTRINGB:1,OFF");
		}
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
#if 0
	else if(param1 == 0 && param2 == 2)
	{
		if(0)        //!DMNV_WriteHiddenMenuFlag(FALSE)  TODO BY FileSytem     Hidden Menu Deactive

		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+CME ERROR:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
			return;
		}
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+KSTRINGB:0,OK");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if(param1 == 0 && param2 == 3)
	{
		if(0)           //!DMNV_WriteHiddenMenuFlag(TRUE)   TODO BY FileSytem     Hidden Menu Active

		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+CME ERROR:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
			return;
		}
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+KSTRINGB:0,OK");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1 == 1 && param2 == 1))
	{
		if(0)              //!DMNV_ReadHiddenMenuFlag(&key_string_flag)   TODO BY FileSytem     Hidden Menu Close

		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+CME ERROR:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
			return;
		}

		// key string block on
		pRsp = AT_MALLOC(100);
		if(key_string_flag)
		{
			AT_Sprintf(pRsp, "+KSTRINGB:1,ON");
		}
		else
		{
			AT_Sprintf(pRsp, "+KSTRINGB:1,OFF");
		}
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
#endif
	else
	{
		AT_DFMS_Result_NA();
		return;
	}

}
VOID AT_DFMS_RSTVERIF(AT_CMD_PARA *pParam)// paramore
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 *pRsp = NULL;
	UINT8 verify_flag = FALSE;
	int callLogCur      = 0;
	int callLogMax		= 0;
	int messageCur      = 0;
	int messageMax		= 0;
	int contactsCur     = 0;
	int contactsMax		= 0;
	int calendarCur     = 0;
	int calendarMax     = 0;
	int memoCur         = 0;
	int memoMax	= 0;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_RSTVERIF, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_RSTVERIF, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex++;
	uSize   = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_RSTVERIF, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}
	if(param1 == 0 && param2 == 0)
	{
		AT_FactorySettings_ReadRestoreFactoryFlag(&verify_flag);
		if(verify_flag)  //verify_flag
		{
			pRsp = AT_MALLOC(100);
			memset(pRsp, 0x0, 100);

			//Get count of various applications
			getCallLogInfo(&callLogCur, &callLogMax);
			getMessageInfo(&messageCur, &messageMax);
			getContactsInfo(&contactsCur, &contactsMax);
			getCalendarInfo(&calendarCur, &calendarMax);
			getMemoInfo(&memoCur, &memoMax);

			if(callLogCur == 0 && messageCur == 0 && contactsCur == 0 && calendarCur == 0 && memoCur == 0)
			{
				AT_Sprintf(pRsp, "+RSTVERIF:%d,OK", param1);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			}
			else
			{
				AT_Sprintf(pRsp, "+CME ERROR:NG\n");
				AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			}
			AT_FREE(pRsp);
		}
		else //verifyflag false
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+CME ERROR:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
	}
	else
	{
		AT_DFMS_Result_NA();
	}

}

VOID AT_DFMS_FACTOLOG(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 param3  = 0;
	UINT8 param4  = 0;
	UINT8 *pRsp = NULL;
	BOOL Flag = TRUE;
	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 4))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_FACTOLOG, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_FACTOLOG, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex++;
	uSize   = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_FACTOLOG, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex++;
	uSize   = SIZEOF(param3);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param3, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_FACTOLOG, get parameter error3\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex++;
	uSize   = SIZEOF(param4);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param4, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_FACTOLOG, get parameter error4\n");
		AT_DFMS_Result_NA();
		return;
	}

	// TODO      Need API to enable/disable processor sleep     Power & Assesoris TEAM

	if(param1 == 0 && param2 == 1 && param3 == 1 && param4 == 1)
	{
		//PBA Function Factory Test Log Start + Sleep
	}
	else if(param1 == 0 && param2 == 1 && param3 == 0 && param4 == 0)
	{
		//PBA Function Factory Test Log Stop
	}
	else if(param1 == 0 && param2 == 1 && param3 == 1 && param4 == 2)
	{
		//PBA Fucntion Test Start +Sleep
	}
	else
	{

		AT_DFMS_Result_NA();
		return;
	}
	pRsp = AT_MALLOC(100);

	if(Flag)
	{
		AT_Sprintf(pRsp, "+FACTOLOG:0,OK");
	}
	AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	AT_FREE(pRsp);

}
/*****************************************************************************/
// 	Description :get Keytrace ON flags
//	Note: used by at+keytrace command to get keytraceON/OFF flag
//  Author: d.dubey
/*****************************************************************************/
BOOL AT_Is_KeytraceON()
{
	return keytrace_flag;
}
/*****************************************************************************/
// 	Description :Get AT command keycode from keypad key code
//	Note: used by at+keytrace command to write AT command keycode from device keycode
//  Author: d.dubey
/*****************************************************************************/
unsigned int  AT_Get_Key_From_Keypad( int keycode)
{
	unsigned int index = 0;
	for(index = 0; index < KEYCOMD_NUM; index++)
	{
		if(KeyMapChst[index] == keycode)
			break;
	}

	if(index < KEYCOMD_NUM)
		return       AT_KEYCMD_map[index];
	else
		return 0xff;
}
VOID AT_DFMS_KEYTRACE(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 *pRsp = NULL;
	UINT8 arrCharacterSet[15] = { 0 };
	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);

	if ((iResult != ERR_SUCCESS) || (uParaCount != 1))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_KEYTRACE, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex = 0;
	uSize   = SIZEOF(arrCharacterSet);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &arrCharacterSet, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_KEYTRACE, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	AT_TC(g_sw_DFMS, "exe 	  in AT_DFMS_KEYTRACE, get parameter error1 \n");
	AT_TC_MEMBLOCK(g_sw_DFMS, arrCharacterSet, strlen(arrCharacterSet), 16);
	if(!AT_MemCmp(arrCharacterSet, "ON", 2) || !(AT_MemCmp(arrCharacterSet, "on", 2)))
	{
		keytrace_flag = 1;
	}
	else if(!AT_MemCmp(arrCharacterSet, "OFF", 3) || !(AT_MemCmp(arrCharacterSet, "off", 3)))
	{
		keytrace_flag = 0;
	}
	else
	{
		AT_DFMS_Result_NA();
		return;
	}

	AT_TC(g_sw_DFMS, "exe		in AT_DFMS_KEYTRACE, get parameter error3\n");
	AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0);
}

VOID AT_DFMS_PRODCODE(AT_CMD_PARA *pParam)
{

	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2 = 0;
	UINT8 *pRsp = NULL;
	UINT8 arrCharacterSet[15] = { 0 };

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_PRODCODE, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_PRODCODE, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	if(param1  == 2)
	{

		uIndex++;
		uSize  = SIZEOF(arrCharacterSet);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &arrCharacterSet, &uSize);
		if (iResult != ERR_SUCCESS )
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_PRODCODE, get parameter error3\n");
			AT_DFMS_Result_NA();
			return;
		}
	}
	else
	{
		uIndex++;
		uSize  = SIZEOF(param2);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
		if (iResult != ERR_SUCCESS )
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_PRODCODE,get parameter error3\n");
			AT_DFMS_Result_NA();
			return;
		}
	}

	if((param1  == 1) && (param2  == 0))
	{

		AT_FactorySettings_ReadProductCode(arrCharacterSet);

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+PRODCODE:1, %s", arrCharacterSet);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else if((param1  == 2))
	{

		AT_FactorySettings_WriteProductCode(arrCharacterSet);
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+PRODCODE:2, ");//TO do
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_DFMS_Result_NA();
	}

}

VOID AT_DFMS_FACTORST(AT_CMD_PARA *pParam)
{

	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2 = 0;
	UINT8 *pRsp = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_FACTORST, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_FACTORST, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);

	if(iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_FACTORST, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	if((param1  == 0) && (param2  == 0))
	{
		if(AT_FactorySettings_WriteRestoreFactoryFlag(2))
		{
			//The function for Factory Reset
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+FACTORST:%d", param1 ); //TO do
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
			memoryResetAT();
		}
		else
		{
			AT_DFMS_Result_NA();
		}
	}
	else
	{
		AT_DFMS_Result_NA();
	}

}

VOID AT_DFMS_MSLSECUR(AT_CMD_PARA *pParam)
{

	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2 = 0;
	UINT8 param3 = 0;
	UINT8 param_len = 0;
	UINT8 *pRsp = NULL;
	char    msl_code[33]    = {0};  // MSL code 32 bytes
	char    msl_address[11] = {0};  // MSL address 10 bytes
	char    msl_code_from_nv[33]    = {0};  // MSL code 32 bytes in phone
	char    msl_address_from_nv[11] = {0};  // MSL address 10 bytes in phone
	BOOL ret      = FALSE;   //for test by v.vinit
	UINT8      msl_security_code_nv[44] = {0};
	UINT8 arrCharacterSet[15] = { 0 };

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_MSLSECUR, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_MSLSECUR, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	if(param1  == 2)
	{

		uIndex++;
		uSize  = SIZEOF(msl_security_code_nv);
		param_len = uSize + 1;
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &msl_security_code_nv, &uSize);
		if (iResult != ERR_SUCCESS )
		{

			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_MSLSECUR, get parameter error3\n");

			AT_DFMS_Result_NA();
			return;
		}

		// write MSL
		if(45 == param_len && '_' == msl_security_code_nv + 10)
		{
			// extract MSL address & MSL Code
			memcpy(msl_address, msl_security_code_nv, 10);
			memcpy(msl_code, msl_security_code_nv + 11, 32);

			ret = AT_FactorySettings_ReadMSLSECUR(msl_security_code_nv);

			// if MSL address/code exist in phone
			if(ret && (43 == strlen((char *)msl_security_code_nv)) && ('0' != msl_security_code_nv[10]))
			{
				memcpy(msl_address_from_nv, msl_security_code_nv, 10);
				memcpy(msl_code_from_nv, msl_security_code_nv + 11, 32);
				msl_address_from_nv[10] = '\0';
				msl_code_from_nv[32] = '\0';

				// if MSL address in phone is different to cmd data
				// or if MSL code in phone is different to cmd data
				if(0 != strncmp(msl_address, msl_address_from_nv, 10)
				        || 0 != strncmp(msl_code, msl_code_from_nv, 32))
				{
					msl_verified = FALSE;
				}
				else
				{
					msl_verified = TRUE;

					pRsp = AT_MALLOC(100);
					AT_Sprintf(pRsp, "+MSLSECUR:2,OK" );//TO do
					AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
					AT_FREE(pRsp);
				}
			}
			// not exist, write address
			else
			{
				//TODO: Need to implement the following function
				ret = AT_FactorySettings_WriteMSLSECUR(msl_security_code_nv);
				//ret = DMNV_WriteMSLSECUR(param2);//lint !e718 !e746

				if ( ret )
				{
					msl_verified = TRUE;
					pRsp = AT_MALLOC(100);
					AT_Sprintf(pRsp, "+MSLSECUR:2,OK" );//TO do
					AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
					AT_FREE(pRsp);
				}
				else
				{
					msl_verified  = FALSE;
					AT_TC(g_sw_DFMS, "exe       in AT_DFMS_MSLSECUR, get parameter error1\n");
					AT_DFMS_Result_NA();
					return;
				}
			}
		}

	}
	else if(param1 == 1)
	{
		uIndex++;
		uSize  = SIZEOF(param2);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
		if (iResult != ERR_SUCCESS )
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_MSLSECUR, get parameter error3\n");
			AT_DFMS_Result_NA();
			return;
		}

		ret = AT_FactorySettings_ReadMSLSECUR(msl_security_code_nv);
		if(ret && 43 == strlen((char *)msl_security_code_nv))
		{
			memcpy(msl_address, msl_security_code_nv, 10);
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+MSLSECUR:1,%s", msl_address ); //TO do
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else
		{

			memset(msl_security_code_nv, '0', 44);
			msl_security_code_nv[43] = 0;

			ret = AT_FactorySettings_WriteMSLSECUR(msl_security_code_nv);
			if(ret)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf(pRsp, "+MSLSECUR:1,%.10s", msl_security_code_nv); //TO do
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
				return;
			}
			else
			{
				AT_TC(g_sw_DFMS, "exe       in AT_DFMS_MSLSECUR, get parameter error3\n");
				AT_DFMS_Result_NA();
				return;
			}
		}
	}
	else
	{
		AT_DFMS_Result_NA();
		return;
	}

}

VOID AT_DFMS_AKSEEDNO(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2 = 0;
	UINT8 *pRsp = NULL;
	UINT8 al_Enc_Num[40] = {0};
	static UINT8 al_Ak_Num[40];
	UINT8 arrCharacterSet[40] = { 0 };

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_MSLSECUR, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_PRODCODE, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	if(param1  == 0)
	{

		uIndex++;
		uSize  = SIZEOF(arrCharacterSet);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &arrCharacterSet, &uSize);
		if (iResult != ERR_SUCCESS )
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_PRODCODE, get parameter error3\n");
			AT_DFMS_Result_NA();
			return;
		}
	}
	else
	{
		uIndex++;
		uSize  = SIZEOF(param2);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
		if (iResult != ERR_SUCCESS )
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_PRODCODE,get parameter error3\n");
			AT_DFMS_Result_NA();
			return;
		}
	}

	// AK SEED NO Check Request
	if( param1 == 0)
	{
		if(memcmp(arrCharacterSet, al_Ak_Num, 40) == 0)
		{
			pRsp = AT_MALLOC(100);

			AT_Sprintf(pRsp, "+AKSEEDNO:%d,OK", 0);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);

			ak_seed_no_verified = TRUE;
		}
		else
		{
			ak_seed_no_verified = FALSE;
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_AKSEEDNO, get parameter error1\n");
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+CME ERROR:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);

			return;
		}
	}
	// AK Seed Number Read
	else if(param1 == 1 && param2 == 0)
	{
		memset( al_Enc_Num, NULL, sizeof( al_Enc_Num ));
		memset( al_Ak_Num, NULL, sizeof( al_Ak_Num ));

		//TODO: Need to implement the following API
		Get_Number( al_Enc_Num, al_Ak_Num);

		pRsp = AT_MALLOC(100);

		AT_Sprintf(pRsp, "+AKSEEDNO:%d,%s", 1, al_Enc_Num);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_DFMS_Result_NA();
	}
}

VOID AT_DFMS_LVOFLOCK(AT_CMD_PARA *pParam)
{
#if 0
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 *pRsp = NULL;
	//  TODO: Need to implement following structure
	//MN_SIM_LOCK_CUSTOMIZE_DATA_T * simlock_customize_data_ptr = SCI_NULL;
	uint32 user_lock_status;
	uint16 rets = 0;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_FACTORST, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_FACTORST, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);

	if(iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_FACTORST, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	if (param1 == 1)
	{

		/*
		   if( !msl_verified || !ak_seed_no_verified)
		   {
		   pRsp = AT_MALLOC(100);
		   AT_Sprintf(pRsp, "+LVOFLOCK:NG");
		   AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		   AT_FREE(pRsp);
		   }
		   */
		/*TODO:
		  simlock_customize_data_ptr = (MN_SIM_LOCK_CUSTOMIZE_DATA_T *)SCI_ALLOC_BASEZ(sizeof(MN_SIM_LOCK_CUSTOMIZE_DATA_T));
		  if(NVERR_NONE != EFS_NvitemRead(ATC_NV_SIM_LOCK_CUSTOMIZE_DATA_ID,
		  sizeof(MN_SIM_LOCK_CUSTOMIZE_DATA_T),
		  (void *)simlock_customize_data_ptr))*/
		{

			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LVOFLOCK:%d,%s", param1, "00000000");
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		//TODO
		// user_lock_status = simlock_customize_data_ptr->SIM_lock_status;

		if(( 0 == user_lock_status ) || (0xFFFFFFFF == user_lock_status ))
		{
			rets = 0x0;
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LVOFLOCK:%d,%08d", param1, rets);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}

		if( 0 != (user_lock_status & 1 /*MN_SIM_NETWORK_LOCK */))  // TO DO MN_SIM_NETWORK_LOCK
		{
			if(0 == simlock_customize_data_ptr->network_locks.numLocks)
			{

				pRsp = AT_MALLOC(100);
				AT_Sprintf(pRsp, "+LVOFLOCK:%d,NWLOCK FAIL", param1);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			else
			{
				rets += 0x1;
			}
		}

		if( 0 != (user_lock_status & MN_SIM_NETWORK_SUBSET_LOCK))
		{
			if(0 == simlock_customize_data_ptr->network_subset_locks.numLocks)
			{

				pRsp = AT_MALLOC(100);
				AT_Sprintf(pRsp, "+LVOFLOCK:%d,SUBSETLOCK FAIL", param1);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			else
			{
				rets += 0x2;
			}
		}

		if( 0 != (user_lock_status & MN_SIM_SP_LOCK))
		{
			if(0 == simlock_customize_data_ptr->SP_locks.numLocks)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf(pRsp, , "+LVOFLOCK:%d,SPLOCK FAIL", param1)
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			else
			{
				rets += 0x8;
			}
		}

		if( 0 != (user_lock_status & MN_SIM_CORPORATE_LOCK))
		{
			if(0 == simlock_customize_data_ptr->corporate_locks.numLocks)
			{

				pRsp = AT_MALLOC(100);
				AT_Sprintf(pRsp, "+LVOFLOCK:%d,CPLOCK FAIL", param1);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			else
			{
				rets += 0x10;
			}
		}

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+LVOFLOCK:%d,%08d", param1, rets);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{

		AT_DFMS_Result_NA();
	}

#endif
}

VOID AT_DFMS_PRECONFG(AT_CMD_PARA *pParam)
{
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2 = 0;
	UINT8 *pRsp = NULL;
	UINT8  cust_name[8] = {0};
	UINT8 arrCharacterSet[15] = { 0 };

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_PRECONFG, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_PRECONFG, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);

	if(iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_PRECONFG, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(param1 == 0)
	{
		//TODO: need to check
		if(param2 == 0)
		{
			//TODO : Need to implement the function for getting Customer name

			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+PRECONFG:0,%s", cust_name);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else
		{
			AT_DFMS_Result_NA();
		}

	}
	else if(param1 == 1)
	{
		if(param2 == 0)
		{
			// TODO : Need to implement the function for getting Customer name

			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+PRECONFG:1,%s", cust_name);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+CME ERROR:NA\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}

	}
	else if(param1 == 2)
	{

		//TODO : Need to implement for getting csc initalization
#if 0 // if CSC initialize

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+PRECONFG:2,OK");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);

#else
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+PRECONFG:2,PRECONFIG FAIL");
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);

#endif
	}
	else
	{
		AT_DFMS_Result_NA();
	}
}

VOID AT_DFMS_DETALOCK(AT_CMD_PARA *pParam)
{

#define NV_SIM_LOCK_DETAL_DATA_ID 498
	//TODO : Need to implement Follwing Sturucture
	MN_SIM_LOCK_DETAL_DATA_T *simlock_detal_data_ptr = NULL;
	MN_SIM_LOCK_DETAL_DATA_T *encrypt_detal_data_ptr = NULL;

	ATC_PRODUCTION_LINE_PARAM_T param_write[7] = {0};
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2 = 0;
	UINT8 *pRsp = NULL;
	UINT8 mck[100] = {0};
	UINT8 nck[100] = {0};
	UINT8 sck[100] = {0};
	UINT8  spck[100] = {0};
	UINT8  cpck[100] = {0};
	UINT8  pck[100] = {0};
	UINT8  temp[100] = {0};
	UINT8  *param_ptr   = NULL;
	UINT8 arrCharacterSet[15] = { 0 };

	simlock_detal_data_ptr = (MN_SIM_LOCK_DETAL_DATA_T *)AT_MALLOC(sizeof(MN_SIM_LOCK_DETAL_DATA_T));
	encrypt_detal_data_ptr = (MN_SIM_LOCK_DETAL_DATA_T *)AT_MALLOC(sizeof(MN_SIM_LOCK_DETAL_DATA_T));

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_DETALOCK, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(param1 == 1)
	{
		iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
		if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_DETALOCK, parameter error\n");
			AT_DFMS_Result_NA();
			return;
		}

		uIndex++;
		uSize  = SIZEOF(param2);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
		if (iResult != ERR_SUCCESS )
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_DETALOCK,get parameter error3\n");
			AT_DFMS_Result_NA();
			return;
		}
	}
	if(param1  == 2)
	{

		iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
		if ((iResult != ERR_SUCCESS) || (uParaCount != 7))
		{
			AT_TC(g_sw_DFMS, "exe       in AT_DFMS_DETALOCK, parameter error\n");
			AT_DFMS_Result_NA();
			return;
		}

		for(int i = 0; i < 6; i++)
		{

			uIndex++;
			uSize  = SIZEOF(arrCharacterSet);
			iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &param_write[i].param, &uSize);
			if (iResult != ERR_SUCCESS )
			{
				AT_TC(g_sw_DFMS, "exe       in AT_DFMS_DETALOCK, get parameter error3\n");
				AT_DFMS_Result_NA();
				return;
			}
		}
	}

	if( !msl_verified || !ak_seed_no_verified)
	{

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+DETALOCK:NG");
		AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}

	//read detal lock

	if(param1 == 1 && param2 == 0)
	{

		//TODO : Nedd to implement following function
		if( !AT_FactorySettings_ReadDetaLock(simlock_detal_data_ptr))//lint !e718 !e746
		{

			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+DETALOCK:NG");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		memset(temp, 0, 100);

		for (int i = 0; i < 20; i++)
		{
			AT_Sprintf(temp, "%02X", simlock_detal_data_ptr->mck[i]);
			strcat(mck, temp);
		}
		for (int i = 0; i < 20; i++)
		{
			AT_Sprintf(temp, "%02X", simlock_detal_data_ptr->nck[i]);
			strcat(nck, temp);
		}
		for (int i = 0; i < 20; i++)
		{
			AT_Sprintf(temp, "%02X", simlock_detal_data_ptr->sck[i]);
			strcat(sck, temp);
		}
		for (int i = 0; i < 20; i++)
		{
			AT_Sprintf(temp, "%02X", simlock_detal_data_ptr->spck[i]);
			strcat(spck, temp);
		}
		for (int i = 0; i < 20; i++)
		{
			AT_Sprintf(temp, "%02X", simlock_detal_data_ptr->cpck[i]);
			strcat(cpck, temp);
		}
		for (int i = 0; i < 20; i++)
		{
			AT_Sprintf(temp, "%02X", simlock_detal_data_ptr->pck[i]);
			strcat(pck, temp);
		}

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+DETALOCK:%c,%s,%s,%s,%s,%s,%s", *(param_ptr), mck, nck, sck, spck, cpck, pck);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	// write detal lock
	else if( param1 == 2)
	{
		memset((void *)param_write, 0, 7 * sizeof(ATC_PRODUCTION_LINE_PARAM_T));

		if( !key_check(param_write[0].param, param_write[0].param_len))
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+DETALOCK:%c,MASTER FAIL", param_write[0].param[0]);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if( !key_check(param_write[1].param, param_write[1].param_len))
		{

			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+DETALOCK:%c,NWLOCK FAIL", param_write[0].param[0]);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if( !key_check(param_write[2].param, param_write[2].param_len))
		{

			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+DETALOCK:%c,SUBSETLOCK FAIL", param_write[0].param[0]);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if( !key_check(param_write[3].param, param_write[3].param_len))
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+DETALOCK:%c,SPLOCK FAIL", param_write[0].param[0]);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if( !key_check(param_write[4].param, param_write[4].param_len))
		{

			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+DETALOCK:%c,CPLOCK FAIL", param_write[0].param[0]);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if( !key_check(param_write[5].param, param_write[5].param_len))
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+DETALOCK:%c,SIMLOCK FAIL", param_write[0].param[0]);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else
		{
			uint8 i = 0;
			//TODO :Need to implement following API
			for(i = 0; i < 8; i++)
			{
				simlock_detal_data_ptr->mck[i] = param_write[0].param[i];
				simlock_detal_data_ptr->nck[i] = param_write[1].param[i];
				simlock_detal_data_ptr->sck[i] = param_write[2].param[i];
				simlock_detal_data_ptr->spck[i] = param_write[3].param[i];
				simlock_detal_data_ptr->cpck[i] = param_write[4].param[i];
				simlock_detal_data_ptr->pck[i] = param_write[5].param[i];
			}
			//TODO :Need to implement following API

			Atc_SysCrHashSHA1(  simlock_detal_data_ptr->mck,
			                    encrypt_detal_data_ptr->mck  );
			Atc_SysCrHashSHA1(  simlock_detal_data_ptr->nck,
			                    encrypt_detal_data_ptr->nck  );
			Atc_SysCrHashSHA1(  simlock_detal_data_ptr->sck,
			                    encrypt_detal_data_ptr->sck  );
			Atc_SysCrHashSHA1(  simlock_detal_data_ptr->spck,
			                    encrypt_detal_data_ptr->spck  );
			Atc_SysCrHashSHA1(  simlock_detal_data_ptr->cpck,
			                    encrypt_detal_data_ptr->cpck  );
			Atc_SysCrHashSHA1(  simlock_detal_data_ptr->pck,
			                    encrypt_detal_data_ptr->pck  );

			//TODO: Need to implement follwing API

			if(! AT_FactorySettings_WriteDetaLock(encrypt_detal_data_ptr))//lint !e718 !e746
			{

				pRsp = AT_MALLOC(100);
				AT_Sprintf(pRsp, "+DETALOCK:NG");
				AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+DETALOCK:2,OK");
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
	}
	else
	{

		AT_DFMS_Result_NA();
	}

}

//LOCAL
BOOL key_check(UINT8 *keys, UINT16  key_len)
{
	UINT8 i;

	if(8 != key_len)
	{
		return FALSE;
	}
	for(i = 0; i < key_len; i++)
	{
		if(!((keys[i]) >= '0' && (keys[i]) <= '9'))
		{
			return FALSE;
		}
	}
	return TRUE;
}

PUBLIC BOOL Atc_SysCrHashSHA1(UINT8 *szIn, UINT8 *szOut)
{
#if 0

	//TODO:
	SHA_CTX		context;
	CrUINT8		digest[UNLOCK_KEY_MAX];		// 128bits
	UINT8		input[UNLOCK_KEY_MAX];		// 128bits

	// NULL���� ������ ������ ���� �����.
	memset(input, 0, UNLOCK_KEY_MAX);
	memset(digest, 0, UNLOCK_KEY_MAX);
	strcpy(input, szIn);
	//TODO: Need to implement API
	//#ifndef WIN32
	// generate hash
	ATC_SHA1_Init(&context);
	ATC_SHA1_Update(&context, (CrUINT8 *)input, 16);
	ATC_SHA1_Final(digest, &context);
	//#endif
	memcpy(szOut, digest, 20);

	//SCI_TRACE_LOW("szIn=%s", szIn);
	//SCI_TRACE_LOW("szOut=%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
	//  szOut[0], szOut[1], szOut[2], szOut[3], szOut[4],  szOut[5],  szOut[6], szOut[7],
	//  szOut[8], szOut[9], szOut[10],szOut[11],szOut[12], szOut[13], szOut[14],szOut[15],
	//   szOut[16],szOut[17],szOut[18],szOut[19]);
#endif

	return TRUE;
}

VOID AT_DFMS_LOCKREAD(AT_CMD_PARA *pParam)
{
#if 0
	//TODO : Need to implement the structure
	//MN_SIM_LOCK_CUSTOMIZE_DATA_T * simlock_customize_data_ptr = SCI_NULL;
	// NETWORK_SUBSET_LOCKS_T     network_subset_locks={0};
	//CORPORATE_LOCKS_T          corporate_locks = {0};
	//NETWORK_LOCKS_T            network_locks = {0};
	//SP_LOCKS_T                 sp_locks = {0};
	UINT32                          user_lock_status = 0;
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2 = 0;
	UINT8 *pRsp = NULL;

	pRsp = AT_MALLOC(100);
	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_LOCKREAD, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_LOCKREAD, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);

	if(iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_LOCKREAD, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	if ( param1 != 1 )
	{

		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+CME ERROR:NA\n");
		AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}

	//   TODO: Need API

	/*  simlock_customize_data_ptr = (MN_SIM_LOCK_CUSTOMIZE_DATA_T *)SCI_ALLOC_BASEZ(sizeof(MN_SIM_LOCK_CUSTOMIZE_DATA_T));
	    if(NVERR_NONE != EFS_NvitemRead(ATC_NV_SIM_LOCK_CUSTOMIZE_DATA_ID,
	    sizeof(MN_SIM_LOCK_CUSTOMIZE_DATA_T),
	    (void *)simlock_customize_data_ptr))*/

	user_lock_status = simlock_customize_data_ptr->SIM_lock_status;

	if(param2 == 0)
	{
		network_locks = simlock_customize_data_ptr->network_locks;

		if((0 == (user_lock_status & MN_SIM_NETWORK_LOCK)) ||
		        (0 == network_locks.numLocks))
		{

			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,NONE", param1);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if(1 == network_locks.numLocks)
		{
			if(2 == network_locks.locks[0].mnc_digit_num)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf(pRsp, , "+LOCKREAD:%d,%d%02d", param1, network_locks.locks[0].mcc, network_locks.locks[0].mnc);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			else if(3 == network_locks.locks[0].mnc_digit_num)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf(pRsp, "+LOCKREAD:%d,%d%03d", param1, network_locks.locks[0].mcc, network_locks.locks[0].mnc);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}

			break;
		}
		else if(2 == network_locks.numLocks)
		{
			uint8 str_temp1[32] = {0};
			uint8 str_temp2[32] = {0};

			if(2 == network_locks.locks[0].mnc_digit_num)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf((char *)str_temp1, "%d%02d", network_locks.locks[0].mcc, network_locks.locks[0].mnc);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			else if(3 == network_locks.locks[0].mnc_digit_num)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf((char *)str_temp1, "%d%03d", network_locks.locks[0].mcc, network_locks.locks[0].mnc);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}

			if(2 == network_locks.locks[1].mnc_digit_num)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf((char *)str_temp2, "%d%02d", network_locks.locks[1].mcc, network_locks.locks[1].mnc);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			else if(3 == network_locks.locks[1].mnc_digit_num)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf((char *)str_temp2, "%d%03d", network_locks.locks[1].mcc, network_locks.locks[1].mnc);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,%s_%s", param1, str_temp1, str_temp2);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if(3 == network_locks.numLocks)
		{
			uint8 str_temp1[32] = {0};
			uint8 str_temp2[32] = {0};
			uint8 str_temp3[32] = {0};

			if(2 == network_locks.locks[0].mnc_digit_num)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf((char *)str_temp1, "%d%02d", network_locks.locks[0].mcc, network_locks.locks[0].mnc);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			else if(3 == network_locks.locks[0].mnc_digit_num)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf((char *)str_temp1, "%d%03d", network_locks.locks[0].mcc, network_locks.locks[0].mnc);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}

			if(2 == network_locks.locks[1].mnc_digit_num)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf((char *)str_temp2, "%d%02d", network_locks.locks[1].mcc, network_locks.locks[1].mnc);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			else if(3 == network_locks.locks[1].mnc_digit_num)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf((char *)str_temp2, "%d%03d", network_locks.locks[1].mcc, network_locks.locks[1].mnc);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}

			if(2 == network_locks.locks[2].mnc_digit_num)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf((char *)str_temp3, "%d%02d", network_locks.locks[2].mcc, network_locks.locks[2].mnc);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			else if(3 == network_locks.locks[2].mnc_digit_num)
			{
				pRsp = AT_MALLOC(100);
				AT_Sprintf((char *)str_temp3, "%d%03d", network_locks.locks[2].mcc, network_locks.locks[2].mnc);
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,%s_%s_%s", param1, str_temp1, str_temp2, str_temp3);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp)
		}
	}
	else if(param2 == 1)
	{
		network_subset_locks = simlock_customize_data_ptr->network_subset_locks;

		if((0 == (user_lock_status & MN_SIM_NETWORK_SUBSET_LOCK)) ||
		        (0 == network_subset_locks.numLocks))
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,NONE", param1);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if(1 == network_subset_locks.numLocks)
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,%d%d", param1, network_subset_locks.locks[0].network_subset[0],
			           network_subset_locks.locks[0].network_subset[1]);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if(2 == network_subset_locks.numLocks)
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,%d%d_%d%d", param1, network_subset_locks.locks[0].network_subset[0],
			           network_subset_locks.locks[0].network_subset[1], network_subset_locks.locks[1].network_subset[0], network_subset_locks.locks[1].network_subset[1]);

			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if(3 == network_subset_locks.numLocks)
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,%d%d_%d%d_%d%d", param1, network_subset_locks.locks[0].network_subset[0],
			           network_subset_locks.locks[0].network_subset[1], network_subset_locks.locks[1].network_subset[0], network_subset_locks.locks[1].network_subset[1],
			           network_subset_locks.locks[2].network_subset[0], network_subset_locks.locks[2].network_subset[1]);

			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp)
		}
	}
	else if(param2 == 2)
	{
		sp_locks = simlock_customize_data_ptr->SP_locks;

		if((0 == (user_lock_status & MN_SIM_SP_LOCK)) ||
		        (0 == sp_locks.numLocks))
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,NONE", param1);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if(1 == sp_locks.numLocks)
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,%d", param1, sp_locks.locks[0].sp);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if(2 == sp_locks.numLocks)
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,%d_%d", param1, sp_locks.locks[0].sp,
			           sp_locks.locks[1].sp);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if(3 == sp_locks.numLocks)
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,%d_%d_%d", param1, sp_locks.locks[0].sp,
			           sp_locks.locks[1].sp,
			           sp_locks.locks[2].sp);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp)
		}
	}
	else if(param2 == 3)
	{
		corporate_locks = simlock_customize_data_ptr->corporate_locks;

		if((0 == (user_lock_status & MN_SIM_SP_LOCK)) ||
		        (0 == corporate_locks.numLocks))
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,NONE", param1);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if(1 == corporate_locks.numLocks)
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,%d", param1, corporate_locks.locks[0].corporate);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if(2 == corporate_locks.numLocks)
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,%d_%d", param1, corporate_locks.locks[0].corporate,
			           corporate_locks.locks[1].corporate);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if(3 == corporate_locks.numLocks)
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:%d,%d_%d_%d", param1, corporate_locks.locks[0].corporate,
			           corporate_locks.locks[1].corporate,
			           corporate_locks.locks[2].corporate);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else
		{
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+LOCKREAD:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp)
		}
	}
	else
	{
		AT_DFMS_Result_NA();
	}

#endif
}
// display functions

VOID GetDisplayCalCRC(UINT16 *crc, const UINT8 *block, UINT32 len)
{
	UINT16       reg;

	if (len == 0)
		return;

	reg = *crc;

	do
	{
		reg = reg >> 8 ^ get_dis_crc_table[(reg & 255) ^ *block++];
	}
	while (--len);

	reg ^= 0xFFFF;
	*crc = reg;
}
void GetDisplaySendData(uint8 lcd_num, uint8 seq_num)
{
	uint16 vl_size_bits_Valid_LCD_Data, crc;
	uint8 crc_h, crc_l;
	int i = 0;
	// UINT8 *pRsp = NULL;
	// pRsp = AT_MALLOC(4112);
	if( 0 == lcd_num )  //for main lcd
	{
		if( !v_GetDisplayStart )
		{
			uint32 i;
			uint16 height = 0;
			uint16 width = 0;
			v_GetDisplayStart = TRUE;
			v_GetDisplaySendData = (UINT8 *)AT_MALLOC(GET_DISPLAY_SIZE_OF_SEND_DATA * sizeof(UINT8));
			if (v_GetDisplaySendData == NULL)
			{
				AT_TC(g_sw_DFMS, "exe       in GetDisplaySendData, AT_MALLOC error\n");
				AT_DFMS_Result_NA();
				return;
			}

			AT_MemSet(v_GetDisplaySendData, 0x00, sizeof(GET_DISPLAY_SIZE_OF_SEND_DATA * sizeof(UINT8)));

#if 1

			v_pGetMainLCDBuffer = (UINT8 *)AT_MALLOC(128 * 128 * 2 * sizeof(UINT8));
			if (v_pGetMainLCDBuffer == NULL)
			{
				AT_TC(g_sw_DFMS, "exe       in GetDisplaySendData, AT_MALLOC error\n");
				AT_DFMS_Result_NA();
				return;
			}

			AT_MemSet(v_pGetMainLCDBuffer, 0x00, (128 * 128 * 2 * sizeof(UINT8)));
			//TODO NEED LCD buffer from IO team
			mci_LcdLayerMerge((UINT16 *)v_pGetMainLCDBuffer, 0, 0, 127, 127);
			COS_Sleep(5);
#endif
		}
		v_GetDisplaySendData[0] = GET_DISPLAY_DATA_STREAM_START;    // cmd_code
		v_GetDisplaySendData[1] = lcd_num;   // lcd_num
		v_GetDisplaySendData[2] = seq_num;   //seq_num
		v_GetDisplaySendData[3] = 0;   // seq_num
		if (v_seqnum >= MAIN_LCD_LAST_SEQ_NUM)
		{
			/* In case of Last Seq Num */
			v_GetDisplaySendData[4] = GET_DISPLAY_SEND_NO_MORE;
			vl_size_bits_Valid_LCD_Data = GET_DISPLAY_LAST_DATA_SIZE;
		}
		else
		{
			/* Incase of Normal Seq Num */
			v_GetDisplaySendData[4] = GET_DISPLAY_SEND_MORE;
			vl_size_bits_Valid_LCD_Data = GET_DISPLAY_SIZE_OF_LCD_DATA * 8;
		}
		memcpy(&v_GetDisplaySendData[5], &vl_size_bits_Valid_LCD_Data, 2);   // Size of Valid LCD Data bits
		v_BufferIndex = v_seqnum * GET_DISPLAY_SIZE_OF_LCD_DATA ;/// 4;
		memcpy(&v_GetDisplaySendData[7], &v_pGetMainLCDBuffer[v_BufferIndex], GET_DISPLAY_SIZE_OF_LCD_DATA);
		memset(&v_GetDisplaySendData[4103], 0x00, 5);
		AT_TC(g_sw_DFMS, "v_GetDisplaySendData7- %d", v_BufferIndex);
		crc = 0xFFFF;
		GetDisplayCalCRC( &crc, v_GetDisplaySendData, GET_DISPLAY_SIZE_OF_SEND_DATA - 3);
		crc_l = (uint8) crc;
		crc_h = (uint8) (crc >> 8);

		v_GetDisplaySendData[4108] = crc_l;
		v_GetDisplaySendData[4109] = crc_h;
		v_GetDisplaySendData[4110] = GET_DISPLAY_DATA_STREAM_END;
		//memcpy(pRsp,v_GetDisplaySendData,GET_DISPLAY_SIZE_OF_SEND_DATA);

		AT_WriteUart((UINT8 *)v_GetDisplaySendData, GET_DISPLAY_SIZE_OF_SEND_DATA * sizeof(UINT8));
		//AT_CleanCmdBuf(AT_CMD_BUF * pCBuf)
	}
}
void GetDisplayDeleteCmd()
{
	v_BufferIndex = 0;
	if( v_seqnum == MAIN_LCD_LAST_SEQ_NUM )
	{

		if(v_GetDisplaySendData)
		{
			AT_FREE(v_GetDisplaySendData);
			v_GetDisplaySendData = NULL;
		}
		if(v_pGetMainLCDBuffer)
		{
			AT_FREE(v_pGetMainLCDBuffer);
			v_pGetMainLCDBuffer = NULL;
		}

		v_GetDisplayStart = FALSE;
	}
}
VOID AT_Clear_CurCMD(VOID)
{
	AT_CMD **ppCmdList = AT_GetCommandList();

	// if async timer exist, kill it.

	if (AT_IsAsyncTimer())
		AT_KillAsyncTimer();

	// release the current command and flush the result
	if (*ppCmdList != NULL)
	{
		AT_FreeCurCmd(ppCmdList, *ppCmdList);
		ppCmdList = AT_GetCommandList();
	}

	AT_SetStatus(AT_STATUS_CMD_LINE);
	return;
}

//display functions
VOID AT_DFMS_GETDISPLAY(AT_CMD_PARA *pParam)
{
	UINT8 uSize  = 0;
	UINT8 param1  = 0;
	UINT8 param2 = 0;
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 *pRsp = NULL;
	UINT32 result = 0;
	BOOL return_val = FALSE;
	UINT8 lcd_num = 0;
	UINT8 seq_num = 0;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_GETDISPLAY, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_GETDISPLAY, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);

	if(iResult != ERR_SUCCESS )
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_GETDISPLAY, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(param1 == 0)
	{
		lcd_num = param1;
		seq_num = param2;
		v_seqnum = seq_num;
		GetDisplaySendData(lcd_num, seq_num);
		GetDisplayDeleteCmd();
		AT_Clear_CurCMD();
	}
	else
	{
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+CME ERROR:NA\n");
		AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
}

/*****************************************************************************/
// 	Description :get the test NV data
//	Note: AT command used reading test NV data from factry area
//  Author: v.vinit
/*****************************************************************************/
VOID AT_DFMS_GETTESTNV(AT_CMD_PARA *pParam)
{
	UINT8 uSize;
	UINT8 param1  = 0;
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 *pRsp = NULL;

	uint16          test_nv_index     = 0;
	ATC_FACTORY_ITEM_T          test_nv_buf[41] = {0};
	uint8            test_nv_id    = 0;
	uint8            test_nv_result_code = 0;
	ATC_FACTORY_ITEM_RSP_T        str_tmp = {0};
	BOOL b_need_set_default_value = FALSE;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 1))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_GETDISPLAY, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_GETDISPLAY, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(param1 < 1 || param1 > 40)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_GETDISPLAY, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(1)
	{
		test_nv_index = param1 - 1;

		if(AT_FactorySettings_ReadTestNV((uint16 *)test_nv_buf))//lint !e718 !e746
		{

			if(0 == test_nv_buf[test_nv_index].result_code )
			{
				b_need_set_default_value = TRUE;
			}
			else
			{
				test_nv_id = test_nv_buf[test_nv_index].id;
				test_nv_result_code = test_nv_buf[test_nv_index].result_code;
			}
		}
		else
		{
			//SCI_TRACE_SLIGHT("ATC:read NV fail, set default value");
			b_need_set_default_value = TRUE;
		}

		if (b_need_set_default_value)
		{
			//SCI_TRACE_SLIGHT("ATC: set test NV default value");
			test_nv_id = param1;
			test_nv_result_code = 'N';
		}

		if(test_nv_id >= 1 && test_nv_id <= 9)
		{
			sprintf((char *) & (str_tmp.id[0]), "%02d", test_nv_id);
		}
		else if(test_nv_id >= 10 && test_nv_id <= 40)
		{
			sprintf((char *) & (str_tmp.id[0]), "%d", test_nv_id);
		}

		//sprintf((char *)&(str_tmp.result_code), "%c", test_nv_result_code);
		str_tmp.result_code = test_nv_result_code;
		pRsp = AT_MALLOC(256);
		AT_Sprintf((char *)pRsp, "+GETTESTNV:%.2s,%c", str_tmp.id, str_tmp.result_code);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{
		AT_DFMS_Result_NA();
	}
}

/*****************************************************************************/
// 	Description :set the test NV data
//	Note: AT command used writing test data in factry area
//  Author: v.vinit
/*****************************************************************************/
VOID AT_DFMS_SETTESTNV(AT_CMD_PARA *pParam)
{
	UINT8 uSize;
	UINT8 param1  = 0;
	UINT8 param2[2]  = {0};
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 *pRsp = NULL;
	uint8   param_len    = 0;

	ATC_PRODUCTION_LINE_PARAM_T parameter[2] = {0};
	ATC_FACTORY_ITEM_T        test_nv_buf[41] = {0};
	ATC_FACTORY_ITEM_T		  hist_nv = {0};
	UINT16          test_nv_index     = 0;
	char nv_val[2] = {0};
	int i = 0;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SETTESTNV, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SETTESTNV, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &param2, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SETTESTNV, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	param2[1] = '\0';
	test_nv_index = param1 - 1;
	if(AT_FactorySettings_ReadTestNV((uint16 *)test_nv_buf))
	{

		AT_TC(g_sw_DFMS, "ATC: read NV success");
	}
	else
	{
		AT_TC(g_sw_DFMS, "ATC: read NV fail");
	}

	if(test_nv_index >= 40)
	{
		if((test_nv_index + 1) == 98) //PBA
		{
			for(i = 3; i < 40; i++)
			{
				test_nv_buf[i].id = i + 1;
				test_nv_buf[i].result_code = 'N';
			}
			if(AT_FactorySettings_WriteTestNV((uint16 *)test_nv_buf))
			{
				hist_nv.id = param1;
				hist_nv.result_code = 'P';
				ATC_RecordHistoryNV(hist_nv);

				pRsp = AT_MALLOC(256);
				memset(pRsp, 0x0, 256);
				sprintf((char *)pRsp, "+SETTESTNV:98,P");
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
		}
		else if((test_nv_index + 1) == 99) //Main
		{
			for(i = 6; i < 40; i++)
			{
				test_nv_buf[i].id = i + 1;
				test_nv_buf[i].result_code = 'N';
			}
			if(AT_FactorySettings_WriteTestNV((uint16 *)test_nv_buf))
			{

				hist_nv.id = param1;
				hist_nv.result_code = 'P';
				ATC_RecordHistoryNV(hist_nv);

				pRsp = AT_MALLOC(256);
				memset(pRsp, 0x0, 256);
				sprintf((char *)pRsp, "+SETTESTNV:99,P");
				AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
				AT_FREE(pRsp);
			}
		}
		else
		{

			AT_DFMS_Result_NA();
			AT_TC(g_sw_DFMS, "ATC: wrong index");
			return;
		}
	}

	test_nv_buf[test_nv_index].id = test_nv_index + 1;
	//parameter[1].param[0]=param2;
	memcpy(&test_nv_buf[test_nv_index].result_code, &param2, 1);
	//test_nv_buf[test_nv_index].result_code = 'P';
	if(AT_FactorySettings_WriteTestNV((uint16 *)test_nv_buf))//lint !e718 !e746
	{
		pRsp = AT_MALLOC(256);
		memset(pRsp, 0x0, 256);

		if(test_nv_index < 9)
		{
			sprintf((char *)pRsp, "+SETTESTNV:%02d,%s", test_nv_index + 1, param2);
		}
		else if(test_nv_index >= 9 && test_nv_index < 40)
		{
			sprintf((char *)pRsp, "+SETTESTNV:%d,%s", test_nv_index + 1, param2);
		}

		hist_nv.id = test_nv_buf[test_nv_index].id;
		hist_nv.result_code = test_nv_buf[test_nv_index].result_code;

		ATC_RecordHistoryNV(hist_nv);

		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
	}
	else
	{

		AT_DFMS_Result_NA();
		AT_TC(g_sw_DFMS, "ATC: wrong index");
	}
}

/*****************************************************************************/
// 	Description :set the full test NV data
//	Note: AT command used writing full test  data in factry area
//  Author: d.dubey
/*****************************************************************************/
VOID AT_DFMS_SETFULLTESTNV(AT_CMD_PARA *pParam)
{
	UINT8 uSize;
	UINT8 param1[125]  = {0};
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 *pRsp = NULL;
	int i = 0;
	int j = 0;
	int k = 0;
	int l = 0;
	uint16			test_nv_index	  = 0;
	ATC_FACTORY_ITEM_T		  test_nv_buf[41] = {0};

	AT_TC(g_sw_DFMS, "exe       In SETFULLTESTNV 1\n");
	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SETTESTNV, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	j = 0;
	if(AT_FactorySettings_ReadTestNV((uint16 *)test_nv_buf))
	{
		AT_TC(g_sw_DFMS, "ATC: read Test NV success");
	}
	else
	{
		AT_TC(g_sw_DFMS, "ATC: read NV fail");
		AT_DFMS_Result_NA();
		return;
	}

	for(i = 0; i < uSize;)
	{
		AT_TC(g_sw_DFMS, "exe       In SETFULLTESTNV 2\n");
		test_nv_index = (param1[i] - '0') * 10 + ((param1[i + 1] - '0')) - 1;
		test_nv_buf[j].id = test_nv_index + 1;
		memcpy(&test_nv_buf[j].result_code, &(param1[i + 2]), 1);
		i = i + 3;
		j++;
	}

	if(AT_FactorySettings_WriteTestNV((uint16 *)test_nv_buf))
	{
		AT_TC(g_sw_DFMS, "ATC: write Test NV success");
	}
	else
	{
		AT_TC(g_sw_DFMS, "ATC: write Test NV FAIL");
		AT_DFMS_Result_NA();
		return;
	}

	pRsp = AT_MALLOC(256);
	memset(pRsp, 0x0, 256);
	sprintf((char *)pRsp, "+SETFULLTESTNV:%s", (char *)param1);
	AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	AT_FREE(pRsp);
}

/*****************************************************************************/
// 	Description :get the full test NV data
//	Note: AT command used reading  full test  data from factry area
//  Author: d.dubey
/*****************************************************************************/

VOID AT_DFMS_GETFULLTESTNV(AT_CMD_PARA *pParam)
{
	UINT8 uSize;
	UINT8 param1[125]  = {0};
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 *pRsp = NULL;

	ATC_FACTORY_ITEM_T        test_nv_buf[41] = {0};
	char        str_tmp[41] = {0};
	uint8 i = 0;

	pRsp = AT_MALLOC(256);
	memset(pRsp, 0x0, 256);
	sprintf((char *)pRsp, "+GETFULLTESTNV:");

	if(!AT_FactorySettings_ReadTestNV((uint16 *)test_nv_buf))
	{
		AT_TC(g_sw_DFMS, "ATC: GETFULLTESTNV read fail");
		memset(test_nv_buf, 'N', sizeof(test_nv_buf));

		for(i = 0;  i < 40; i++)
		{
			test_nv_buf[i].id = i + 1;
		}

		if(!AT_FactorySettings_WriteTestNV((uint16 *)test_nv_buf))
		{
			AT_TC(g_sw_DFMS, "ATC: wrtite test NV fail");
		}
	}

	for(i = 0;  i < 40; i++)
	{
		memset(str_tmp, 0, sizeof(str_tmp));
		sprintf(str_tmp, "%02d", i + 1);

		strcat(pRsp, str_tmp);

		memset(str_tmp, 0, sizeof(str_tmp));
		if('N' != test_nv_buf[i].result_code
		        && 'P' != test_nv_buf[i].result_code
		        && 'F' != test_nv_buf[i].result_code
		        && 'E' != test_nv_buf[i].result_code )
		{
			sprintf(str_tmp, "%c", 'N');
		}
		else
		{
			sprintf(str_tmp, "%c", test_nv_buf[i].result_code);
		}
		strcat(pRsp, str_tmp);
	}
	AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	AT_FREE(pRsp);
}

/*****************************************************************************/
// 	Description :get the full history  data
//	Note: AT command used reading  full test history data from factry area
//  Author: d.dubey
/*****************************************************************************/
VOID AT_DFMS_GETFULLHISTNV(AT_CMD_PARA *pParam)
{
	UINT8 *pRsp = NULL;

	ATC_FACTORY_ITEM_T            hist_nv_buf[61] = {0};
	ATC_FACTORY_ITEM_RSP_T     str_tmp[60]       = {0};
	uint8                                     i                       = 0;
	uint8                                     tmp_id              = 0;

	if(!AT_FactorySettings_ReadHistNV((uint16 *)hist_nv_buf))//lint !e718 !e746
	{
		AT_TC(g_sw_DFMS, "ATC: first time read hist nv , fail");
		memset(hist_nv_buf, 0xff, sizeof(hist_nv_buf));

		if(!AT_FactorySettings_WriteHistNV((uint16 *)hist_nv_buf))//lint !e718 !e746
		{
			AT_TC(g_sw_DFMS, "ATC: write history NV fail");
			AT_DFMS_Result_NA();
			return;
		}
	}

	for(i = 0; hist_nv_buf[i].result_code != 0xff && i < 60; i++)
	{
		tmp_id = hist_nv_buf[i].id & 0x7f;
		if(tmp_id >= 1 && tmp_id <= 9)
		{
			sprintf((char *) & (str_tmp[i].id[0]), "%02d", tmp_id);
		}
		else if((tmp_id >= 10 && tmp_id <= 40) || tmp_id == 98 || tmp_id == 99)
		{
			sprintf((char *) & (str_tmp[i].id[0]), "%d", tmp_id);
		}

		sprintf((char *) & (str_tmp[i].result_code), "%c", hist_nv_buf[i].result_code);
	}

	pRsp = AT_MALLOC(256);
	memset(pRsp, 0x0, 256);
	sprintf((char *)pRsp, "+GETFULLHISTNV:%s", (char *)str_tmp);

	AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	AT_FREE(pRsp);

}

/*****************************************************************************/
// 	Description :Erase the log  data
//	Note: AT command used for erasing  log data from factry area
//  Author: d.dubey
/*****************************************************************************/
VOID AT_DFMS_LOGERASE(AT_CMD_PARA *pParam)
{
	UINT8 *pRsp = NULL;
	ATC_FACTORY_ITEM_T        test_nv_buf[60] = {0};

	memset(test_nv_buf, 0xff, sizeof(test_nv_buf));
	if(!AT_FactorySettings_WriteHistNV((uint16 *)test_nv_buf))
	{
		AT_TC(g_sw_DFMS, "ATC: write his NV fail");
		AT_DFMS_Result_NA();
		return;
	}
	pRsp = AT_MALLOC(256);
	memset(pRsp, 0x0, 256);
	sprintf((char *)pRsp, "+LOGERASE:");
	AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	AT_FREE(pRsp);

}

/*****************************************************************************/
// 	Description :set  the factory  data
//	Note: AT command used for writing  factry data in  factry area
//  Author: d.dubey
/*****************************************************************************/
VOID AT_DFMS_SETFDATA(AT_CMD_PARA *pParam)
{
	UINT8 uSize         = 0;
	UINT8 param1        = 0;
	UINT8 uIndex        = 0;
	INT32 iResult       = 0;
	UINT8 uParaCount    = 0;
	UINT8 *pRsp         = NULL;
	UINT8 param2[2]     = {0};
	AT_FACT_RECD_PARAM fail_rec = {0,};
	memset(&fail_rec, 'N', sizeof(AT_FACT_RECD_PARAM));

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SETTESTNV, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize   = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize  = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &param2, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SETTESTNV, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(AT_FactorySettings_ReadFactData(&fail_rec))
	{
		uint8 index = param1;
		uint8 value = param2;

		switch(index)
		{
		case 1:
		{
			fail_rec.fail_record = value;
			break;
		}

		case 2:
		{
			fail_rec.retry = value;
			break;
		}

		case 3:
		{
			fail_rec.dummy11 = value;
			break;
		}

		case 4:
		{
			fail_rec.dummy12 = value;
			break;
		}

		default:
		{
			AT_TC(g_sw_DFMS,  "ATC: invalid index");
			AT_DFMS_Result_NA();
			return;
		}
		}

		if(AT_FactorySettings_WriteFactData(&fail_rec))
		{
			pRsp = AT_MALLOC(256);
			memset(pRsp, 0x0, 256);
			sprintf((char *)pRsp, "+SETFDATA:%d,%d",   param1, param2);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else
		{
			AT_TC(g_sw_DFMS,  "ATC: wrtie NV fail");
			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+CME ERROR:NG\n");
			AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
			return;
		}
	}
	else
	{
		AT_TC(g_sw_DFMS,  "ATC: read NV fail");
		pRsp = AT_MALLOC(100);
		AT_Sprintf(pRsp, "+CME ERROR:NG\n");
		AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		AT_FREE(pRsp);
		return;
	}


}
/*****************************************************************************/
// 	Description :get  the factory  data
//	Note: AT command used for reading  factry data from  factry area
//  Author: d.dubey
/*****************************************************************************/
VOID AT_DFMS_GETFDATA(AT_CMD_PARA *pParam)
{
	UINT8 uSize         = 0;
	UINT8 param1        = 0;
	INT32 iResult       = 0;
	UINT8 uParaCount    = 0;
	UINT8 uIndex        = 0;
	UINT8 *pRsp         = NULL;
	BOOL status         = TRUE;
	AT_FACT_RECD_PARAM fail_rec = {0,};
	memset(&fail_rec, 'N', sizeof(AT_FACT_RECD_PARAM));

	uIndex  = 0;
	uSize   = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SETTESTNV, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(!AT_FactorySettings_ReadFactData(&fail_rec))
	{
		AT_TC(g_sw_DFMS,   "ATC: read NV fail");
		AT_DFMS_Result_NA();
		return;
	}
	pRsp = AT_MALLOC(100);
	memset(pRsp, 0x0, 100);
	switch(param1)
	{
	case 1:
		sprintf((char *)pRsp, "+GETFDATA:%c", fail_rec.fail_record);
		break;
	case 2:
		sprintf((char *)pRsp, "+GETFDATA:%c", fail_rec.retry);
		break;
	case 3:
		sprintf((char *)pRsp, "+GETFDATA:%c", fail_rec.dummy11);
		break;
	case 4:
		sprintf((char *)pRsp, "+GETFDATA:%c", fail_rec.dummy12);
		break;
	default:
		AT_TC(g_sw_DFMS,  "ATC: invalid index");
		status = FALSE;
		break;
	}
	if(status)
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	else
		AT_DFMS_Result_NA();

	AT_FREE(pRsp);
}

/*****************************************************************************/
// 	Description :set  the full  data
//	Note: AT command used for writing  full data in  factry area
//  Author: d.dubey
/*****************************************************************************/
VOID AT_DFMS_SETFULLFDATA	(AT_CMD_PARA *pParam)
{
	UINT8 uSize;
	UINT8 param1[10]  = {0};
	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 *pRsp = NULL;

	AT_FACT_RECD_PARAM fail_rec = {0};
	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SETTESTNV, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	fail_rec.fail_record =   param1[0];
	fail_rec.retry         =   param1[1];
	fail_rec.dummy11     = param1[2];
	fail_rec.dummy12     = param1[3];

	pRsp = AT_MALLOC(100);
	memset(pRsp, 0x0, 100);
	if(AT_FactorySettings_WriteFactData(&fail_rec))
	{
		sprintf((char *)pRsp, "+SETFULLFDATA:%s", param1);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	}
	else
	{
		AT_TC(g_sw_DFMS,  "ATC: wrtie NV fail");
		AT_Sprintf(pRsp, "+CME ERROR:NG\n");
		AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	}
	AT_FREE(pRsp);

}

/*****************************************************************************/
// 	Description :get  the full  data
//	Note: AT command used for reading  full data from  factry area
//  Author: d.dubey
/*****************************************************************************/
VOID AT_DFMS_GETFULLFDATA(AT_CMD_PARA *pParam)
{
	UINT8 *pRsp = NULL;
	AT_FACT_RECD_PARAM fail_rec = {0};
	memset(&fail_rec, 'N', sizeof(AT_FACT_RECD_PARAM));

	pRsp = AT_MALLOC(256);
	memset(pRsp, 0x0, 256);

	if(AT_FactorySettings_ReadFactData(&fail_rec))
	{
		sprintf((char *)pRsp, "+GETFULLFDATA:%c%c%c%c",
		        fail_rec.fail_record, fail_rec.retry, fail_rec.dummy11, fail_rec.dummy12);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	}
	else
	{
		AT_TC(g_sw_DFMS,  "ATC: read NV fail");
		AT_Sprintf(pRsp, "+CME ERROR:NG\n");
		AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	}
	AT_FREE(pRsp);
}

/*****************************************************************************/
// 	Description :
//	Note:
//  Author: d.dubey
/*****************************************************************************/

extern void AT_StartFactoryModeSamsung(void);
extern void AT_ExitFactoryModeSamsung(void);
extern bool AT_IsFactoryModeSamsungExist(void);

VOID AT_DFMS_FUNCTEST(AT_CMD_PARA *pParam)
{
	UINT8 uSize         = 0;
	UINT8 param1        = 0;
	UINT8 param2        = 0;
	UINT8 uIndex        = 0;
	INT32 iResult       = 0;
	UINT8 uParaCount    = 0;
	UINT8 *pRsp         = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if((iResult != ERR_SUCCESS) || (uParaCount != 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_FUNCTEST, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize   = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_FUNCTEST, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex++;
	uSize   = SIZEOF(param2);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param2, &uSize);
	if(iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_FUNCTEST, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	if(param1 == 0 && param2 == 2)
	{
		if(!AT_IsFactoryModeSamsungExist())
		{
			pRsp = AT_MALLOC(64);
			memset(pRsp, 0x0, 64);

			AT_StartFactoryModeSamsung();

			AT_Sprintf((char *)pRsp, "\r\n+FUNCTEST:0,OK\n\r");
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
			return ;
		}
	}
	else if(param1 == 0 && param2 == 0)
	{
		if(AT_IsFactoryModeSamsungExist())
		{
			pRsp = AT_MALLOC(64);
			memset(pRsp, 0x0, 64);

			AT_ExitFactoryModeSamsung();

			AT_Sprintf((char *)pRsp, "\r\n+FUNCTEST:0,OK\n\r");
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
			return ;
		}
	}

	pRsp = AT_MALLOC(64);
	memset(pRsp, 0x0, 64);
	AT_Sprintf(pRsp, "+CME ERROR:NA\n");
	AT_DFMS_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	AT_FREE(pRsp);
}

#if 0
VOID AT_DFMS_Demo(AT_CMD_PARA *pParam)
{
	INT32 eResult;
	UINT8 uMode  = 0xff, uKey = 0xff, uDisp = 0xff, uInd = 0xff; // , ubf=0xff
	UINT8 iCount = 0;
	UINT8 uLen   = 0;

	// UINT8 send_msg[10];
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID;
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, nSim);
#else
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME);
#endif
		return;
	}
	else
	{
		switch (pParam->iType)
		{

		case AT_CMD_SET:
		{
			eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);

			if (eResult != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
#endif
				return;
			}

			if (!iCount)  // no parameter, just return ok
			{
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0);
#endif
				return;
			}

			// get first param
			uLen = 1;

			eResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uMode, &uLen);

			if (eResult != ERR_SUCCESS && eResult != ERR_AT_UTIL_CMD_PARA_NULL)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
#endif
				return;
			}

			if (eResult == ERR_SUCCESS && uMode != 3)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
#endif
				return;
			}

			// second param
			uLen = 1;

			eResult = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &uKey, &uLen);

			if (eResult != ERR_SUCCESS && eResult != ERR_AT_UTIL_CMD_PARA_NULL)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
#endif
				return;
			}

			if (eResult == ERR_SUCCESS && uKey != 0)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
#endif
				return;
			}

			// third param
			uLen = 1;

			eResult = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_UINT8, &uDisp, &uLen);

			if (eResult != ERR_SUCCESS && eResult != ERR_AT_UTIL_CMD_PARA_NULL)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
#endif
				return;
			}

			if (eResult == ERR_SUCCESS && uDisp != 0)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
#endif
				return;
			}

			// fourth param
			uLen = 1;

			eResult = AT_Util_GetParaWithRule(pParam->pPara, 3, AT_UTIL_PARA_TYPE_UINT8, &uInd, &uLen);

			if (eResult != ERR_SUCCESS) // && eResult != ERR_AT_UTIL_CMD_PARA_NULL
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
#endif
				return;
			}

			if (uInd != 2 && uInd != 0)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
#endif
				return;
			}
			else
			{
				// g_uCmer_ind = uInd;
				gATCurrentuCmer_ind = uInd;
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0);
#endif
				return;
			}
		}

		case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, "+CMER: (3),(0),(0),(0,2)", AT_StrLen("+CMER: (3),(0),(0),(0,2)"),
			             nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, "+CMER: (3),(0),(0),(0,2)", AT_StrLen("+CMER: (3),(0),(0),(0,2)"));
#endif
			break;

		case AT_CMD_READ:
		{
			UINT8 uOutStr[24] = { 0, };

			// +CMER: <mode>,<keyp>,<disp>,<ind>,<bfr>
			AT_Sprintf(uOutStr, "+CMER: 3,0,0,%u", gATCurrentuCmer_ind);  // added by yangtt at 2008-5-12
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutStr, AT_StrLen(uOutStr), nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutStr, AT_StrLen(uOutStr));
#endif
			break;
		}

		default:
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, nSim);
#else
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME);
#endif
			break;
		}
	}

	return;
}

#if 0
const SA_COMMAND_TABLE_T g_SamsungTable[] =
{
	{(UINT8 *)"+HEADINFO", AT_DFMS_info_GetHeadin, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+FCFMTEST", AT_DFMS_Radio_FM, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+FCEPTEST", AT_DFMS_EarSW_FCEPTEST, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+FCESTEST", AT_DFMS_EarSW_FCESTEST, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+SYSSLEEP", AT_DFMS_ForceSleep, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+BANSELCT", AT_DFMS_BandSelection, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+VIBRTEST", AT_DFMS_Motor, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+KEYSHORT", AT_DFMS_KeyShort, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+SPKSTEST", AT_DFMS_SperakerReveiver, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+SIMDETEC", AT_DFMS_SimTest_Detec, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+SERIALNO", AT_DFMS_SerialNumber, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+VERSNAME", AT_DFMS_SWversion, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+RTCCTEST", AT_DFMS_RTC, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+TEMPTEST", AT_DFMS_TEMPTEST, SA_CMDCLS_GC, 1, AT_CMER_PERM},
	{(UINT8 *)"+MAXPOWER", AT_DFMS_MAXPOWER, SA_CMDCLS_GC, 1, AT_CMER_PERM},

};

#endif
#endif

#endif
