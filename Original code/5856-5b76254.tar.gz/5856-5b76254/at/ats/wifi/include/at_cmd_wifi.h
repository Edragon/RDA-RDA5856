/*********************************************************
 *
 * File Name
 *	at_cmd_wifi.h
 * Author
 * 	Felix
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 *
 *********************************************************/

#ifndef _AT_CMD_WIFI_H_
#define _AT_CMD_WIFI_H_

#ifdef __cplusplus
extern "C" {
#endif

  /**************************************************************************************************
	 *                                          INCLUDES
	 **************************************************************************************************/
#include "at_common.h"



#ifdef __cplusplus
}
#endif

typedef enum 
{
    NO_TEST,
    RX_TEST,
    TX_TEST,
    OTHER
}WIFI_TEST_MODE;

#if (0)
void wifi_test_mode_open(WIFI_TEST_MODE mode);
VOID AT_WIFI_CmdFunc_iOpen(AT_CMD_PARA* pParam);
VOID AT_WIFI_CmdFunc_iClose(AT_CMD_PARA* pParam);
VOID AT_WIFI_CmdFunc_iSet(AT_CMD_PARA* pParam);
VOID AT_WIFI_CmdFunc_iTOpen(AT_CMD_PARA* pParam);
VOID AT_WIFI_CmdFunc_iTClose(AT_CMD_PARA* pParam);
VOID AT_WIFI_CmdFunc_iTSet(AT_CMD_PARA* pParam);
VOID AT_WIFI_CmdFunc_iTSetReg(AT_CMD_PARA* pParam);
#endif /* 0 */

VOID AT_WIFI_CmdFunc_WPOWER(AT_CMD_PARA* pParam);
VOID AT_WIFI_CmdFunc_WSCAN(AT_CMD_PARA* pParam);
VOID AT_WIFI_CmdFunc_WJOIN(AT_CMD_PARA* pParam);
VOID AT_WIFI_CmdFunc_WADDR(AT_CMD_PARA* pParam);
VOID AT_WIFI_CmdFunc_WACON(AT_CMD_PARA* pParam);
VOID AT_WIFI_CmdFunc_WRESET(AT_CMD_PARA* pParam);

#ifdef USB_WIFI_SUPPORT
extern VOID at_wifi_PowerOn(UINT8* local_mac);
#endif
#if defined(__WIFI_RADIO_BOX__)
  VOID AT_EMOD_CmdFunc_WRBPLAYURL(AT_CMD_PARA *pParam);
  VOID AT_EMOD_CmdFunc_WRBURLLIST(AT_CMD_PARA *pParam);
  VOID AT_EMOD_CmdFunc_WRBMEDIAPLAY(AT_CMD_PARA *pParam);
  VOID AT_EMOD_CmdFunc_WRBMEDIAPAUSE(AT_CMD_PARA *pParam);
  VOID AT_EMOD_CmdFunc_WRBMEDIARESUME(AT_CMD_PARA *pParam);  
  VOID AT_EMOD_CmdFunc_WRBMEDIASTOP(AT_CMD_PARA *pParam);
  VOID AT_EMOD_CmdFunc_WRBMEDIAVOLUME(AT_CMD_PARA *pParam);
//  VOID AT_EMOD_CmdFunc_WRBSETMODE(AT_CMD_PARA *pParam);  
//  VOID AT_EMOD_CmdFunc_DLNAAVTEST(AT_CMD_PARA *pParam);
#endif
#ifdef IP_CAMERA_SUPPORT
VOID AT_IPCAM_CmdFunc_OPEN(AT_CMD_PARA *pParam);
VOID AT_IPCAM_CmdFunc_CLOSE(AT_CMD_PARA *pParam);
#endif /* IP_CAMERA_SUPPORT */
#if defined(__ZBAR_SUPPORT__)
VOID AT_WIFI_CmdFunc_QRDEC(AT_CMD_PARA *pParam);
#endif /* __ZBAR_SUPPORT__ */

#ifdef __WIFI_TEST_INDEX__
VOID AT_WIFI_TM_CmdFunc_Setr(AT_CMD_PARA* pParam);
VOID AT_WIFI_TM_CmdFunc_Setch(AT_CMD_PARA* pParam);
VOID AT_WIFI_TM_CmdFunc_Tx(AT_CMD_PARA* pParam);
VOID AT_WIFI_TM_CmdFunc_Rx(AT_CMD_PARA* pParam);
VOID AT_WIFI_TM_CmdFunc_Powerup(AT_CMD_PARA* pParam);
VOID AT_WIFI_TM_CmdFunc_Powerdown(AT_CMD_PARA* pParam);
VOID AT_WIFI_TM_CmdFunc_Uttxlen(AT_CMD_PARA* pParam);
VOID AT_WIFI_TM_CmdFunc_Rfregw(AT_CMD_PARA* pParam);
#endif
#endif
 
