/*********************************************************
 *
 * File Name
 *  at_cmd_wifi.c
 * Author
 *  ?
 * Date
 *
 * Descriptions:
 *  at command for wifi operation
 *
 *********************************************************/
#ifdef WIFI_SUPPORT
#include "at_common.h"
#include "at_module.h"
#include "at_cmd_wifi.h"
#include "wifi_config.h"
#include "wifi_api.h"
#include "event.h"


#if defined(__WIFI_RADIO_BOX__)
//#include "dataaccountcommon.h"
#endif
#ifdef IP_CAMERA_SUPPORT
#include "ap_camera.h"
#endif /* IP_CAMERA_SUPPORT */
#ifdef RADIOBOX_NV_FEATURE
#include "RadioBoxNv.h"
#endif


#ifdef RDA_DLNA
#include "cmediarenderer.h"
#endif

#if defined(__WIFI_RADIO_BOX__)
#include "downloadmusic.h"
#endif /* __WIFI_RADIO_BOX__ */


//wif config
#define AT_WIFI_CMD_ELAPSE  60
#define AUTO_SCAN_CONNECT 1

extern void wifi_PowerOff_Req(void);
extern VOID at_wifi_PowerOn(UINT8* local_mac);
extern VOID Wifi_ipAddrChangeReq(void * req);
extern VOID wifi_ScanAps(UINT8 dur, UINT8 *ssid);
extern VOID wifi_ConnectAp_Req(WIFI_BSS_DESC* tmp_bss, UINT8 len, wifi_conn_t* conn, UINT16 dur);

typedef enum
{
    WLAN_STATE_NULL,
    WLAN_STATE_DEINIT_WAIT,
    WLAN_STATE_INIT_WAIT,
    WLAN_STATE_INIT,
    WLAN_STATE_DISCONNECT_WAIT,
    WLAN_STATE_CONNECT_WAIT,
    WLAN_STATE_CONNECTED,
    WLAN_STATE_TOTAL
} wlan_state_enum;

typedef enum
{
    WLAN_SCAN_STATE_NULL,
    WLAN_SCAN_STATE_WAITING,
    WLAN_SCAN_STATE_ABORTING,
    WLAN_SCAN_STATE_TOTAL
} wlan_scan_state_enum;


typedef struct
{
    UINT8 ref_count;
    UINT16 msg_len;
    BOOL use_dhcp;
    UINT8 ip_addr[4];
    UINT8 gateway[4];
    UINT8 netmask[4];
    UINT8 pri_dns_addr[4];
    UINT8 sec_dns_addr[4];
} at_abm_ipaddr_change_req_struct;

wifi_default_conn_t *g_wifi_default_connect = NULL;

UINT8 wifi_nDLCI = 0xFF;
wlan_state_enum g_wifiState             =   WLAN_STATE_NULL;
wlan_scan_state_enum g_wifiScanState    =   WLAN_SCAN_STATE_NULL;

UINT8 g_wifiMacTest[6] = {0};
at_abm_ipaddr_change_req_struct g_ipReq= {0,};
WIFI_BSS_DESC *g_ssidList;

#define CFG_SENDDATALEN     64
#define  ERROR_RETURN(pResult,reason,nDLCI) do{ pResult = AT_CreateRC(CMD_FUNC_FAIL,\
        CMD_RC_ERROR, \
        reason,\
        CMD_ERROR_CODE_TYPE_CME,\
        0,\
        NULL,\
        0,\
        nDLCI);\
    AT_Notify2ATM(pResult,nDLCI);\
    if(pResult != NULL){ \
        AT_FREE(pResult);\
        pResult = NULL; \
    }\
    return;\
}while(0)
#define  OK_RETURN(pResult,pString,nDLCI) do{   pResult = AT_CreateRC(  CMD_FUNC_SUCC,\
        CMD_RC_OK, \
        CMD_ERROR_CODE_OK,\
        CMD_ERROR_CODE_TYPE_CME,\
        0,\
        pString,\
        strlen(pString),\
        nDLCI);\
    AT_Notify2ATM(pResult,nDLCI);\
    if(pResult != NULL){ \
        AT_FREE(pResult);\
        pResult = NULL; \
    }\
    return;\
}while(0)


#define AT_WIFI_IS_AUTO_CONECT()    (NULL != g_wifi_default_connect)
#define AT_WIFI_DIS_AUTO_CONECT()   do{  \
if(AT_WIFI_IS_AUTO_CONECT())   \
    COS_FREE(g_wifi_default_connect); \
g_wifi_default_connect = NULL; \
}while(0)

VOID AT_WIFI_Result_OK(UINT32 uReturnValue,
                       UINT32 uResultCode, UINT8 nDelayTime, UINT8* pBuffer, UINT16 nDataSize, UINT8 nDLCI)

{
    PAT_CMD_RESULT pResult = NULL;

    pResult = AT_CreateRC(uReturnValue,
                          uResultCode, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, nDelayTime, pBuffer, nDataSize, nDLCI);

    AT_Notify2ATM(pResult, nDLCI);
    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}

VOID AT_WIFI_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI)
{
    PAT_CMD_RESULT pResult = NULL;

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, uErrorCode, nErrorType, 0, 0, 0, nDLCI);
    AT_Notify2ATM(pResult, nDLCI);

    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}

VOID AT_WIFI_Open_Rsp(COS_EVENT* pEvent)
{
    if(0x00 == pEvent->nParam1)
    {
        AT_WIFI_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, wifi_nDLCI);
    }
    else
    {
        AT_WIFI_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, wifi_nDLCI);
    }
}

//========================================================
//VOID AT_WIFI_AsyncEventProcess(COS_EVENT* pEvent)
//Handle asynchronous msg, called by AT_AsyncEventProcess.
//========================================================
#if 0//defined(__WIFI_RADIO_BOX__)
BOOL AT_WIFI_AsyncEventProcess(COS_EVENT* pEvent)
{
    UINT8 OutStr[50];
    memset(OutStr, 0, 50);

    AT_TC(g_sw_WIFI, "AT_WIFI_AsyncEventProcess: %d offset: %d",pEvent->nEventId);

    switch (pEvent->nEventId)
    {
        case EV_CFW_WIFI_INIT_RSP:
        {
            if(0x00 !=pEvent->nParam1)
            {
                if(g_wifiState==WLAN_STATE_INIT_WAIT)
                {
                    g_wifiState = WLAN_STATE_INIT;
                    AT_Sprintf(OutStr, "+WIFI:WIFI_INIT_OK");
                    AT_WIFI_Result_OK(CMD_FUNC_SUCC_ASYN,CMD_RC_CR,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);
                    g_wifiState = WLAN_STATE_CONNECT_WAIT;
                    wifi_ScanAps(10,NULL);
                    g_wifiScanState = WLAN_SCAN_STATE_WAITING;
                }
                else
                {
                    AT_Sprintf(OutStr, "+WIFI:WIFI_INIT_FAILED");
                    AT_WIFI_Result_OK(CMD_FUNC_SUCC,CMD_RC_OK,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);
                    if(g_wifiState==WLAN_STATE_INIT_WAIT)
                    {
                        g_wifiState = WLAN_STATE_NULL;
                    }
                    g_wifiScanState = WLAN_SCAN_STATE_NULL;
                }
            }
            else
            {
                AT_Sprintf(OutStr, "+WIFI:WIFI_INIT_FAILED");
                AT_WIFI_Result_OK(CMD_FUNC_SUCC,CMD_RC_OK,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);
                if(g_wifiState==WLAN_STATE_INIT_WAIT)
                {
                    g_wifiState = WLAN_STATE_NULL;
                }
                g_wifiScanState = WLAN_SCAN_STATE_NULL;
            }
            break;
        }
        case EV_CFW_WIFI_DEINIT_RSP:
        {
            if(g_wifiState==WLAN_STATE_DEINIT_WAIT)
            {
                AT_Sprintf(OutStr, "+WIFI:WIFI_DEINIT_OK");
                AT_WIFI_Result_OK(CMD_FUNC_SUCC,CMD_RC_OK,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);

                g_wifiState = WLAN_STATE_NULL;
                g_wifiScanState = WLAN_SCAN_STATE_NULL;
            }
            else
            {
                AT_Sprintf(OutStr, "+WIFI:WIFI_DEINIT_FAILED");
                AT_WIFI_Result_OK(CMD_FUNC_SUCC,CMD_RC_OK,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);
            }
            break;
        }
        case EV_CFW_WIFI_SCAN_RSP:
        {
            UINT32 scan_cnt = pEvent->nParam2;
            UINT32 scan_index = 0;
            if (g_wifiScanState == WLAN_SCAN_STATE_WAITING)
            {

                AT_Sprintf(OutStr, "+WSCAN: %x, cnt=%d(%d)", pEvent->nParam1, pEvent->nParam2, scan_cnt);
                AT_WIFI_Result_OK(CMD_FUNC_CONTINUE,CMD_RC_CR,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);

                g_wifiScanState = WLAN_SCAN_STATE_NULL;
                g_ssidList =(WIFI_BSS_DESC *) pEvent->nParam1;

#ifdef RADIOBOX_NV_FEATURE
                if(scan_cnt > 0)
                {
                    BOOL inHistory_flag = FALSE;
                    wifi_manage_struct *history_ssid = get_wifi_nv_cntx_data();
                    for (scan_index = 0; scan_index < scan_cnt; scan_index++)
                    {
                        if(0 == strncmp(history_ssid->ssid,(g_ssidList+scan_index)->ssid,history_ssid->ssid_len))
                        {
                            if(history_ssid->ssid_len == strlen((g_ssidList+scan_index)->ssid))
                            {
                                UINT8 wjoin_cmd[192] = {0,};

                                inHistory_flag = TRUE;
                                dbg_TraceOutputText(0,"history_ssid->ssid = %s,history_ssid->pwd_key = %s",history_ssid->ssid,history_ssid->pwd_key);
                                sprintf(wjoin_cmd,"AT+WJOIN=%d,\"%s\"",scan_index,history_ssid->pwd_key);
#if defined(__WIFI_RADIO_BOX_MUX__)
                                SendCmdToATTask(wjoin_cmd,strlen(wjoin_cmd),0);
#else
                                SendCmdToATTask(wjoin_cmd,strlen(wjoin_cmd));
#endif

                            }
                        }
                    }
                }
#endif

                for (scan_index = 0; scan_index < scan_cnt; scan_index++)
                {
                    AT_Sprintf(OutStr, "%d: %s", scan_index, (g_ssidList+scan_index)->ssid);
                    //AT_WIFI_Result_OK(CMD_FUNC_CONTINUE,CMD_RC_CR,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);
                    AT_WriteUart(OutStr, AT_StrLen(OutStr));
                    AT_WriteUart("\r\n", AT_StrLen("\r\n"));
                }
#if (0)
                /*send aplist to apk through BT */
                mmi_abm_wifi_ap_list_cnf_struct cnf;
                memset(&cnf,0x00,sizeof(cnf));
                cnf.num = scan_cnt;
                for (scan_index = 0; scan_index < scan_cnt; scan_index++)
                {
                    AT_Sprintf(cnf.ap_list[scan_index].ssid, "%s", (g_ssidList+scan_index)->ssid);
                }
#endif /* 0 */

                AT_WIFI_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, wifi_nDLCI);
            }
            break;
        }
        case EV_CFW_WIFI_CONN_RSP:
        {
            if (g_wifiState==WLAN_STATE_CONNECT_WAIT)
            {
                AT_Sprintf(OutStr, "+WIFI:WIFI_CONNECT");
                AT_WIFI_Result_OK(CMD_FUNC_SUCC_ASYN,CMD_RC_CR,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);

                g_ipReq.use_dhcp = 1;
                Wifi_ipAddrChangeReq(&g_ipReq);
            }
            g_wifiScanState = WLAN_SCAN_STATE_NULL;
            break;
        }
        case EV_CFW_WIFI_DISCONN_RSP:
        case EV_CFW_WIFI_DISCONNECT_IND:
        {
            if(g_wifiState==WLAN_STATE_DEINIT_WAIT)
            {
                AT_Sprintf(OutStr, "+WIFI:WIFI_DISCONNECT");
                AT_WIFI_Result_OK(CMD_FUNC_SUCC,CMD_RC_OK,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);
            }
#if defined(__WIFI_AUTOMATIC_RECONNECT__)
            else if(g_wifiState==WLAN_STATE_CONNECTED)
            {
                g_wifiState = WLAN_STATE_CONNECT_WAIT;
                AT_Sprintf(OutStr, "+WIFI:WIFI_DISCONNECT");
                AT_WIFI_Result_OK(CMD_FUNC_SUCC,CMD_RC_CR,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);
                g_ipReq.use_dhcp = 1;
                Wifi_ipAddrChangeReq(&g_ipReq);
            }
#endif
            else
            {
                g_wifiState = WLAN_STATE_CONNECT_WAIT;
                AT_Sprintf(OutStr, "+WIFI:WIFI_DISCONNECT");
                AT_WIFI_Result_OK(CMD_FUNC_SUCC,CMD_RC_CR,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);
            }
            break;
        }
        case EV_CFW_WIFI_IPADDR_UPDATE_IND:
        {
            if (g_wifiState==WLAN_STATE_CONNECT_WAIT)
            {
                g_wifiState = WLAN_STATE_CONNECTED;
                AT_Sprintf(OutStr, "+WIFI:WIFI_IPADDR_UPDATE");
                AT_WIFI_Result_OK(CMD_FUNC_SUCC,CMD_RC_OK,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);
            }
            else
            {
                g_wifiState = WLAN_STATE_CONNECTED;
                AT_Sprintf(OutStr, "+WIFI:WIFI_IPADDR_UPDATE_UNKNOW");
                AT_WIFI_Result_OK(CMD_FUNC_SUCC,CMD_RC_OK,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);
            }
            break;
        }

        default :
            return FALSE;

    }
#ifdef RADIOBOX_NV_FEATURE
    write_app_wifi_manage_data_to_nv(g_wifiState);
#endif

	return TRUE;
}

#else

BOOL AT_WIFI_AsyncEventProcess(COS_EVENT* pEvent)
{
    UINT8 OutStr[50];
    memset(OutStr, 0, 50);

    switch (pEvent->nEventId)
    {
        case EV_CFW_WIFI_INIT_RSP:
        {
            if(0x00 !=pEvent->nParam1)
            {
                AT_WIFI_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, wifi_nDLCI);
                if(g_wifiState==WLAN_STATE_INIT_WAIT)
                {
                    g_wifiState = WLAN_STATE_INIT;
                }

                if (AT_WIFI_IS_AUTO_CONECT())
                {
                
                    // TODO:  Fix bug: Can't scan enough APs just after power_up,sleep 10ms will be better
                    COS_Sleep(10);
                    
                    SendCmdToATTask("AT+WSCAN",strlen("AT+WSCAN"));
                }
            }
            else
            {
                AT_WIFI_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, wifi_nDLCI);
                if(g_wifiState==WLAN_STATE_INIT_WAIT)
                {
                    g_wifiState = WLAN_STATE_NULL;
                }

                AT_WIFI_DIS_AUTO_CONECT();
            }
            break;
        }
        case EV_CFW_WIFI_DEINIT_RSP:
        {
            AT_WIFI_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, wifi_nDLCI);
            if(g_wifiState==WLAN_STATE_DEINIT_WAIT)
            {
                g_wifiState = WLAN_STATE_NULL;
            }
            break;
        }
        case EV_CFW_WIFI_SCAN_RSP:
        {
             UINT32 scan_cnt = pEvent->nParam2;
            UINT32 scan_index = 0;
            
            g_ssidList =(WIFI_BSS_DESC *) pEvent->nParam1;
            
            if(AT_WIFI_IS_AUTO_CONECT())
            {
                BOOL is_find = FALSE;
                
                for (scan_index = 0; scan_index < scan_cnt; scan_index++)
                {
                    //Connect to xxxx
                    if(strcmp((g_ssidList+scan_index)->ssid,g_wifi_default_connect->ssid) == 0)
                    {
                        AT_Sprintf(OutStr, "AT+WJOIN=%d,%s",scan_index,g_wifi_default_connect->pwd);
                        SendCmdToATTask(OutStr, AT_StrLen(OutStr));
                        is_find = TRUE;
                        break;
                    }
                }

                //Not find expect ap name, rescan again
                if(!is_find)
                {
                    AT_WriteUartString("Can't find arranged ap!\r\n");
                    SendCmdToATTask("AT+WSCAN",strlen("AT+WSCAN"));
                }

            }
            else
            {
                AT_Sprintf(OutStr, "+WSCAN: %x, cnt=%d(%d)", pEvent->nParam1, pEvent->nParam2, scan_cnt);
                AT_WriteUart(OutStr, AT_StrLen(OutStr));
                AT_WriteUart("\r\n", AT_StrLen("\r\n"));
                
                for (scan_index = 0; scan_index < scan_cnt; scan_index++)
                {
                    AT_Sprintf(OutStr, "%d: %s", scan_index, (g_ssidList+scan_index)->ssid);
                    AT_WriteUart(OutStr, AT_StrLen(OutStr));
                    AT_WriteUart("\r\n", AT_StrLen("\r\n"));
                }
            }

            AT_WIFI_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, wifi_nDLCI);

            break;
        }
        case EV_CFW_WIFI_CONN_RSP:
        {
            AT_WIFI_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, wifi_nDLCI);
            AT_WIFI_DIS_AUTO_CONECT();
            break;
        }
        case EV_CFW_WIFI_DISCONN_RSP:
        {
            AT_WIFI_Result_OK(CMD_FUNC_SUCC, CMD_RC_ERROR, 0, NULL, 0, wifi_nDLCI);
            break;
        }
        case EV_CFW_WIFI_DISCONNECT_IND:
        {
            AT_WriteUartString("WIFI Disconnected");
            AT_WIFI_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, wifi_nDLCI);
            break;
        }

        case EV_CFW_WIFI_IPADDR_UPDATE_IND:
        {
            AT_WriteUartString("WIFI IP Updated");
            AT_WIFI_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, wifi_nDLCI);

#if defined(__ZBAR_SUPPORT__)
            IPCamera_API_Start_Qrdec();
#endif /* __ZBAR_SUPPORT__ */
#ifdef RDA_DLNA	
			{
					CgUpnpAvRenderer *dmr = cg_upnpav_dmr_new();
					cg_upnpav_dmr_start(dmr);			
			}
#endif
            break;
        }
#if defined(IP_CAMERA_SUPPORT)
		case MSG_ID_IP_CAMERA_FINISHED:
			if(0x00 !=pEvent->nParam1)
			{
			    AT_WriteUartString("IP Camera Send frame error");
				AT_WIFI_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, NULL, 0, wifi_nDLCI);
			}
			else
			{
			    AT_WriteUartString("IP Camera Stoped");
				AT_WIFI_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, wifi_nDLCI);
			}
			break;
#endif /* IP_CAMERA_SUPPORT */


#if defined(__WIFI_TEST_INDEX__)
		case EV_CFW_WIFI_TEST_MODE_INFO_IND:
			AT_WriteUart(pEvent->nParam1, pEvent->nParam2);
			COS_FREE(pEvent->nParam1);
			break;
#endif /* __WIFI_TEST_INDEX__ */
        default :
            return FALSE;

    }

	return TRUE;
}

#endif
#if 0//!defined(WIN32)  /*add by huangyx, mp3host, 0508 20:19*/
extern void wifi_test_mode_close(void);
extern void wifi_test_mode_set_rfregw(UINT16 reg_addr,UINT16 val);
extern void wifi_test_mode_set(UINT16 dbga,UINT16 rate,UINT16 channel,UINT16 len);

//========================================================
//VOID AT_WIFI_CmdFunc_iOpen(AT_CMD_PARA* pParam)
//
//========================================================
VOID AT_WIFI_CmdFunc_iOpen(AT_CMD_PARA* pParam)
{

    INT32 iRet = ERR_SUCCESS;
    PAT_CMD_RESULT pResult;
    static WIFI_TEST_MODE siOpenCmd = NO_TEST;
    UINT8 OutStr[50]= {0,};

    if (pParam == NULL)
    {
        goto iOpen_ERROR;
    }
    else
    {
        AT_CMD_PARA* Param = pParam;

        AT_TC(g_sw_WIFI, "iOpen Param->iType %d",Param->iType);

        if (Param->pPara == NULL)
        {
            goto iOpen_ERROR;
        }

        switch (Param->iType)
        {
            case AT_CMD_SET:
            {
                UINT8 uCmd;
                UINT8 uLen           = 0;
                UINT8 uNumOfParam    = 0;
                UINT8 arrBuf[5]      = {0x00,};

                if (ERR_SUCCESS != AT_Util_GetParaCount(Param->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }

                AT_TC(g_sw_WIFI, "NumOfParam %d",uNumOfParam);

                if (uNumOfParam != 1)
                {
                    goto iOpen_ERROR;
                }

                // Get first parameter
                uLen = 5;
                if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 0, arrBuf, &uLen))) // Get first parameter.
                {
                    AT_TC(g_sw_WIFI, "AT_Util_GetPara iRet Err 0x%x",iRet);
                    goto iOpen_ERROR;
                }


                I_AM_HERE();

                uCmd = AT_StrAToI(arrBuf);
                siOpenCmd = uCmd;

                wifi_nDLCI = pParam->nDLCI;
                if(1 == siOpenCmd)
                {
                    if(g_wifiState==WLAN_STATE_NULL)
                    {
                        wifi_PowerOn(g_wifiMacTest);
                        g_wifiState=WLAN_STATE_INIT_WAIT;
                        AT_WIFI_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                        return;
                    }
                    else if(g_wifiState==WLAN_STATE_CONNECTED)
                    {

                        AT_Sprintf(OutStr, "+WIFI:WIFI_CONNECT");
                        AT_WIFI_Result_OK(CMD_FUNC_CONTINUE,CMD_RC_CR,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);
                        AT_Sprintf(OutStr, "+WIFI:WIFI_IPADDR_UPDATE");
                        AT_WIFI_Result_OK(CMD_FUNC_CONTINUE,CMD_RC_CR,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);

                        AT_WIFI_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, wifi_nDLCI);

                        return;
                    }
                    else
                    {
                        AT_WIFI_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                        return;
                    }
                }
                else if(2 == siOpenCmd)
                {
                    AT_Sprintf(OutStr, "+WIFI:STATE %d",g_wifiState);
                    AT_WIFI_Result_OK(CMD_FUNC_SUCC,CMD_RC_CR,0,OutStr,AT_StrLen(OutStr),wifi_nDLCI);
                    //AT_WIFI_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, wifi_nDLCI);
                }
                else
                {
                    if(g_wifiState!=WLAN_STATE_NULL)
                    {
                        wifi_PowerOff_Req();
                        g_wifiState=WLAN_STATE_DEINIT_WAIT;
                        AT_WIFI_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                        return;
                    }
                }
                AT_WIFI_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                return;
            }
            case AT_CMD_TEST:
            {

                UINT8 Str[] = "iOpen: NO_TEST, RX_TEST, TX_TEST, OTHER ";
                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

                if (pResult != NULL)
                {
                    AT_Notify2ATM(pResult, pParam->nDLCI);
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }

            case AT_CMD_READ:
            {

                UINT8 *p[] = {"NO_TEST","RX_TEST","TX_TEST","OTHER"};
                UINT8 Str[30] = {0x00,};
                AT_Sprintf(Str, "iOpen: %s", p[siOpenCmd]);

                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

                if (NULL != pResult)
                {
                    AT_Notify2ATM(pResult, pParam->nDLCI);
                }

                if (NULL != pResult)
                {
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }
            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (NULL != pResult)
    {
        AT_Notify2ATM(pResult, pParam->nDLCI);
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;

}

//========================================================
//VOID AT_WIFI_CmdFunc_iTOpen(AT_CMD_PARA* pParam)
//
//========================================================

VOID AT_WIFI_CmdFunc_iTOpen(AT_CMD_PARA* pParam)
{

    INT32 iRet = ERR_SUCCESS;
    PAT_CMD_RESULT pResult;
    static WIFI_TEST_MODE siOpenCmd = NO_TEST;

    if(NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        AT_CMD_PARA* Param = pParam;

        AT_TC(g_sw_WIFI, "iTOpen Param->iType %d",Param->iType);

        if(NULL == Param->pPara)
        {
            goto iOpen_ERROR;
        }

        switch(Param->iType)
        {
            case AT_CMD_SET:
            {
                UINT8 uCmd;
                UINT8 uLen        = 0;
                UINT8 uNumOfParam = 0;
                UINT8 arrBuf[5]      = {0x00,};
                UINT8 Str[] = "iTOpen: OK";

                if (ERR_SUCCESS != AT_Util_GetParaCount(Param->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }

                AT_TC(g_sw_WIFI, "NumOfParam %d",uNumOfParam);

                if (uNumOfParam != 1)
                {
                    goto iOpen_ERROR;
                }

                // Get first parameter
                uLen = 5;
                if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 0, arrBuf, &uLen))) // Get first parameter.
                {
                    AT_TC(g_sw_WIFI, "AT_Util_GetPara iRet Err 0x%x",iRet);
                    goto iOpen_ERROR;
                }


                I_AM_HERE();

                uCmd = AT_StrAToI(arrBuf);
                siOpenCmd = uCmd;

                wifi_test_mode_open(uCmd);

                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

                AT_Notify2ATM(pResult, pParam->nDLCI);
                if (pResult != NULL)
                {
                    AT_FREE(pResult);
                    pResult = NULL;
                }
                return;
            }
            case AT_CMD_TEST:
            {

                UINT8 Str[] = "iTOpen: NO_TEST, RX_TEST, TX_TEST, OTHER ";

                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

                if(NULL != pResult)
                {
                    AT_Notify2ATM(pResult, pParam->nDLCI);
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }

            case AT_CMD_READ:
            {

                UINT8 *p[] = {"NO_TEST","RX_TEST","TX_TEST","OTHER"};
                UINT8 Str[30] = {0x00,};
                AT_Sprintf(Str, "iTOpen: %s", p[siOpenCmd]);

                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

                if (NULL != pResult)
                {
                    AT_Notify2ATM(pResult, pParam->nDLCI);
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }

            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if(NULL != pResult)
    {
        AT_Notify2ATM(pResult, pParam->nDLCI);
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;

}


//========================================================
//VOID AT_WIFI_CmdFunc_iTClose(AT_CMD_PARA* pParam)
//
//========================================================

VOID AT_WIFI_CmdFunc_iTClose(AT_CMD_PARA* pParam)
{

    PAT_CMD_RESULT pResult;

    if (NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        AT_CMD_PARA* Param = pParam;

        AT_TC(g_sw_WIFI, "iClose Param->iType %d",Param->iType);

        if (NULL == Param->pPara)
        {
            goto iOpen_ERROR;
        }

        switch (Param->iType)
        {
            case AT_CMD_TEST:
            {
                UINT8 Str[] = "iTClose ";
                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

                if(NULL != pResult)
                {
                    AT_Notify2ATM(pResult, pParam->nDLCI);
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }

            case AT_CMD_EXE:
            {

                wifi_test_mode_close();
                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

                if (NULL != pResult)
                {
                    AT_Notify2ATM(pResult, pParam->nDLCI);
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }

            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (NULL != pResult)
    {
        AT_Notify2ATM(pResult, pParam->nDLCI);
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;

}

//========================================================
//VOID AT_WIFI_CmdFunc_iTSetReg(AT_CMD_PARA* pParam)
//
//========================================================

VOID AT_WIFI_CmdFunc_iTSetReg(AT_CMD_PARA* pParam)
{

    PAT_CMD_RESULT pResult;
    INT32 iRet = ERR_SUCCESS;

    if(NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        AT_CMD_PARA* Param = pParam;

        AT_TC(g_sw_WIFI, "iSetReg Param->iType %d",Param->iType);

        if(NULL == Param->pPara)
        {
            goto iOpen_ERROR;
        }

        switch (Param->iType)
        {
            case AT_CMD_SET:
            {
                UINT8 uNumOfParam = 0;
                UINT8 uLen        = 0;
                UINT8 arrBuf[5]   = {0x00,};
                UINT16 uRegAddr   = 0;
                UINT16 uVal       = 0;
                UINT8 Str[] = "iTSetReg: OK";

                if (ERR_SUCCESS != AT_Util_GetParaCount(Param->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }

                AT_TC(g_sw_WIFI, "NumOfParam %d",uNumOfParam);

                if (uNumOfParam != 2)
                {
                    goto iOpen_ERROR;
                }

                // Get first parameter
                uLen = 5;
                if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 0, arrBuf, &uLen))) // Get first parameter.
                {
                    AT_TC(g_sw_WIFI, "AT_Util_GetPara iRet Err 0x%x",iRet);
                    goto iOpen_ERROR;
                }


                I_AM_HERE();

                uRegAddr = AT_StrAToI(arrBuf);

                uLen = 5;
                if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 1, arrBuf, &uLen)))
                {
                    AT_TC(g_sw_WIFI, "AT_Util_GetPara iRet Err 0x%x",iRet);
                    goto iOpen_ERROR;
                }

                I_AM_HERE();

                uVal = AT_StrAToI(arrBuf);
                wifi_test_mode_set_rfregw(uRegAddr,uVal);


                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

                AT_Notify2ATM(pResult, pParam->nDLCI);

                if(NULL != pResult)
                {
                    AT_FREE(pResult);
                    pResult = NULL;
                }
                return;
            }

            case AT_CMD_TEST:
            {

                UINT8 Str[] = "iTSetReg: void wifi_test_mode_set_rfregw(UINT16 reg_addr,UINT16 val)";
                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

                if (NULL != pResult)
                {
                    AT_Notify2ATM(pResult, pParam->nDLCI);
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }
            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (NULL != pResult)
    {
        AT_Notify2ATM(pResult, pParam->nDLCI);
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}

//========================================================
//VOID AT_WIFI_CmdFunc_iTSet(AT_CMD_PARA* pParam)
//
//========================================================

VOID AT_WIFI_CmdFunc_iTSet(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;
    INT32 iRet = ERR_SUCCESS;

    if(NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        AT_CMD_PARA* Param = pParam;

        AT_TC(g_sw_WIFI, "iOpen Param->iType %d",Param->iType);

        if (NULL == Param->pPara)
        {
            goto iOpen_ERROR;
        }

        switch (Param->iType)
        {
            case AT_CMD_SET:
            {
                UINT8 uNumOfParam       = 0;
                UINT8 uLen              = 0;
                UINT8 arrBuf[5]         = {0x00,};
                UINT16 uDbga            = 0;
                UINT16 uRate            = 0;
                UINT16 uChannel         = 0;
                UINT8 arrStr[] = "iTSet: OK";

                if (ERR_SUCCESS != AT_Util_GetParaCount(Param->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }
                AT_TC(g_sw_WIFI, "NumOfParam %d",uNumOfParam);

                if (uNumOfParam != 4)
                {
                    goto iOpen_ERROR;
                }

                // Get first parameter
                uLen = 5;
                if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 0, arrBuf, &uLen))) // Get first parameter.
                {
                    AT_TC(g_sw_WIFI, "AT_Util_GetPara iRet Err 0x%x",iRet);
                    goto iOpen_ERROR;
                }


                I_AM_HERE();

                uDbga = AT_StrAToI(arrBuf);

                uLen = 5;
                if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 1, arrBuf, &uLen)))
                {
                    AT_TC(g_sw_WIFI, "AT_Util_GetPara iRet Err 0x%x",iRet);
                    goto iOpen_ERROR;
                }


                I_AM_HERE();

                uRate = AT_StrAToI(arrBuf);

                uLen = 5;
                if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 2, arrBuf, &uLen)))
                {
                    AT_TC(g_sw_WIFI, "AT_Util_GetPara iRet Err 0x%x",iRet);
                    goto iOpen_ERROR;
                }

                I_AM_HERE();

                uChannel = AT_StrAToI(arrBuf);

                uLen = 5;
                if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 3, arrBuf, &uLen)))
                {
                    AT_TC(g_sw_WIFI, "AT_Util_GetPara iRet Err 0x%x",iRet);
                    goto iOpen_ERROR;
                }


                I_AM_HERE();

                uLen = AT_StrAToI(arrBuf);
                wifi_test_mode_set(uDbga,uRate,uChannel,uLen);


                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, arrStr, AT_StrLen(arrStr), pParam->nDLCI);

                if(NULL != pResult)
                {
                    AT_Notify2ATM(pResult, pParam->nDLCI);
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }

            case AT_CMD_TEST:
            {

                UINT8 arrStr[] = "iTSet: void wifi_test_mode_set(UINT16 dbga,UINT16 rate,UINT16 channel,UINT16 len)";
                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, arrStr, AT_StrLen(arrStr), pParam->nDLCI);

                if (NULL != pResult)
                {
                    AT_Notify2ATM(pResult, pParam->nDLCI);
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }


            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if(NULL != pResult)
    {
        AT_Notify2ATM(pResult, pParam->nDLCI);
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;

}
#endif /* __WIFI_TEST_INDEX__ */



//========================================================
// VOID AT_WIFI_CmdFunc_WPOWER(AT_CMD_PARA* pParam)
// Power on/off wifimodule, have one parameter, 1 mean power on,0 mean power off
//========================================================
VOID AT_WIFI_CmdFunc_WPOWER(AT_CMD_PARA* pParam)
{

    UINT8 uStrLen                   = 1;
    INT32 iRetValue                 = 0;
    static WIFI_TEST_MODE siOpenCmd = NO_TEST;
    PAT_CMD_RESULT pResult;

    if (NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {

        AT_TC(g_sw_WIFI, "WPOWER Param->iType %d",pParam->iType);

        if(NULL == pParam->pPara)
        {
            goto iOpen_ERROR;
        }

        switch (pParam->iType)
        {

            case AT_CMD_SET:
            {
                UINT8 uNumOfParam = 0;
                if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }
                if (1 != uNumOfParam)
                {
                    goto iOpen_ERROR;
                }

                iRetValue = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &siOpenCmd, &uStrLen);

                if (ERR_SUCCESS != iRetValue)
                {
                    AT_WIFI_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                    return;
                }

                I_AM_HERE();

                if(siOpenCmd == 1)
                {
                    at_wifi_PowerOn(g_wifiMacTest);
                    g_wifiState=WLAN_STATE_INIT_WAIT;
                }
                else
                {
                    wifi_PowerOff_Req();
                    g_wifiState=WLAN_STATE_DEINIT_WAIT;
                }

                wifi_nDLCI = pParam->nDLCI;
                AT_WIFI_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);

                return;
            }

            case AT_CMD_TEST:
            {

                UINT8 arrStr[] = "iOpen: NO_TEST, RX_TEST, TX_TEST, OTHER ";
                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, arrStr, AT_StrLen(arrStr), pParam->nDLCI);

                if (NULL != pResult)
                {
                    AT_Notify2ATM(pResult, pParam->nDLCI);
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }

            case AT_CMD_READ:
            {
                UINT8 *p[] = {"NO_TEST","RX_TEST","TX_TEST","OTHER"};
                UINT8 arrStr[30] = {0x00,};
                AT_Sprintf(arrStr, "WPOWER: %s", p[siOpenCmd]);

                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, arrStr, AT_StrLen(arrStr), pParam->nDLCI);

                if (pResult != NULL)
                    AT_Notify2ATM(pResult, pParam->nDLCI);

                if (pResult != NULL)
                {
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }
            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (NULL != pResult)
    {
        AT_Notify2ATM(pResult, pParam->nDLCI);
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;

}


//========================================================
//VOID AT_WIFI_CmdFunc_WSCAN(AT_CMD_PARA* pParam)
//Scan hotspot list,without parmeter
//========================================================
VOID AT_WIFI_CmdFunc_WSCAN(AT_CMD_PARA* pParam)
{

    PAT_CMD_RESULT pResult;

    if (NULL == pParam )
    {
        goto iOpen_ERROR;
    }
    else
    {
        AT_CMD_PARA* Param = pParam;

        AT_TC(g_sw_WIFI, "WSCAN Param->iType %d",Param->iType);

        if (NULL == Param->pPara)
        {
            goto iOpen_ERROR;
        }

        switch (Param->iType)
        {
            case AT_CMD_EXE:
            {
                wifi_nDLCI = pParam->nDLCI;
                wifi_ScanAps(5,NULL);
                g_wifiScanState = WLAN_SCAN_STATE_WAITING;
			    AT_WriteUartString("WIFI Scaning...");
                AT_WIFI_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);

                return;
            }
            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (NULL != pResult)
    {
        AT_Notify2ATM(pResult, pParam->nDLCI);
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;

}


//========================================================
//VOID AT_WIFI_CmdFunc_WJOIN(AT_CMD_PARA* pParam)
//Connect with hotspot, two parameters: num, ssid
//========================================================
VOID AT_WIFI_CmdFunc_WJOIN(AT_CMD_PARA* pParam)
{
    INT32 iRet = ERR_SUCCESS;
    wifi_conn_t tWifiConn;
    PAT_CMD_RESULT pResult;
    UINT8 OutStr[50]= {0};

    if (NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        AT_CMD_PARA* Param = pParam;
        if (NULL == Param->pPara)
        {
            goto iOpen_ERROR;
        }

        switch (Param->iType)
        {
            case AT_CMD_SET:
            {
                UINT8 uPara1;
                UINT8 uPara1Len = 1;
                UINT8 uParaCount;
                UINT8 uSize ;
                UINT8 arrCharacterSet[20] = {0,};

                iRet = AT_Util_GetParaCount(pParam->pPara, &uParaCount);

                if(ERR_SUCCESS != iRet)
                {
                    goto iOpen_ERROR;
                }

                AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uPara1, &uPara1Len);

                if(2 == uParaCount)
                {
                    uSize  = SIZEOF(arrCharacterSet);
                    AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, &arrCharacterSet, &uSize);

                    tWifiConn.password = arrCharacterSet;
                    tWifiConn.pwd_len = uSize;
                }
                else
                {
                    tWifiConn.password = NULL;
                    tWifiConn.pwd_len = 0;
                }

                tWifiConn.ssid = (g_ssidList+uPara1)->ssid;
                tWifiConn.ssid_len = strlen(tWifiConn.ssid);
                wifi_nDLCI = pParam->nDLCI;

                AT_Sprintf(OutStr, "Joining %s,pwd=%s ...", tWifiConn.ssid,(NULL == tWifiConn.password ? "" : tWifiConn.password));
                
                wifi_ConnectAp_Req(g_ssidList+uPara1, sizeof(WIFI_BSS_DESC), &tWifiConn, 15);
                g_wifiState = WLAN_STATE_CONNECT_WAIT;
                AT_WIFI_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, AT_WIFI_CMD_ELAPSE, OutStr, strlen(OutStr), pParam->nDLCI);

                return;
            }
            break;

            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (pResult != NULL)
    {
        AT_Notify2ATM(pResult, pParam->nDLCI);
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;

}

//========================================================
//VOID AT_WIFI_CmdFunc_WADDR(AT_CMD_PARA* pParam)
//Get ip address,without parameter
//========================================================
VOID AT_WIFI_CmdFunc_WADDR(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;

    if(NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        if (pParam->pPara == NULL)
        {
            goto iOpen_ERROR;
        }

        switch (pParam->iType)
        {

            case AT_CMD_EXE:
            {
                g_ipReq.use_dhcp = 1;
                Wifi_ipAddrChangeReq(&g_ipReq);
                wifi_nDLCI = pParam->nDLCI;
                g_wifiState = WLAN_STATE_CONNECT_WAIT;
                AT_WIFI_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, AT_WIFI_CMD_ELAPSE, NULL, 0, pParam->nDLCI);

                return;
            }
            default:
            {
                goto iOpen_ERROR;
            }

        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (pResult != NULL)
    {
        AT_Notify2ATM(pResult, pParam->nDLCI);
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;

}

//========================================================
//VOID AT_WIFI_CmdFunc_WACON(AT_CMD_PARA* pParam)
//Try to connect special WIFI
//WIFI:T:WPA;P:123456789;S:Office_2.4G;
//AT+WACON=Office_2.4G,123456789
//========================================================
VOID AT_WIFI_CmdFunc_WACON(AT_CMD_PARA* pParam)
{
    INT32 iRet = ERR_SUCCESS;
    PAT_CMD_RESULT pResult;
    UINT8 OutStr[50]= {0};

    if (NULL == pParam)
    {
        goto Param_ERROR;
    }
    else
    {
        AT_CMD_PARA* Param = pParam;
        if (NULL == Param->pPara)
        {
            goto Param_ERROR;
        }

        switch (Param->iType)
        {
            case AT_CMD_SET:
            {
                UINT8 uParaLen = 1;
                UINT8 uParaCount;
                wifi_default_conn_t *tmp_conn;

                iRet = AT_Util_GetParaCount(pParam->pPara, &uParaCount);

                if(ERR_SUCCESS != iRet || uParaCount <= 0)
                {
                    goto Param_ERROR;
                }

                if(NULL == g_wifi_default_connect)
                {
                    tmp_conn = (wifi_default_conn_t *) COS_MALLOC(sizeof(wifi_default_conn_t));
                    if(NULL == tmp_conn)
                    {
                        goto Param_ERROR;
                    }
                }
                else
                {
                    tmp_conn = g_wifi_default_connect;
                }
                
                memset(tmp_conn,0,sizeof(wifi_default_conn_t));
                tmp_conn->ssid_len = IW_ESSID_MAX_SIZE + 1;


                
                AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, tmp_conn->ssid, &tmp_conn->ssid_len);
                if(uParaCount > 1)
                {
                    tmp_conn->pwd_len = IW_EPWD_MAX_SIZE;
                    AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, tmp_conn->pwd, &tmp_conn->pwd_len);
                }

                g_wifi_default_connect = tmp_conn;

                SendCmdToATTask("AT+WPOWER=1",strlen("AT+WPOWER=1"));
                OK_RETURN(pResult, "AUTO_CONNECT_START",0);
                return;
            }
            break;

            default:
            {
                goto Param_ERROR;
            }
        }
    }

Param_ERROR:

    ERROR_RETURN(pResult,CMD_ERROR_CODE_OK,pParam->nDLCI);
    return;

}

VOID AT_WIFI_CmdFunc_WRESET(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;

    if (NULL == pParam )
    {
        goto iOpen_ERROR;
    }
    else
    {
        AT_CMD_PARA* Param = pParam;

        AT_TC(g_sw_WIFI, "WRESET Param->iType %d",Param->iType);

        if (NULL == Param->pPara)
        {
            goto iOpen_ERROR;
        }

        switch (Param->iType)
        {
            case AT_CMD_EXE:
            {
                wifi_nDLCI = pParam->nDLCI;
                wifi_ResetReq();                
			    AT_WriteUartString("WIFI Reseting...");
                AT_WIFI_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);

                return;
            }
            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (NULL != pResult)
    {
        AT_Notify2ATM(pResult, pParam->nDLCI);
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;

}

#if defined(__WIFI_RADIO_BOX__)

VOID AT_EMOD_CmdFunc_WRBPLAYURL(AT_CMD_PARA *pParam)
{
    static UINT8 on_flag = 0;
    PAT_CMD_RESULT pResult = NULL;
    UINT8 uParaCount = 0;
    UINT8 param_len = 1;
    UINT8 Rsp[512] = {0,};
    UINT8 arrUrlCharacter[0xff] = {0,};

    AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBPLAYURL Enter");

    if (pParam->iType == AT_CMD_TEST)
    {
        AT_Sprintf(Rsp, "+WRBPLAYURL: ");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;

    }
    else if (pParam->iType == AT_CMD_READ)
    {
        AT_Sprintf(Rsp, "+WRBPLAYURL:");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;
    }
    else if (pParam->iType == AT_CMD_SET)
    {
        if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBPLAYURL Err1");
            return;
        }

        if (uParaCount != 1)
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBPLAYURL Err2");
            return;
        }
        memset(arrUrlCharacter,0,sizeof(arrUrlCharacter));
        param_len=sizeof(arrUrlCharacter)-1;
        if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, &arrUrlCharacter, &param_len))
        {
            AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBPLAYURL Err3");
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        WRB_SendPlayUrlREQ(arrUrlCharacter,0);
#if 0
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
#else
        AT_Sprintf(Rsp, "+WRBPLAYURL");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
#endif
    }
    else if (pParam->iType == AT_CMD_EXE)
    {
//      WifiPlayURLTest();
        char *pUrl = "http://10.1.17.38/test.mp3";
        WRB_SendPlayUrlREQ(pUrl, 0);
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;
    }
    else
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;
    }
}

VOID AT_EMOD_CmdFunc_WRBURLLIST(AT_CMD_PARA *pParam)
{
    static UINT8 on_flag = 0;
    PAT_CMD_RESULT pResult = NULL;
    UINT8 uParaCount = 0;
    UINT8 cVal = 0xff;
    UINT8 param_len = 1;
    UINT8 Rsp[512] = {0,};
    UINT8 arrCmdCharacter[20] = {0,};
    UINT8 arrUrlCharacter[256] = {0,};

    AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBURLLIST Enter");

    if (pParam->iType == AT_CMD_TEST)
    {
        AT_Sprintf(Rsp, "+AT_EMOD_CmdFunc_WRBURLLIST: ");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;

    }
    else if (pParam->iType == AT_CMD_READ)
    {
        AT_Sprintf(Rsp, "+AT_EMOD_CmdFunc_WRBURLLIST: ");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;
    }
    else if (pParam->iType == AT_CMD_SET)
    {
        if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBURLLIST Err1");
            return;
        }

        if (uParaCount != 3)
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBURLLIST Err2");
            return;
        }

        param_len=sizeof(arrCmdCharacter)-1;
        if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, &arrCmdCharacter, &param_len))
        {
            AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBURLLIST Err3");
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        param_len=1;
        if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &cVal, &param_len))
        {
            AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBURLLIST Err4");
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        param_len=sizeof(arrUrlCharacter)-1;
        if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_STRING, &arrUrlCharacter, &param_len))
        {
            AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBURLLIST Err5");
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBURLLIST cmd:%s,para:%s",arrCmdCharacter,arrUrlCharacter);

        if (0==strcmp(arrCmdCharacter,"GETURLLIST"))
        {
            uint8 index=0;
            uint8 total = 0;
            uint8 * pUrl=NULL;
            AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBURLLIST GETURLLIST cVal=%d,0x%x",cVal,cVal);
            if (255==cVal)
            {
                //list all
                AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBURLLIST GETURLLIST list all");
                do
                {
                    GetList(index,&pUrl,&total);
                    
                    AT_Sprintf(Rsp, "+GETURLLIST:\"%s\",%d,%d",pUrl,index,total);
                    AT_WriteUart(Rsp, strlen(Rsp));
                    index++;
                }
                while((index<total) && (total>0));

                OK_RETURN(pResult, "OK", pParam->nDLCI);
                return;
            }
            else if (cVal<10)
            {
                //list[index]
                AT_TC(g_sw_SPEC, "AT_EMOD_CmdFunc_WRBURLLIST GETURLLIST list[index]");

                GetList(cVal,&pUrl,&total);
                AT_Sprintf(Rsp, "+GETURLLIST:\"%s\",%d,%d",pUrl,cVal,total);
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
                return;
            }
            OK_RETURN(pResult, Rsp, pParam->nDLCI);
        }
        else if (0==strcmp(arrCmdCharacter,"ADDURLTOLIST"))
        {
            uint8 uRet=0;
            uRet=AddURL(arrUrlCharacter);

            AT_Sprintf(Rsp, "+ADDURLTOLIST:\"%s\",%d",arrUrlCharacter,uRet);
            OK_RETURN(pResult, Rsp, pParam->nDLCI);
            return;
        }
        else if (0==strcmp(arrCmdCharacter,"MODIFYURLLIST"))
        {
            if(strlen(arrUrlCharacter)>0)
            {
                ChangeURL(cVal,arrUrlCharacter);
            }
            else
            {
                ChangeURL(cVal,NULL);
            }
            AT_Sprintf(Rsp, "+MODIFYURLLIST:\"%s\",%d",arrUrlCharacter,cVal);
            OK_RETURN(pResult, Rsp, pParam->nDLCI);
            return;
        }
        else
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }
    }
    else
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;
    }
}


VOID AT_EMOD_CmdFunc_WRBMEDIAPLAY(AT_CMD_PARA *pParam)
{
    static UINT8 on_flag = 0;
    PAT_CMD_RESULT pResult = NULL;
    UINT8 uParaCount = 0;
    UINT8 cVal = 0;
    UINT8 param_len = 1;
    UINT8 Rsp[30] = {0,};

    if (pParam->iType == AT_CMD_TEST)
    {
        AT_Sprintf(Rsp, "+WRBPLAYURL: ");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;

    }
    else if (pParam->iType == AT_CMD_READ)
    {
        AT_Sprintf(Rsp, "+BTACTIVATE:");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;
    }
    else if (pParam->iType == AT_CMD_SET)
    {
        if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        if (uParaCount != 1)
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &cVal, &param_len))
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }
    }
    else if (pParam->iType == AT_CMD_EXE)
    {
        WRB_SendMediaPlayREQ();
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;
    }
    else
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;
    }
}

VOID AT_EMOD_CmdFunc_WRBMEDIAPAUSE(AT_CMD_PARA *pParam)
{
    static UINT8 on_flag = 0;
    PAT_CMD_RESULT pResult = NULL;
    UINT8 uParaCount = 0;
    UINT8 cVal = 0;
    UINT8 param_len = 1;
    UINT8 Rsp[30] = {0,};

    if (pParam->iType == AT_CMD_TEST)
    {
        AT_Sprintf(Rsp, "+WRBPLAYURL: ");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;

    }
    else if (pParam->iType == AT_CMD_READ)
    {
        AT_Sprintf(Rsp, "+BTACTIVATE:");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;
    }
    else if (pParam->iType == AT_CMD_SET)
    {
        if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        if (uParaCount != 1)
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &cVal, &param_len))
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }
    }
    else if (pParam->iType == AT_CMD_EXE)
    {
        WRB_SendMediaPauseREQ();
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;
    }
    else
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;
    }
}

VOID AT_EMOD_CmdFunc_WRBMEDIARESUME(AT_CMD_PARA *pParam)
{
    static UINT8 on_flag = 0;
    PAT_CMD_RESULT pResult = NULL;
    UINT8 uParaCount = 0;
    UINT8 cVal = 0;
    UINT8 param_len = 1;
    UINT8 Rsp[30] = {0,};

    if (pParam->iType == AT_CMD_TEST)
    {
        AT_Sprintf(Rsp, "+WRBPLAYURL: ");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;

    }
    else if (pParam->iType == AT_CMD_READ)
    {
        AT_Sprintf(Rsp, "+BTACTIVATE:");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;
    }
    else if (pParam->iType == AT_CMD_SET)
    {
        if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        if (uParaCount != 1)
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &cVal, &param_len))
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }
    }
    else if (pParam->iType == AT_CMD_EXE)
    {
        WRB_SendMediaResumeREQ();
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;
    }
    else
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;
    }
}

VOID AT_EMOD_CmdFunc_WRBMEDIASTOP(AT_CMD_PARA *pParam)
{
    static UINT8 on_flag = 0;
    PAT_CMD_RESULT pResult = NULL;
    UINT8 uParaCount = 0;
    UINT8 cVal = 0;
    UINT8 param_len = 1;
    UINT8 Rsp[30] = {0,};

    if (pParam->iType == AT_CMD_TEST)
    {
        AT_Sprintf(Rsp, "+WRBPLAYSTOP: ");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;

    }
    else if (pParam->iType == AT_CMD_READ)
    {
        AT_Sprintf(Rsp, "+WRBPLAYSTOP:");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;
    }
    else if (pParam->iType == AT_CMD_SET)
    {
        if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        if (uParaCount != 1)
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &cVal, &param_len))
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }
    }
    else if (pParam->iType == AT_CMD_EXE)
    {
        WRB_SendMediaStopREQ();
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;
    }
    else
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;
    }
}

VOID AT_EMOD_CmdFunc_WRBMEDIAVOLUME(AT_CMD_PARA *pParam)
{
    static UINT8 on_flag = 0;
    PAT_CMD_RESULT pResult = NULL;
    UINT8 uParaCount = 0;
    UINT8 cVolume = 0;
    UINT8 param_len = 1;
    UINT8 Rsp[30] = {0,};

    if (pParam->iType == AT_CMD_TEST)
    {
        AT_Sprintf(Rsp, "+WRBPLAYSTOP: ");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;

    }
    else if (pParam->iType == AT_CMD_READ)
    {
        AT_Sprintf(Rsp, "+WRBPLAYSTOP:");
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;
    }
    else if (pParam->iType == AT_CMD_SET)
    {
        if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        if (uParaCount != 1)
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &cVolume, &param_len))
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
            return;
        }

        WRB_Send_MediaVolumeREQ(cVolume);
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
    }
    else if (pParam->iType == AT_CMD_EXE)
    {
        OK_RETURN(pResult, Rsp, pParam->nDLCI);
        return;
    }
    else
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;
    }
}


#if (0)

#include "btmmia2dp.h"
#include "bt_avrcp_struct.h"
#include "dataaccountenum.h"
#include "av_bt.h"
extern wlan_state_enum g_wifiState;
extern UINT8 g_wifiMacTest[6];
extern mmi_a2dp_cntx_struct g_mmi_a2dp_cntx;

VOID AT_EMOD_CmdFunc_WRBSETMODE(AT_CMD_PARA *pParam)//BTBOX/WIFBOX
{
    PAT_CMD_RESULT pResult = NULL;
    UINT8 nIndex;
    UINT8 uSize;
    UINT8 Rsp[30] = {0,};
    UINT8 nContext[30]= {0,};
    if (pParam->iType == AT_CMD_TEST)
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;

    }
    else if (pParam->iType == AT_CMD_READ)
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;
    }
    else if (pParam->iType == AT_CMD_SET)
    {
        nIndex  = 0;
        uSize  = SIZEOF(nContext);
        pResult = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_STRING, &nContext, &uSize);
        if(strcmp(nContext,"BTBOX") == 0)
        {
            if(g_wifiState!=WLAN_STATE_NULL)
            {
                wifi_PowerOff();
                g_wifiState=WLAN_STATE_DEINIT_WAIT;
            }

            if(g_mmi_a2dp_cntx.state==MMI_A2DP_STATE_ACTIVATED)
            {
                mmi_bt_avrcp_connect_ct_req(g_mmi_a2dp_cntx.bd_addr);
                mmi_bt_a2dp_connect_req(g_mmi_a2dp_cntx.bd_addr);
            }
            OK_RETURN(pResult, Rsp, pParam->nDLCI);
        }
        else if(strcmp(nContext,"WIFBOX") == 0)
        {
            if(g_mmi_a2dp_cntx.state==MMI_A2DP_STATE_CONNECTED)
            {
                mmi_bt_a2dp_disconnect_req(g_mmi_a2dp_cntx.bd_addr, g_mmi_a2dp_cntx.connect_id);
                Avrcp_Disconnect_Req();
            }
            if(g_wifiState==WLAN_STATE_NULL)
            {
                wifi_PowerOn(g_wifiMacTest);
                g_wifiState=WLAN_STATE_INIT_WAIT;
            }
            OK_RETURN(pResult, Rsp, pParam->nDLCI);
        }
        else
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        }
        return;
    }
    else if (pParam->iType == AT_CMD_EXE)
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;
    }
    else
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;
    }
}

#include <cybergarage/upnp/cupnp.h>
#include <cybergarage/upnp/std/av/cmediarenderer.h>
static CgUpnpAvRenderer *at_dmr =NULL;
CgUpnpDevice *guPnPDev=NULL;

VOID AT_EMOD_CmdFunc_DLNAAVTEST(AT_CMD_PARA *pParam)//BTBOX/WIFBOX
{
    PAT_CMD_RESULT pResult = NULL;
    UINT8 nIndex;
    UINT8 uSize;
    UINT8 Rsp[30] = {0,};
    UINT8 nContext[0xff]= {0,};
    if (pParam->iType == AT_CMD_TEST)
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;

    }
    else if (pParam->iType == AT_CMD_READ)
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;
    }
    else if (pParam->iType == AT_CMD_SET)
    {
        nIndex  = 0;
        uSize  = SIZEOF(nContext);
        pResult = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_STRING, &nContext, &uSize);
        if(strcmp(nContext,"xmlParser") == 0)
        {
            nIndex=1;
            uSize  = SIZEOF(nContext);
            pResult = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_STRING, &nContext, &uSize);
            if(strcmp(nContext,"start") == 0)
            {
                xmlParser_test();
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"stop") == 0)
            {
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"reset") == 0)
            {
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
        }
        else if(strcmp(nContext,"threadTest") == 0)
        {
            nIndex=1;
            uSize  = SIZEOF(nContext);
            pResult = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_STRING, &nContext, &uSize);
            if(strcmp(nContext,"start") == 0)
            {
                thread_test();
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"stop") == 0)
            {
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"reset") == 0)
            {
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
        }
        else if(strcmp(nContext,"seek") == 0)
        {
            nIndex=1;
            uSize  = SIZEOF(nContext);
            pResult = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_STRING, &nContext, &uSize);

            if(NULL != nContext)
            {
                AT_Sprintf(Rsp, "seek");
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
        }
        else if(strcmp(nContext,"GetRelTime") == 0)
        {
#if 0
            char *RelTime = upnpcg_media_getreltime();

            if(NULL != RelTime)
                AT_Sprintf(Rsp, "GetRelTime: %s",RelTime);
            else
                AT_Sprintf(Rsp, "GetRelTime: %s","play terminated!");
#endif
            OK_RETURN(pResult, Rsp, pParam->nDLCI);
        }
        else if(strcmp(nContext,"TrackDuration") == 0)
        {
            char *duration = upnpcg_media_gettrackduration();
            if(NULL != duration)
                AT_Sprintf(Rsp, "TrackDuration = %s",duration);
            else
                AT_Sprintf(Rsp, "TrackDuration: NULL");
            OK_RETURN(pResult, Rsp, pParam->nDLCI);
        }
        else if(strcmp(nContext,"socketTest") == 0)
        {
            nIndex=1;
            uSize  = SIZEOF(nContext);
            pResult = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_STRING, &nContext, &uSize);
            if(strcmp(nContext,"httpclient") == 0)
            {
                socket_systemtest_httpclient_start();
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"httpserver") == 0)
            {
                socket_systemtest_httpserver_start();
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"ssdpclientunicast") == 0)
            {
                socket_systemtest_ssdpclient_unicast_start();
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"ssdpclientmulticast") == 0)
            {
                socket_systemtest_ssdpclient_multicast_start();
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"ssdpserver") == 0)
            {
                socket_systemtest_ssdpserver_start();
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"connectOK") == 0)
            {
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"connectERR") == 0)
            {
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
        }
        else if(strcmp(nContext,"timetest") == 0)
        {
            long time=0;
            nIndex=1;
            uSize  = SIZEOF(nContext);
            pResult = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_STRING, &nContext, &uSize);
            if(strcmp(nContext,"systemtime") == 0)
            {
                time=time_test_getcurrentsystemtime();
                AT_Sprintf(Rsp, "systemtime: %d,%x",time,time);
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"waitms") == 0)
            {
                time=time_test_waitms(100);
                AT_Sprintf(Rsp, "waitms: %d,%x",time,time);
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"waitrandom") == 0)
            {
                time=time_test_waitrandom(100);
                AT_Sprintf(Rsp, "waitrandom: %d,%x",time,time);
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
        }
        else if(strcmp(nContext,"dmrTest") == 0)
        {
            nIndex=1;
            uSize  = SIZEOF(nContext);
            pResult = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_STRING, &nContext, &uSize);
            if(NULL == at_dmr)
            {
                COS_MallocPreferUsrMalloc(FALSE);
                at_dmr = cg_upnpav_dmr_new();
                COS_MallocPreferUsrMalloc(TRUE);
            }
            if(strcmp(nContext,"start") == 0)
            {
                if(NULL == at_dmr)
                {
                    COS_MallocPreferUsrMalloc(FALSE);
                    at_dmr = cg_upnpav_dmr_new();
                    COS_MallocPreferUsrMalloc(TRUE);
                }
#if 1
                cg_upnpav_dmr_start_thread(at_dmr);
#else
                if (cg_upnpav_dmr_start(at_dmr) == FALSE)
                {
                    ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
                }
#endif
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"stop") == 0)
            {
                cg_upnpav_dmr_stop(at_dmr);
                cg_upnpav_dmr_delete(at_dmr);
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"reset") == 0)
            {
                if (cg_upnpav_dmr_stop(at_dmr) == FALSE)
                {
                    ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
                }
                if (cg_upnpav_dmr_start(at_dmr) == FALSE)
                {
                    ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
                }
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"download") == 0)
            {
                nIndex=2;
                uSize  = SIZEOF(nContext);
                pResult = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_STRING, &nContext, &uSize);

                at_dmr->netmediaplayer->NetMediaPlayerInfo.mediaplaystatus = cg_mediaplay_status_stop;
                at_dmr->netmediaplayer->mediadownloadinfo.range = 0;
                //cg_net_url_set(at_dmr->netmediaplayer->mediaurl, "http://192.168.1.100/AudioJoiner140529164744.mp3");
                //cg_net_url_set(at_dmr->netmediaplayer->mediaurl, "http://192.168.1.125:12345/media/externalaudiomedia65924");
                //cg_net_url_set(at_dmr->netmediaplayer->mediaurl, "http://192.168.43.158/AudioJoiner140529164744.mp3");
//              cg_net_url_set(at_dmr->netmediaplayer->mediaurl, "http://192.168.1.105/AudioJoiner140529164744.mp3");
//              cg_net_url_set(at_dmr->netmediaplayer->mediaurl, "http://172.22.1.201/foswiki/pub/User/Test/AudioJoiner140529164744.mp3");

                cg_net_url_set(at_dmr->netmediaplayer->mediaurl, nContext);
                sxr_mediamanagetask_start(at_dmr);
                mediaProcessStart(at_dmr);
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"alive") == 0)
            {
                cg_upnp_device_start_announceonce_thread(at_dmr);
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"debug") == 0)
            {
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"break") == 0)
            {
                hal_DbgAssert("force break");
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        }
        else if(strcmp(nContext,"upnpTest") == 0)
        {
            nIndex=1;
            uSize  = SIZEOF(nContext);
            pResult = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_STRING, &nContext, &uSize);

            if(strcmp(nContext,"start") == 0)
            {
                if(NULL!=guPnPDev)
                {
                    guPnPDev = cg_upnp_device_new();
                }
                if (cg_upnp_device_start(guPnPDev) == FALSE)
                {
                    ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
                }
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"stop") == 0)
            {
                cg_upnp_device_stop(guPnPDev);
                cg_upnp_device_delete(guPnPDev);
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"reset") == 0)
            {
                if (cg_upnp_device_stop(guPnPDev) == FALSE)
                {
                    ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
                }
                if (cg_upnp_device_start(guPnPDev) == FALSE)
                {
                    ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
                }
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }

        }
        else if(strcmp(nContext,"mediatest") == 0)
        {
            long time=0;
            nIndex=1;
            uSize  = SIZEOF(nContext);
            pResult = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_STRING, &nContext, &uSize);
            if(strcmp(nContext,"play") == 0)
            {
                static int i = 0;
                const char *url_array[11] =
                {
                    "http://192.168.1.4/USA_01.mp3",
                    "http://192.168.1.4/USA_02.mp3",
                    "http://192.168.1.4/USA_03.mp3",
                    "http://192.168.1.4/USA_04.mp3",
                    "http://192.168.1.4/USA_05.mp3",
                    "http://192.168.1.4/USA_06.mp3",
                    "http://192.168.1.4/USA_07.mp3",
                    "http://192.168.1.4/USA_08.mp3",
                    "http://192.168.1.4/USA_09.mp3",
                    "http://192.168.1.4/USA_10.mp3",
                    "http://192.168.1.4/USA_11.mp3",
                };
                //media_test_start("http://192.168.1.4/USA_02.mp3");
                media_test_start(url_array[i]);
                i++;
                if(i == 11)
                    i = 0;
                AT_Sprintf(Rsp, "play");
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            if(strcmp(nContext,"printTask") == 0)
            {
                sxr_print_all_active_task();
                AT_Sprintf(Rsp, "Done");
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"Stop") == 0)
            {
                //mytest();
                //test_aac_data
                AT_Sprintf(Rsp, "Stop");
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"Pause") == 0)
            {
                //upnpsxrMediaCBInfoEnqueue(upnpsxrMediaCBInfoGetqueue(),EV_UPNP_MIDIA_TASK_PAUSE);
                AT_Sprintf(Rsp, "Pause");
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"Resume") == 0)
            {
                //upnpsxrMediaCBInfoEnqueue(upnpsxrMediaCBInfoGetqueue(),EV_UPNP_MIDIA_TASK_RESUME);
                AT_Sprintf(Rsp, "Resume");
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
            else if(strcmp(nContext,"AddBuff") == 0)
            {
                AT_Sprintf(Rsp, "AddBuff");
                OK_RETURN(pResult, Rsp, pParam->nDLCI);
            }
        }
        else
        {
            ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        }
    }
    else if (pParam->iType == AT_CMD_EXE)
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;
    }
    else
    {
        ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
        return;
    }
}
#endif /* 0 */

#endif
#ifdef IP_CAMERA_SUPPORT
VOID AT_IPCAM_CmdFunc_OPEN(AT_CMD_PARA *pParam)
{
    PAT_CMD_RESULT pResult;
    INT32 iRet = ERR_SUCCESS;

    if(NULL == pParam)
    {
        goto Param_ERROR;
    }
    else
    {
        if (pParam->pPara == NULL)
        {
            goto Param_ERROR;
        }

        switch (pParam->iType)
        {

            case AT_CMD_SET:
            {
                UINT8 Len ;
                UINT32 host_port;
                UINT8 host_addr[100] = {0};


                iRet = AT_Util_GetParaCount(pParam->pPara, &Len);

                if((ERR_SUCCESS != iRet)||(Len < 2))
                {
                    goto Param_ERROR;
                }

                Len = sizeof(host_addr);
                AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, host_addr, &Len);

                Len = 4;
                AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT32, &host_port, &Len);
				
	            if(IPCamera_API_Start(host_addr, host_port))
                    OK_RETURN(pResult, "IP CAM START OK", pParam->nDLCI);
                else
                    ERROR_RETURN(pResult, "IP CAM START ERROR", pParam->nDLCI);

                return;
            }
            default:
            {
                goto Param_ERROR;
            }

        }
    }

Param_ERROR:
    ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
    
    return;
}

VOID AT_IPCAM_CmdFunc_CLOSE(AT_CMD_PARA *pParam)
{
    PAT_CMD_RESULT pResult;

    if(NULL == pParam)
    {
        goto Param_ERROR;
    }
    else
    {
        if (pParam->pPara == NULL)
        {
            goto Param_ERROR;
        }

        switch (pParam->iType)
        {
            case AT_CMD_EXE:
            {
                IPCamera_API_Stop();
                OK_RETURN(pResult, "IP CAM STOPED", pParam->nDLCI);
                return;
            }
            default:
            {
                goto Param_ERROR;
            }

        }
    }

Param_ERROR:
    ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);

    return;

}

#endif /* IP_CAMERA_SUPPORT */
#if defined(__ZBAR_SUPPORT__)
VOID AT_WIFI_CmdFunc_QRDEC(AT_CMD_PARA *pParam)
{
    PAT_CMD_RESULT pResult;
    INT32 iRet = ERR_SUCCESS;

    if(NULL == pParam)
    {
        goto Param_ERROR;
    }
    else
    {
        if (pParam->pPara == NULL)
        {
            goto Param_ERROR;
        }

        switch (pParam->iType)
        {

            case AT_CMD_SET:
            {
                UINT8 Len ;
                UINT8 is_open;

                iRet = AT_Util_GetParaCount(pParam->pPara, &Len);

                if(ERR_SUCCESS != iRet)
                {
                    goto Param_ERROR;
                }

                Len = 1;
                AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &is_open, &Len);

                if(is_open)
                {
    	            if(IPCamera_API_Start_Qrdec())
                        OK_RETURN(pResult, "IP CAM START QRDEC OK", pParam->nDLCI);
                    else
                        ERROR_RETURN(pResult, "IP CAM START QRDEC ERROR", pParam->nDLCI);
                }
                else
                {
    	            if(IPCamera_API_Stop_Qrdec())
                        OK_RETURN(pResult, "IP CAM STOP QRDEC OK", pParam->nDLCI);
                    else
                        ERROR_RETURN(pResult, "IP CAM STOP QRDEC ERROR", pParam->nDLCI);
                }
                

                return;
            }
            default:
            {
                goto Param_ERROR;
            }

        }
    }

Param_ERROR:
    ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
    
    return;
}
#endif /* __ZBAR_SUPPORT__ */

#ifdef __WIFI_TEST_INDEX__
extern void rda_wifi_test_powerdown(void);
extern void rda_wifi_test_powerup(void);
extern void wifi_test_tx(const uint8 *buf, unsigned short num_to_send, unsigned short *num_send);
VOID AT_WIFI_TM_CmdFunc_Powerdown(AT_CMD_PARA* pParam)
{
#if 1

    PAT_CMD_RESULT pResult = NULL;
    UINT8 wifi_test_order[]="wifi_powerdown";

    rda_wifi_test_powerdown();
    OK_RETURN(pResult, wifi_test_order, pParam->nDLCI);

    return;
#endif
}
typedef struct
{
    unsigned short wlan_version;
    UINT32 rx_data_length;

    UINT8* wifi_test_pOffset;

} wifi_test_mode;
extern wifi_test_mode* wifitm_oppsp;

VOID AT_WIFI_TM_CmdFunc_Powerup(AT_CMD_PARA* pParam)
{
#if 1
    PAT_CMD_RESULT pResult = NULL;
    UINT8 wifi_test_order[30]= {0};

    rda_wifi_test_powerup();

    AT_Sprintf(wifi_test_order, "wifi_powerup");

    OK_RETURN(pResult, wifi_test_order, pParam->nDLCI);

    return;
#endif
}
VOID AT_WIFI_TM_CmdFunc_Tx(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;
    UINT32 nRet = ERR_SUCCESS;
    INT32 iRet = ERR_SUCCESS;
    static WIFI_TEST_MODE siOpenCmd = NO_TEST;
    char wifi_test_order[16]= {"utm 2\r\n"};
    UINT16 sent_len;
    if (pParam == NULL)
        goto iOpen_ERROR;
    else
    {
        AT_CMD_PARA* Param = pParam;

        AT_TC(g_sw_WIFI, "-------->>iClose Param->iType %d",Param->iType);

        if (Param->pPara == NULL) //
        {
            AT_TC(g_sw_WIFI, "-------->>xx");
            goto iOpen_ERROR;
        }
        switch (Param->iType)
        {
            case AT_CMD_EXE:
            {
                wifi_test_tx(wifi_test_order, strlen(wifi_test_order), &sent_len);
                OK_RETURN(pResult, wifi_test_order, pParam->nDLCI);

                return;
            }
            case AT_CMD_READ:
            {

                
                OK_RETURN(pResult, "OK", pParam->nDLCI);



                return;
            }

            default:
                goto iOpen_ERROR;
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (pResult != NULL)
        AT_Notify2ATM(pResult, pParam->nDLCI);

    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}
VOID AT_WIFI_TM_CmdFunc_Rx(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;
    UINT32 nRet = ERR_SUCCESS;
    INT32 iRet = ERR_SUCCESS;
    static WIFI_TEST_MODE siOpenCmd = NO_TEST;
    char wifi_test_order[16]= {"utm 1\r\n"};
    UINT16 sent_len;
    if (pParam == NULL)
        goto iOpen_ERROR;
    else
    {
        AT_CMD_PARA* Param = pParam;

        AT_TC(g_sw_WIFI, "-------->>iClose Param->iType %d",Param->iType);

        if (Param->pPara == NULL) //
        {
            AT_TC(g_sw_WIFI, "-------->>xx");
            goto iOpen_ERROR;
        }
        switch (Param->iType)
        {
            case AT_CMD_EXE:
            {

                UINT8 Str[] = "iOpen: NO_EXE";
                wifi_test_tx(wifi_test_order, strlen(wifi_test_order), &sent_len);
                OK_RETURN(pResult, wifi_test_order, pParam->nDLCI);

                if (pResult != NULL)
                    AT_Notify2ATM(pResult, pParam->nDLCI);

                if (pResult != NULL)
                {
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }
            case AT_CMD_READ:
            {

                UINT8 Str[] = "iOpen: NO_READ";

				OK_RETURN(pResult, "OK", pParam->nDLCI);

                if (pResult != NULL)
                    AT_Notify2ATM(pResult, pParam->nDLCI);

                if (pResult != NULL)
                {
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }

            default:
                goto iOpen_ERROR;
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (pResult != NULL)
        AT_Notify2ATM(pResult, pParam->nDLCI);

    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}
VOID AT_WIFI_TM_CmdFunc_Uttxlen(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;
    UINT32 nRet = ERR_SUCCESS;
    INT32 iRet = ERR_SUCCESS;
    static WIFI_TEST_MODE siOpenCmd = NO_TEST;
    char wifi_test_order[32]= {"uttxlen 1000\r\n"};
    UINT16 sent_len;
    if (pParam == NULL)
        goto iOpen_ERROR;
    else
    {
        AT_CMD_PARA* Param = pParam;

        AT_TC(g_sw_WIFI, "-------->>iClose Param->iType %d",Param->iType);

        if (Param->pPara == NULL) //
        {
            AT_TC(g_sw_WIFI, "-------->>xx");
            goto iOpen_ERROR;
        }
        switch (Param->iType)
        {
            case AT_CMD_EXE:
            {

                UINT8 Str[] = "iOpen: NO_EXE";
                wifi_test_tx(wifi_test_order, strlen(wifi_test_order), &sent_len);
                OK_RETURN(pResult, wifi_test_order, pParam->nDLCI);

                if (pResult != NULL)
                    AT_Notify2ATM(pResult, pParam->nDLCI);

                if (pResult != NULL)
                {
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }
            case AT_CMD_READ:
            {

                UINT8 Str[] = "iOpen: NO_READ";

				OK_RETURN(pResult, "OK", pParam->nDLCI);

                if (pResult != NULL)
                    AT_Notify2ATM(pResult, pParam->nDLCI);

                if (pResult != NULL)
                {
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }

            default:
                goto iOpen_ERROR;
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (pResult != NULL)
        AT_Notify2ATM(pResult, pParam->nDLCI);

    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}
VOID AT_WIFI_TM_CmdFunc_Setr(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;
    UINT32 nRet = ERR_SUCCESS;
    INT32 iRet = ERR_SUCCESS;
    static WIFI_TEST_MODE siOpenCmd = NO_TEST;
    char wifi_test_order[16]= {0};
    UINT16 sent_len;
    if (pParam == NULL)
        goto iOpen_ERROR;
    else
    {
        AT_CMD_PARA* Param = pParam;

        AT_TC(g_sw_WIFI, "-------->>iClose Param->iType %d",Param->iType);

        if (Param->pPara == NULL) //
        {
            AT_TC(g_sw_WIFI, "-------->>xx");
            goto iOpen_ERROR;
        }
        switch (Param->iType)
        {
            case AT_CMD_SET:
            {
                UINT8 NumOfParam = 0;
                UINT8* Num       = Param->pPara;
                UINT8 Buf[5] = {0x00,};
                UINT8 Cmd, State, Item;
                UINT8* InString = NULL;
                UINT8 i = 0,j=0;
                // Get first parameter
                i = 5;
                if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 0, Buf, &i))) // Get first parameter.
                {
                    AT_TC(g_sw_WIFI, "AT_Util_GetPara iRet Err 0x%x",iRet);
                    goto iOpen_ERROR;
                }
                I_AM_HERE();

                Cmd = AT_StrAToI(Buf);
                siOpenCmd = Cmd;
                if((Cmd<1)||((Cmd>54)))
                {
                    goto iOpen_ERROR;
                }
                AT_Sprintf(wifi_test_order, "setr %d\r\n", Cmd);
                wifi_test_tx(wifi_test_order, strlen(wifi_test_order), &sent_len);


                OK_RETURN(pResult, wifi_test_order, pParam->nDLCI);
                return;
            }
            case AT_CMD_TEST:
            {

                UINT8 Str[] = "iOpen: NO_TEST";

                OK_RETURN(pResult, Str, pParam->nDLCI);
                return;
            }
            case AT_CMD_EXE:
            {

                UINT8 Str[] = "iOpen: NO_EXE";
                OK_RETURN(pResult, Str, pParam->nDLCI);

                return;
            }
            case AT_CMD_READ:
            {
                UINT8 send_msg[100]="rda5990p";

                if (pResult != NULL)
                    AT_Notify2ATM(pResult, pParam->nDLCI);

                if (pResult != NULL)
                {
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }

            default:
                goto iOpen_ERROR;
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (pResult != NULL)
        AT_Notify2ATM(pResult, pParam->nDLCI);

    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}
VOID AT_WIFI_TM_CmdFunc_Setch(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;
    UINT32 nRet = ERR_SUCCESS;
    INT32 iRet = ERR_SUCCESS;
    static WIFI_TEST_MODE siOpenCmd = NO_TEST;
    char wifi_test_order[16]= {0};
    UINT16 sent_len;
    if (pParam == NULL)
        goto iOpen_ERROR;
    else
    {
        AT_CMD_PARA* Param = pParam;

        AT_TC(g_sw_WIFI, "-------->>iClose Param->iType %d",Param->iType);

        if (Param->pPara == NULL) //
        {
            AT_TC(g_sw_WIFI, "-------->>xx");
            goto iOpen_ERROR;
        }
        switch (Param->iType)
        {
            case AT_CMD_SET:
            {
                UINT8 NumOfParam = 0;
                UINT8* Num       = Param->pPara;
                UINT8 Buf[5] = {0x00,};
                UINT8 Cmd, State, Item;
                UINT8* InString = NULL;
                UINT8 i = 0,j=0;
                // Get first parameter
                i = 5;
                if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 0, Buf, &i))) // Get first parameter.
                {
                    AT_TC(g_sw_WIFI, "AT_Util_GetPara iRet Err 0x%x",iRet);
                    goto iOpen_ERROR;
                }
                I_AM_HERE();

                Cmd = AT_StrAToI(Buf);
                siOpenCmd = Cmd;
                if((Cmd<1)||((Cmd>14)))
                {
                    goto iOpen_ERROR;
                }
                AT_Sprintf(wifi_test_order, "setch %d\r\n", Cmd);
                wifi_test_tx(wifi_test_order, strlen(wifi_test_order), &sent_len);

                OK_RETURN(pResult, wifi_test_order, pParam->nDLCI);

                return;
            }
            case AT_CMD_TEST:
            {

                UINT8 Str[] = "iOpen: NO_TEST";

                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

                if (pResult != NULL)
                    AT_Notify2ATM(pResult, pParam->nDLCI);

                if (pResult != NULL)
                {
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }
            case AT_CMD_EXE:
            {

                UINT8 Str[] = "iOpen: NO_EXE";

                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

                if (pResult != NULL)
                    AT_Notify2ATM(pResult, pParam->nDLCI);

                if (pResult != NULL)
                {
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }
            case AT_CMD_READ:
            {

                UINT8 Str[] = "iOpen: NO_READ";

                pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
                                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

                if (pResult != NULL)
                    AT_Notify2ATM(pResult, pParam->nDLCI);

                if (pResult != NULL)
                {
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }

            default:
                goto iOpen_ERROR;
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (pResult != NULL)
        AT_Notify2ATM(pResult, pParam->nDLCI);

    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}
VOID AT_WIFI_TM_CmdFunc_Rfregw(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;
    UINT32 nRet = ERR_SUCCESS;
    INT32 iRet = ERR_SUCCESS;
    static WIFI_TEST_MODE siOpenCmd = NO_TEST;
    //char wifi_test_order[32]={"rfregw 23 03ff\r\n"};
    char wifi_test_order[32]= {0};
    UINT16 sent_len;
    hal_HstSendEvent(0xffff9999);
    if (pParam == NULL)
    {
        hal_HstSendEvent(0xffffaaaa);
        goto iOpen_ERROR;
    }
    else
    {
        AT_CMD_PARA* Param = pParam;

        AT_TC(g_sw_WIFI, "-------->>iClose Param->iType %d",Param->iType);

        if (Param->pPara == NULL) //
        {
            hal_HstSendEvent(0xffffbbbb);
            AT_TC(g_sw_WIFI, "-------->>xx");
            goto iOpen_ERROR;
        }
        hal_HstSendEvent(0xffffcccc);
        hal_HstSendEvent(Param->iType);
        switch (Param->iType)
        {
            case AT_CMD_SET:
            {

                UINT8 NumOfParam = 0;
                UINT8* Num       = Param->pPara;
                UINT8 Buf[8] = {0x00,};
                UINT8 Cmd, State, Item;
                UINT8* InString = NULL;
                UINT8 i = 0,j=0;
                // Get first parameter
                i = 8;
                hal_HstSendEvent(0xffffffff);
                if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 0, Buf, &i))) // Get first parameter.
                {
                    AT_TC(g_sw_WIFI, "AT_Util_GetPara iRet Err 0x%x",iRet);
                    hal_HstSendEvent(0xffffeeee);
                    goto iOpen_ERROR;
                }
                I_AM_HERE();
                hal_HstSendEvent(0xffffdddd);
                AT_Sprintf(wifi_test_order,"rfregw 23 %s\r\n", Buf);//rfregw 23 0bff

                wifi_test_tx(wifi_test_order, strlen(wifi_test_order), &sent_len);


                OK_RETURN(pResult, wifi_test_order, pParam->nDLCI);
                return;
            }
            case AT_CMD_READ:
            {

                UINT8 Str[] = "iOpen: NO_READ";

				OK_RETURN(pResult, "OK", pParam->nDLCI);

                if (pResult != NULL)
                    AT_Notify2ATM(pResult, pParam->nDLCI);

                if (pResult != NULL)
                {
                    AT_FREE(pResult);
                    pResult = NULL;
                }

                return;
            }

            default:
                goto iOpen_ERROR;
        }
    }

iOpen_ERROR:

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
                          CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

    if (pResult != NULL)
        AT_Notify2ATM(pResult, pParam->nDLCI);

    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}
#endif
#endif
