// //////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002-2012, Coolsand Technologies, Inc.
// All Rights Reserved
//
// This source code is property of Coolsand. The information contained in this
// file is confidential. Distribution, reproduction, as well as exploitation,
// or transmission of any content of this file is not allowed except if
// expressly permitted.Infringements result in damage claims!
//
// FILENAME: at_cmd_apps.c
//
// DESCRIPTION: Application related AT commands
// TODO: ...
//
// REVISION HISTORY:
// NAME              DATE                REMAKS
// Lixp      2013-07-31       Created initial version 1.0
//
// //////////////////////////////////////////////////////////////////////////////


#ifdef __NGUX_PLATFORM__

#include "at_common.h"
#include "at_sa.h"
#include "at_module.h"
#include "at_cmd_apps.h"
#include "at_cmd_gc.h"
#include "at_cfg.h"
#include "csw.h"
#include "nvram_user_defs.h"
#include "custom_mmi_default_value.h"

#define CONTENT_SIZE 128
#define MAX_CALENDAR_EVENT_NUMBER 10

// AT+SSHR
VOID AT_DFMS_SSHR(AT_CMD_PARA *pParam)
{

	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	UINT8 *readResultContent;
	UINT8 contentLength  = 0;
	char buffer[CONTENT_SIZE] = {0};
	UINT8 StartLimitYear = 0, EndLimitYear = 0, maxEntries = 0, maxSubjectLength = 0, count = 0;

	UINT8 *pRsp = NULL;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SSHR, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}
	else
	{
		/**************apeksha.b****************/
		if(uParaCount == 0) //read-all case
		{
			maxEntries = MAX_CALENDAR_EVENT_NUMBER;
			maxSubjectLength = CONTENT_SIZE;
			StartLimitYear = 2000;
			EndLimitYear = 2127;
			count = ATGetCalendarCount();
			UINT8 *pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+SSHR: %d,%d,%d,%d,%d\n OK", maxEntries, maxSubjectLength, StartLimitYear, EndLimitYear, count );
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
		}
		else if(uParaCount == 1)
		{
			uIndex  = 0;
			uSize  = SIZEOF(param1);
			iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
			if (iResult != ERR_SUCCESS)
			{
				AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SSHR, get parameter error1\n");
				AT_DFMS_Result_NA();
				return;
			}

			readResultContent = ATGetSelectedIndexContent(param1);
			contentLength = strlen(readResultContent);
			sprintf(buffer, "%d,%s", contentLength, readResultContent);

			pRsp = AT_MALLOC(100);
			AT_Sprintf(pRsp, "+SSHR:%d, %s\n OK", param1, buffer);
			AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
			AT_FREE(pRsp);
			/**************apeksha.b****************/
		}
	}
}

// AT+SSHW
VOID AT_DFMS_SSHW(AT_CMD_PARA *pParam)
{

	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;

	UINT8 *pRsp = NULL;
	char resultCodeWrite[10] = "NOT OK";
	UINT8 content[CONTENT_SIZE] = { 0 };
	int isSaved = 0, indexNumber = -1;
	UINT8 strContent[CONTENT_SIZE] = { 0 };
	UINT8 *token = NULL;
	char s = ',';

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount > 2))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SSHW, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex  = 0;
	uSize  = SIZEOF(content);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_STRING, &content, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SSHW, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}
	uIndex++;
	uSize   = SIZEOF(indexNumber);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &indexNumber, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_RSTVERIF, get parameter error2\n");
		AT_DFMS_Result_NA();
		return;
	}

	token = strtok(content, s);//content consists of =��<SubjectLen>,<Subject>��
	/* walk through other tokens */
	while( token != NULL )
	{
		strcpy(strContent, token); 		//value of subject field
		token = strtok(NULL, s);
	}

	isSaved = ATSaveAtIndex(&strContent, indexNumber);
	if(isSaved == 1)
		strcpy(resultCodeWrite, "OK");
	pRsp = AT_MALLOC(100);
	AT_Sprintf(pRsp, "+SSHW:%s", resultCodeWrite);
	AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	AT_FREE(pRsp);
}


// AT+SSHD
VOID AT_DFMS_SSHD(AT_CMD_PARA *pParam)
{

	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;
	int result = 0;

	UINT8 *pRsp = NULL;
	char resultCodeDelete[10] = "NOT OK" ;

	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if ((iResult != ERR_SUCCESS) || (uParaCount != 1))
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SSHD, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	uIndex  = 0;
	uSize  = SIZEOF(param1);
	iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SSHD, get parameter error1\n");
		AT_DFMS_Result_NA();
		return;
	}

	result = ATDeleteSelectedIndexContent(param1);
	if(result == 1)
		strcpy(resultCodeDelete, "OK");
	pRsp = AT_MALLOC(100);
	AT_Sprintf(pRsp, "+SSHD:%s", resultCodeDelete);
	AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	AT_FREE(pRsp);
}

// AT+SSHT
VOID AT_DFMS_SSHT(AT_CMD_PARA *pParam)
{

	INT32 iResult                        = 0;
	UINT8 uParaCount                     = 0;
	UINT8 uIndex                         = 0;
	UINT8 uSize                         = 0;
	UINT8 param1  = 0;
	UINT8 param2  = 0;

	UINT8 *pRsp = NULL;
	int eventCount = 0;
	iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
	if (iResult != ERR_SUCCESS || uParaCount != 0)
	{
		AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SSHT, parameter error\n");
		AT_DFMS_Result_NA();
		return;
	}

	eventCount = ATGetCalendarCount();
	pRsp = AT_MALLOC(100);
	AT_Sprintf(pRsp, "+SSHT:%d", eventCount);
	AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	AT_FREE(pRsp);

}

VOID AT_DFMS_SPLC(AT_CMD_PARA *pParam)
{
	INT32 iResult = 0;
	UINT8 pRsp[50] = {0,};
	UINT8 uParaCount = 0;
	UINT8 password[11] = {0,};//pass size is SETTINGS_PASSWORD
	UINT32 pw_len = 0;
	UINT16 error = 0;
	INT32 lockState = 1;

	if (pParam->iType == AT_CMD_READ)
	{
		lockState = ReadByteValue(NVRAM_SETTINGS_PRIVACY_LOCK_CALL_LOG) &&
		            ReadByteValue(NVRAM_SETTINGS_PRIVACY_LOCK_CONTACTS) &&
		            ReadByteValue(NVRAM_SETTINGS_PRIVACY_LOCK_CALENDAR) &&
		            ReadByteValue(NVRAM_SETTINGS_PRIVACY_LOCK_MESSAGE) &&
		            ReadByteValue(NVRAM_SETTINGS_PRIVACY_LOCK_MEMO);

		sprintf((char *)pRsp, "+SPLC: %d", lockState == 0 ? 1 : 0);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
		return;
	}
	else if (pParam->iType == AT_CMD_SET)
	{
		iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
		if (iResult != ERR_SUCCESS || uParaCount != 1)
		{
			AT_TC(g_sw_DFMS, "SPLC get ParaCount err");
			AT_DFMS_Result_NA();
			return;
		}

		pw_len = sizeof(password);
		iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, password, &pw_len);
		if (iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_DFMS, "SPLC get password err");
			AT_DFMS_Result_NA();
			return;
		}

		WriteRecordInt(NVRAM_SETTINGS_PASSWORD, 0, password, sizeof(password), &error, __FILE__, __LINE__);
		AT_DFMS_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pRsp, AT_StrLen(pRsp));
	}
	else
	{
		AT_DFMS_Result_NA();
		return;
	}

}
#endif
