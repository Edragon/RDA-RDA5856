/******************************************************************************************
	Copyright (C), 2002-2010, Coolsand. Co., Ltd.
	File name     : at_cmd_gc.c
	Author        : wangqunyang
	Version       : 2.0
	Date          : 2008.03.20
	Description   : This file implements AT General Command functions
	Others        :
	History       :

   1.        Date : unkown
           Author : unkown
      Description : build this file
          Version : V1.0

   2.        Date : 2007.10.18
           Author : wangqunyang
      Description : modify some code and added comment
          Version : V2.0

*******************************************************************************************/

#include "at_common.h"
#include "at_uart.h"
#include "at_module.h"
#include "at_cmd_gc.h"
#include "at_cfg.h"
#include "csw.h"
#include "dm_audio.h"
#include "pal_gsm.h"
#include "l1s.h"

#define ERR_CFW_REPEAT_TRANSFER         0x10000011

// #define CFG_FILE_NAME "at_user_cfg.bin"

UINT8 g_pCeer[64] = { 0 };

UINT8 g_gc_pwroff = 0;  // hameina[+]for smso&cfun, moved to top of the file
UINT8 g_cfg_cfun[2]  = {0, 0}; // switch on/off; 5:current status is on

#define BIT_SET(uint8_num, bit_seq) (  ((uint8_num)&(1<<(bit_seq))) ? (bit_seq) : 0 )
#define TIM_ALARM_INDEX_MAX 15

extern UINT32 CFW_CfgNumRangeCheck(UINT32 nInput, UINT8 *pString);
extern BOOL AT_CIND_GetBattery(UINT8 *pBattchg);
extern BOOL AT_CIND_GetCC(BOOL *pCall, BOOL *pSounder);

#ifdef AT_DUAL_SIM
extern BOOL AT_CIND_SMS(UINT8 *pNewMsg, UINT8 *pMemFull, UINT8 nSim);
extern BOOL AT_CIND_NetWork(UINT8 *pSignalQ, UINT8 *pRegistS, UINT8 *pRoamS, UINT8 nDLCI, UINT8 nSim);
#else
extern BOOL AT_CIND_SMS(UINT8 *pNewMsg, UINT8 *pMemFull);
extern BOOL AT_CIND_NetWork(UINT8 *pSignalQ, UINT8 *pRegistS, UINT8 *pRoamS, UINT8 nDLCI);
#endif

// [+]2007.11.12 for AT^CDTMF
extern BOOL CSW_ATCcIsDTMF(INT8 iTone);

// extern UINT8 g_cc_VTD;
extern VOID AT_Audio_Init(VOID);  // added by yangtt at 2008-5-21 for bug 8506
extern VOID CFW_EmodSaveIMEI(UINT8 *pImei, UINT8 imeiLen, UINT8 nSimID);

VOID AT_GC_CPOF_CFUN_IND(CFW_EVENT *cfwEvent);

// extern INT32 fat_OEM2Unicode(UINT8* pszOEM, UINT16 iOLen, UINT8* pszUnicode, UINT16* piULen);

BOOL AT_GC_Init(VOID)
{
	AT_Audio_Init();  // added by yangtt at 2008-5-21 for bug 8506
	return TRUE;
}

UINT32 AT_GC_CfgGetResultCodePresentMode(UINT8 *pMode)
{
	if (pMode == NULL)
	{
		return ERR_AT_CME_PARAM_INVALID;
	}

	// *pMode = gAtCurrentSetting.g_eResultcodePresentation;
	*pMode = gATCurrenteResultcodePresentation;

	return ERR_SUCCESS;
}

UINT32 AT_GC_CfgGetResultCodeFormatMode(UINT8 *pMode)
{
	if (pMode == NULL)
	{
		return ERR_AT_CME_PARAM_INVALID;
	}

	// *pMode = g_eResultcodeFormat;

	// ZXB: [+]We have a bug on init CFG, here it's just a patch for a correct command V setting.
	if (gATCurrenteResultcodeFormat != 0 && gATCurrenteResultcodeFormat != 1)
		gATCurrenteResultcodeFormat = 1;

	// <<

	*pMode = gATCurrenteResultcodeFormat;

	return ERR_SUCCESS;
}

UINT32 AT_GC_CfgGetEchoMode(UINT8 *pMode)
{
	if (pMode == NULL)
	{
		return ERR_AT_CME_PARAM_INVALID;
	}

	// *pMode = g_eCommandEchoMode;
	*pMode = gATCurrenteCommandEchoMode;

	return ERR_SUCCESS;
}

UINT8 AT_GC_CfgGetS0Value(VOID)
{
	return gATCurrentcc_s0;
}

UINT8 AT_GC_CfgGetS3Value(VOID)
{

	// *pValue = gATCurrentnS3;
	return gATCurrentnS3;
}

UINT8 AT_GC_CfgGetS4Value(VOID)
{
	return gATCurrentnS4;
}

UINT8 AT_GC_CfgGetS5Value(VOID)
{
	return gATCurrentnS5;
}

/*
UINT32  AT_GC_CfgSetResultCodePresentMode(UINT8 nMode)
{
	if ((nMode != GC_RESULTCODE_PRESENTATION_ENABLE)
	     && (nMode != GC_RESULTCODE_PRESENTATION_DISABLE))
	{
		return ERR_AT_CME_PARAM_INVALID;
	}

	g_eResultcodePresentation = nMode;
	return ERR_SUCCESS;
}

UINT32  AT_GC_CfgSetResultCodeFormatMode( UINT8 nMode )
{
	if ((nMode != GC_RESULTCODE_FORMAT_VERBOSE)
	     && (nMode != GC_RESULTCODE_FORMAT_LIMITED))
	{
		return ERR_AT_CME_PARAM_INVALID;
	}

	g_eResultcodeFormat = nMode;
	return ERR_SUCCESS;
}

UINT32  AT_GC_CfgSetEchoMode( UINT8 nMode )
{
	if ((nMode != GC_COMMANDECHO_MODE_ENABLE)
	     && (nMode != GC_COMMANDECHO_MODE_DISABLE))
	{
		return ERR_AT_CME_PARAM_INVALID;
	}

	g_eCommandEchoMode = nMode;
	return ERR_SUCCESS;
}
*/

VOID AT_GC_AsyncEventProcess(COS_EVENT *pEvent)
{
	CFW_EVENT cfwEvent;

#ifdef AT_DUAL_SIM
	UINT8 nSim;
#endif
	AT_CosEvent2CfwEvent(pEvent, &cfwEvent);
	AT_TC(g_sw_GC, "AT_GC_AsyncEventProcess, EV_ID=0X%x, EV_TIM_ALRAM_IND=0x%x\n", cfwEvent.nEventId, EV_TIM_ALRAM_IND);
#ifdef AT_DUAL_SIM
	nSim = cfwEvent.nFlag;
#endif
	switch (cfwEvent.nEventId)
	{

	case EV_CFW_EXIT_IND:
	{
		// AT_GC_CPOF_CFUN_IND(&cfwEvent);
		break;
	}

	case EV_TIM_ALRAM_IND: // alarm IND
	{
		UINT8 OutStr[20];

		memset(OutStr, 0, 20);
		AT_TC(g_sw_GC, "AT_GC_AsyncEventProcess, 2, param1=0X%x, param2=0x%x, param3=0x%x\n",
		      pEvent->nParam1, pEvent->nParam2, pEvent->nParam3);
		AT_Sprintf(OutStr, "+CALV: %u", pEvent->nParam3 >> 16);
#ifdef AT_DUAL_SIM
		AT_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, OutStr, AT_StrLen(OutStr), cfwEvent.nUTI, nSim);
#else
		AT_Result_OK(CSW_IND_NOTIFICATION, CMD_RC_CR, 0, OutStr, AT_StrLen(OutStr), cfwEvent.nUTI);
#endif
	}

	default:
		break;

	}

	return;
}

UINT32 AT_CfgGetErrorReport(UINT8 *pLevel)
{
	// *pLevel = g_uCmee;
	*pLevel = gATCurrentuCmee;
	return (ERR_SUCCESS);
}

VOID AT_GC_CmdFunc_CMEE(AT_CMD_PARA *pParam)
{
	INT32 eResult;
	UINT8 atl_para;
	UINT8 iCount = 0;
	UINT8 len    = 0;
	UINT8 send_msg[10];

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}
	else
	{
		switch (pParam->iType)
		{

		case AT_CMD_SET:
			eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);

			if (eResult == ERR_SUCCESS)
			{
				if (iCount > 1)
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				}

				// [[hameina[+] 2007.12.21  for bug 7263
				else if (!iCount)
				{
#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif

				}

				// ]]hameina[+] 2007.12.21  for bug 7263
				else
				{
					len     = 1;
					eResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, (PVOID)(&atl_para), &len);

					if (ERR_SUCCESS != eResult || (atl_para > 2))
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					}
					else
					{
						// err_code = CFW_CfgSetErrorReport((UINT8)atl_para);

						// g_uCmee = atl_para;
						gATCurrentuCmee = atl_para;

#ifdef AT_DUAL_SIM
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
					}
				}
			}
			else
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			}

			break;

		case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, "+CMEE: (0-2)", AT_StrLen("+CMEE: (0-2)"), pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, "+CMEE: (0-2)", AT_StrLen("+CMEE: (0-2)"), pParam->nDLCI);
#endif
			break;

		case AT_CMD_READ:

			// err_code = CFW_CfgGetErrorReport(&cfw_para);
			// atl_para = g_uCmee;
			atl_para = gATCurrentuCmee;
			AT_Sprintf(send_msg, "+CMEE: %u", atl_para);
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, send_msg, AT_StrLen(send_msg), pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, send_msg, AT_StrLen(send_msg), pParam->nDLCI);
#endif
			break;

		default:
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			break;
		}
	}

	return;
}

VOID AT_Cond_ResumeIrqCmd()
{

    pal_SetUsrVector (PAL_FINT_IRQ, (void (*)(u32))l1s_FrameInterrupt);
    pal_SetUsrVector (PAL_DSP_IRQ, (void (*)(u32))l1s_DspIrq);
    pal_SetUsrVectorMsk (PAL_DSP_IRQ, PAL_PCH_READY | PAL_EQUALIZATION_COMPLETE | PAL_USF_READY);

}
/*************************************************************
//AT+SETOOKMODE=1 : param1 OOKmode.
//AT+SETOOKMODE=0 : close OOKmode.
 *************************************************************/
VOID AT_GC_SETOOKMODE(AT_CMD_PARA* pParam)
{
    INT32 iResult                        = 0;
    UINT8 uParaCount                     = 0;
    UINT8 uIndex                         = 0;
    UINT8 uSize                         = 0;
    UINT8 param1  = 0;
    UINT8 param2  = 0;
    UINT8 param3  = 0;
    UINT8 param4  = 0;
    UINT8 *pRsp = NULL;
    int16 maxpower = 0;
		extern VOID rfd_XcvSetXcvMode(bool chorfremod);  // 0 channel mode , 1 frequency mode
		extern VOID rfd_XcvSetOokPower(char power);  // 4 power level
		extern VOID rfd_XcvSetOokChannel(INT16 channel);  // [0-163] max channel is 163
		extern VOID rfd_XcvSetOokData(bool Ookdata);  //Ookdata
		extern VOID rfd_XcvSetXcvTestMode(bool testmod);  // 1 testmode, 0 normal mode
#ifdef AT_DUAL_SIM
    UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
    iResult = AT_Util_GetParaCount(pParam->pPara, &uParaCount);
    if ((iResult != ERR_SUCCESS) || (uParaCount !=1))
    {
        AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SETOOKMODE, parameter error\n");
#ifdef AT_DUAL_SIM
        AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    uIndex  = 0;
    uSize  = SIZEOF(param1);
    iResult = AT_Util_GetParaWithRule(pParam->pPara, uIndex, AT_UTIL_PARA_TYPE_UINT8, &param1, &uSize);
    if (iResult != ERR_SUCCESS)
    {
        AT_TC(g_sw_DFMS, "exe       in AT_DFMS_SETOOKMODE, get parameter error1\n");
#ifdef AT_DUAL_SIM
        AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
        AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
        return;
    }

    uIndex++;


    CFW_NwStopStack(0);
#ifdef AT_DUAL_SIM
    CFW_NwStopStack(1);
#endif
    COS_Sleep(3000);
// ��?3��at��?�̡¨�?��?��?
    if(param1)
    { 

			{
					rfd_XcvSetXcvTestMode(1);
					rfd_XcvSetXcvMode(1);
					rfd_XcvSetOokPower(0);
					rfd_XcvSetOokChannel(1);
					
			}
			{
			   for(int numook = 0; numook < 100; numook++)
			   {
			   				rfd_XcvSetOokData(numook%2);
			   				//sleep 125 us
			   }
			   
			}
 
    }
    else
    {

        AT_Cond_ResumeIrqCmd();

        extern PUBLIC UINT32 CFW_StackInit(
#ifdef CFW_MULTI_SIM
                CFW_SIM_ID nSimID
#endif
                );
        CFW_StackInit(0);
#ifdef AT_DUAL_SIM
        CFW_StackInit(1);
#endif
        rfd_XcvSetXcvTestMode(0);
					rfd_XcvSetXcvMode(0);
					rfd_XcvSetOokPower(0);

    }

}
VOID AT_GC_CmdFunc_CEER(AT_CMD_PARA *pParam)
{
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}
	else
	{
		switch (pParam->iType)
		{

		case AT_CMD_EXE:

			if (AT_StrLen(g_pCeer))
			{
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, g_pCeer, AT_StrLen(g_pCeer), pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, g_pCeer, AT_StrLen(g_pCeer), pParam->nDLCI);
#endif
			}
			else
			{
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, "+CEER: 255", AT_StrLen("+CEER: 255"), pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, "+CEER: 255", AT_StrLen("+CEER: 255"), pParam->nDLCI);
#endif
			}

			break;

		case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
			break;

		default:
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			break;
		}
	}

	return;
}

VOID AT_GC_CmdFunc_CMER(AT_CMD_PARA *pParam)
{
	INT32 eResult;
	UINT8 uMode  = 0xff, uKey = 0xff, uDisp = 0xff, uInd = 0xff; // , ubf=0xff
	UINT8 iCount = 0;
	UINT8 uLen   = 0;

	// UINT8 send_msg[10];
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}
	else
	{
		switch (pParam->iType)
		{

		case AT_CMD_SET:
		{
			eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);

			if (eResult != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}

			if (!iCount)  // no parameter, just return ok
			{
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
				return;
			}

			// get first param
			uLen = 1;

			eResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uMode, &uLen);

			if (eResult != ERR_SUCCESS && eResult != ERR_AT_UTIL_CMD_PARA_NULL)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}

			if (eResult == ERR_SUCCESS && uMode != 3)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}

			// second param
			uLen = 1;

			eResult = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &uKey, &uLen);

			if (eResult != ERR_SUCCESS && eResult != ERR_AT_UTIL_CMD_PARA_NULL)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}

			if (eResult == ERR_SUCCESS && uKey != 0)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}

			// third param
			uLen = 1;

			eResult = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_UINT8, &uDisp, &uLen);

			if (eResult != ERR_SUCCESS && eResult != ERR_AT_UTIL_CMD_PARA_NULL)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}

			if (eResult == ERR_SUCCESS && uDisp != 0)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}

			// fourth param
			uLen = 1;

			eResult = AT_Util_GetParaWithRule(pParam->pPara, 3, AT_UTIL_PARA_TYPE_UINT8, &uInd, &uLen);

			if (eResult != ERR_SUCCESS) // && eResult != ERR_AT_UTIL_CMD_PARA_NULL
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}

			if (uInd != 2 && uInd != 0)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}
			else
			{
				AT_TC(g_sw_SA, TSTXT("CMER We set gATCurrentuCmer_ind nSim[%d] to %x\n"), nSim, uInd);

				// g_uCmer_ind = uInd;
				gATCurrentuCmer_ind[nSim] = uInd;
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
				return;
			}
		}

		case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, "+CMER: (3),(0),(0),(0,2)", AT_StrLen("+CMER: (3),(0),(0),(0,2)"),
			             pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, "+CMER: (3),(0),(0),(0,2)", AT_StrLen("+CMER: (3),(0),(0),(0,2)"),
			             pParam->nDLCI);
#endif
			break;

		case AT_CMD_READ:
		{
			UINT8 uOutStr[24] = { 0, };

			// +CMER: <mode>,<keyp>,<disp>,<ind>,<bfr>
			AT_Sprintf(uOutStr, "+CMER: 3,0,0,%u", gATCurrentuCmer_ind[nSim]);  // added by yangtt at 2008-5-12
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutStr, AT_StrLen(uOutStr), pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, uOutStr, AT_StrLen(uOutStr), pParam->nDLCI);
#endif
			break;
		}

		default:
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			break;
		}
	}

	return;
}
BOOL CFW_CheckPowerCommStatus(CFW_SIM_ID nSimID);

VOID AT_GC_CmdFunc_CFUN(AT_CMD_PARA *pParam)
{
	INT32 eResult;
	UINT8 iCount    = 0;
	UINT8 fun       = 0, rst = 0;
	//UINT32 err_code = ERR_SUCCESS;
	UINT8 len       = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	UINT8 nFM = 0;

	//hal_HstSendEvent(0xfc000010);

	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{

	case AT_CMD_SET:
	{
		eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);

		if(TRUE == CFW_CheckPowerCommStatus(nSim))
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}
		if (eResult == ERR_SUCCESS)
		{
			if (iCount > 2)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}
			else if (!iCount)
			{
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
				return;
			}

			// get first param <fun>
			len = 1;

			eResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &fun, &len);

			if (eResult == ERR_SUCCESS)
			{
				if (fun != 0 && fun != 1 && fun != 4 && fun != 5 && fun != 6 && fun != 7)
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}

				if(fun == 5 || fun == 6 || fun == 7) //to adapt android ,WCDMA- PREFER(7),GSM(5),WCDMA-ONLY(6)
				{
#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, pParam->nDLCI, 0);
#endif
					return;
				}
			}
			else if (eResult != ERR_AT_UTIL_CMD_PARA_NULL)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}

			// get second param <rst>
			if (iCount > 1)
			{
				len     = 1;
				eResult = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &rst, &len);

				if (eResult != ERR_SUCCESS || rst)
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}
			}

			switch (fun)
			{
				//modify by frank for android
#if 0
			case 0:
				g_cfg_cfun = 0;
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, pParam->nDLCI, 0);
#endif
				break;
#endif
			case 1:

				if (ERR_SUCCESS != CFW_GetComm((CFW_COMM_MODE *)&nFM, nSim))
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}
				g_cfg_cfun[nSim] = fun;

				if (CFW_ENABLE_COMM == nFM)
				{
#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
				}
				else
				{
					CFW_SetComm(CFW_ENABLE_COMM, 0, pParam->nDLCI, nSim);
#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
				}
				break;

			case 0:
			case 4:

#ifdef AT_DUAL_SIM
				CFW_GprsAtt(0, pParam->nDLCI, nSim);
#else
				CFW_GprsAtt(0, pParam->nDLCI);
#endif
				if (ERR_SUCCESS != CFW_GetComm((CFW_COMM_MODE *)&nFM, nSim))
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}
				g_cfg_cfun[nSim]  = fun;

				if (CFW_DISABLE_COMM == nFM)

				{
#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
				}
				else
				{
					CFW_SetComm(CFW_DISABLE_COMM, 0, (UINT16)pParam->nDLCI, nSim);
#ifdef CHIP_HAS_AP

#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 90, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 90, 0, 0, pParam->nDLCI);
#endif

#else
#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
#endif
				}
				break;

			default:
				break;
			}
#if 0
			// [[hameina[mod] 2007.12.06 for bug 7154, move from above to here
			if (fun == 5) // switch on CSW
			{
				err_code = CFW_ShellControl(CFW_CONTROL_CMD_POWER_ON);

				if (ERR_SUCCESS == err_code)
				{
					g_gc_pwroff = 2;
#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
					return;
				}
				else if (ERR_CFW_REPEAT_TRANSFER == err_code)
				{
#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
					return;
				}
				else
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}
			}
			else if (fun == 6)  // switch off csw
			{
				if (g_cfg_cfun == 6)  // added by yangtt at 2008-6-16 for bug 8739
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					AT_TC(g_sw_GC, " csw already switch off ");
					return;

				}
				err_code = CFW_ShellControl(CFW_CONTROL_CMD_POWER_OFF);

				if (ERR_SUCCESS == err_code)
				{
					g_gc_pwroff = 2;
#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
					return;
				}
				else
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}
			}
#ifdef DEBUG_AT
			else if (fun == 1 || fun == 2)  // + wulc 2012.02.18 return ok for Android Simulator initialization
			{
#    ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#    else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#    endif
				return;
			}
#endif
			// ]]hameina[mod] 2007.12.06 for bug 7154, move from above to here
#endif

		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		break;
	}

	case AT_CMD_TEST:
	{
		// [[hameina[mod] 2007.12.06 for bug 7154
		// AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, "+CFUN: (5,6),(0-1)", AT_StrLen("+CFUN: (5,6),(0-1)"), pParam->nDLCI);
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, "+CFUN: (0,1,4,5,6,7)", AT_StrLen("+CFUN: (0,1,4,5,6,7)"), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, "+CFUN: (0,1,4,5,6,7)", AT_StrLen("+CFUN: (0,1,4,5,6,7)"), pParam->nDLCI);
#endif

		// ]]hameina[mod] 2007.12.06 for bug 7154
		return;
	}

	case AT_CMD_READ:
	{
		UINT8 OutStr[12];
		if (ERR_SUCCESS != CFW_GetComm((CFW_COMM_MODE *)&nFM, nSim))
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		// err_code = CFW_CfgGetPhoneFunctionality(&cfw_para[0]);
		AT_Sprintf(OutStr, "+CFUN: %u", nFM );
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, OutStr, AT_StrLen(OutStr), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, OutStr, AT_StrLen(OutStr), pParam->nDLCI);
#endif
		return;
	}

	default:
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}
	}
}

VOID AT_GC_CmdFunc_CSCS(AT_CMD_PARA *pParam)
{
	UINT8 arrRes[40];
	INT32 iRet      = ERR_SUCCESS;
	UINT8 paraCount = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	if (pParam->iType == AT_CMD_TEST)
	{
		AT_MemZero(arrRes, sizeof(arrRes));
		AT_StrCpy(arrRes, "+CSCS: (\"GSM\",\"HEX\",\"PCCP936\",\"UCS2\")");
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), pParam->nDLCI);
#endif
		return;
	}
	else if (pParam->iType == AT_CMD_SET)
	{
		iRet = AT_Util_GetParaCount(pParam->pPara, &paraCount);

		if (iRet != ERR_SUCCESS || paraCount > 1)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		if (paraCount == 0)
		{
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
			return;
		}

		UINT8 arrCharacterSet[15] = { 0 };
		UINT8 nParamLen           = sizeof(arrCharacterSet);

		AT_MemZero(arrCharacterSet, sizeof(arrCharacterSet));
		iRet = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, arrCharacterSet, &nParamLen);

		if (iRet != ERR_SUCCESS)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		AT_StrUpr(arrCharacterSet);

		if (AT_StrCmp(arrCharacterSet, "GSM") == 0)
			cfg_SetTeChset(cs_gsm);
		else if (AT_StrCmp(arrCharacterSet, "HEX") == 0)
			cfg_SetTeChset(cs_hex);
		else if (AT_StrCmp(arrCharacterSet, "PCCP936") == 0)
			cfg_SetTeChset(cs_gbk);
		else if (AT_StrCmp(arrCharacterSet, "UCS2") == 0)
			cfg_SetTeChset(cs_ucs2);
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif

		return;
	}
	else if (pParam->iType == AT_CMD_READ)
	{
		AT_MemZero(arrRes, sizeof(arrRes));

		if (cfg_GetTeChset() == cs_ucs2)
			AT_StrCpy(arrRes, "+CSCS: \"UCS2\"");
		else if (cfg_GetTeChset() == cs_hex)
			AT_StrCpy(arrRes, "+CSCS: \"HEX\"");
		else if (cfg_GetTeChset() == cs_gbk)
			AT_StrCpy(arrRes, "+CSCS: \"PCCP936\"");
		else if (cfg_GetTeChset() == cs_gsm)
			AT_StrCpy(arrRes, "+CSCS: \"GSM\"");
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), pParam->nDLCI);
#endif

		return;
	}
	else
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_EXE_NOT_SURPORT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}
}

// to check the time format yangtt at 08-4-22 begin
#define _U	0x01  // upper
#define _L	0x02  // lower
#define _D	0x04  // digit
#define _C	0x08  // cntrl
#define _P	0x10  // punct
#define _S	0x20  // white space (space/lf/tab)
#define _X	0x40  // hex digit
#define _SP	0x80  // hard space (0x20)

const unsigned char at_ctype[] =
{
	_C, _C, _C, _C, _C, _C, _C, _C, /* 0-7 */
	_C, _C | _S, _C | _S, _C | _S, _C | _S, _C | _S, _C, _C,  /* 8-15 */
	_C, _C, _C, _C, _C, _C, _C, _C, /* 16-23 */
	_C, _C, _C, _C, _C, _C, _C, _C, /* 24-31 */
	_S | _SP, _P, _P, _P, _P, _P, _P, _P, /* 32-39 */
	_P, _P, _P, _P, _P, _P, _P, _P, /* 40-47 */
	_D, _D, _D, _D, _D, _D, _D, _D, /* 48-55 */
	_D, _D, _P, _P, _P, _P, _P, _P, /* 56-63 */
	_P, _U | _X, _U | _X, _U | _X, _U | _X, _U | _X, _U | _X, _U, /* 64-71 */
	_U, _U, _U, _U, _U, _U, _U, _U, /* 72-79 */
	_U, _U, _U, _U, _U, _U, _U, _U, /* 80-87 */
	_U, _U, _U, _P, _P, _P, _P, _P, /* 88-95 */
	_P, _L | _X, _L | _X, _L | _X, _L | _X, _L | _X, _L | _X, _L, /* 96-103 */
	_L, _L, _L, _L, _L, _L, _L, _L, /* 104-111 */
	_L, _L, _L, _L, _L, _L, _L, _L, /* 112-119 */
	_L, _L, _L, _P, _P, _P, _P, _C, /* 120-127 */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 128-143 */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 144-159 */
	_S | _SP, _P, _P, _P, _P, _P, _P, _P, _P, _P, _P, _P, _P, _P, _P, _P, /* 160-175 */
	_P, _P, _P, _P, _P, _P, _P, _P, _P, _P, _P, _P, _P, _P, _P, _P, /* 176-191 */
	_U, _U, _U, _U, _U, _U, _U, _U, _U, _U, _U, _U, _U, _U, _U, _U, /* 192-207 */
	_U, _U, _U, _U, _U, _U, _U, _P, _U, _U, _U, _U, _U, _U, _U, _L, /* 208-223 */
	_L, _L, _L, _L, _L, _L, _L, _L, _L, _L, _L, _L, _L, _L, _L, _L, /* 224-239 */
	_L, _L, _L, _L, _L, _L, _L, _P, _L, _L, _L, _L, _L, _L, _L, _L
};  /* 240-255 */

#define AT_isdigit(c)	((_AT_ismask(c)&(_D)) != 0)
#define _AT_ismask(x) (at_ctype[(int)(unsigned char)(x)])

// to check the time format  end  yangtt at 08-4-22
BOOL AT_TimeFormat_isAvailable(UINT8 *pString)
{
	UINT8 *p;
	UINT8 i, iLen;

	if (NULL == pString)
	{
		return FALSE;
	}

	p = pString;

	iLen = (UINT8)AT_StrLen(p);

	// "yy/mm/dd,hh:mm:ss"
	// 01234567890123456

	if (iLen > 17)
	{
		if ((p[17] != '+'))
		{
			if ((p[17] != '-'))
				return FALSE;
		}

		if ((p[2] != '/') || (p[5] != '/') || (p[8] != ',') || (p[11] != ':') || (p[14] != ':'))
			return FALSE;

		for (i = 0; i < iLen; i++)
		{
			if ((i == 2) || (i == 5) || (i == 8) || (i == 11) || (i == 14) || (i == 17))
			{

			}
			else
			{

				if (!(AT_isdigit(p[i])))
					return FALSE;

			}

		}
	}
	else  // // yangtt at 08-4-22 for bug  8222
	{
		if ((p[2] != '/') || (p[5] != '/') || (p[8] != ',') || (p[11] != ':') || (p[14] != ':'))
			return FALSE;

		for (i = 0; i < iLen; i++)
		{
			if ((i == 2) || (i == 5) || (i == 8) || (i == 11) || (i == 14))
			{

			}
			else
			{

				if (!(AT_isdigit(p[i])))
					return FALSE;
			}

		}

	}

	return TRUE;
}

/****************************************************
 *******Set command sets the real time clock of the MT
 ****************************************************/
VOID AT_GC_CmdFunc_CCLK(AT_CMD_PARA *pParam)
{
	UINT8 iCount = 0;
	UINT8 cfw_para[24];
	UINT8 respond[80];
	UINT8 String[18];
	UINT8 len      = 24;
	INT8 iTimeZone = 0;
	BOOL tmRet     = 0;
	INT32 iResult;
	TM_FILETIME ft;
	TM_SYSTEMTIME st;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	AT_MemSet(cfw_para, 0x00, 20);
	AT_MemSet(respond, 0x00, 80);

	AT_TC(g_sw_GC, "=======CCLK 111======,pParam->iType=%d\n", pParam->iType);

	if (pParam->pPara == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{

	case AT_CMD_SET:
		iResult = AT_Util_GetParaCount(pParam->pPara, &iCount);
		AT_TC(g_sw_GC, "=======CCLK,33 iResult is 0x%x, iCount=%d=====\n", iResult, iCount);

		if (iResult != ERR_SUCCESS || (iCount != 1))
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		iResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, (PVOID)cfw_para, &len);

		AT_TC(g_sw_GC, "=======CCLK,44 iResult is 0x%x, len=%d=====\n", iResult, len);

		if (ERR_SUCCESS != iResult || len == 0)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		AT_Util_TrimAll(cfw_para);

		if (!AT_StrLen(cfw_para) || (AT_StrLen(cfw_para) > 20)) // amend yangtt 04-16 for bug 7974 //HAMEINA [+] add the last part
		{
			AT_TC(g_sw_GC, "=======CCLK,55 =====\n");
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;

		}

		// added by yangtt at 08-04-22 for 8074
		if (FALSE == AT_TimeFormat_isAvailable(cfw_para))
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		memset(String, 0, 17);

		AT_StrNCpy(String, cfw_para, 17); // yangtt at 08-4-22 for bug 8074 8222
		tmRet = TM_FormatDateTimeEx(&ft, String);

		if (tmRet)
		{
			AT_TC(g_sw_GC, "=======CCLK 66!====ft=%ld==\n", ft);
			tmRet = TM_FileTimeToSystemTime(ft, &st);
			AT_TC(g_sw_GC, "=======CCLK 67!====st.uYear=%ld==\n", st.uYear);

			if (!tmRet)
			{
				AT_TC(g_sw_GC, "=======CCLK 77!======\n");
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				break;
			}

			tmRet = TM_SetSystemTime(&st);

			AT_TC(g_sw_GC, "=======CCLK, 88 execution is %d!======\n", tmRet);

			if (!tmRet)
			{
				AT_TC(g_sw_GC, "=======CCLK, 10 ======\n");
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			}
			else
			{
				if (AT_StrLen(cfw_para) > 18)
				{
					len = 1;

					// [[hameina [mod]2007.12.07 verify timezone, for bug 7195

					if (cfw_para[18] >= '0' && cfw_para[18] <= '9') // hameina[+] 2007.12.06:bug 7195
					{
						if (AT_StrLen(cfw_para) > 19)
						{
							if (cfw_para[19] < '0' || cfw_para[19] > '9') // hameina[mod]2007.12.11 for bug 7217 <= to <, >= to >
							{
#ifdef AT_DUAL_SIM
								AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
								AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
								return;
							}
						}

						iTimeZone = atoi(&cfw_para[18]);

						if (cfw_para[17] == '-')
							iTimeZone = -iTimeZone;

						AT_TC(g_sw_GC, "=======CCLK 99, get timezone=%d! zone str=%s\n", iTimeZone, &cfw_para[17]);

						// [[hameina [+] 07-11-27 :bug 7124
						if (iTimeZone > 13 || iTimeZone < -12)  // yangtt at 2008-05-04 for bug 8222
						{
#ifdef AT_DUAL_SIM
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
							return;
						}

						// ]]hameina [+] 07-11-27 :bug 7124
						tmRet = TM_SetTimeZone(iTimeZone);

						if (tmRet)
#ifdef AT_DUAL_SIM
							AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
							AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
						else
						{
#ifdef AT_DUAL_SIM
							AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
							AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						}
					}
					else
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}

					// [[hameina [mod]2007.12.07 verify timezone, for bug 7195
				}
				else
				{
#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
				}

			}

		}
		else
		{
			AT_TC(g_sw_GC, "=======CCLK, 100 ======\n");
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		}

		break;

	case AT_CMD_TEST:
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
		break;

	case AT_CMD_READ:
		tmRet = TM_GetSystemTime(&st);

		if (!tmRet)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		tmRet = TM_SystemTimeToFileTime(&st, &ft);

		if (!tmRet)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PHONE_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PHONE_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		tmRet = TM_FormatFileTimeToStringEx(ft, String);

		if (!tmRet)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PHONE_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PHONE_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		iTimeZone = TM_GetTimeZone();

		if (iTimeZone >= 0)
		{
			AT_Sprintf(respond, "+CCLK: \"%s+%d\"", String, iTimeZone);
		}
		else
		{
			AT_Sprintf(respond, "+CCLK: \"%s%d\"", String, iTimeZone);
		}
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, respond, AT_StrLen(respond), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, respond, AT_StrLen(respond), pParam->nDLCI);
#endif

		break;

	default:
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_SUPPORTED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_SUPPORTED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

		break;
	}
	}

	return;
}

VOID AT_GC_CmdFunc_E(AT_CMD_PARA *pParam)
{
	INT32 eResult;
	UINT8 iCount = 0;
	UINT8 atl_para;
	UINT8 cfw_para;
	UINT8 len = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	if (pParam->iType == AT_CMD_EXE)
	{
		eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);

		if (eResult == ERR_SUCCESS)
		{
			if ((iCount != 1) && (iCount != 0))
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}
			else if (iCount == 0)
			{
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
				return;
			}
			else
			{
				len = 1;

				if (ERR_SUCCESS == AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &atl_para, &len))
				{
					cfw_para = (UINT8)atl_para;

					if (cfw_para > 1)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}

					// g_eCommandEchoMode = atl_para;
					gATCurrenteCommandEchoMode = atl_para;

#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif

					return;
				}
				else
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}
			}

		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}
	}
	else
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}
}

/******************************************************************************************
Function		:	AT_GC_CmdFunc_V
Description		:   AT General Command
					The setting of this parameter determines the contents of the header
					and trailer transmitted with result codes and information responses.
					It also determines whether result codes are transmitted in a numeric
					form or an alphabetic (or "verbose") form.
					The text portion of information responses is not affected by this setting.

Command format  :	ATV[<value>]
Called By		:	AT_RunCommand()
Data Accessed   :
Data Updated    :
Input			:   pParam
Output			:
Return			:	void
Others			:	modify by wangqunyang 20/03/2008
*******************************************************************************************/
VOID AT_GC_CmdFunc_V(AT_CMD_PARA *pParam)
{

	INT32 eResult  = 0;  // Return result code
	UINT8 iCount   = 0; // Parameters count
	UINT8 atl_para = GC_RESULTCODE_FORMAT_VERBOSE;  /* according to itu-v.25ter:
                                                     The default value is: 1 */
	UINT8 len = 0;  // parameters length

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	/* The parameter is NULL, return */

	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}
	else
	{
		// /////////////////////////////////////////////////
		/* Judge the command type, it is execute command */
		// /////////////////////////////////////////////////
		if (pParam->iType == AT_CMD_EXE)
		{

			// Fill value in the "iCount" and return result
			eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);

			if (eResult == ERR_SUCCESS)
			{

				if (iCount > 1) // iCount bigger than 1
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}
				else if (iCount == 0) // iCount equal to 0
				{
#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
					return;
				}
				else  // iCount equal to 1
				{

					len = 1;

					// Get parameters and fill with "atl_para" and "len"

					if (ERR_SUCCESS == AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &atl_para, &len))
					{

						// if (atl_para < 0 || atl_para > 1)
						if (atl_para > 1)
						{
#ifdef AT_DUAL_SIM
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
							return;
						}

						/*
						   ** Evaluate to the global variable: g_eResultcodeFormat
						 */
						// g_eResultcodeFormat = atl_para;
						gATCurrenteResultcodeFormat = atl_para;

#ifdef AT_DUAL_SIM
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif

						return;

					}
					else
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}
				}
			}

			// /////////////////////////////////////////////////
			/* Judge the command type, it is non execute command */
			// /////////////////////////////////////////////////
			else
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}
	}
}

/******************************************************************************************
Function		:	AT_GC_CmdFunc_Q
Description		:   AT General Command
					The setting of this parameter determines whether or not the DCE
					transmits result codes to the DTE

Command format  :	ATV[<value>]
Called By		:	AT_RunCommand()
Data Accessed   :
Data Updated    :
Input			:   pParam
Output			:
Return			:	void
Others			:	modify by wangqunyang 20/03/2008
*******************************************************************************************/
VOID AT_GC_CmdFunc_Q(AT_CMD_PARA *pParam)
{

	INT32 eResult  = 0;  // Return result code
	UINT8 iCount   = 0; // Parameters count
	UINT8 atl_para = GC_RESULTCODE_PRESENTATION_ENABLE; /* according to itu-v.25ter:
                                                         The default value is: 0 */
	UINT8 len = 0;  // parameters length

	/* The parameter is NULL, return */
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}
	else
	{
		// /////////////////////////////////////////////////
		/* Judge the command type, it is execute command */
		// /////////////////////////////////////////////////
		if (pParam->iType == AT_CMD_EXE)
		{

			// Fill value in the "iCount" and return result
			eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);
			AT_TC(g_sw_GC, "=======iCount=======%d\n", iCount);

			if (eResult == ERR_SUCCESS)
			{

				if ((iCount != 1) && (iCount != 0))
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}
				else if (iCount == 0)
				{

#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
					return;
				}
				else
				{
					len = 1;

					if (ERR_SUCCESS == AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &atl_para, &len))
					{

						// if ((atl_para < 0) || (atl_para > 1))
						if (atl_para > 1)
						{
#ifdef AT_DUAL_SIM
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
							return;
						}

						// g_eResultcodePresentation = atl_para;
						gATCurrenteResultcodePresentation = atl_para;

#ifdef AT_DUAL_SIM
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
						return;

					}
					else
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}
				}
			}

			// /////////////////////////////////////////////////
			/* Judge the command type, it is non execute command */
			// /////////////////////////////////////////////////
			else
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}
	}
}

VOID AT_GC_CmdFunc_CALA(AT_CMD_PARA *pParam)
{

	UINT8 alarm_index = 0;

	INT32 eResult;
	UINT8 iCount = 0;
	UINT8 i;
	UINT8 str_len;
	UINT8 str_temp  = 0;
	UINT8 alarm_num = 0;

	TM_ALARM *alarm_list = NULL;
	TM_ALARM cfw_alarm;
	TM_FILETIME ft;
	CALA cala;
	UINT8 len     = 0;
	UINT8 msg[36] = { 0 };  // hameina[mod] 2007.12.10 bug 7201: max text len is 32,30->36

	UINT8 String[24];
	UINT8 respond[80];
	UINT8 cfw_para[20];

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	AT_MemSet(&cala, 0, sizeof(CALA));

	// AT_MemSet(&week, 0, sizeof(RECURR));

	AT_TC(g_sw_GC, "=======CALA 1======,pParam->iType=%d\n", pParam->iType);
	AT_MemSet(cfw_para, 0x00, 20);
	AT_MemSet(&cfw_alarm, 0x00, sizeof(TM_ALARM));
	AT_MemSet(respond, 0x00, 80);

	if (NULL == pParam)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{

	case AT_CMD_SET:
	{
		eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);
		AT_TC(g_sw_GC, "=======CALA 2======,iCount=%d, eResult=0x%x\n", iCount, eResult);

		if (eResult != ERR_SUCCESS || iCount < 1 || iCount > 5) // hameina[mod]2007.12.10 bug 7203 6->5
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		for (i = 0; i < 5; i++)
		{
			switch (i)
			{

			case 0:  // time
				str_len = 20;
				eResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, (PVOID)(cala.time), &str_len);
				AT_TC(g_sw_GC, "=======CALA 3======,cala.time=%s, eResult=0x%x\n", cala.time, eResult);

				if (ERR_SUCCESS != eResult || !str_len)
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}

				str_temp = str_len;

				AT_Util_TrimAll(cala.time);
				break;

			case 1:  // index

				if (iCount)
				{
					len     = 1;
					eResult = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &(cala.index), &len);
					AT_TC(g_sw_GC, "=======CALA 4======,cala.index=%d, eResult=0x%x\n", cala.index, eResult);

					if (eResult == ERR_SUCCESS)
					{
						// cala.index = uIndex;
						if ((cala.index > TIM_ALARM_INDEX_MAX) || (cala.index < 1))
						{
#ifdef AT_DUAL_SIM
							AT_Result_Err(ERR_AT_CME_INVALID_INDEX, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
							AT_Result_Err(ERR_AT_CME_INVALID_INDEX, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
							return;
						}
					}

					// [[hameina[+]2007.12.11 bug 7203:the last param can't be ignored.
					else if (eResult == ERR_AT_UTIL_CMD_PARA_NULL && iCount == 2)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}

					// ]]hameina[+]2007.12.11 bug 7203:the last param can't be ignored.
					else if (eResult == ERR_AT_UTIL_CMD_PARA_NULL)
					{
						cala.index = 1;
					}
					else
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_INDEX, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_INDEX, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}
				}
				else
					cala.index = 1;

				break;

			case 2:  // type
				if (iCount > 1)
				{
					len     = 1;
					eResult = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_UINT8, &(cala.type), &len);
					AT_TC(g_sw_GC, "=======CALA 5======,cala.type=%d, eResult=0x%x\n", cala.type, eResult);

					// added by yangtt at 2008-03-22 for bug 8074

					if (cala.type != 0)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INDIAL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INDIAL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}

					// [[hameina[+]2007.12.11 bug 7203:the last param can't be ignored.
					if (eResult == ERR_AT_UTIL_CMD_PARA_NULL && iCount == 3)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}

					// ]]hameina[+]2007.12.11 bug 7203:the last param can't be ignored.
					else if (eResult == ERR_AT_UTIL_CMD_PARA_NULL)
					{
						cala.type = 0;
					}
					else if (eResult != ERR_SUCCESS)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}
				}
				else
					cala.type = 0;

				break;

			case 3:  // text to be displayed when the alarm ring
				if (iCount > 2)
				{
					str_len = 36; // hameina 07-11-27 :bug 7133 32->36
					eResult = AT_Util_GetParaWithRule(pParam->pPara, 3, AT_UTIL_PARA_TYPE_STRING, (PVOID)(cala.text), &str_len);
					AT_TC(g_sw_GC, "=======CALA 6======,cala.text=%s, eResult=0x%x\n", cala.text, eResult);

					// [[hameina[+]2007.12.11 bug 7203:the last param can't be ignored.

					if (eResult == ERR_AT_UTIL_CMD_PARA_NULL && iCount == 4)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}

					// ]]hameina[+]2007.12.11 bug 7203:the last param can't be ignored.
					else if (eResult != ERR_SUCCESS && eResult != ERR_AT_UTIL_CMD_PARA_NULL)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}

					// [[hameina [+]07.11.27 :bug 7133
					if (str_len > 32)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_TEXT_LONG, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_TEXT_LONG, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}

					// ]]hameina [+]07.11.27 :bug 7133
				}

				break;

			case 4:  // recurr,

				if (iCount > 3)
				{
					len     = 16;
					eResult = AT_Util_GetParaWithRule(pParam->pPara, 4, AT_UTIL_PARA_TYPE_STRING, (PVOID)cala.reccurr, &len);
					AT_TC(g_sw_GC, "=======CALA 7======,cala.reccurr=%s, eResult=0x%x\n", cala.reccurr, eResult);

					if (eResult == ERR_SUCCESS)
					{
						AT_Util_TrimAll(cala.reccurr);
					}

					// [[hameina[+]2007.12.11 bug 7203:the last param can't be ignored.
					else if (eResult == ERR_AT_UTIL_CMD_PARA_NULL && iCount == 5)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}

					// ]]hameina[+]2007.12.11 bug 7203:the last param can't be ignored.
					else if (eResult == ERR_AT_UTIL_CMD_PARA_NULL)
					{
						cala.reccurr[0] = 0;
					}
					else
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}
				}
				else
					cala.reccurr[0] = 0;

				break;

			default:
				break;
			}
		}

		cfw_alarm.nIndex = cala.index;

		cfw_alarm.nType       = cala.type;
		cfw_alarm.pText       = cala.text;
		cfw_alarm.nTextLength = (UINT8)AT_StrLen(cala.text);
		AT_TC(g_sw_GC, "=======CALA 8======,cala.reccurr[0]=%d\n", cala.reccurr[0]);

		if (!cala.reccurr[0]) // --->yy/mm/dd,hh:mm:ss
		{
			if (!TM_FormatDateTimeEx(&ft, cala.time))
			{
				AT_TC(g_sw_GC, "=======CALA 9======,cala.time=%s, e\n", cala.time);
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PHONE_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PHONE_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}

			cfw_alarm.nFileTime = ft.DateTime;

			AT_TC(g_sw_GC, "=======CALA 10======,ft.DateTime=%d\n", ft.DateTime);
		}
		else  // --->hh:mm:ss
		{
			UINT8 tmp_time = 0;
			UINT8 tme_len  = 0;

			if (cala.time[2] != ':' || cala.time[5] != ':')
			{
				AT_TC(g_sw_GC, "=======CALA 11======,ft.cala.time[2]=%c, cala.time[5]=%c\n", cala.time[2], cala.time[2]);
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}
			else
			{
				cala.time[2] = ',';
				cala.time[5] = ',';
			}

			tme_len = 1;

			eResult = AT_Util_GetParaWithRule(cala.time, 0, AT_UTIL_PARA_TYPE_UINT8, (PVOID)&tmp_time, &tme_len);

			if (eResult != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				AT_TC(g_sw_GC, "=======CALA 12======\n");
				return;
			}

			cfw_alarm.nFileTime = tmp_time * 60 * 60;

			eResult = AT_Util_GetParaWithRule(cala.time, 1, AT_UTIL_PARA_TYPE_UINT8, (PVOID)&tmp_time, &tme_len);

			if (eResult != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				AT_TC(g_sw_GC, "=======CALA 13======\n");
				return;
			}

			cfw_alarm.nFileTime += tmp_time * 60;

			eResult = AT_Util_GetParaWithRule(cala.time, 2, AT_UTIL_PARA_TYPE_UINT8, (PVOID)&tmp_time, &tme_len);

			if (eResult != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				AT_TC(g_sw_GC, "=======CALA 14======\n");
				return;
			}

			cfw_alarm.nFileTime += tmp_time;

			AT_TC(g_sw_GC, "=======CALA 15======cfw_alarm.nFileTime=%d\n", cfw_alarm.nFileTime);
		}

		if (!cala.reccurr[0])
		{
			cfw_alarm.nRecurrent = 1;
		}
		else if (cala.reccurr[0] == 0x30)
		{
			cfw_alarm.nRecurrent = 0;

		}
		else if (len) // string recurr not null
		{
			eResult = AT_Util_GetParaCount(cala.reccurr, &iCount);

			if (eResult != ERR_SUCCESS || iCount > 7)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				AT_TC(g_sw_GC, "=======CALA 16======\n");
				return;
			}
			else
			{
				UINT8 uRecurr_tmp = 0;

				for (i = 0; i < iCount; i++)
				{
					len     = 1;
					eResult = AT_Util_GetParaWithRule(cala.reccurr, i, AT_UTIL_PARA_TYPE_UINT8, &uRecurr_tmp, &len);

					if (eResult == ERR_SUCCESS)
					{
						if (!uRecurr_tmp || uRecurr_tmp > 7)
						{
#ifdef AT_DUAL_SIM
							AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
							AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
							AT_TC(g_sw_GC, "=======CALA 17,i=%d=====\n", i);
							return;
						}
						else
							cfw_alarm.nRecurrent |= 1 << uRecurr_tmp;

						AT_TC(g_sw_GC, "=======CALA 18, i=%d,cfw_alarm.nRecurrent=0x%x\n", i, cfw_alarm.nRecurrent);
					}
					else
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						AT_TC(g_sw_GC, "=======CALA 19,i=%d=====\n", i);
						return;
					}
				}

				cfw_alarm.nRecurrent &= 0xfe; // set bit 0 to zero
			}
		}

		if (!TM_SetAlarm(&cfw_alarm/*, &alarm_num*/))
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

			AT_TC(g_sw_GC, "=======CALA 20===sul_err=0x%x===\n", SUL_GetLastError());
			return;
		}

#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif

		break;
	}

	case AT_CMD_TEST:

		AT_Sprintf(msg, "+CALA: (1-%d),(0),(32),(15)", TIM_ALARM_INDEX_MAX);
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, msg, AT_StrLen(msg), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, msg, AT_StrLen(msg), pParam->nDLCI);
#endif
		break;

	case AT_CMD_READ:

		if (TM_ListAlarm(&alarm_num, &alarm_list))
		{
			// UINT8 time_str[20];
			// UINT8 send_msg[80];

			for (alarm_index = 0; alarm_index < alarm_num; alarm_index++)
			{
				AT_MemSet(respond, 0, 80);
				AT_MemSet(String, 0x00, 24);
				ft.DateTime = alarm_list[alarm_index].nFileTime;

				if (!TM_FormatFileTimeToStringEx(ft, String))
				{
					if (alarm_list != NULL)
					{
						AT_FREE(alarm_list);
						alarm_list = NULL;
					}

#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

					return;
				}

				AT_TC(g_sw_GC, "=======CALA 21===String=%s, alarm_list[%d].nTextLength =%d\n", String, alarm_index,
				      alarm_list[alarm_index].nTextLength);

				AT_StrNCpy(msg, alarm_list[alarm_index].pText, alarm_list[alarm_index].nTextLength);

				// msg[alarm_list[alarm_index].nTextLength]=0;

				if (alarm_list[alarm_index].nRecurrent == 1)  // just alerm once
				{
					AT_TC(g_sw_GC, "=======CALA 21===String=%s\n", String);
					AT_Sprintf(respond, "+CALA: \"%s\",%u,%u,\"%s\"",
					           String, alarm_list[alarm_index].nIndex, alarm_list[alarm_index].nType, msg);
				}
				else if (alarm_list[alarm_index].nRecurrent == 0) // from monday to sunday
				{
					AT_Sprintf(respond, "+CALA: \"%s\",%u,%u,\"%s\",\"1,2,3,4,5,6,7\"",
					           String, alarm_list[alarm_index].nIndex, alarm_list[alarm_index].nType, msg);
				}
				else
				{
					UINT8 recurr = 0;

					AT_Sprintf(respond, "+CALA: \"%s\",%u,%u,\"%s\",\"",
					           String, alarm_list[alarm_index].nIndex, alarm_list[alarm_index].nType, msg);

					for (i = 0; i < 7; i++)
					{
						recurr = BIT_SET(alarm_list[alarm_index].nRecurrent, (i + 1));

						if (recurr)
						{
							AT_Sprintf(cfw_para, "%u,", recurr);
							AT_StrCat(respond, cfw_para);
						}
					}

					// AT_StrCat(respond, "\"");
					respond[AT_StrLen(respond) - 1] = '"';
				}
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, respond, AT_StrLen(respond), pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, respond, AT_StrLen(respond), pParam->nDLCI);
#endif

			}

			alarm_index = 0;

			if (alarm_list != NULL)
			{
				AT_FREE(alarm_list);
				alarm_list = NULL;
			}

#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, 0, 0, pParam->nDLCI, nSim);
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_CR, 0, 0, 0, pParam->nDLCI);
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
			return;
		}
		else
		{
			if (alarm_list != NULL)
			{
				AT_FREE(alarm_list);
				alarm_list = NULL;
			}

#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

			return;
		}

		break;

	default:
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		break;
	}

	return;
}

VOID AT_GC_CmdFunc_CALD(AT_CMD_PARA *pParam)
{

	UINT8 alarm_index = 0;

	INT32 eResult;
	UINT8 iCount = 0;

	// UINT8 i;
	UINT8 len    = 0;
	UINT8 msg[6] = { 0, 0, 0, 0, 0, 0 };
	UINT8 String[50];

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (NULL == pParam)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	AT_TC(g_sw_GC, "=======CALD 1======,pParam->iType=%d\n", pParam->iType);

	switch (pParam->iType)
	{

	case AT_CMD_SET:
	{
		eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);
		AT_TC(g_sw_GC, "=======CALD 2======,iCount=%d, eResult=0x%x\n", iCount, eResult);

		if (eResult != ERR_SUCCESS || iCount != 1)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		len = 1;

		eResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &alarm_index, &len);
		AT_TC(g_sw_GC, "=======CALD 4======,alarm_index=%d, eResult=0x%x\n", alarm_index, eResult);

		if (eResult == ERR_SUCCESS)
		{
			// cala.index = uIndex;
			if ((alarm_index > TIM_ALARM_INDEX_MAX) || (alarm_index < 1))
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_INVALID_INDEX, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_INVALID_INDEX, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

				return;
			}
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_INVALID_INDEX, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_INVALID_INDEX, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

			return;
		}

		if (!TM_KillAlarm(alarm_index))
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			AT_TC(g_sw_GC, "=======CALD 20===sul_err=0x%x===\n", SUL_GetLastError());
			return;
		}

#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif

		break;
	}

	case AT_CMD_TEST:
	{
		TM_ALARM *sAlarmList = NULL;

		if (TM_ListAlarm(&alarm_index, &sAlarmList))
		{

			AT_MemSet(String, 0x00, 50);

			if (!alarm_index)
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
			else
			{
				AT_StrCpy(String, "+CALD: ");

				for (iCount = 0; iCount < alarm_index; iCount++)
				{
					AT_Sprintf(msg, "%u,", sAlarmList[iCount].nIndex);
					AT_StrCat(String, msg);
				}

				String[AT_StrLen(String) - 1] = 0;
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, String, AT_StrLen(String), pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, String, AT_StrLen(String), pParam->nDLCI);
#endif
			}

			alarm_index = 0;

			if (sAlarmList != NULL)
			{
				AT_FREE(sAlarmList);
				sAlarmList = NULL;
			}

			break;
		}
		else
		{
			if (sAlarmList != NULL)
			{
				AT_FREE(sAlarmList);
				sAlarmList = NULL;
			}

#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

			return;
		}

		break;
	}

	default:
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		break;
	}

	return;
}

VOID AT_GC_CmdFunc_X(AT_CMD_PARA *pParam)
{
#define AT_X_RANGE   "0-4"
	INT32 eResult;
	PAT_CMD_RESULT presult = NULL;
	UINT8 iCount           = 0;
	UINT8 atl_para;
	UINT8 nValue;

#ifdef AT_DUAL_SIM
	//UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
		presult =
		    AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, ERR_INVALID_PARAMETER, CMD_ERROR_CODE_TYPE_CME, 0, 0, 0, pParam->nDLCI);

		AT_Notify2ATM(presult, pParam->nDLCI);

		if (presult != NULL)
		{
			AT_FREE(presult);
			presult = NULL;
		}

		return;
	}
	else
	{
		if (pParam->iType == AT_CMD_EXE)
		{
			eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);

			if (eResult == ERR_SUCCESS)
			{
				if (iCount == 1)
				{
					UINT8 len = 1;

					eResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &atl_para, &len);

					if (ERR_SUCCESS == eResult)
					{
						UINT32 ret = ERR_SUCCESS;

						ret = CFW_CfgNumRangeCheck((UINT32)atl_para, (UINT8 *)AT_X_RANGE);

						if (ret != ERR_SUCCESS)
						{
							presult = AT_CreateRC(CMD_FUNC_FAIL,
							                      CMD_RC_ERROR, ERR_INVALID_PARAMETER, CMD_ERROR_CODE_TYPE_CME, 0, 0, 0,
							                      pParam->nDLCI);
							AT_Notify2ATM(presult, pParam->nDLCI);

							if (presult != NULL)
							{
								AT_FREE(presult);
								presult = NULL;
							}

							return;
						}

						ret = CFW_CfgSetConnectResultFormatCode(atl_para);

						if (ret != ERR_SUCCESS)
						{
							presult = AT_CreateRC(CMD_FUNC_FAIL,
							                      CMD_RC_ERROR, ERR_INVALID_PARAMETER, CMD_ERROR_CODE_TYPE_CME, 0, 0, 0,
							                      pParam->nDLCI);
							AT_Notify2ATM(presult, pParam->nDLCI);

							if (presult != NULL)
							{
								AT_FREE(presult);
								presult = NULL;
							}

							return;
						}

						ret = CFW_CfgGetConnectResultFormatCode(&nValue);

						if (ret != ERR_SUCCESS)
						{
							presult = AT_CreateRC(CMD_FUNC_FAIL,
							                      CMD_RC_ERROR, ERR_INVALID_PARAMETER, CMD_ERROR_CODE_TYPE_CME, 0, 0, 0,
							                      pParam->nDLCI);
							AT_Notify2ATM(presult, pParam->nDLCI);

							if (presult != NULL)
							{
								AT_FREE(presult);
								presult = NULL;
							}

							return;
						}
						else if (nValue != atl_para)
						{
							presult = AT_CreateRC(CMD_FUNC_FAIL,
							                      CMD_RC_ERROR, ERR_INVALID_PARAMETER, CMD_ERROR_CODE_TYPE_CME, 0, 0, 0,
							                      pParam->nDLCI);
							AT_Notify2ATM(presult, pParam->nDLCI);

							if (presult != NULL)
							{
								AT_FREE(presult);
								presult = NULL;
							}

							return;
						}

						presult =
						    AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, 0, 0, pParam->nDLCI);

						AT_Notify2ATM(presult, pParam->nDLCI);

						if (presult != NULL)
						{
							AT_FREE(presult);
							presult = NULL;
						}

						return;

					}
				}
				else
				{
					presult =
					    AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, ERR_INVALID_PARAMETER, CMD_ERROR_CODE_TYPE_CME, 0, 0, 0,
					                pParam->nDLCI);

					AT_Notify2ATM(presult, pParam->nDLCI);

					if (presult != NULL)
					{
						AT_FREE(presult);
						presult = NULL;
					}

					return;
				}

			}
			else
			{
				presult =
				    AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, ERR_INVALID_PARAMETER, CMD_ERROR_CODE_TYPE_CME, 0, 0, 0,
				                pParam->nDLCI);

				AT_Notify2ATM(presult, pParam->nDLCI);

				if (presult != NULL)
				{
					AT_FREE(presult);
					presult = NULL;
				}

				return;
			}

		}

		else
		{
			presult =
			    AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, ERR_INVALID_PARAMETER, CMD_ERROR_CODE_TYPE_CME, 0, 0, 0,
			                pParam->nDLCI);

			AT_Notify2ATM(presult, pParam->nDLCI);

			if (presult != NULL)
			{
				AT_FREE(presult);
				presult = NULL;
			}

			return;
		}
	}
}

VOID AT_GC_CmdFunc_CPOF(AT_CMD_PARA *pParam)
{
	UINT32 err_code = ERR_SUCCESS;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	AT_TC(g_sw_GC, "=======CPOF======,pParam->iType=%d\n", pParam->iType);

	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}
	else
	{

		if (pParam->iType == AT_CMD_EXE)
		{
			g_gc_pwroff = 1;
			err_code    = CFW_ShellControl(CFW_CONTROL_CMD_POWER_OFF);

			if (err_code != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}
			else
			{
				// AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
				// just for debugging,need more work  ,by wulc
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
				DM_DeviceSwithOff();

				return;
			}
		}
		else if (AT_CMD_TEST == pParam->iType)
		{
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
			return;
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}
	}
}

VOID AT_GC_CPOF_CFUN_IND(CFW_EVENT *cfwEvent)
{
	UINT8 nType = 0x0;
	UINT32 nParam1;
	UINT32 nParam2;

#ifdef AT_DUAL_SIM
	UINT8 nSim;
#endif
	CFW_EVENT *pCfwEvent = cfwEvent;
	nType   = pCfwEvent->nType;
	nParam1 = pCfwEvent->nParam1;
	nParam2 = pCfwEvent->nParam2;
#ifdef AT_DUAL_SIM
	nSim = pCfwEvent->nFlag;
#endif
	AT_TC(g_sw_GC, "in AT_GC_CPOF_CFUN_IND, nType=0x%x, nParam1=0x%x, nParam2=0x%x\n", nType, nParam1, nParam2);

	if (nType == 0x00)
	{
		// g_cfg_cfun = 6;

		if ((nParam1 != 0x01) || (nParam2 != 0))
		{
			g_gc_pwroff = 0;
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pCfwEvent->nUTI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pCfwEvent->nUTI);
#endif
			return;
		}
		else
		{
			if (g_gc_pwroff == 1) // smso
			{
				g_gc_pwroff = 0;
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, "+CPOF: MS OFF OK", AT_StrLen("+CPOF: MS OFF OK"), pCfwEvent->nUTI,
				             nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, "+CPOF: MS OFF OK", AT_StrLen("+CPOF: MS OFF OK"), pCfwEvent->nUTI);
#endif
				DM_DeviceSwithOff();
			}
			else if (g_gc_pwroff == 2)  // CFUN, just switch of cfw
			{
				g_gc_pwroff = 0;
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pCfwEvent->nUTI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pCfwEvent->nUTI);
#endif
			}

			return;
		}

	}
	else  // if (nType == 0xF0)
	{
		g_gc_pwroff = 0;
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pCfwEvent->nUTI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pCfwEvent->nUTI);
#endif
		return;
	}

}

VOID AT_GC_CmdFunc_S3(AT_CMD_PARA *pParam)
{

	UINT8 arrRes[4];
	INT32 iRet       = 0;
	UINT8 nParaCount = 0;
	UINT8 nS3        = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	AT_TC(g_sw_GC, "=======AT_GC_CmdFunc_S3======,pParam->iType=%d\n", pParam->iType);

	if (pParam->iType == AT_CMD_READ)
	{
		AT_MemZero(arrRes, sizeof(arrRes));
		AT_Sprintf(arrRes, "%3u", gATCurrentnS3);
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), pParam->nDLCI);
#endif
		return;
	}
	else if (pParam->iType == AT_CMD_SET)
	{
		iRet = AT_Util_GetParaCount(pParam->pPara, &nParaCount);

		if (iRet != ERR_SUCCESS || nParaCount > 1)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		if (nParaCount == 0)
		{
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
			return;
		}

		UINT8 nParamLen = 1;

		iRet = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &nS3, &nParamLen);

		if (iRet != ERR_SUCCESS)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		// added by yangtt at 2008-06-13 for bug 8733 begin
		if (nS3 > 31) // added by yangtt at 2008-06-13 for bug 8776
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		// added by yangtt at 2008-06-13 for bug 8733 end
		// g_nS3 = nS3;
		gATCurrentnS3 = nS3;

#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif

		return;

	}
	else
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

}

VOID AT_GC_CmdFunc_S4(AT_CMD_PARA *pParam)
{

	UINT8 arrRes[4];
	INT32 iRet       = 0;
	UINT8 nParaCount = 0;
	UINT8 nS4        = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	if (pParam->iType == AT_CMD_READ)
	{
		AT_MemZero(arrRes, sizeof(arrRes));
		AT_Sprintf(arrRes, "%3u", gATCurrentnS4);
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), pParam->nDLCI);
#endif
		return;
	}
	else if (pParam->iType == AT_CMD_SET)
	{
		iRet = AT_Util_GetParaCount(pParam->pPara, &nParaCount);

		if (iRet != ERR_SUCCESS || nParaCount > 1)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		if (nParaCount == 0)
		{
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
			return;
		}

		UINT8 nParamLen = 1;

		iRet = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &nS4, &nParamLen);

		if (iRet != ERR_SUCCESS)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		// added by yangtt at 2008-06-13 for bug 8733 begin
		if (nS4 > 31) // added by yangtt at 2008-06-13 for bug 8776
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		// added by yangtt at 2008-06-13 for bug 8733 end
		// g_nS4 = nS4;
		gATCurrentnS4 = nS4;

#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif

		return;

	}
	else
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

		return;
	}

}

VOID AT_GC_CmdFunc_S5(AT_CMD_PARA *pParam)
{

	UINT8 arrRes[4];
	INT32 iRet       = 0;
	UINT8 nParaCount = 0;
	UINT8 nS5        = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	if (pParam->iType == AT_CMD_READ)
	{
		AT_MemZero(arrRes, sizeof(arrRes));
		AT_Sprintf(arrRes, "%3u", gATCurrentnS5);
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, AT_StrLen(arrRes), pParam->nDLCI);
#endif
		return;
	}
	else if (pParam->iType == AT_CMD_SET)
	{
		iRet = AT_Util_GetParaCount(pParam->pPara, &nParaCount);

		if (iRet != ERR_SUCCESS || nParaCount > 1)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		if (nParaCount == 0)
		{
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
			return;
		}

		UINT8 nParamLen = 1;

		iRet = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &nS5, &nParamLen);

		if (iRet != ERR_SUCCESS)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		// added by yangtt at 2008-06-13 for bug 8733 begin
		if (nS5 > 31) // added by yangtt at 2008-06-13 for bug 8776
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		// added by yangtt at 2008-06-13 for bug 8733 end
		// g_nS5 = nS5;
		gATCurrentnS5 = nS5;

#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif

		return;

	}
	else
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

		return;
	}

}

/***************************************************************************
**AT+ICF  Add by wulc 2012.02.06
**This extended-format compound parameter is used to determine the local
**serial port start-stop (asynchronous) character framing that the DCE
**shall use while accepting DTE commands and while transmitting information
**text andresult code, if this is not automatically determined
****************************************************************************/
VOID AT_GC_CmdFunc_ICF(AT_CMD_PARA *pParam)
{
	PAT_CMD_RESULT presult = NULL;
	INT32 eResult, eResult1;
	UINT8 iCount = 0;
	UINT8 len    = 0;
	UINT8 send_msg[108];
	UINT32 nFormat;
	UINT32 nParity;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	AT_TC(g_sw_GC, "pParam->iType =%d\n\r", pParam->iType);

	if (pParam == NULL)
	{
		presult =
		    AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, ERR_INVALID_PARAMETER, CMD_ERROR_CODE_TYPE_CME, 0, 0, 0, pParam->nDLCI);
		AT_Notify2ATM(presult, pParam->nDLCI);

		if (presult != NULL)
		{
			AT_FREE(presult);
			presult = NULL;
		}

		return;
	}
	else
	{
		switch (pParam->iType)
		{

		case AT_CMD_SET:
			eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);
			AT_TC(g_sw_GC, "iCount =%ld\n\r", iCount);

			if (eResult == ERR_SUCCESS)
			{
				if (iCount != 2)
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				}
				else
				{
					len     = 4;
					eResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT32, (PVOID)(&nFormat), &len);
					AT_TC(g_sw_GC, "nFormat =%ld\n\r", nFormat);
					eResult1 = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT32, (PVOID)(&nParity), &len);
					AT_TC(g_sw_GC, "nParity =%ld\n\r", nParity);

					if ((ERR_SUCCESS != eResult) || (ERR_SUCCESS != eResult1))
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}
					else
					{

#ifdef AT_DUAL_SIM
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
						COS_Sleep(50);
						uart_SetCfgFormat(nFormat);
						uart_SetParity(nParity);
						AT_UartReopen(ds_low);
						return;

					}
				}

			}
			else
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			}
			break;

		case AT_CMD_TEST:
			memset(send_msg, 0, 108);
			AT_Sprintf(send_msg, "+ICF:(0-6),(0-3)");
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, send_msg, AT_StrLen(send_msg), pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, send_msg, AT_StrLen(send_msg), pParam->nDLCI);
#endif
			break;

		case AT_CMD_READ:
			AT_Sprintf(send_msg, "+ICF: %u, %u", uart_GetCfgFormat(), uart_GetCfgParity());
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, send_msg, AT_StrLen(send_msg), pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, send_msg, AT_StrLen(send_msg), pParam->nDLCI);
#endif
			break;

		default:
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			break;
		}
	}

}

// [+]2007.11.13 AT+IPR
VOID AT_GC_CmdFunc_IPR(AT_CMD_PARA *pParam)
{
	INT32 eResult;
	UINT32 nRate;
	UINT8 iCount = 0;
	UINT8 len    = 0;
	UINT8 send_msg[108];

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}
	else
	{
		switch (pParam->iType)
		{

		case AT_CMD_SET:
			eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);

			if (eResult == ERR_SUCCESS)
			{
				if (iCount != 1)
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				}
				else
				{
					len     = 4;
					eResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT32, (PVOID)(&nRate), &len);

					if (ERR_SUCCESS != eResult) // ??nRate possible value is check??(nRate> 2)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}
					else
					{
						if (nRate >= UART_BAUD_RATE_2400 && nRate <= UART_BAUD_RATE_921600)
						{
							AT_TC(g_sw_GC, "@ AT+IPR: SET COMMADN  new baudrate=%ld\n\r", uart_GetCfgBaudrate());

							// if(NULL == ((AT_CMD*)(*AT_GetCommandList())->pNext))
							// {
#ifdef AT_DUAL_SIM
							AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
							AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
							COS_Sleep(50);  // [+]bug7094
							uart_SetCfgBaudrate((UART_BAUDRATE) nRate);

							// TODO: ����һ��Ҫ����һ��״̬!!!!!!!!!!!!!
							AT_UartReopen(ds_low);
							return;

							// }
#if 0
							else
							{
								AT_ClearCommandList();
								AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
								uart_SetCfgBaudrate((UART_BAUDRATE) nRate);

								// TODO: ����һ��Ҫ����һ��״̬!!!!!!!!!!!!!
								AT_UartReopen();
								return;
							}

#endif
						}

						else
						{
#ifdef AT_DUAL_SIM
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
							return;
						}

					}
				}

			}
			else
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			}

			break;

		case AT_CMD_TEST:
			memset(send_msg, 0, 108);
			AT_Sprintf(send_msg, "(),(2400,4800,9600,14400,19200,28800,33600,38400,57600,115200)");
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, send_msg, AT_StrLen(send_msg), pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, send_msg, AT_StrLen(send_msg), pParam->nDLCI);
#endif
			break;

		case AT_CMD_READ:
			AT_Sprintf(send_msg, "+IPR: %u", uart_GetCfgBaudrate());
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, send_msg, AT_StrLen(send_msg), pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, send_msg, AT_StrLen(send_msg), pParam->nDLCI);
#endif
			break;

		default:
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			break;
		}
	}

	return;
}

VOID AT_GC_CmdFunc_IFC(AT_CMD_PARA *pParam)
{
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
#ifdef AT_DUAL_SIM
	AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
	AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
	// TODO .....
	return;

}
VOID AT_GC_CmdFunc_QIFC(AT_CMD_PARA *pParam)
{
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
#ifdef AT_DUAL_SIM
	AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
	AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
	// TODO .....
	return;

}

// CSW Phone active status operations
#define AT_ACTIVE_STATUS_READY            0
#define AT_ACTIVE_STATUS_UNAVAILABLE      1
#define AT_ACTIVE_STATUS_UNKNOWN          2
#define AT_ACTIVE_STATUS_RINGING          3
#define AT_ACTIVE_STATUS_CALL_IN_PROGRESS 4
#define AT_ACTIVE_STATUS_ASLEEP           5


UINT32 AT_GetPhoneActiveStatus(UINT8 nSim)
{

	UINT32 ret = AT_ACTIVE_STATUS_UNKNOWN;

#if 0 // ZXB

	if (AT_GetCommandTable() != NULL)
	{
		ret = AT_ACTIVE_STATUS_READY;
	}
	else
	{
		ret = AT_ACTIVE_STATUS_UNAVAILABLE;
	}

#else
	ret = AT_ACTIVE_STATUS_READY;

#endif

	switch (CFW_CcGetCallStatus(nSim))
	{

	case 0x01: // case CC_STATE_ACTIVE:

	case 0x02: // case CC_STATE_HOLD:

	case 0x40: // case CC_STATE_RELEASE:
	{
		ret = AT_ACTIVE_STATUS_CALL_IN_PROGRESS;
		break;
	}

	case 0x04: // case CC_STATE_WAITING:

	case 0x08: // case CC_STATE_INCOMING:

	case 0x10: // case CC_STATE_DIALING:

	case 0x20: // case CC_STATE_ALERTLING:
	{
		ret = AT_ACTIVE_STATUS_RINGING;
		break;
	}

	default:
		break;
	}

	return ret;
}

// AT_20071123_CAOW_B,reopen by wulc 2012.02.14
VOID AT_GC_CmdFunc_CPAS(AT_CMD_PARA *pParam)
{
	UINT8 res[10]     = { 0 };
	UINT16 PhoneState = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	AT_TC(g_sw_GC, "AABB----------SPAS CmdType : %d----------\n", pParam->iType);

	switch (pParam->iType)
	{

	case AT_CMD_EXE:
		// copy result info & Create success result
#ifdef AT_DUAL_SIM
		PhoneState = AT_GetPhoneActiveStatus(nSim);
#else
		PhoneState = AT_GetPhoneActiveStatus();
#endif

		if (PhoneState == AT_ACTIVE_STATUS_READY ||
		        PhoneState == AT_ACTIVE_STATUS_UNAVAILABLE ||
		        PhoneState == AT_ACTIVE_STATUS_UNKNOWN ||
		        PhoneState == AT_ACTIVE_STATUS_RINGING || PhoneState == AT_ACTIVE_STATUS_CALL_IN_PROGRESS)
		{
			AT_MemZero(res, 10);
			AT_Sprintf(res, "+CPAS:%u", PhoneState);
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, res, AT_StrLen(res), pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, res, AT_StrLen(ress), pParam->nDLCI);
#endif
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		}
		break;

	case AT_CMD_TEST:  // AT+CPAS=?
		// copy result info & Create success result
		AT_MemZero(res, 10);
		AT_Sprintf(res, "+CPAS:0,1,3,4");
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, res, AT_StrLen(res), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, res, AT_StrLen(ress), pParam->nDLCI);
#endif
		break;

	default:
		// CMD type error, Create error result
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_SUPPORTED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_SUPPORTED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		break;
	}

	AT_TC(g_sw_GC, "AABB----------CPAS Cmd END------------\n");
}

// AT_20071123_CAOW_E

/**************************************************************************************************
 * @fn
 *
 * @brief
 *
 * @param
 *
 * @return
 **************************************************************************************************/
VOID AT_GC_CmdFunc_CIND(AT_CMD_PARA *pParam)
{
	// CFW_IND_EVENT_INFO                                 IndInfo;
	UINT8 sz_result[200] = { 0 };

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	AT_TC(g_sw_GC, "----------CIND CmdType : %d----------\n", pParam->iType);

	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{

	case AT_CMD_SET: // +CIND=[<ind>[,<ind>[,...]]]
	{
		INT32 eResult;
		UINT8 iParaCount = 0;
		UINT8 TEMP[10];
		UINT8 i = 0;
		UINT8 nParaLen[10];
		UINT16 nIndId = 0;

		eResult = AT_Util_GetParaCount(pParam->pPara, &iParaCount);
		if ((eResult != ERR_SUCCESS) || 10 < iParaCount)  // || 0 > iParaCount)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}
		AT_MemZero(TEMP, sizeof(TEMP));

		for (i = 0; i < 10; i++)
		{
			nParaLen[i] = 1;
		}

		for (i = 0; i < iParaCount; i++)
		{
			eResult = AT_Util_GetParaWithRule(pParam->pPara, i, AT_UTIL_PARA_TYPE_UINT8, &TEMP[i], &nParaLen[i]);

			// if para is null , set nParaLen[i] = 0;
			if (eResult == ERR_AT_UTIL_CMD_PARA_NULL)
			{
				nParaLen[i] = 0;
			}

			if (((eResult != ERR_SUCCESS) && (eResult != ERR_AT_UTIL_CMD_PARA_NULL)) || (TEMP[i] > 1))  // || TEMP[i]<0))
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}
		}

		eResult = CFW_CfgGetIndicatorEvent(&nIndId, nSim);
		if (eResult == ERR_SUCCESS)
		{
			for (i = 0; i < 10; i++)
			{
				if (1 != nParaLen[i]) // if para is null ,get csw value
					TEMP[i] = (nIndId & ((UINT16)0x01 << i)) || 0;
			}

			nIndId = 0;
			for (i = 0; i < 10; i++)
			{
				nIndId |= (UINT16)TEMP[i] << i;
			}

			eResult = CFW_CfgSetIndicatorEvent(nIndId, nSim);

			if (eResult == ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
				return;
			}
			else
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}

		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}
		break;
	}

	case AT_CMD_READ:  // AT+CIND?
	{

		UINT8 nBatteryCharge = 0;
		UINT8 nSignal        = 0;
		UINT8 nService       = 0;
		BOOL bCall           = FALSE;
		BOOL bSounder        = FALSE;
		UINT8 nMessage       = 0;
		UINT8 nRoam          = 0;
		UINT8 nSmsfull       = 0;

		AT_TC(g_sw_GC, "----------CIND CmdType : %d----------\n", pParam->iType);

		// get battery chareg level

//		if (!AT_CIND_GetBattery(&nBatteryCharge))
//		{
//#ifdef AT_DUAL_SIM
//			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
//#else
//			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
//#endif
//			return;
//		}

		// get sounder & call ind
		if (!AT_CIND_GetCC(&bCall, &bSounder))
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		// get signal & service & roam  ind
#ifdef AT_DUAL_SIM
		if (!AT_CIND_NetWork(&nSignal, &nService, &nRoam, pParam->nDLCI, nSim))
#else
		if (!AT_CIND_NetWork(&nSignal, &nService, &nRoam, pParam->nDLCI))
#endif
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		// get sms-receive & sms-full ind
#ifdef AT_DUAL_SIM
		if (!AT_CIND_SMS(&nMessage, &nSmsfull, nSim))
#else
		if (!AT_CIND_SMS(&nMessage, &nSmsfull))
#endif
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		AT_MemZero(sz_result, sizeof(sz_result));

		AT_Sprintf(sz_result, "+CIND: %u,%u,%u,%d,%u,%d,%u,%u", nBatteryCharge, nSignal, nService, bSounder, nMessage,
		           bCall, nRoam, nSmsfull);
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, sz_result, AT_StrLen(sz_result), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, sz_result, AT_StrLen(sz_result), pParam->nDLCI);
#endif

	}

	break;

	case AT_CMD_TEST:
		AT_MemZero(sz_result, sizeof(sz_result));
		AT_Sprintf(sz_result,
		           "+CIND: (\"battchg\",(0-5)),(\"signal\",(0-5)),(\"service\",(0-1)),(\"sounder\",\",(0-1)),(\"message\",(0-1)),(\"call\",(0-1)),(\"roam\",(0-1)),(\"smsfull\",(0-1))");
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, sz_result, AT_StrLen(sz_result), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, sz_result, AT_StrLen(sz_result), pParam->nDLCI);
#endif
		break;

	default: // error type
		// CMD type error, Create error result
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		break;
	}
}

//extern BOOL g_bTesting; // added by yangtt at 2008-05-05 for bug 8274

// [+]for AT^CDTMF 2007.11.12
VOID AT_GC_CmdFunc_CDTMF(AT_CMD_PARA *pParam)
{
	INT32 iRetValue;
	UINT8 uParaCount;
	UINT8 nOutputStr[36] = { 0, };
	UINT32 nRet          = 0;
	UINT8 nDTMF          = 0;
	UINT16 nDuration     = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
//	if (g_bTesting == TRUE) // added by yangtt at 2008-05-05 for bug 8274
//	{
//#ifdef AT_DUAL_SIM
//		AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
//#else
//		AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
//#endif
//		return;
//	}

	// Check [in] Param
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}
	else
	{
		switch (pParam->iType)
		{

		case AT_CMD_SET:

			if ((pParam->pPara == NULL) || (ERR_SUCCESS != (iRetValue = AT_Util_GetParaCount(pParam->pPara, &uParaCount)))) /* GET param count */
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}
			else
			{
				// UINT8  nLen=1;
				if (uParaCount > 2 || !uParaCount)
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}

				AT_TC(g_sw_GC, "@ %s %d uParaCount = %d\n", __func__, __LINE__, uParaCount);

				AT_Util_TrimAll(pParam->pPara);

				if (uParaCount == 1)
				{
					AT_TC(g_sw_GC, "@ %s %d   AT_StrLen(pParam->pPara) = %d\n", __func__, __LINE__, AT_StrLen(pParam->pPara));

					if (AT_StrLen(pParam->pPara) != 1)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}
				}
				else if (pParam->pPara[1] != ',' && uParaCount == 2)
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}

				nDTMF = pParam->pPara[0];

				AT_TC(g_sw_GC, "@ %s %d    nDTMF = %d, %c\n\r", __func__, __LINE__, nDTMF, nDTMF);

				if (!CSW_ATCcIsDTMF(nDTMF))
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}

				AT_TC(g_sw_GC, "@ %s %d  pPara[0]=%d, pPara[1]=%d\n\r", __func__, __LINE__, pParam->pPara[0], pParam->pPara[1]);

				if (1 == uParaCount)
				{
					// nDuration = g_cc_VTD * 100;
					nDuration = gATCurrentcc_VTD * 100;
				}
				else if (2 == uParaCount)
				{
					UINT8 nLen = 2;

					iRetValue = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT16, &nDuration, &nLen);

					if (ERR_SUCCESS != iRetValue)
					{
						AT_TC(g_sw_GC, "@ AT^CDTMF:   nDuration = %d, ret = 0x%x\n\r", nDuration, iRetValue);
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}

					if (!nDuration || nDuration > 10)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						return;
					}

					nDuration *= 100;
				}

				AT_TC(g_sw_GC, "@ AT^CDTMF:   nRet = 0x%x\n\r", nRet);

				if (nDTMF == '#')
					nDTMF = DM_TONE_DTMF_S;
				else if ('*' == nDTMF)
					nDTMF = DM_TONE_DTMF_P;
				else if (nDTMF >= 'A' && nDTMF <= 'D')
					nDTMF = nDTMF - 55; // DM_TONE_DTMF_A =10, 'A'=65
				else
					nDTMF = nDTMF - 0x30;
#ifdef AT_DUAL_SIM

				iRetValue = DM_PlayTone(nDTMF, DM_TONE_m3dB, nDuration, 0);
#else
				iRetValue = DM_PlayTone(nDTMF, DM_TONE_m3dB, nDuration);

#endif

				if (ERR_SUCCESS != nRet || !iRetValue)
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(nRet, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(nRet, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				}
				else
				{
#ifdef AT_DUAL_SIM
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
					AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
				}
			}

			return;

		case AT_CMD_TEST:
			// =?
			SUL_ZeroMemory8(nOutputStr, 36);
			SUL_StrCat(nOutputStr, "^CDTMF: (0-9,*,#,A,B,C,D),(1-10)");
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, nOutputStr, AT_StrLen(nOutputStr), pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, nOutputStr, AT_StrLen(nOutputStr), pParam->nDLCI);
#endif

			return;

		default:
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CMS_OPER_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}
	}

	return;
}

// atw == atw0

VOID AT_GC_CmdFunc_AndW(AT_CMD_PARA *pParam)
{
	INT32 eResult;
	UINT8 iCount = 0;
	BOOL err_code;
	UINT8 atw_para;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	AT_TC(g_sw_GC, "AT_GC_CmdFunc_AndW");

	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
	}
	else
	{
		if (pParam->iType == AT_CMD_EXE)
		{
			eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);

			if (eResult == ERR_SUCCESS)
			{
				switch (iCount)
				{

				case 0:
					err_code = at_CfgSetAtSettings(iCount);

					if (TRUE == err_code)
					{
#ifdef AT_DUAL_SIM
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
					}
					else
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					}

					AT_TC(g_sw_GC, "at_CfgSetAtSettings=0x%x, ", err_code);

					break;

				case 1:
					eResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &atw_para, &iCount);

					if (ERR_SUCCESS == eResult)
					{
						if (0 != atw_para)
						{
#ifdef AT_DUAL_SIM
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						}
						else
						{
							err_code = at_CfgSetAtSettings(atw_para);

							if (TRUE == err_code)
							{
#ifdef AT_DUAL_SIM
								AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
								AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
							}
							else
							{
#ifdef AT_DUAL_SIM
								AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
								AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
							}
						}

					}
					else
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					}
					break;

				default:
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					break;
				}
			}
			else
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			}
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		}
	}

	return;
}

// at&f == at&f0

VOID AT_GC_CmdFunc_AndF(AT_CMD_PARA *pParam)
{
	INT32 eResult;
	UINT8 iCount = 0;
	BOOL err_code;
	UINT8 atf_para;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
	}
	else
	{
		if (pParam->iType == AT_CMD_EXE)
		{
			eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);

			if (eResult == ERR_SUCCESS)
			{
				switch (iCount)
				{

				case 0:
					err_code = at_CfgGetAtSettings(MANUFACTURER_DEFALUT_SETING, NULL);

					if (TRUE != err_code)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					}
					else
					{
#ifdef AT_DUAL_SIM
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
					}
					break;

				case 1:
					eResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &atf_para, &iCount);

					if (ERR_SUCCESS == eResult)
					{
						if (0 != atf_para)
						{
#ifdef AT_DUAL_SIM
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
							return; // added by yangtt at 2008-5-30 for bug 8603
						}

					}
					else
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					}

					err_code = at_CfgGetAtSettings(MANUFACTURER_DEFALUT_SETING, NULL);

					if (TRUE != err_code)
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					}
					else
					{
#ifdef AT_DUAL_SIM
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
					}

					break;

				default:
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

					break;
				}
			}
			else
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			}
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		}
	}

	return;
}

// ATZ == ATZ0
//#include "dbg.h"
VOID AT_GC_CmdFunc_Z(AT_CMD_PARA *pParam)
{
	INT32 eResult;
	UINT8 iCount   = 0;
	UINT8 atz_para = 0;
	BOOL err_code;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	//DBG_ASSERT(0,"Z COMMAND");
	if (pParam == NULL)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
	}
	else
	{
		if (pParam->iType == AT_CMD_EXE)
		{
			eResult = AT_Util_GetParaCount(pParam->pPara, &iCount);

			if (eResult == ERR_SUCCESS)
			{
				switch (iCount)
				{

				case 0:
#ifdef CHIP_HAS_AP
					err_code = TRUE;
#else
					err_code = at_CfgGetAtSettings(USER_SETTING_1, atz_para);
#endif
					AT_TC(g_sw_GC, "=======ERRCODE =%d\n", err_code);
					//err_code = TRUE;
					if (TRUE == err_code)
					{
#ifdef AT_DUAL_SIM
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
						AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
					}
					else
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					}

					break;

				case 1:
					eResult = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &atz_para, &iCount);

					if (ERR_SUCCESS == eResult)
					{
						if (0 != atz_para)
						{
#ifdef AT_DUAL_SIM
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
							AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
						}
						else
						{
#ifdef CHIP_HAS_AP
							err_code = TRUE;
#else
							err_code = at_CfgGetAtSettings(USER_SETTING_1, atz_para);
#endif

							if (TRUE == err_code)
							{
#ifdef AT_DUAL_SIM
								AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
								AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
							}
							else
							{
#ifdef AT_DUAL_SIM
								AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
								AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
							}
						}
					}
					else
					{
#ifdef AT_DUAL_SIM
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
						AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					}

					break;

				default:
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					break;
				}
			}
			else
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			}
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		}
	}

	return;
}

//
// FUNCTION: AT_CC_CmdFunc_S0
//
// DESCRIPTION:
// The Implementation of AT Command REQ,
// config the count of which the call rings, MT should auto answer the call.
// config function should record the value
// This Function will process all related asynchronous operations to other
// software layers(DMS,DSS,TAPI,APS,...).
// CoolStudio REQ Event: <NO REQ EVENT>
// AT Command      : S0
// AT Command Type : 2. Configuration Commands(CFG)
// At Command Mask : 0
// /////////////////////////////////////////////
// the definition of S0 is gATCurrentcc_s0
// //////////////////////////////////////////////
// ARGUMENTS:
//
// RETURN:
//
// COMMENTS:
//
VOID AT_GC_CmdFunc_S0(AT_CMD_PARA *pParam)
{
	UINT8 strS0[12];
	UINT8 ucLen;
	UINT8 ucParaCount = 0;
	UINT32 uRetVal    = ERR_SUCCESS;
	UINT8 uParam      = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	// parameter check

	if (NULL == pParam)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	AT_TC(g_sw_GC, "Parameter string: %s  Parameter type: %d\n", pParam->pPara, pParam->iType);

	// init param
	memset(strS0, 0, 24);

	// at command type judge

	switch (pParam->iType)
	{
		// extend command (set)

	case AT_CMD_SET:
	{
		// get param count, check the input string
		uRetVal = AT_Util_GetParaCount(pParam->pPara, &ucParaCount);

		// result check

		if (ERR_SUCCESS != uRetVal || ucParaCount > 1)
		{
			// return parameter error
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			break;
		}

		// none param input, just return OK
		if (!ucParaCount)
		{
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
			break;
		}

		// first parameter
		ucLen = SIZEOF(UINT8);

		uRetVal = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, (PVOID)&uParam, &ucLen);

		if (ERR_SUCCESS != uRetVal)
		{
			// return parameter error
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_INVALID_CHAR_INTEXT, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

			break;
		}

		AT_TC(g_sw_GC, "Para count:%d Parameter 1: %d\n", ucParaCount, uParam);

		gATCurrentcc_s0 = uParam;

		if (ERR_SUCCESS != uRetVal)
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
		}
	}

	break;

	// extend command (test)

	case AT_CMD_TEST:
		// return command format "0-255"
		SUL_StrCopy(strS0, "0-255");
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, strS0, AT_StrLen(strS0), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, strS0, AT_StrLen(strS0), pParam->nDLCI);
#endif
		break;

		// extend command (read)

	case AT_CMD_READ:
		// get stored value from config function
		uParam = gATCurrentcc_s0;

		// output debug information
		AT_TC(g_sw_GC, "ATS0 read ret: %x\n", uRetVal);

		// execute result return

		if (ERR_SUCCESS == uRetVal)
		{
			SUL_StrPrint(strS0, "%d", uParam);
#ifdef AT_DUAL_SIM
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, strS0, AT_StrLen(strS0), pParam->nDLCI, nSim);
#else
			AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, strS0, AT_StrLen(strS0), pParam->nDLCI);
#endif
		}
		else
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		}

		break;

		// error command type

	default:
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif

		break;

	}

	return;
}

VOID AT_GC_CmdFunc_EGMR(AT_CMD_PARA *pParam)
{
	UINT8 uParaCount = 0;
	UINT32 eParamOk  = 0;
	UINT8 uCommand   = 0;
	UINT8 imeisize   = 0;
	UINT8 imei[40]   = { 0 };
	UINT8 uStrLen    = 0;
	UINT8 arrRes[50];
	UINT8 Revtype = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	AT_MemZero(arrRes, sizeof(arrRes));

	if (pParam == NULL)
	{

#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
		return;
	}

	if (pParam->iType == AT_CMD_TEST)
	{

		AT_Sprintf(arrRes, "+EGMR: (0,1),(7)");
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, sizeof(arrRes), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, sizeof(arrRes), pParam->nDLCI);
#endif
		return;
	}
#if 0
	else if (pParam->iType == AT_CMD_READ)
	{
		CFW_EmodGetIMEI(imei, &imeisize, nSim);
		AT_Sprintf(arrRes, "+EGMR:%s", imei);

#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, sizeof(arrRes), pParam->nDLCI, nSim);
#else
		AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, sizeof(arrRes), pParam->nDLCI);
#endif
		return;
	}
#endif
	else if (pParam->iType == AT_CMD_SET)
	{
		if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
		{

#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}

		/* check para count */
		if ((2 > uParaCount) || (3 < uParaCount))
		{
#ifdef AT_DUAL_SIM
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
			AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
			return;
		}
		if (uParaCount == 2)
		{
			/* get all param */
			uStrLen = 1;

			eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uCommand, &uStrLen);

			if (eParamOk != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}
			if (uCommand != 0)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;

			}
			uStrLen  = 1;
			eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &Revtype, &uStrLen);

			if (eParamOk != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}
			if (Revtype == 7)
			{
				CFW_EmodGetIMEI(imei, &imeisize, nSim);
				AT_Sprintf(arrRes, "+EGMR:%s", imei);

#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, sizeof(arrRes), pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, arrRes, sizeof(arrRes), pParam->nDLCI);
#endif
				return;

			}
			else
			{
				AT_Sprintf(arrRes, "The function is not support !");

#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, arrRes, sizeof(arrRes), pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, arrRes, sizeof(arrRes), pParam->nDLCI);
#endif
				return;
			}

		}
		else if (uParaCount == 3)
		{
			/* get all param */
			uStrLen = 1;

			eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uCommand, &uStrLen);

			if (eParamOk != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}
			if (uCommand != 1)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;

			}
			uStrLen  = 1;
			eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &Revtype, &uStrLen);

			if (eParamOk != ERR_SUCCESS)
			{
#ifdef AT_DUAL_SIM
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
				AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
				return;
			}
			if (Revtype == 7)
			{
				uStrLen  = 40;
				eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_STRING, imei, &uStrLen);

				if (eParamOk != ERR_SUCCESS)
				{
#ifdef AT_DUAL_SIM
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
					AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
					return;
				}
#ifdef AT_DUAL_SIM
				CFW_EmodSaveIMEI(imei, AT_StrLen(imei), nSim);
#else
				CFW_EmodSaveIMEI(imei, AT_StrLen(imei));
#endif
#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, 0, 0, pParam->nDLCI);
#endif
				return;

			}
			else
			{
				AT_Sprintf(arrRes, "The function is not support !");

#ifdef AT_DUAL_SIM
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, arrRes, sizeof(arrRes), pParam->nDLCI, nSim);
#else
				AT_Result_OK(CMD_FUNC_SUCC, CMD_RC_CR, 0, arrRes, sizeof(arrRes), pParam->nDLCI);
#endif
				return;
			}

		}
		return;
	}
	else
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}
}

UINT16 gc_GetCfgInfo_IndCtrlMask(VOID)
{
	return gAtCurrentSetting.g_CfgInfo.ind_ctrl_mask;
}

BOOL gc_SetCfgInfo_IndCtrlMask(UINT16 mask)
{
	/*
	   @RUBY STYLE PSEUDOCODE@
	   set the new mask to g_CfgInfo
	   update g_CfgInfo into flash
	   * */
	gAtCurrentSetting.g_CfgInfo.ind_ctrl_mask = mask;

	if (at_CfgSetAtSettings(1) == TRUE)
	{
		AT_TC(g_sw_GC, "Succeeded to save configuration information into flash.");
		return TRUE;
	}
	else
	{
		AT_TC(g_sw_GC, "Failed to save configuration information into flash!");
		return FALSE;
	}
}

at_chset_t cfg_GetMtChset(void)
{
	return gAtCurrentSetting.g_CfgInfo.mt_chset;
}

at_chset_t cfg_GetTeChset(void)
{
	return gAtCurrentSetting.g_CfgInfo.te_chset;
}

void cfg_SetTeChset(at_chset_t chset)
{
	AT_ASSERT(chset >= cs_gsm && chset < cs_COUNT_);
	gAtCurrentSetting.g_CfgInfo.te_chset = chset;

	if (at_CfgSetAtSettings(1) == TRUE)
		AT_TC(g_sw_GC, "Save configuration informaton okay.");
	else
		AT_TC(g_sw_GC, "Save configuration informaton failed.");
}
UINT8 g_set_ACLB = 0;
UINT8 g_ACLB_FM   = CFW_CHECK_COMM;
UINT8 g_ACLB_SIM1_FM   = CFW_CHECK_COMM;
//extern BOOL g_auto_calib;
BOOL g_auto_calib;
VOID AT_GC_CmdFunc_ACLB(AT_CMD_PARA *pParam)
{
	CFW_COMM_MODE nMode;
	UINT32 uRetVal    = ERR_SUCCESS;
	AT_TC(g_sw_GC, "ACLB: start!\n");
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
	if(1 == nSim)
	{
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_SUPPORTED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
		return ;
	}

#endif

	if (NULL == pParam)
	{
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_MEMORY_FAILURE, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		return;
	}

	switch (pParam->iType)
	{
	case AT_CMD_EXE:
	{
#ifdef AT_DUAL_SIM
		CFW_GetComm( &nMode , nSim);

		g_ACLB_FM = nMode;
		g_set_ACLB = 1 ;
		//hal_HstSendEvent(0xaabbff01);
		//hal_HstSendEvent(nMode);
		if(CFW_DISABLE_COMM == nMode)
		{
			g_auto_calib = TRUE;
			g_set_ACLB = 2;
			uRetVal = CFW_SetComm(CFW_ENABLE_COMM , 0, pParam->nDLCI, nSim);
		}
		else
		{
			g_auto_calib = TRUE;
			uRetVal = CFW_SetComm(CFW_DISABLE_COMM , 0, pParam->nDLCI, nSim);
		}
		///close anther sim
		CFW_GetComm( &nMode , 1);
		g_ACLB_SIM1_FM = nMode;
		if(CFW_ENABLE_COMM == nMode)
		{
			uRetVal = CFW_SetComm(CFW_DISABLE_COMM , 0, pParam->nDLCI, 1);
		}
#endif
#ifdef AT_DUAL_SIM
		AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 255, 0, 0, pParam->nDLCI, nSim);//10s
#else
		AT_Result_OK(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, 255, 0, 0, pParam->nDLCI);
#endif

	}
	break;
	case AT_CMD_TEST:
		//break;
	case AT_CMD_READ:
		//break;

	default:
#ifdef AT_DUAL_SIM
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI, nSim);
#else
		AT_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
#endif
		break;

	}

	return;
}

// ///////////////////////////////////////////////////////////////////////////////
// The end of the file
// ///////////////////////////////////////////////////////////////////////////////

