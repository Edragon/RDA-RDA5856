/*********************************************************
 *
 * File Name
 *	at_cmd_special_emod.h
 * Author
 * 	Felix
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 *
 *********************************************************/

#ifndef _AT_CMD_EX_GPS_H_
#define _AT_CMD_EX_GPS_H_

#ifdef __cplusplus
extern "C" {
#endif

  /**************************************************************************************************
	 *                                          INCLUDES
	 **************************************************************************************************/
#  include "at_common.h"

#if defined(__AT_GPS__)
  VOID AT_EMOD_CmdFunc_GPS(AT_CMD_PARA *pParam);
  VOID AT_EMOD_CmdFunc_GPS_Sleep(AT_CMD_PARA *pParam);  
  VOID AT_EMOD_CmdFunc_GPS_Send(AT_CMD_PARA *pParam);
  VOID AT_EMOD_CmdFunc_GPS_I2C(AT_CMD_PARA *pParam);  
  VOID AT_EMOD_CmdFunc_GPS_AGPS(AT_CMD_PARA *pParam);
#endif
  /* 
   *
   */

  /**************************************************************************************************
	**************************************************************************************************/

#ifdef __cplusplus
}
#endif
#endif
