/*********************************************************
 *
 * File Name
 *	at_cmd_special_flash.h
 * Author
 * 	Felix
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 *
 *********************************************************/

#ifndef _AT_CMD_EX_FLASH_H_
#define _AT_CMD_EX_FLASH_H_

#ifdef __cplusplus
extern "C" {
#endif

	/**************************************************************************************************
	 *                                          INCLUDES
	 **************************************************************************************************/
#  include "at_common.h"

	/**************************************************************************************************
	 *                                         CONSTANTS
	 **************************************************************************************************/

	/**************************************************************************************************
	 *                                          MACROS
	 **************************************************************************************************/
	//
	// ERROR
	//
#define AT_EX_FAIL_CreateRC(pResult,errCode,errorType,delayTime,pBuff,dataSize ,nDLCI)\
	do{                                                                                            \
		pResult = AT_CreateRC(CMD_FUNC_FAIL,CMD_RC_ERROR,errCode,errorType,delayTime,pBuff,dataSize,nDLCI);\
	} while(0)

	//
	// SUCCESS
	//
#define AT_EX_SUCC_CreateRC(pResult,delayTime,pBuff,dataSize,nDLCI)\
	do{\
		pResult = AT_CreateRC(CMD_FUNC_SUCC,CMD_RC_OK,CMD_ERROR_CODE_OK,CMD_ERROR_CODE_TYPE_CME,delayTime,pBuff,dataSize,nDLCI);\
	}while(0)

	//
	// success,need waite asyn
	//
#define AT_EX_SUCC_ASYN_CreateRC(pResult,delayTime,pBuff,dataSize,nDLCI)\
	do{\
		pResult = AT_CreateRC(CMD_FUNC_SUCC_ASYN,CMD_RC_OK,CMD_ERROR_CODE_OK,CMD_ERROR_CODE_TYPE_CME,delayTime,pBuff,dataSize,nDLCI);\
	}while(0)

#define AT_EX_MONI_TIM_ID         20
#define AT_EX_MONP_TIM_ID         21

	/**************************************************************************************************
	 *                                         TYPEDEFS
	 **************************************************************************************************/

	/**************************************************************************************************
	 *                                     GLOBAL VARIABLES
	 **************************************************************************************************/

	/**************************************************************************************************
	 *                                     FUNCTIONS - API
	 **************************************************************************************************/

	/**************************************************************************************************
	**************************************************************************************************/

#ifdef __cplusplus
}
#endif
#endif
