#ifndef AT_CMD_CFG_H
#define AT_CMD_CFG_H

#include "cfw.h"

// /////////////////////////////////////////////////////////////////////////////////////
// At default setttings (Manufacture specific)
// /////////////////////////////////////////////////////////////////////////////////////
#define AT_ASCII_CR 	13
#define AT_ASCII_LF 	10
#define AT_ASCII_BS 	8
#define RECEIVE_GAIN 	6
#define TRANSMIT_GAIN	1
// 10
#define	IND_CTRL_MASK	0
#define	TE_CHEST	cs_gbk
#define	MT_CHSET	cs_gbk
#define DISABLE_CMEE_ERROR 	1
#define DURATION_OF_TONE 	1
#define OPER_FORMAT_NUMERIC 	2
#define AUTOMATIC_REGISTER 	0
#define MONP_DISPLAY_PERIOD 	10
#define MONI_DISPLAY_PERIOD 	10
#define DISABLE_UPLINK_VOICE  	0
#define OPERATOR_NUMBER_ORDER 	100
// Random value
#define NO_INDICATOR_EVENT_REPORT 	0
#define DISABLE_AUTOMATIC_ANSWERING 	0
#define PHONEBOOK_MEMORY_STORAGE 	CFW_PBK_SIM
#define CLIR_PRESENTION_INDICATOR 	0
#define DISABLE_CSSU_RESULT_CODE 	0
#define DISABLE_CSSI_RESULT_CODE 	0
#define DISABLE_RESULT_CODE_PRESENTION_STATUS 	0

// ////////////////////////////////////////////////////////////////////////////////////////

#define RESULT_CODE_PRESENTATION_DEFUALT_VAL 	GC_RESULTCODE_PRESENTATION_ENABLE
#define RESULT_CODE_FORMAT_DEFUALT_VAL		GC_RESULTCODE_FORMAT_VERBOSE
#define COMMAND_ECHO_MODE_DEFUALT_VAL 		GC_COMMANDECHO_MODE_ENABLE
#define NS3_DEFUALT_VAL				AT_ASCII_CR
#define NS4_DEFUALT_VAL 			AT_ASCII_LF
#define NS5_DEFUALT_VAL 			AT_ASCII_BS

#define	CFG_INFO_IND_CTRL_MASK_DEFAULT_VAL	IND_CTRL_MASK
#define	CFG_INFO_TE_CHEST_DEFAULT_VAL		TE_CHEST
#define	CFG_INFO_MT_CHSET_DEFAULT_VAL		MT_CHSET

#define CMEE_DEFAULT_VAL			DISABLE_CMEE_ERROR
#define CMR_IND_DEFAULT_VAL 			NO_INDICATOR_EVENT_REPORT
#define CC_VTD_DEFUALT_VAL			DURATION_OF_TONE
#define CC_S0_DEFUALT_VAL 			DISABLE_AUTOMATIC_ANSWERING
#define	OPER_FORAMT_DEFAULT_VAL			OPER_FORMAT_NUMERIC
#define	COPS_MODE_DEFUALT_VAL			AUTOMATIC_REGISTER
#define	PREFERED_OPER_FROMAT_DEFUALT_VAL	NW_PREFERRED_OPERATOR_FORMAT_NUMERIC
// UINT8 g_arrPreferredOperater[6];      //TODO..

extern UINT8 g_arrPreferredOperater[];

#define	ARR_PREFERRED_OPER_DEFUALT_VAL		(&g_arrPreferredOperater[0])
#define	PREFERRED_OPER_INDEX_DEFUALT_VAL	OPERATOR_NUMBER_ORDER
#define	GET_PREFERRED_OPER_CALLER_DEFAULT_VAL 	NW_GETPREFERREDOPERATORS_CALLER_READ

// pbk related
#define	PBKLIST_ENTRY_CALLER_DEFAULT_VAL	PBK_LISTENTRY_CALLER_CPBR
#define	PBK_CHARSET_DEFUALT_VAL			PBK_CHARACTER_SET_TRANSPARENT
#define	CPBS_DEFUALT_VAL			PHONEBOOK_MEMORY_STORAGE

// sat related
#define	ALPHABET_DEFUALT_VAL			UCS2_SET

// TODO..sms related
#define	g_pAtSmsSetting = ;

// ss related
#define	CALL_WAITING_PRESENTATION_RESULT_CODE_DEFUALT_VAL   DISABLE_RESULT_CODE_PRESENTION_STATUS
// CCWA �����õ���cfg
#define	SS_USSD_DEFUALT_VAL 			DISABLE_RESULT_CODE_PRESENTION_STATUS
// URC control signal
#define	CLIP_DEFUALT_VAL			DISABLE_RESULT_CODE_PRESENTION_STATUS
#define	CLIR_DEFAULT_VAL			CLIR_PRESENTION_INDICATOR
#define	COLP_DEFUALT_VAL			DISABLE_RESULT_CODE_PRESENTION_STATUS
#define	CSSU_DEFUALT_VAL			DISABLE_CSSU_RESULT_CODE
#define	CSSI_DEFUALT_VAL			DISABLE_CSSI_RESULT_CODE

// special related
#define	MONI_DEFUALT_VAL			MONI_DISPLAY_PERIOD
#define	MONP_DEFUALT_VAL			MONP_DISPLAY_PERIOD
#define PM_IND_MARK_DEFAULT_VAL			PM_BATTERY_IND_DISABLE
#define	VGR_VOLUME_DEFUALT_VAL			RECEIVE_GAIN
#define	VGT_VOLUME_DEFUALT_VAL			TRANSMIT_GAIN
#define	CMUT_MUTE_DEFULT_VAL			DISABLE_UPLINK_VOICE
#define	AUDIO_TEST_MODE_DEFUALT_VAL		AT_AUDIO_TEST_EARPIECE
// g_stGain;                          //audio_cfg???

#  if 0
// /////////////////////////////////////////////////////////////////////////////////
// API to operate at settings
// /////////////////////////////////////////////////////////////////////////////////
// API to save at settings
extern bool at_CfgSetAtSettings(UINT8 set_id);

// API to get at setttings
extern bool at_CfgGetAtSettings(UINT8 flag, UINT8 set_id);
#endif

#endif
