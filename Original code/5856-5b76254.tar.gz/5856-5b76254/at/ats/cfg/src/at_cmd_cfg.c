// //////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002-2012, Coolsand Technologies, Inc.
// All Rights Reserved
//
// This source code is property of Coolsand. The information contained in this
// file is confidential. Distribution, reproduction, as well as exploitation,
// or transmission of any content of this file is not allowed except if
// expressly permitted.Infringements result in damage claims!
//
// FILENAME: at_cmd_cfg.c
//
// DESCRIPTION:
// TODO: ...
//
// REVISION HISTORY:
// NAME              DATE                REMAKS
// Lixp      2012-2-20       Created initial version 1.0
//
// //////////////////////////////////////////////////////////////////////////////

#include "at_common.h"
#include "at_module.h"
#include "at_cfg.h"
#include "at_cmd_cfg.h"
#include "fs.h"

#define __UCS2NAME__
// File to save the configurations
#ifndef __UCS2NAME__
#define AT_USER_CFG_FILE_NAME  "at_user_cfg.bin"
#else
// AT_CFG.BIN
CONST UINT8 uAtFileName[] =
{
	0x00, 0x41, 0x00, 0x54, 0x00, 0x5f, 0x00, 0x43, 0x00, 0x46, 0x00, 0x47, 0x00, 0X2E, 0X00, 0X42, 0X00, 0x49, 0x00,
	0x4e, 0x00, 0x00
};

// CONST UINT8 uAtFileName[]={0x41, 0x00,0x54,0x00,0x5f,0x00,0x43,0x00,0x46,0x00,0x47,0x00,0X2E, 0X00,0X42,0X00,0x49,0x00,0x4e,0x00,0x00,0x00};
// CONST UINT8 uAtFileName[]={0x4100, 0x5400,0x5f00,0x4300,0x4600,,0x4700,0X2E00, 0X4200,0x4900,0x4e00};
#define AT_USER_CFG_FILE_NAME  "AT_CFG.BIN"

#endif
#ifndef PCWSTR
#define PCWSTR UINT16*
#endif
// ////////////////////////////////////////////////////////////////////////////////
// Only 1 kinds of user profile settings are provided currently
#define USER_SETTINGS_NUM  1
AT_USER_SETTINGS gAtUserSettings[USER_SETTINGS_NUM];  // user settings
AT_CURRENT_SETTINGS gAtCurrentSetting;  // current settings

const AT_DEFAULT_SETTINGS gDefaultSettings =    // default setttings
{
	// gc related
	.g_eResultcodePresentation = RESULT_CODE_PRESENTATION_DEFUALT_VAL,
	.g_eResultcodeFormat       = RESULT_CODE_FORMAT_DEFUALT_VAL,
	.g_eCommandEchoMode        = COMMAND_ECHO_MODE_DEFUALT_VAL,
	.g_nS3                     = NS3_DEFUALT_VAL,
	.g_nS4                     = NS4_DEFUALT_VAL,
	.g_nS5                     = NS5_DEFUALT_VAL,
	.g_uCmee                   = CMEE_DEFAULT_VAL,
	.g_uCmer_ind               = {CMR_IND_DEFAULT_VAL, CMR_IND_DEFAULT_VAL},
	.g_CfgInfo = {
		CFG_INFO_IND_CTRL_MASK_DEFAULT_VAL, 0,
		CFG_INFO_TE_CHEST_DEFAULT_VAL,
		CFG_INFO_MT_CHSET_DEFAULT_VAL
	},

	// cc related
	.g_cc_VTD = CC_VTD_DEFUALT_VAL,
	.g_cc_s0  = CC_S0_DEFUALT_VAL,

	// nw related
	.g_OperFormat           = OPER_FORAMT_DEFAULT_VAL,
	.g_COPS_Mode_Temp       = COPS_MODE_DEFUALT_VAL,
	.g_nPreferredOperFormat = PREFERED_OPER_FROMAT_DEFUALT_VAL,

	// UINT8 g_arrPreferredOperater[6];      //TODO..
	.g_pArrPreferredOperater        = ARR_PREFERRED_OPER_DEFUALT_VAL,
	.g_nPreferredOperatorIndex      = PREFERRED_OPER_INDEX_DEFUALT_VAL,
	.g_nGetPreferredOperatorsCaller = GET_PREFERRED_OPER_CALLER_DEFAULT_VAL,

	// pbk related
	.g_pbkListEntryCaller = PBKLIST_ENTRY_CALLER_DEFAULT_VAL,
	.g_pbkCharacterSet    = PBK_CHARSET_DEFUALT_VAL,
	.g_nTempStorage       = CPBS_DEFUALT_VAL,

	// sat related
	.g_Alphabet = ALPHABET_DEFUALT_VAL,

	// TODO..sms related
	.g_AtSmsSetting                                   = {
		.g_CSMP_fo                     = 17, // [+]2007.11.20 bug 7000 TODO = 17???
		.g_CSDH_show                   = 0,  // show header
		.g_AtSMSInfo                   = {
			{
				.nStorage1     = CFW_SMS_STORAGE_SM,//Add by XP 20130130 for SMS default storage setting.
				.nStorage2     = CFW_SMS_STORAGE_SM,
#ifdef __NGUX_PLATFORM__
				.nStorage3     = CFW_SMS_STORAGE_SM,//Add by XP 20130814 for MINIGUI project AT&MMI issue.
#else
				.nStorage3     = CFW_SMS_STORAGE_MT,
#endif
				.sCnmi.nBfr    = 0,
				.sCnmi.nBm     = 0,
				.sCnmi.nDs     = 0,
				.sCnmi.nMode   = 0,
				.sCnmi.nMt     = 0,
				.nServType     = 0,
				.nOverflowCtrl = 1,
				.nOverflowMode = 0
			},
			{
				.nStorage1     = CFW_SMS_STORAGE_SM,//Add by XP 20130130 for SMS default storage setting.
				.nStorage2     = CFW_SMS_STORAGE_SM,
#ifdef __NGUX_PLATFORM__
				.nStorage3     = CFW_SMS_STORAGE_SM,//Add by XP 20130814 for MINIGUI project AT&MMI issue.
#else
				.nStorage3     = CFW_SMS_STORAGE_MT,
#endif
				.sCnmi.nBfr    = 0,
				.sCnmi.nBm     = 0,
				.sCnmi.nDs     = 0,
				.sCnmi.nMode   = 0,
				.sCnmi.nMt     = 0,
				.nServType     = 0,
				.nOverflowCtrl = 1,
				.nOverflowMode = 0
			}
		}
		,  // CPMS������صĴ洢����Ϣ
		.g_SMSFormat = 0,  // SMS Foramt: 0: PDU 1:text

	}
	,

	// ss related
	.g_ucSsCallWaitingPresentResultCode = CALL_WAITING_PRESENTATION_RESULT_CODE_DEFUALT_VAL,  // CCWA �����õ���cfg
	.g_ss_ussd                          = SS_USSD_DEFUALT_VAL, // URC control signal
	.ucClip                             = CLIP_DEFUALT_VAL,
	.ucClir                             = CLIR_DEFAULT_VAL,
	.ucColp                             = COLP_DEFUALT_VAL,
	.ucCSSU                             = CSSU_DEFUALT_VAL,
	.ucCSSI                             = CSSI_DEFUALT_VAL,

	// gprs
	.g_gprs_auto = 3, // yy [mod] 2008-4-23 for Bug ID:8185
	.g_baud_rate = UART_BAUD_RATE_115200, // added by yangtt 04-16
	// special related
	.g_u8nMONIPara    = MONI_DEFUALT_VAL,
	.g_u8nMONPPara    = MONP_DEFUALT_VAL,
	.g_nPMIndMark     = PM_IND_MARK_DEFAULT_VAL,
	.g_VGR_Volume     = VGR_VOLUME_DEFUALT_VAL,
	.g_VGT_Volume     = VGT_VOLUME_DEFUALT_VAL,
	.g_CMUT_mute      = CMUT_MUTE_DEFULT_VAL,
	.g_nAudioTestMode = AUDIO_TEST_MODE_DEFUALT_VAL,

	// g_stGain;                          //audio_cfg???
};

extern INT32 fat_OEM2Unicode(UINT8 *pszOEM, UINT16 iOLen, UINT8 *pszUnicode, UINT16 *piULen);

#define AT_Oem2Unicode fat_OEM2Unicode

// ///////////////////////////////////////////////////////////////////////////
// Configuration settings API
// ///////////////////////////////////////////////////////////////////////////
static BOOL at_WriteCfgToDisk(UINT8 set_id)
{
	INT32 iFd = -1;

	// UINT8 *pszUniName=NULL;
	// UINT16 uONSize = 0;
	// UINT32 uUNSize = 0;
	UINT32 iResult = ERR_SUCCESS;

	if (set_id >= USER_SETTINGS_NUM)
	{
		return FALSE;
	}
#ifndef  __UCS2NAME__
	uONSize = SUL_Strlen(AT_USER_CFG_FILE_NAME);

	/* we must use uniform transport mode: big ending */
	// AT_Set_MultiLanguage();
	ML_SetCodePage(ML_CP936);

	// Hameina [mod]:AT_Oem2Unicode()is replaced
	// iResult = AT_Oem2Unicode(AT_USER_CFG_FILE_NAME, uONSize, szUniName, &uUNSize);
	iResult = ML_LocalLanguage2Unicode(AT_USER_CFG_FILE_NAME, uONSize, &pszUniName, &uUNSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_GC, "Local language to Unicode failing.iResult = %d.", iResult);
		return FALSE;
	}
	iFd = FS_Open((void *)pszUniName, FS_O_RDWR, 0);
	if (iFd < 0)
	{
		AT_TC(g_sw_GC, "first open failing.h=%d", iFd);
		iFd = FS_Create((UINT16 *)pszUniName, 0);
	}

	if (iFd < 0)
	{
		AT_TC(g_sw_GC, "Open global configuration file failed,filename=%s,h=%d", AT_USER_CFG_FILE_NAME, iFd);
		AT_FREE(pszUniName);  // Hameina[+]08-05-31
		pszUniName = NULL;
		return FALSE;
	}

	// TODO.. multiple user settings need to be saved orderly,currently only one user settings,addr = fseek(set_id)
	if (FS_Write(iFd, (UINT8 *)&gAtUserSettings[set_id], sizeof(AT_GENERAL_SETTINGS)) != sizeof(AT_GENERAL_SETTINGS))
	{
		AT_TC(g_sw_GC, "File writing operation failed,filename=%s", AT_USER_CFG_FILE_NAME);
		FS_Close(iFd);
		AT_FREE(pszUniName);  // Hameina[+]08-05-31
		pszUniName = NULL;
		return FALSE;
	}

	FS_Close(iFd);
	AT_FREE(pszUniName);  // Hameina[+]08-05-31
	pszUniName = NULL;
	return TRUE;

#else

	iFd = FS_Open((void *)uAtFileName, FS_O_RDWR, 0);
	if (iFd < 0)
	{
		AT_TC(g_sw_GC, "first open failing.h=%d", iFd);
		iFd = FS_Create((PCSTR)uAtFileName, 0);
	}

	if (iFd < 0)
	{
		AT_TC(g_sw_GC, "Open global configuration file failed,filename=%s,h=%d", AT_USER_CFG_FILE_NAME, iFd);
		return FALSE;
	}

	// TODO.. multiple user settings need to be saved orderly,currently only one user settings,addr = fseek(set_id)
	iResult = FS_Write(iFd, (UINT8 *)&gAtUserSettings[set_id], sizeof(AT_GENERAL_SETTINGS));
	if (iResult != sizeof(AT_GENERAL_SETTINGS))
	{
		AT_TC(g_sw_GC, "File writing operation failed,filename=%s,iResutl = %d.", AT_USER_CFG_FILE_NAME, iResult);
		FS_Close(iFd);
		return FALSE;
	}
	else
	{
		AT_TC(g_sw_GC, "File writing operation success,filename=%s,size = %d.", AT_USER_CFG_FILE_NAME, iResult);
		FS_Close(iFd);
		return TRUE;

	}

#endif

}

static BOOL at_ReadCfgFromDisk(UINT8 set_id)
{
	INT32 h                      = 0;
	AT_GENERAL_SETTINGS cfg_buff = { 0 };

	// UINT8 * pszUniName = NULL;
	// UINT16 uSrcSize = 0;
	// UINT32 uUniSize = 0;
	UINT32 iResult  = 0;
	INT32 iFileSize = 0;

	if (set_id >= USER_SETTINGS_NUM)
	{
		return FALSE;
	}
#ifndef  __UCS2NAME__

	uSrcSize = SUL_Strlen(AT_USER_CFG_FILE_NAME);

	// Hameina [mod]:AT_Oem2Unicode()is replaced
	ML_SetCodePage(ML_CP936);

	// iResult = AT_Oem2Unicode(AT_USER_CFG_FILE_NAME,  uSrcSize, szUniName, &uUniSize);
	iResult = ML_LocalLanguage2Unicode(AT_USER_CFG_FILE_NAME, uSrcSize, &pszUniName, &uUniSize);
	if (iResult != ERR_SUCCESS)
	{
		AT_TC(g_sw_GC, "in ReadCfgFromDisk.Local language to Unicode failing.iResult = %d.", iResult);
		return FALSE;
	}

	h = FS_Open((void *)pszUniName, FS_O_RDONLY, 0);
	AT_TC(g_sw_GC, "FS_Open()=%d.", h);
	if (h < 0)
	{

		h = FS_Create((UINT16 *)pszUniName, 0);

		if (h < 0)
		{
			AT_TC(g_sw_GC, "Open global configuration file failed,filename=%s,h=%d", AT_USER_CFG_FILE_NAME, h);
			AT_FREE(pszUniName);  // Hameina[+]08-05-31
			pszUniName = NULL;
			return FALSE;
		}

		if (FS_Write(h, (UINT8 *)&gDefaultSettings, sizeof(AT_GENERAL_SETTINGS)) != sizeof(AT_GENERAL_SETTINGS))
		{
			FS_Close(h);
			AT_FREE(pszUniName);  // Hameina[+]08-05-31
			pszUniName = NULL;
			AT_TC(g_sw_GC, "File writing operation failed,filename=%s", AT_USER_CFG_FILE_NAME);
			return FALSE;
		}

		gAtCurrentSetting = gDefaultSettings;
		AT_FREE(pszUniName);  // Hameina[+]08-05-31
		pszUniName = NULL;
		return TRUE;

	}

	// also, need to consider the situation of mutiple setteing, h = fseek(set_id)
	iFileSize = FS_Read(h, (UINT8 *)&cfg_buff, sizeof(AT_GENERAL_SETTINGS));
	AT_TC(g_sw_GC, "FS_Read()=%d.", iFileSize);
	if (iFileSize == sizeof(AT_GENERAL_SETTINGS))
	{
		AT_TC(g_sw_GC, "Succeed read configuration information from file %s.", AT_USER_CFG_FILE_NAME);
		gAtCurrentSetting = cfg_buff;
	}
	else
	{
		FS_Close(h);
		AT_TC(g_sw_GC, "Read configuration information failed from file %s.", AT_USER_CFG_FILE_NAME);

		// added by yangtt to resolve the restart frequently problem at 04-23-2008  begin
		h = FS_Delete((UINT16 *)pszUniName);

		if (h < 0)
		{
			AT_TC(g_sw_GC, "FS_Delete   failed ");
			return FALSE;
		}

		h = FS_Create((UINT16 *)pszUniName, 0);

		if (h < 0)
		{
			AT_TC(g_sw_GC, "Open global configuration file failed,filename=%s,h=%d", AT_USER_CFG_FILE_NAME, h);
			return FALSE;
		}

		if (FS_Write(h, (UINT8 *)&gDefaultSettings, sizeof(AT_GENERAL_SETTINGS)) != sizeof(AT_GENERAL_SETTINGS))
		{
			FS_Close(h);
			AT_TC(g_sw_GC, "File writing operation failed,filename=%s", AT_USER_CFG_FILE_NAME);
			return FALSE;
		}

		gAtCurrentSetting = gDefaultSettings;

		return TRUE;

		// added by yangtt to resolve the restart frequently problem at 04-23-2008  end

	}

	FS_Close(h);
#else

	h = FS_Open((void *)uAtFileName, FS_O_RDONLY, 0);
	AT_TC(g_sw_GC, "FS_Open()=%d.", h);
	if (h < 0)
	{

		h = FS_Create((PCSTR)uAtFileName, 0);

		if (h < 0)
		{
			AT_TC(g_sw_GC, "Open global configuration file failed,filename=%s,h=%d", AT_USER_CFG_FILE_NAME, h);
			return FALSE;
		}
		iResult = FS_Write(h, (UINT8 *)&gDefaultSettings, sizeof(AT_GENERAL_SETTINGS));
		if (iResult != sizeof(AT_GENERAL_SETTINGS))
		{
			FS_Close(h);
			AT_TC(g_sw_GC, "File writing operation failed,filename=%s,iResult = %d.", AT_USER_CFG_FILE_NAME, iResult);
			return FALSE;
		}
		else
		{
			FS_Close(h);
			AT_TC(g_sw_GC, "File writing operation success,filename=%s,iResult = %d.", AT_USER_CFG_FILE_NAME, iResult);

		}

		gAtCurrentSetting = gDefaultSettings;
		return TRUE;

	}

	// also, need to consider the situation of mutiple setteing, h = fseek(set_id)
	iFileSize = FS_Read(h, (UINT8 *)&cfg_buff, sizeof(AT_GENERAL_SETTINGS));
	AT_TC(g_sw_GC, "FS_Read()=%d.", iFileSize);
	if (iFileSize == sizeof(AT_GENERAL_SETTINGS))
	{
		AT_TC(g_sw_GC, "Succeed read configuration information from file %s.", AT_USER_CFG_FILE_NAME);
		gAtCurrentSetting = cfg_buff;
	}
	else
	{
		FS_Close(h);
		AT_TC(g_sw_GC, "Read configuration information failed from file %s,iFileSize = %d.", AT_USER_CFG_FILE_NAME,
		      iFileSize);

		// added by yangtt to resolve the restart frequently problem at 04-23-2008  begin
		iResult = FS_Delete((PCSTR)uAtFileName);

		if (iResult != ERR_SUCCESS)
		{
			AT_TC(g_sw_GC, "FS_Delete   failed.");
			return FALSE;
		}
		else
		{
			AT_TC(g_sw_GC, "FS_Delete   success. ");

		}

		h = FS_Create((PCSTR)uAtFileName, 0);

		if (h < 0)
		{
			AT_TC(g_sw_GC, "Open global configuration file failed,filename=%s,h=%d", AT_USER_CFG_FILE_NAME, h);
			return FALSE;
		}
		iResult = FS_Write(h, (UINT8 *)&gDefaultSettings, sizeof(AT_GENERAL_SETTINGS));
		if (iResult != sizeof(AT_GENERAL_SETTINGS))
		{
			FS_Close(h);
			AT_TC(g_sw_GC, "File writing operation failed,filename=%s,iResult = %d.", AT_USER_CFG_FILE_NAME, iResult);
			return FALSE;
		}
		else
		{
			FS_Close(h);
			AT_TC(g_sw_GC, "File writing operation success,filename=%s,write return = %d.", AT_USER_CFG_FILE_NAME, iResult);

		}
		gAtCurrentSetting = gDefaultSettings;

		return TRUE;

		// added by yangtt to resolve the restart frequently problem at 04-23-2008  end

	}

	FS_Close(h);
#endif
	return TRUE;
}

// API to save at settings
BOOL at_CfgSetAtSettings(UINT8 set_id)
{
	BOOL result = TRUE;

	gAtUserSettings[set_id] = gAtCurrentSetting;
	result                  = at_WriteCfgToDisk(set_id);

	return result;
}

// API to get at setttings
BOOL at_CfgGetAtSettings(UINT8 flag, UINT8 set_id)
{
	BOOL result = FALSE;

	switch (flag)
	{

	case MANUFACTURER_DEFALUT_SETING:
		gAtCurrentSetting = gDefaultSettings;
		result            = TRUE;
		break;

	case USER_SETTING_1:

		if (at_ReadCfgFromDisk(set_id) == FALSE)
			result = FALSE;
		else
			result = TRUE;

		break;

	default:
		result = FALSE;

		break;
	}

	return result;
}
