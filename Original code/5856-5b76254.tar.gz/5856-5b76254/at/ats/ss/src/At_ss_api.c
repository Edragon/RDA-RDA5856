/*********************************************************
 *
 * File Name
 *	?
 * Author
 * 	?
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 *
 *********************************************************/

#include "at_common.h"
#include "at_module.h"
#include "At_ss_def.h"
#include "At_ss_api.h"

// ////////////////////////////////////////////////////////////////////////////
// Name:
// Description: change display to real class
//
//
// Parameter:
// Caller:
// Called:
// Return:
// Remark:
//
// ////////////////////////////////////////////////////////////////////////////
VOID AT_SsClassConvertCcfc(UINT8 ucSrcClass, UINT8 *pucDestClass)
{

	switch (ucSrcClass)
	{

	case 1:  // voice
		*pucDestClass = 11;
		break;

	case 2:  // data
		*pucDestClass = 20;
		break;

	case 4:  // fax
		*pucDestClass = 13;
		break;

	case 8:  // sms
		*pucDestClass = 16;
		break;

	default:
		*pucDestClass = 11;
		break;
	}
}

// ////////////////////////////////////////////////////////////////////////////
// Name:
// Description: change class to display
//
//
// Parameter:
// Caller:
// Called:
// Return:
// Remark:
//
// ////////////////////////////////////////////////////////////////////////////
VOID AT_SsClassConvert2Ccfc(UINT8 ucSrcClass, UINT8 *pucDestClass)
{
	AT_TC(g_sw_AT_SS, "<><><><><><>:%d\n", ucSrcClass);

	switch (ucSrcClass)
	{

	case 11: // voice
		*pucDestClass = 1;  // real value 2^0
		break;

	case 13: // fax
		*pucDestClass = 4;  // 2^1
		break;

	case 16: // sms
		*pucDestClass = 8;
		break;

	case 20: // data
		*pucDestClass = 2;
		break;

	default:
		*pucDestClass = 1;
		break;
	}
}

// ////////////////////////////////////////////////////////////////////////////
// Name:
// Description: process event respond success return
//
//
// Parameter:
// Caller:
// Called:
// Return:
// Remark:
//
// ////////////////////////////////////////////////////////////////////////////

VOID AT_SsEventSuccess(AT_CMD_RESULT **ppResult, UINT8 *pBuf, UINT8 uiBufLen, UINT8 nUTI)
{

	*ppResult = AT_CreateRC(CMD_FUNC_SUCC,
	                        CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, pBuf, uiBufLen, nUTI);
	return;
}

// ////////////////////////////////////////////////////////////////////////////
// Name:
// Description: process event response fail return
//
//
// Parameter:
// Caller:
// Called:
// Return:
// Remark:
//
// ////////////////////////////////////////////////////////////////////////////

VOID AT_SsEventFail(AT_CMD_RESULT **ppResult, UINT32 errCode, UINT8 *pBuf, UINT8 uiBufLen, UINT8 nUTI)
{

	*ppResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_ERROR, errCode, // CMD_ERROR_CODE_OK,
	                        CMD_ERROR_CODE_TYPE_CME, 0, pBuf, uiBufLen, nUTI);
	return;
}

// ////////////////////////////////////////////////////////////////////////////
// Name:
// Description: call interface fail return
//
//
// Parameter:
// Caller:
// Called:
// Return:
// Remark:
//
// ////////////////////////////////////////////////////////////////////////////

VOID AT_SsFuncFail(AT_CMD_RESULT **ppResult, UINT32 errCode, UINT8 *pBuf, UINT8 uiBufLen, UINT8 nUTI)
{
	*ppResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, errCode, CMD_ERROR_CODE_TYPE_CME, 0, pBuf, uiBufLen, nUTI);
	return;
}

// ////////////////////////////////////////////////////////////////////////////
// Name:
// Description: call interface success return
//
//
// Parameter:
// Caller:
// Called:
// Return:
// Remark:
//
// ////////////////////////////////////////////////////////////////////////////

VOID AT_SsFuncSuccess(AT_CMD_RESULT **ppResult, UINT32 returnValue, UINT8 delaytime, UINT8 *pBuf, UINT8 uiBufLen,
                      UINT8 nUTI)
{
	*ppResult = AT_CreateRC(returnValue,
	                        CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, delaytime, pBuf, uiBufLen, nUTI);
	return;
}

// ////////////////////////////////////////////////////////////////////////////
// Name:
// Description: call interface success return
//
//
// Parameter:
// Caller:
// Called:
// Return:
// Remark:
//
// ////////////////////////////////////////////////////////////////////////////

VOID AT_SsSynSuccessWithStr(AT_CMD_RESULT **ppResult, UINT8 *buf, UINT16 len, UINT8 nUTI)
{
	*ppResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, buf, len, nUTI);
	return;
}

// ////////////////////////////////////////////////////////////////////////////
// Name:
// Description:
//
//
// Parameter:
// Caller:
// Called:
// Return:
// Remark:
//
// ////////////////////////////////////////////////////////////////////////////

// =====================================================
//
// GSMBCD��,���ת�����������ֵĻ��������ڶ�Ӧ��λ��F
// ֧��'*''#''p'
// 13811189836 --> 0x31 0x18 0x11 0x98 0x38 0xF6
// ======================================================
UINT16 AT_SsAsciiToGsmBcd(UINT8 *pNumber, // input
                          UINT8 nNumberLen, UINT8 *pBCD // output should >= nNumberLen/2+1
                         )
{
	UINT8 Tmp;
	UINT32 i;
	UINT32 nBcdSize = 0;
	UINT8 *pTmp     = pBCD;

	if (pNumber == (CONST UINT8 *)NULL || pBCD == (UINT8 *)NULL)
	{
		return FALSE;
	}

	AT_MemSet(pBCD, 0, nNumberLen >> 1);

	for (i = 0; i < nNumberLen; i++)
	{
		switch (*pNumber)
		{

		case '*':
			Tmp = (UINT8)0x0A;
			break;

		case '#':
			Tmp = (UINT8)0x0B;
			break;

		case 'p':
			Tmp = (UINT8)0x0C;
			break;

		default:
			Tmp = (UINT8)(*pNumber - '0');
			break;
		}

		if (i % 2)
		{
			*pTmp++ |= (Tmp << 4) & 0xF0;
		}
		else
		{
			*pTmp = (UINT8)(Tmp & 0x0F);
		}

		pNumber++;
	}

	nBcdSize = nNumberLen >> 1;

	if (i % 2)
	{
		*pTmp |= 0xF0;
		nBcdSize += 1;
	}

	return nBcdSize;
}

// convert integer structure to float string
// pucFloatStr[out];pucLen[in/out];pstPUCTInfo[in]
BOOL SS_PPUIntStructureToFloatStr(UINT8 *pucFloatStr, UINT8 *pucLen, CFW_SIM_PUCT_INFO *pstPUCTInfo)
{
	if ((pucFloatStr == NULL) || (pstPUCTInfo == NULL) || (pucLen == NULL) || (*pucLen == 0))
	{
		return FALSE;
	}

	AT_TC(g_sw_AT_SS, "SS_PPUIntStructureToFloatStr,iEPPU --%d, iEX--%d, iSign--%d", pstPUCTInfo->iEPPU, pstPUCTInfo->iEX,
	      pstPUCTInfo->iSign);

	UINT8 arrPPU[4];

	AT_MemZero(arrPPU, sizeof(arrPPU));

	UINT16 ucBase = 1;
	UINT8 ucTemp  = sizeof(arrPPU);

	while (ucTemp-- > 0)
	{
		arrPPU[ucTemp] = ((pstPUCTInfo->iEPPU) % (ucBase * 10)) / ucBase + '0';
		ucBase *= 10;
		AT_TC(g_sw_AT_SS, "SS_PPUIntStructureToFloatStr arrPPU[%d]---%c\r\n", ucTemp, arrPPU[ucTemp]);
	}

	// suppose no begin bit, ucbegin will be 4
	UINT8 ucBegin = 4;

	for (ucTemp = 0; ucTemp < sizeof(arrPPU); ucTemp++)
	{
		AT_TC(g_sw_AT_SS, "SS_PPUIntStructureToFloatStr arrPPU[%d]---%c \r\n", ucTemp, arrPPU[ucTemp]);

		if (arrPPU[ucTemp] != '0')
		{
			ucBegin = ucTemp;
			AT_TC(g_sw_AT_SS, "SS_PPUIntStructureToFloatStr begin valid number--arrPPU[%d]---%c \r\n", ucTemp, arrPPU[ucTemp]);
			break;
		}
	}

	UINT8 ucValidSize = *pucLen - 1;

	UINT8 ucValidBitCount = sizeof(arrPPU) - ucBegin;

	AT_TC(g_sw_AT_SS, "SS_PPUIntStructureToFloatStr ucValidBitCount---%d \r\n", ucValidBitCount);

	if (ucValidBitCount == 0)
	{
		*pucLen = 1;

		if (*pucLen > ucValidSize)
		{
			AT_TC(g_sw_AT_SS, "SS_PPUIntStructureToFloatStr error---len not enough \r\n");
			return FALSE;
		}

		pucFloatStr[0] = '0';

		return TRUE;
	}

	if (pstPUCTInfo->iEX == 0)
	{

		AT_MemZero(pucFloatStr, *pucLen);

		if (ucValidBitCount == 1)
		{
			*pucLen = 1;

			if (*pucLen > ucValidSize)
			{
				AT_TC(g_sw_AT_SS, "SS_PPUIntStructureToFloatStr error---len not enough \r\n");
				return FALSE;
			}

			AT_MemCpy(pucFloatStr, &(arrPPU[ucBegin]), ucValidBitCount);
		}
		else
		{
			*pucLen = ucValidBitCount + 1;

			if (*pucLen > ucValidSize)
			{
				AT_TC(g_sw_AT_SS, "SS_PPUIntStructureToFloatStr error---len not enough \r\n");
				return FALSE;
			}

			pucFloatStr[0] = arrPPU[ucBegin];

			// dot is placed at the first position after ucBegin
			pucFloatStr[1] = '.';
			AT_MemCpy(&pucFloatStr[2], &(arrPPU[ucBegin + 1]), ucValidBitCount - 1);
		}
	}
	else
	{
		if (pstPUCTInfo->iSign == 1)
		{
			*pucLen = ucValidBitCount + pstPUCTInfo->iEX + 1;

			if (*pucLen > ucValidSize)
			{
				AT_TC(g_sw_AT_SS, "SS_PPUIntStructureToFloatStr error---len not enough \r\n");
				return FALSE;
			}

			AT_MemZero(pucFloatStr, *pucLen);

			AT_MemSet(pucFloatStr, '0', (pstPUCTInfo->iEX + 1));
			pucFloatStr[1] = '.';
			AT_MemCpy(&(pucFloatStr[pstPUCTInfo->iEX + 1]), &(arrPPU[ucBegin]), ucValidBitCount);
		}
		else if (pstPUCTInfo->iSign == 0)
		{
			AT_MemZero(pucFloatStr, *pucLen);

			// add dot

			if (pstPUCTInfo->iEX < (ucValidBitCount - 1))
			{
				*pucLen = ucValidBitCount + 1;

				if (*pucLen > ucValidSize)
				{
					AT_TC(g_sw_AT_SS, "SS_PPUIntStructureToFloatStr error---len not enough \r\n");
					return FALSE;
				}

				AT_MemCpy(pucFloatStr, &(arrPPU[ucBegin]), pstPUCTInfo->iEX + 1);

				pucFloatStr[pstPUCTInfo->iEX + 1] = '.';
				AT_MemCpy(&(pucFloatStr[pstPUCTInfo->iEX + 2]), &(arrPPU[ucBegin + pstPUCTInfo->iEX + 1]),
				          ucValidBitCount - (pstPUCTInfo->iEX + 1));
			}

			// add nothing or 0
			else
			{
				*pucLen = pstPUCTInfo->iEX + 1;

				if (*pucLen > ucValidSize)
				{
					AT_TC(g_sw_AT_SS, "SS_PPUIntStructureToFloatStr error---len not enough \r\n");
					return FALSE;
				}

				AT_MemSet(pucFloatStr, '0', *pucLen - 1);

				AT_MemCpy(pucFloatStr, &(arrPPU[ucBegin]), ucValidBitCount);
			}

		}
		else
		{
			AT_TC(g_sw_AT_SS, "SS_PPUIntStructureToFloatStr error---float sign wrong \r\n");
			return FALSE;
		}
	}

	return TRUE;

}

// convert float string  to integer structure
BOOL SS_PPUFloatStrToIntStructure(SIM_PUCT_INFO *pstPUCT, UINT8 *pucFloatStr, UINT8 ucFloatStrLen)
{
	if ((pstPUCT == NULL) || (pucFloatStr == NULL))
	{
		return FALSE;
	}

	// initialize  pstPUCT
	pstPUCT->iEPPU = 0;

	pstPUCT->iEX = 0;

	pstPUCT->iSign = 0;

	// if ppu is a null string
	if (ucFloatStrLen == 0)
	{
		return TRUE;
	}

	// dot
	BOOL bHasDot = FALSE;

	UINT8 ucDotPos = 0;

	// begin point of the valid numbers
	BOOL bBegin = FALSE;

	UINT8 ucBeginPos = 0;

	UINT8 ucValidNumberBits = 0;

	UINT16 uiValidNumber = 0;

	AT_TC(g_sw_AT_SS, "SS_FloatStrToIntStructure \r\n");

	UINT8 ucTemp = 0;

	for (ucTemp = 0; ucTemp < ucFloatStrLen; ucTemp++)
	{
		AT_TC(g_sw_AT_SS, "SS_FloatStrToIntStructure--float[%d]---%c \r\n", ucTemp, pucFloatStr[ucTemp]);

		if (pucFloatStr[ucTemp] == '.')
		{
			if ((ucTemp == 0) || (ucTemp == ucFloatStrLen - 1) || (bHasDot))
			{
				AT_TC(g_sw_AT_SS, "SS_FloatStrToIntStructure error---dot wrong!\r\n");
				return FALSE;
			}

			bHasDot = TRUE;

			ucDotPos = ucTemp;
			AT_TC(g_sw_AT_SS, "SS_FloatStrToIntStructure ---dot pos---%d!\r\n", ucDotPos);
		}

		// 0-9
		else if ((pucFloatStr[ucTemp] > 0x2f) && (pucFloatStr[ucTemp] < 0x3a))
		{
			if (pucFloatStr[ucTemp] != '0')
			{
				if (!bBegin)
				{
					bBegin     = TRUE;
					ucBeginPos = ucTemp;
					AT_TC(g_sw_AT_SS, "SS_FloatStrToIntStructure ---first valid number pos---%d!\r\n", ucBeginPos);
				}
			}

			if (bBegin)
			{
				ucValidNumberBits++;

				if (ucValidNumberBits > 4)
				{
					AT_TC(g_sw_AT_SS, "SS_FloatStrToIntStructure error---valid number bits exceeds 4!\r\n");
					return FALSE;
				}

				uiValidNumber = uiValidNumber * 10 + (pucFloatStr[ucTemp] - '0');

				if (uiValidNumber > 0x0fff)
				{
					AT_TC(g_sw_AT_SS, "SS_FloatStrToIntStructure error---valid numbers exceeds 4095!\r\n");
					return FALSE;
				}

			}
		}
		else
		{
			AT_TC(g_sw_AT_SS, "SS_FloatStrToIntStructure error---invalid char!\r\n");
			return FALSE;
		}
	}

	pstPUCT->iEPPU = uiValidNumber;

	if (bHasDot)
	{
		if (bBegin)
		{
			if (ucDotPos < ucBeginPos)
			{
				pstPUCT->iSign = 1;
			}

			pstPUCT->iEX = (ucDotPos < ucBeginPos) ? (ucBeginPos - ucDotPos) : (ucDotPos - ucBeginPos - 1);
		}

	}
	else
	{
		if (bBegin)
		{
			pstPUCT->iEX = ucValidNumberBits - 1;
		}
	}

	AT_TC(g_sw_AT_SS, "SS_FloatStrToIntStructure  success-iEPPU--%d, iEX---%d, iSign--%d!\r\n", pstPUCT->iEPPU, pstPUCT->iEX,
	      pstPUCT->iSign);

	return TRUE;
}
