/*********************************************************
 *
 * File Name
 *	At_ss_api.h
 * Author
 * 	Felix
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 *
 *********************************************************/

#ifndef _AT_SS_API_H_
#define _AT_SS_API_H_

#include "cfw.h"

VOID AT_SsEventSuccess(AT_CMD_RESULT **ppResult, UINT8 *pBuf, UINT8 uiBufLen, UINT8 nUTI);

// VOID AT_SsEventSuccessContinue(AT_CMD_RESULT **ppResult, UINT8 *pBuf, UINT8 uiBufLen);

VOID AT_SsEventFail(AT_CMD_RESULT **ppResult, UINT32 errCode, UINT8 *pBuf, UINT8 uiBufLen, UINT8 nUTI);
VOID AT_SsFuncFail(AT_CMD_RESULT **ppResult, UINT32 errCode, UINT8 *pBuf, UINT8 uiBufLen, UINT8 nUTI);
VOID AT_SsFuncSuccess(AT_CMD_RESULT **ppResult, UINT32 returnValue, UINT8 delaytime, UINT8 *pBuf, UINT8 uiBufLen,
                      UINT8 nUTI);
VOID AT_SsSynSuccessWithStr(AT_CMD_RESULT **ppResult, UINT8 *buf, UINT16 len, UINT8 nUTI);

UINT16 AT_SsAsciiToGsmBcd(UINT8 *pNumber, UINT8 nNumberLen, UINT8 *pBCD); // output should >= nNumberLen/2+1

// UINT16 AT_SsGsmBcdToAscii (UINT8 *pBcd, UINT8 nBcdLen, UINT8 *pNumber);

// VOID AT_SsClassConvert(UINT8 ucSrcClass, UINT8 *pucDestClass);
VOID AT_SsClassConvertCcfc(UINT8 ucSrcClass, UINT8 *pucDestClass);
VOID AT_SsClassConvert2Ccfc(UINT8 ucSrcClass, UINT8 *pucDestClass);

// [LLP[ADD]2007/11/26
BOOL SS_PPUIntStructureToFloatStr(UINT8 *pucFloatStr, UINT8 *pucLen, CFW_SIM_PUCT_INFO *pstPUCTInfo);
BOOL SS_PPUFloatStrToIntStructure(SIM_PUCT_INFO *pstPUCT, UINT8 *pucFloatStr, UINT8 ucFloatStrLen);

// LLP[ADD]2007/11/26]

// [[hameina[+]2007.9.17
#ifdef AT_DUAL_SIM
extern void AT_CC_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI, UINT8 nSim);
extern void AT_CC_Result_OK(UINT32 uReturnValue, UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize,
                            UINT8 nDLCI, UINT8 nSim);
#else
extern void AT_CC_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI);
extern void AT_CC_Result_OK(UINT32 uReturnValue, UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize,
                            UINT8 nDLCI);
#endif
// ]]hameina[+] 2007.9.17

// extern struct CFW_SIM_PUCT_INFO;

#endif
