// //////////////////////////////////////////////////////////////////////////////

#include "at_common.h"
#include "MainTask.h"
#include "at_cmd_common.h"
#include "ap_common.h"
#include "ap_message.h"
#include "gpio_config.h"
#include "gpio_edrv.h"
#include "hal_sys.h"


#if !defined(WIN32)
#include "hal_map.h"
#endif /* !WIN32 */

#if defined(__AT_MOD_COMMON__)
extern UINT8 g_cur_volume;

#ifdef CUST_HF200U
extern BOOL g_play_bt_vol_tone;
#endif

/******************************************************************************
 * AT_COMMON_Result_OK:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_Result_OK(UINT32 uReturnValue,
                         UINT32 uResultCode, UINT8 nDelayTime, UINT8* pBuffer, UINT16 nDataSize, UINT8 nDLCI)

{
    PAT_CMD_RESULT pResult = NULL;

    pResult = AT_CreateRC(uReturnValue,
                          uResultCode, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, nDelayTime, pBuffer, nDataSize, nDLCI);

    AT_Notify2ATM(pResult, nDLCI);
    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}

/******************************************************************************
 * AT_COMMON_Result_Err:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI)
{
    PAT_CMD_RESULT pResult = NULL;

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, uErrorCode, nErrorType, 0, 0, 0, nDLCI);
    AT_Notify2ATM(pResult, nDLCI);

    if (pResult != NULL)
    {
        AT_FREE(pResult);
        pResult = NULL;
    }

    return;
}

#ifdef CUST_HF200U
VOID AT_COMMON_CmdFunc_EnableVolumeTone(AT_CMD_PARA* pParam)
{

    if (NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        if(NULL == pParam->pPara)
        {
            goto iOpen_ERROR;
        }

        switch (pParam->iType)
        {
            case AT_CMD_SET:
            {
                UINT8 value;
                UINT16 Len;

                UINT8 uNumOfParam = 0;

                if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }
                if (1!= uNumOfParam)
                {
                    goto iOpen_ERROR;
                }
                Len = 1;
                AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &value, &Len);
                g_play_bt_vol_tone  = value;
                AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                return;
            }
            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

        AT_COMMON_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);

}
#endif

/******************************************************************************
 * AT_COMMON_CmdFunc_VolAdd:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_CmdFunc_VolAdd(AT_CMD_PARA* pParam)
{
    COS_EVENT ev;

    ev.nEventId = (UINT16)AT_COMMON_VOLADD;
    ev.nParam1 = (UINT16)(AT_COMMON_VOLADD>>16);
    COS_SendEvent(MOD_APP, &ev, COS_WAIT_FOREVER, COS_EVENT_PRI_NORMAL);
    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);

    return;

}

/******************************************************************************
 * AT_COMMON_CmdFunc_VolSub:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_CmdFunc_VolSub(AT_CMD_PARA* pParam)
{
    COS_EVENT ev;

    ev.nEventId = (UINT16)AT_COMMON_VOLSUB;
    ev.nParam1 = (UINT16)(AT_COMMON_VOLSUB>>16);
    COS_SendEvent(MOD_APP, &ev, COS_WAIT_FOREVER, COS_EVENT_PRI_NORMAL);
    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);

    return;

}

/******************************************************************************
 * AT_COMMON_CmdFunc_Volume:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_CmdFunc_Volume(AT_CMD_PARA* pParam)
{

    if (NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        if(NULL == pParam->pPara)
        {
            goto iOpen_ERROR;
        }

        switch (pParam->iType)
        {
            case AT_CMD_SET:
            {
			    UINT16 value, uStrLen    = 1;
			    INT32 iRetValue  = 0;

                UINT8 uNumOfParam = 0;

                if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }
                if (1!= uNumOfParam)
                {
                    goto iOpen_ERROR;
                }

                uStrLen = 2;
                iRetValue = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT16, &value, &uStrLen);
		        AT_TC(g_sw_ATE, "AT Set Volume %d",value);

                SendAppEvent(AT_COMMON_VOLUME, value);
                AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                return;
            }

            case AT_CMD_READ:
            {
            	AT_WriteUartString("VOLUME=%d\r\n",g_cur_volume);
                AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                return;
            }
            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

	AT_COMMON_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
}

VOID AT_COMMON_CmdFunc_SetMute(AT_CMD_PARA* pParam)
{

    if (NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        if(NULL == pParam->pPara)
        {
            goto iOpen_ERROR;
        }

        switch (pParam->iType)
        {
            case AT_CMD_SET:
            {
                UINT8 value;
                UINT16 Len;

                UINT8 uNumOfParam = 0;

                if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }
                if (1!= uNumOfParam)
                {
                    goto iOpen_ERROR;
                }
                Len = 1;
                AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &value, &Len);
                gpio_SetMute(value);

                AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                return;
            }
            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

        AT_COMMON_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);

}

/******************************************************************************
 * AT_COMMON_CmdFunc_PlayTone:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_CmdFunc_PlayTone(AT_CMD_PARA* pParam)
{

    if (NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        if(NULL == pParam->pPara)
        {
            goto iOpen_ERROR;
        }

        switch (pParam->iType)
        {
            case AT_CMD_SET:
            {
			    UINT16 value, uStrLen    = 2;
			    INT32 iRetValue  = 0;
                UINT8 uNumOfParam = 0;

                if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }
                if (1!= uNumOfParam)
                {
                    goto iOpen_ERROR;
                }

                iRetValue = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT16, &value, &uStrLen);
		        AT_TC(g_sw_ATE, "AT Playtone %d",value);

                SendAppEvent(AT_COMMON_PLAYTONE, value);
                AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                return;
            }

            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

	AT_COMMON_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
}

VOID AT_COMMON_CmdFunc_SetEQ(AT_CMD_PARA* pParam)
{
    if (NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        if (NULL == pParam->pPara)
        {
            goto iOpen_ERROR;
        }

        switch (pParam->iType)
        {
            case AT_CMD_SET:
            {
                UINT16 value, uStrLen = 1;
                INT32 iRetValue = 0;
                UINT8 uNumOfParam = 0;

                if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }

                if (1 != uNumOfParam)
                {
                    goto iOpen_ERROR;
                }

                uStrLen = 2;
                iRetValue = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT16, &value, &uStrLen);
                AT_TC(g_sw_ATE, "AT Set EQ %d", value);
                mediaSendCommand(MC_SETEQ, value);
                AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                return;
            }

            case AT_CMD_READ:
            {
                AT_WriteUartString("%d\r\n", aud_get_eq_mode());
                AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                return;
            }

            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:
    AT_COMMON_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
}


/******************************************************************************
 * AT_COMMON_CmdFunc_Next:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_CmdFunc_Next(AT_CMD_PARA* pParam)
{
    COS_EVENT ev;

    ev.nEventId = (UINT16)AT_COMMON_NEXT;
    ev.nParam1 = (UINT16)(AT_COMMON_NEXT>>16);
    COS_SendEvent(MOD_APP, &ev, COS_WAIT_FOREVER, COS_EVENT_PRI_NORMAL);
    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);

    return;

}

/******************************************************************************
 * AT_COMMON_CmdFunc_Prev:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_CmdFunc_Prev(AT_CMD_PARA* pParam)
{
    COS_EVENT ev;

    ev.nEventId = (UINT16)AT_COMMON_PREV;
    ev.nParam1 = (UINT16)(AT_COMMON_PREV>>16);
    COS_SendEvent(MOD_APP, &ev, COS_WAIT_FOREVER, COS_EVENT_PRI_NORMAL);
    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);

    return;

}


/******************************************************************************
 * AT_COMMON_CmdFunc_Fore:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_CmdFunc_Fore(AT_CMD_PARA* pParam)
{
    COS_EVENT ev;

    ev.nEventId = (UINT16)AT_COMMON_FORE;
    ev.nParam1 = (UINT16)(AT_COMMON_FORE>>16);
    COS_SendEvent(MOD_APP, &ev, COS_WAIT_FOREVER, COS_EVENT_PRI_NORMAL);
    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
    ev.nEventId = (UINT16)AT_COMMON_FORE_PLAY;
    ev.nParam1 = (UINT16)(AT_COMMON_FORE_PLAY>>16);
    COS_SendEvent(MOD_APP, &ev, COS_WAIT_FOREVER, COS_EVENT_PRI_NORMAL);
    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);

    return;

}

/******************************************************************************
 * AT_COMMON_CmdFunc_Back:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_CmdFunc_Back(AT_CMD_PARA* pParam)
{
    COS_EVENT ev;

    ev.nEventId = (UINT16)AT_COMMON_BACK;
    ev.nParam1 = (UINT16)(AT_COMMON_BACK>>16);
    COS_SendEvent(MOD_APP, &ev, COS_WAIT_FOREVER, COS_EVENT_PRI_NORMAL);
    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
    ev.nEventId = (UINT16)AT_COMMON_BACK_PLAY;
    ev.nParam1 = (UINT16)(AT_COMMON_BACK_PLAY>>16);
    COS_SendEvent(MOD_APP, &ev, COS_WAIT_FOREVER, COS_EVENT_PRI_NORMAL);
    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);

    return;

}


/******************************************************************************
 * AT_COMMON_CmdFunc_ModeSwitch:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_CmdFunc_ModeSwitch(AT_CMD_PARA* pParam)
{

    UINT16 uStrLen                   = 1;
    INT32 iRetValue                 = 0;
    UINT8 arrCharacterSet[20] = {0,};
    UINT8 arrStr[30];

    if (NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        if(NULL == pParam->pPara)
        {
            goto iOpen_ERROR;
        }


        switch (pParam->iType)
        {

            case AT_CMD_SET:
            {
                UINT8 uNumOfParam = 0;
                UINT32 result = 0;

                if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }
                if (1!= uNumOfParam)
                {
                    goto iOpen_ERROR;
                }
                uStrLen  = SIZEOF(arrCharacterSet);
                iRetValue = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, &arrCharacterSet, &uStrLen);

                if (0==AT_StrCaselessCmp(arrCharacterSet,"MUSIC"))
                    result = RESULT_MUSIC;
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"RECORD"))
                    result = RESULT_RECORD_START;
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"FM"))
                    result = RESULT_RADIO;
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"BT"))
                    result = RESULT_BT;
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"LINEIN"))
                    result = RESULT_LINE_IN;
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"MAIN"))
                    result = RESULT_MAIN;
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"MUSIC_TF"))
                    result = RESULT_MUSIC_TF;
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"MUSIC_USB"))
                    result = RESULT_MUSIC_USB;
#if (APP_SUPPORT_UART_PLAY == 1)
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"UART_PLAY"))
                    result = RESULT_UART_PLAY;
#endif
#if (APP_SUPPORT_UART_REC == 1)
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"UART_REC"))
                    result = RESULT_UART_REC;
#endif
                if(result > 0)
                {
                    SendAppEvent(EV_UI_FW_SWITCH_MOD, result);
                }

                AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                return;
            }

            case AT_CMD_READ:
            {
                if(IS_MUSIC_MODE())
                {
                    memcpy(arrStr,"MUSIC",sizeof("MUSIC"));
                }
                else if(IS_RECORD_MODE())
                {
                    memcpy(arrStr,"RECORD",sizeof("RECORD"));
                }
                else if(IS_FM_MODE())
                {
                    memcpy(arrStr,"FM",sizeof("FM"));
                }
                else if(IS_BT_MODE())
                {
                    memcpy(arrStr,"BT",sizeof("BT"));
                }
                else if(IS_USB_MODE())
                {
                    memcpy(arrStr,"USB",sizeof("USB"));
                }
                else if(IS_LINEIN_MODE())
                {
                    memcpy(arrStr,"LINEIN",sizeof("LINEIN"));
                }
#ifdef CODEC_SUPPORT
                else if(IS_CODEC_MODE())
                {
                    memcpy(arrStr,"UART_PLAY",sizeof("UART_PLAY"));
                }
#endif

                AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, arrStr, AT_StrLen(arrStr), pParam->nDLCI);
                return;
            }
            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

	AT_COMMON_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
}

/******************************************************************************
 * AT_COMMON_CmdFunc_Sleep:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_CmdFunc_Sleep(AT_CMD_PARA* pParam)
{
    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
    APP_Sleep();
}

/******************************************************************************
 * AT_COMMON_CmdFunc_Reset:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_CmdFunc_Reset(AT_CMD_PARA* pParam)
{
    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
#if !defined(WIN32)
    hal_SysRestart();
#endif /* !WIN32 */
}


/******************************************************************************
 * AT_COMMON_CmdFunc_Shutdown:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_CmdFunc_Shutdown(AT_CMD_PARA* pParam)
{
    COS_EVENT ev;

    ev.nEventId = AP_MSG_FORCE_STANDBY;
    ev.nParam1 = 0;

    COS_SendEvent(MOD_APP, &ev, COS_WAIT_FOREVER, COS_EVENT_PRI_NORMAL);
    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
}


/******************************************************************************
 * AT_COMMON_CmdFunc_Version:
 * DESCRIPTION: -
 *
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
VOID AT_COMMON_CmdFunc_Version(AT_CMD_PARA* pParam)
{
	UINT8 version_string[128];

	//100,170314,162201
	//AT_WriteUartString("%x,%x,%x",AP_GetVersion(),AP_GetBuildDate(),AP_GetBuildTime());
	GPIO_CFG_CONFIG_T *gpio_cfg = tgt_GetGPIOCfg();

	memset(version_string, 0, sizeof(version_string));
	// version: ChipID-Version-Date-Time-MuteEnable|MuteHigh|GPIO
	sprintf(version_string,"%x-%x-%x-%x-M%c%c%d%d", hal_SysGetChipId(HAL_SYS_CHIP_PROD_ID),
		AP_GetVersion(), AP_GetBuildDate(), AP_GetBuildTime(), (gpio_cfg->gpioMuteEnable ? '1' : '0'),
		(gpio_cfg->gpioMuteHigh ? 'H' : 'L'), (gpio_cfg->gpioMute.gpioId&0xffff)/8,
		(gpio_cfg->gpioMute.gpioId&0xffff)%8);

	AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, version_string, strlen(version_string), pParam->nDLCI);
}

#ifdef UART_RAMRUN_SUPPORT
UINT32 g_prog_ramrun_total_size = 0;
UINT32 g_prog_ramrun_rx_size = 0;
VOID AT_COMMON_CmdFunc_ProgRamrun(AT_CMD_PARA* pParam)
{
    if (NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        if(NULL == pParam->pPara)
        {
            goto iOpen_ERROR;
        }

        switch (pParam->iType)
        {
            case AT_CMD_SET:
            {
                UINT16 value, uStrLen    = 1;
                INT32 iRetValue  = 0;
                UINT8 uNumOfParam = 0;

                if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }
                if (1!= uNumOfParam)
                {
                    goto iOpen_ERROR;
                }

                uStrLen = 2;
                iRetValue = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT16, &value, &uStrLen);
                AT_TC(g_sw_ATE, "prog bin size: %d",value);

                g_prog_ramrun_total_size = value;
                g_prog_ramrun_rx_size = 0;
                hal_HstSendEvent (SYS_EVENT, 0x2018fb01);
                hal_HstSendEvent (SYS_EVENT, g_prog_ramrun_total_size);

                AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                return;
            }

            case AT_CMD_READ:
            {
                AT_WriteUartString("prog bin enabled.\r\n");
                AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                return;
            }
            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

    AT_COMMON_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
}

// dual port sram
#define PROG_RAM_START_ADDR 0xa1b000a0  // dp sram base.
#define PROG_RAM_ENTRY 0xa1b00280

int AT_COMMAND_PROG_TO_RAM(UINT8 *buffer, UINT32 buf_size)
{
    hal_HstSendEvent (SYS_EVENT, 0x2018fb02);
    hal_HstSendEvent (SYS_EVENT, buf_size);

    if ((buffer != NULL) && (buf_size > 0)) {
        memcpy(PROG_RAM_START_ADDR+g_prog_ramrun_rx_size, buffer, buf_size);
        g_prog_ramrun_rx_size += buf_size;
    }

    if (g_prog_ramrun_rx_size >= g_prog_ramrun_total_size) {
        UINT32 csStatus;
        csStatus = hal_SysEnterCriticalSection();
        hal_TimWatchDogClose();
        AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, 0);

        // jump to ramrun, boot_Sector entry.
        VOID(*flashEntry)(UINT32);
        hal_HstSendEvent (SYS_EVENT, 0x2018fb03);
        flashEntry = (VOID(*)(UINT32))PROG_RAM_ENTRY;
        flashEntry(0);

        hal_SysExitCriticalSection(csStatus);
    }
    hal_HstSendEvent (SYS_EVENT, 0x2018fb05);

    return buf_size;
}
#endif

#if !defined(WIN32)
/******************************************************************************
 * AT_COMMON_CmdFunc_PeripheralReg:
 * DESCRIPTION: -
 *  Write   AT+CPREG=<ABB/PMU/FMD/XCV>,<REGADDR in hex>,<REGVAL in hex>
 *  Read    AT+CPREG?<ABB/PMU/FMD/XCV>,<REGADDR in hex>
 * Input:
 * Output:
 * Returns:
 *
 *
 ******************************************************************************/
extern HAL_ISPI_DEBUG_T g_halIspiDebug;
VOID AT_COMMON_CmdFunc_ReadPeripheralReg(AT_CMD_PARA* pParam)
{

    UINT16 uStrLen                   = 1;
    INT32 iRetValue                 = 0;
    UINT8 arrCharacterSet[20] = {0};
    UINT8 arrStr[30];

    if (NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        if(NULL == pParam->pPara)
        {
            goto iOpen_ERROR;
        }


        switch (pParam->iType)
        {
            case AT_CMD_SET:
            {
                UINT8 uNumOfParam = 0;
                UINT32 data, result = 0;
                UINT32 timeout = 1000;

                if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }
                if (uNumOfParam < 2)
                {
                    goto iOpen_ERROR;
                }


                uStrLen  = SIZEOF(arrCharacterSet);
                iRetValue = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, &arrCharacterSet, &uStrLen);

                if (0==AT_StrCaselessCmp(arrCharacterSet,"ABB"))
                    g_halIspiDebug.debug.type = HAL_ISPI_REG_TYPE_ABB;
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"PMU"))
                    g_halIspiDebug.debug.type = HAL_ISPI_REG_TYPE_PMD;
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"FMD"))
                    g_halIspiDebug.debug.type = HAL_ISPI_REG_TYPE_FMD;
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"XCV"))
                    g_halIspiDebug.debug.type = HAL_ISPI_REG_TYPE_XCV;


                memset(arrStr, 0, SIZEOF(arrStr));
                uStrLen  = SIZEOF(arrStr);
                iRetValue = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, &arrStr, &uStrLen);
                //sscanf(arrStr, "0x%x", &data);
                data = strtol(arrStr, NULL, 16);
                g_halIspiDebug.debug.address = (UINT16) data;

                g_halIspiDebug.debug.read = 1;
                AT_TC(g_sw_ATE, "AT ReadPReg %s[0x%x]", arrCharacterSet, data);


                do{
                    COS_Sleep(1);
                    if(0 == timeout--) break;
                }while(g_halIspiDebug.debug.read || g_halIspiDebug.debug.write);

                AT_TC(g_sw_ATE, "AT ReadPReg %s[0x%x] = 0x%x", arrCharacterSet,
                                                         g_halIspiDebug.debug.address,
                                                        g_halIspiDebug.data);
                if(0 == timeout)
                {
                    AT_WriteUartString("ReadPReg Timeout\r\n");
                	AT_COMMON_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                }
                else
                {
                    AT_WriteUartString("0x%x\r\n", g_halIspiDebug.data);
                    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                }
                return;
            }


            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

	AT_COMMON_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
}


VOID AT_COMMON_CmdFunc_WritePeripheralReg(AT_CMD_PARA* pParam)
{

    UINT16 uStrLen                   = 1;
    INT32 iRetValue                 = 0;
    UINT8 arrCharacterSet[20] = {0};
    UINT8 arrStr[30];

    if (NULL == pParam)
    {
        goto iOpen_ERROR;
    }
    else
    {
        if(NULL == pParam->pPara)
        {
            goto iOpen_ERROR;
        }


        switch (pParam->iType)
        {
            case AT_CMD_SET:
            {
                UINT8 uNumOfParam = 0;
                UINT32 data, result = 0;
                UINT32 timeout = 1000;

                if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uNumOfParam))
                {
                    goto iOpen_ERROR;
                }
                if (uNumOfParam < 3)
                {
                    goto iOpen_ERROR;
                }

                uStrLen  = SIZEOF(arrCharacterSet);
                iRetValue = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, &arrCharacterSet, &uStrLen);

                if (0==AT_StrCaselessCmp(arrCharacterSet,"ABB"))
                    g_halIspiDebug.debug.type = HAL_ISPI_REG_TYPE_ABB;
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"PMU"))
                    g_halIspiDebug.debug.type = HAL_ISPI_REG_TYPE_PMD;
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"FMD"))
                    g_halIspiDebug.debug.type = HAL_ISPI_REG_TYPE_FMD;
                else if (0==AT_StrCaselessCmp(arrCharacterSet,"XCV"))
                    g_halIspiDebug.debug.type = HAL_ISPI_REG_TYPE_XCV;


                memset(arrStr, 0, SIZEOF(arrStr));
                uStrLen  = SIZEOF(arrStr);
                iRetValue = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, &arrStr, &uStrLen);
                data = strtol(arrStr, NULL, 16);
                g_halIspiDebug.debug.address = (UINT16) data;

                memset(arrStr, 0, SIZEOF(arrStr));
                uStrLen  = SIZEOF(arrStr);
                iRetValue = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_STRING, &arrStr, &uStrLen);
                data = strtol(arrStr, NULL, 16);
                g_halIspiDebug.data = (UINT16) data;
                g_halIspiDebug.debug.write = 1;


                AT_TC(g_sw_ATE, "AT WritePReg %s[0x%x] = 0x%x", arrCharacterSet,
                                                              g_halIspiDebug.debug.address,
                                                              g_halIspiDebug.data);


                do{
                    COS_Sleep(1);
                    if(0 == timeout--) break;
                }while(g_halIspiDebug.debug.read || g_halIspiDebug.debug.write);

                if(0 == timeout)
                {
                    AT_WriteUartString("WritePReg Timeout\r\n");
                	AT_COMMON_Result_Err(ERR_AT_CME_EXE_FAIL, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
                    return;
                }

                AT_TC(g_sw_ATE, "AT WritePReg Done");

                AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
                return;
            }


            default:
            {
                goto iOpen_ERROR;
            }
        }
    }

iOpen_ERROR:

	AT_COMMON_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
}

#else /* WIN32 */

VOID AT_COMMON_CmdFunc_ReadPeripheralReg(AT_CMD_PARA* pParam)
{
    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
}

VOID AT_COMMON_CmdFunc_WritePeripheralReg(AT_CMD_PARA* pParam)
{
    AT_COMMON_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 10, NULL, 0, pParam->nDLCI);
}

#endif /* !WIN32 */

#endif
