/*********************************************************
 *
 * File Name
 *	at_cmd_common.h
 * Author
 * 	Felix
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 *
 *********************************************************/

#ifndef __AT_CMD_COMMON_H__
#define __AT_CMD_COMMON_H__

#include "event.h"
#include "at_common.h"
extern VOID AT_COMMON_CmdFunc_VolAdd(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_VolSub(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_Volume(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_SetMute(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_PlayTone(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_Next(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_Prev(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_Fore(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_Back(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_ModeSwitch(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_SetEQ(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_Sleep(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_Reset(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_Shutdown(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_ReadPeripheralReg(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_WritePeripheralReg(AT_CMD_PARA* pParam);
extern VOID AT_COMMON_CmdFunc_Version(AT_CMD_PARA* pParam);

#ifdef CUST_HF200U
extern VOID AT_COMMON_CmdFunc_EnableVolumeTone(AT_CMD_PARA* pParam);
#endif

#ifdef UART_RAMRUN_SUPPORT
extern VOID AT_COMMON_CmdFunc_ProgRamrun(AT_CMD_PARA* pParam);
#endif

#endif

