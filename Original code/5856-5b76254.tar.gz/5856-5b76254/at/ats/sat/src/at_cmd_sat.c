// //////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002-2012, Coolsand Technologies, Inc.
// All Rights Reserved
//
// This source code is property of Coolsand. The information contained in this
// file is confidential. Distribution, reproduction, as well as exploitation,
// or transmission of any content of this file is not allowed except if
// expressly permitted.Infringements result in damage claims!
//
// FILENAME: at_cmd_sat.c
//
// DESCRIPTION:
// TODO: ...
//
// REVISION HISTORY:
// NAME              DATE                REMAKS
// Lixp      2012-2-20       Created initial version 1.0
//
// //////////////////////////////////////////////////////////////////////////////

#include "at_common.h"
#include "cfw.h"
#include "at_module.h"
#include "at_cmd_sat.h"
#include "at_cmd_sim.h"
#include "at_cfg.h"
#include "cfw.h"  // wangcf [+]2008-5-11

UINT8 AllowedInstance = NONE_INSTANCE;


// add by wangxd for bug 8672
static UINT8 g_ActiveSatFlag = 0;
// add_end by wangxd for bug 8672


BOOL gATSATSendSMSFlag[NUMBER_OF_SIM]   = {FALSE, FALSE};
BOOL gATSATLocalInfoFlag[NUMBER_OF_SIM] = {FALSE, FALSE};
BOOL gATSATSendUSSDFlag[NUMBER_OF_SIM]  = {FALSE, FALSE};
BOOL gATSATSetupCallFlag[NUMBER_OF_SIM] = {FALSE, FALSE};
UINT8 CFW_GetCurrentCmdNum(CFW_SIM_ID nSimID);
UINT32 sms_tool_CheckDcs(UINT8 *pDcs);
VOID _ResetSimTimer(UINT8 nTimeInterval, UINT8 nTimeUnit, CFW_SIM_ID nSimID);
VOID AT_SIMID_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nUTI);
VOID CFW_SetSATIndFormate(BOOL bMode);
UINT32 ML_Unicode2LocalLanguageBigEnding(const UINT8 *in, UINT32 in_len,
        UINT8 **out, UINT32 *out_len, UINT8 nCharset[12]);

BOOL gATSATComQualifier[NUMBER_OF_SIM]  = {0,};
UINT32 CFW_SimInit( BOOL bRstSim, CFW_SIM_ID nSimID);
UINT8 gFetchData[256] = { 0x00, };

UINT32 AT_SAT_SpecialCMDSendSMS(UINT8 *pFetchData, UINT32 nFetchDatalen, CFW_SIM_ID nSimID)
{
	UINT8 nAlphaLen  = 0;
	UINT8 nAddrLen   = 0;
	UINT8 nAddrType  = 0;
	UINT8 nTPDULen   = 0;

	UINT8 *nAlphaStr = NULL;
	UINT8 *nAddrStr  = NULL;
	UINT8 *nTPDUStr  = NULL;

	CFW_SAT_SMS_RSP *pSmsResp = NULL;

	UINT16 nMemsize = SIZEOF(CFW_SAT_SMS_RSP);
	UINT16 nLength = 0x00;

	UINT32 nIndex = 0x00;
	UINT8 *pOffset = pFetchData;

	AT_TC(g_sw_AT_SAT, "AT_SAT_SpecialCMDSendSMS gATSATSendSMSFlag %d\n", gATSATSendSMSFlag[nSimID]);

	gATSATSendSMSFlag[nSimID] = TRUE;
	if (pOffset[1] == 0x81)
		nIndex = 2;
	else
		nIndex = 1;

	UINT8 nCmdQual		= pOffset[nIndex + 5];


	nIndex = nIndex + 10;

	if ((pOffset[nIndex] == 0x05) || (pOffset[nIndex] == 0x85))
	{
		if (pOffset[++nIndex] == 0x81)
			nIndex++;

		nLength   = pOffset[nIndex++];
		nAlphaLen = nLength;
		nAlphaStr = pOffset + nIndex;
	}
	else
		nLength = 0;

	nIndex    = nIndex + nLength;
	nMemsize += nLength;

	if ((pOffset[nIndex] == 0x06) || (pOffset[nIndex] == 0x86))
	{
		if (pOffset[++nIndex] == 0x81)
			nIndex++;
		nLength   = pOffset[nIndex++] - 1;
		nAddrLen  = nLength;
		nAddrType = pOffset[nIndex++];
		nAddrStr  = pOffset + nIndex;
	}
	else
		nLength = 0;
	nIndex    = nIndex + nLength;
	nMemsize += nLength;

	if ((pOffset[nIndex] == 0x0B) || (pOffset[nIndex] == 0x8B))
	{
		if (pOffset[++nIndex] == 0x81)
			nIndex++;
		nLength  = pOffset[nIndex++];
		nTPDULen = nLength;
		nTPDUStr = (UINT8 *)pOffset + nIndex;
	}
	else
	{
		AT_TC(g_sw_AT_SAT, "Error Invalid data Not 0x0B or 0x8B But 0x%x", pOffset[nIndex]);
		return ERR_INVALID_PARAMETER;
	}
	nMemsize += nLength;

	pSmsResp = (CFW_SAT_SMS_RSP *)AT_MALLOC(nMemsize);
	if (pSmsResp == NULL)
	{
		AT_TC(g_sw_AT_SAT, "Error Malloc failed\n");
		return ERR_NO_MORE_MEMORY;
	}
	SUL_ZeroMemory8(pSmsResp, nMemsize);

	pSmsResp->nAlphaLen = nAlphaLen;
	pSmsResp->pAlphaStr = (UINT8 *)pSmsResp + SIZEOF(CFW_SAT_SMS_RSP);
	SUL_MemCopy8(pSmsResp->pAlphaStr, nAlphaStr, nAlphaLen);

	pSmsResp->nAddrLen  = nAddrLen;
	pSmsResp->nAddrType = nAddrType;

	pSmsResp->pAddrStr = pSmsResp->pAlphaStr + nAlphaLen;

	if (nAddrLen != 0)
	{
		SUL_MemCopy8(pSmsResp->pAddrStr, nAddrStr, nAddrLen);
	}

	pSmsResp->nPDULen = nTPDULen;
	pSmsResp->pPDUStr = pSmsResp->pAddrStr + nAddrLen;

	SUL_MemCopy8(pSmsResp->pPDUStr, nTPDUStr, nTPDULen);

	// check the DCS and tpdu, if dcs is 7 bits and all the tpdu bit7 is 0, it means the DCS is not equal to the data,
	// we need to transfer the 8 bit data to 7 bit.

	UINT8 uDCSOffsize   = 0;
	UINT8 uVPLen        = 0;
	UINT8 uVPF          = 0;
	UINT8 UdataOff      = 0;

	UINT8 buff7[140] = { 0, };
	UINT8 buff7len   = 0;

	// MTI+MR+DALEN/2+DATYPE+PID + DCS
	uDCSOffsize = 2 + (pSmsResp->pPDUStr[2] + 1) / 2 + 1 + 2;

	// bit3,4 of MTI is vpf
	uVPF = (pSmsResp->pPDUStr[0] >> 3) & 3;
	if (!uVPF)  // NOT present
		uVPLen = 0;
	else if (uVPF == 2) // relative format
		uVPLen = 1;
	else
		uVPLen = 7;

	AT_TC(g_sw_AT_SAT, "uDCSOffsize=%d,pPDUPacketTmp[uDCSOffsize]=0x%02x, uVPLen=%d pSmsResp->pPDUStr[uDCSOffsize-1] %d\n",
	      uDCSOffsize, pSmsResp->pPDUStr[uDCSOffsize], uVPLen, pSmsResp->pPDUStr[uDCSOffsize - 1]);

	// dcs offsize + udl+1-->userdata
	// cause VPF is 0, it means vp field is not present, so when test, we don't count this, othersize VP will take 1~7 octs.
	UdataOff = uDCSOffsize + 2 + uVPLen;

	// SEND SHORT MESSAGE;
	//bit 1:                  0 = packing not required
	//                        1 = SMS packing by the ME required
	if( 0x00 == nCmdQual )
	{
		//packing not required
	}
	else if (!pSmsResp->pPDUStr[uDCSOffsize])	// check if match the condition 1, DCS is 0
	{
		UINT8 uLoop = 0;

		// here need to check whether all the bit7 of userdata is 0,
		for (uLoop = 0; uLoop < pSmsResp->pPDUStr[UdataOff - 1]; uLoop++)
		{
			if ((pSmsResp->pPDUStr[UdataOff + uLoop] >> 7) & 1)
				break;
		}

		AT_TC(g_sw_AT_SAT, "uLoop=%d, pSmsResp->pPDUStr[UdataOff-1]=%d\n", uLoop,
		      pSmsResp->pPDUStr[UdataOff - 1]);

		// check if match the condition 2: all the bit 7 of user data is 0.
		if (uLoop && (uLoop == pSmsResp->pPDUStr[UdataOff - 1]))
		{
			buff7len = SUL_Encode7Bit(&pSmsResp->pPDUStr[UdataOff], buff7, pSmsResp->pPDUStr[UdataOff - 1]);

			SUL_MemCopy8(&pSmsResp->pPDUStr[UdataOff], buff7, buff7len);

			AT_TC(g_sw_AT_SAT, "UdataOff=%d, buff7len= %d\n", UdataOff, buff7len);

			AT_TC(g_sw_AT_SAT, "pSmsResp->nPDULen before = %d\n", pSmsResp->nPDULen);

			pSmsResp->nPDULen +=  (buff7len - pSmsResp->pPDUStr[UdataOff - 1]);

			AT_TC(g_sw_AT_SAT, "pSmsResp->nPDULen end = %d\n", pSmsResp->nPDULen);

		}
	}
	else if(0xF2 == pSmsResp->pPDUStr[uDCSOffsize])
	{
		// change DCS to 0, 7  bit decode
		pSmsResp->pPDUStr[uDCSOffsize] = 0;
		UINT8 uLoop = 0;
		AT_TC(g_sw_AT_SAT, "New pSmsResp->pPDUStr[UdataOff - 1]= %d\n", pSmsResp->pPDUStr[UdataOff - 1]);
		// here need to check whether all the bit7 of userdata is 0,
		for (uLoop = 0; uLoop < pSmsResp->pPDUStr[UdataOff - 1]; uLoop++)
		{
			if ((pSmsResp->pPDUStr[UdataOff + uLoop] >> 7) & 1)
				break;
		}

		if (uLoop && (uLoop == pSmsResp->pPDUStr[UdataOff - 1]))
		{
			// encode user data to 7 bit data
			buff7len = SUL_Encode7Bit(&pSmsResp->pPDUStr[UdataOff], buff7, pSmsResp->pPDUStr[UdataOff - 1]);
			SUL_MemCopy8(&pSmsResp->pPDUStr[UdataOff], buff7, buff7len);

			AT_TC(g_sw_AT_SAT, "UdataOff=%d, buff7len= %d\n", UdataOff, buff7len);
			AT_TC(g_sw_AT_SAT, "pSmsResp->nPDULen before = %d\n", pSmsResp->nPDULen);

			pSmsResp->nPDULen +=  (buff7len - pSmsResp->pPDUStr[UdataOff - 1]);

			AT_TC(g_sw_AT_SAT, "pSmsResp->nPDULen end = %d\n", pSmsResp->nPDULen);

		}

	}
	else if((4 == (pSmsResp->pPDUStr[uDCSOffsize] & 0x0F)) && (0x00 == pSmsResp->pPDUStr[uDCSOffsize - 1]))
	{
		AT_TC(g_sw_AT_SAT, "((4 == (pSmsResp->pPDUStr[uDCSOffsize] & 0x0F)) && (0x00 == pSmsResp->pPDUStr[uDCSOffsize-1]))\n");
#if 0
		// change DCS to 0, 7  bit decode
		pSmsResp->pPDUStr[uDCSOffsize] = 0;

		// encode user data to 7 bit data
		buff7len = SUL_Encode7Bit(&pSmsResp->pPDUStr[UdataOff], buff7, pSmsResp->pPDUStr[UdataOff - 1]);

		SUL_MemCopy8(&pSmsResp->pPDUStr[UdataOff], buff7, buff7len);

		AT_TC(g_sw_AT_SAT, "UdataOff=%d, buff7len= %d\n", UdataOff, buff7len);
		AT_TC(g_sw_AT_SAT, "pSmsResp->nPDULen before = %d\n", pSmsResp->nPDULen);

		pSmsResp->nPDULen +=  (buff7len - pSmsResp->pPDUStr[UdataOff - 1]);
		AT_TC(g_sw_AT_SAT, "pSmsResp->nPDULen end = %d\n", pSmsResp->nPDULen);
#endif

	}

	UINT32 result           = 0;
	UINT8 *pPDUPacket       = NULL;
	UINT8 *pPDUPacketTmp    = NULL;

	UINT16 nPDUPacket       = 0;
	UINT16 nPDUPacketTmp    = 0;

	UINT8 pAdd[12] = {0x00,};

	AT_TC(g_sw_AT_SAT, "AT_SAT_SpecialCMDSendSMS nAddrLen = %d", pSmsResp->nAddrLen);

	if (pSmsResp->nAddrLen == 0)   //���û�д���ַ��������ȡ�ö���Ϣ���ĺ���
	{
		CFW_SMS_PARAMETER smsInfo;

		memset(&smsInfo, 0, sizeof(CFW_SMS_PARAMETER));
		CFW_CfgGetSmsParam(&smsInfo, 0, nSimID);

		pSmsResp->nAddrLen = smsInfo.nNumber[0];
		memcpy(pAdd, &(smsInfo.nNumber[1]), smsInfo.nNumber[0]);

		nPDUPacketTmp = pSmsResp->nPDULen + pSmsResp->nAddrLen + 1;

		pPDUPacket = (UINT8 *)AT_MALLOC(nPDUPacketTmp);
		if(pPDUPacket == NULL)
		{
			AT_FREE(pSmsResp);
			pSmsResp = NULL;
			return ERR_NO_MORE_MEMORY;
		}

		memset(pPDUPacket, 0xFF, nPDUPacketTmp);
		pPDUPacketTmp = pPDUPacket;
		*(pPDUPacketTmp++) = pSmsResp->nAddrLen;

	}
	else //�����������ַ����ǰ���91 �����Ӻ�
	{
		nPDUPacketTmp = pSmsResp->nPDULen + pSmsResp->nAddrLen + 2; //tpdu length ����2����Ϊ������2λ: ��ַ���Ⱥ� 91
		pPDUPacket = (UINT8 *)AT_MALLOC(nPDUPacketTmp);
		if(pPDUPacket == NULL)
		{
			AT_FREE(pSmsResp);
			pSmsResp = NULL;
			return ERR_NO_MORE_MEMORY;
		}
		memset(pPDUPacket, 0xFF, nPDUPacketTmp);
		memcpy(pAdd, pSmsResp->pAddrStr, pSmsResp->nAddrLen);
		pPDUPacketTmp = pPDUPacket;
		*(pPDUPacketTmp++) = pSmsResp->nAddrLen + 1;   //��ַ�ĳ��ȣ���һ����Ϊ����һ��91
		AT_TC(g_sw_AT_SAT, "AT_SAT_SpecialCMDSendSMS pSmsResp->nAddrType = %d", pSmsResp->nAddrType);
		*(pPDUPacketTmp++) = pSmsResp->nAddrType ;//0x91;   // "+"
	}

	nPDUPacket  = nPDUPacketTmp;

	if (pSmsResp->nAddrLen != 0)
	{
		memcpy(pPDUPacketTmp, pAdd, pSmsResp->nAddrLen);
		pPDUPacketTmp += pSmsResp->nAddrLen;
	}
	if (pSmsResp->nPDULen != 0)
	{
		memcpy(pPDUPacketTmp, pSmsResp->pPDUStr, pSmsResp->nPDULen);
	}

	UINT8 nFormat = 0x00;
	UINT8 Uti  = 0;

	CFW_CfgGetSmsFormat(&nFormat, nSimID);
	CFW_CfgSetSmsFormat(0, nSimID);
	AT_GetFreeUTI(CFW_SS_SRV_ID, &Uti);
	result = CFW_SmsSendMessage(NULL, pPDUPacket, nPDUPacket, Uti, nSimID);
	CFW_CfgSetSmsFormat(nFormat, nSimID);

	AT_TC(g_sw_AT_SAT, "AT_SAT_SpecialCMDSendSMS nAddrLen = %d", pSmsResp->nAddrLen);
	AT_TC(g_sw_AT_SAT, "AT_SAT_SpecialCMDSendSMS nPDULen = %d", pSmsResp->nPDULen);

	if (result == ERR_SUCCESS)
	{
		AT_TC(g_sw_AT_SAT, "AT_SAT_SpecialCMDSendSMS Success");
	}
	else
	{
		AT_TC(g_sw_AT_SAT, "AT_SAT_SpecialCMDSendSMS CFW_SmsSendMessage error!!!! = %x", result);
	}

	AT_FREE(pPDUPacket);
	pPDUPacket = NULL;
	if(pSmsResp  != NULL )
	{
		AT_FREE(pSmsResp);
		pSmsResp = NULL;
	}
	return ERR_SUCCESS;
}


UINT32 gSATCurrentCmdStamp[CFW_SIM_COUNT] = {0x00,};

UINT32 AT_SAT_SpecialCMDProvideLocalInfo(UINT8 *pFetchData, UINT32 nFetchDatalen, CFW_SIM_ID nSimID)
{

	UINT8 *pOffset  = pFetchData;
	UINT8 nIndex    = 0x00;
	UINT8 nUTI      = 0x00;

	UINT32 nRet = ERR_SUCCESS;

	nUTI = AT_ASYN_GET_DLCI(nSimID);

	if (pOffset[1] == 0x81)
		nIndex = 2;
	else
		nIndex = 1;

	UINT8 nComQualifier = pOffset[nIndex + 5];
	//UINT8 nCmdNum         = pOffset[nIndex + 3];
	gATSATComQualifier[nSimID] = nComQualifier;
	nIndex = nIndex + 10;
	AT_TC(g_sw_AT_SAT, "AT_SAT_SpecialCMDProvideLocalInfo nComQualifier %d\n", nComQualifier);

	/*
	-   PROVIDE LOCAL INFORMATION
	'00' = Location Information (MCC, MNC, LAC and Cell Identity)
	'01' = IMEI of the ME
	'02' = Network Measurement results
	'03' = Date, time and time zone
	'04' = Language setting
	'05' = Timing Advance
	'06' to 'FF' = Reserved

	*/
	if(0x00 == nComQualifier)
	{

		CFW_TSM_FUNCTION_SELECT SelecFUN;

		SelecFUN.nNeighborCell = FALSE;
		SelecFUN.nServingCell = TRUE;

		gATSATLocalInfoFlag[nSimID] = TRUE;

#ifdef  AT_DUAL_SIM
		nRet = CFW_EmodOutfieldTestStart(&SelecFUN, nUTI, nSimID);
#else
		nRet = CFW_EmodOutfieldTestStart(&SelecFUN, nUTI);
#endif

		if(nRet == ERR_SUCCESS)
		{
			AT_TC(g_sw_AT_SAT,  " Func: %s PROVIDE LOCAL INFO ERR_SUCCESS", __FUNCTION__);
		}
		else
		{
			AT_TC(g_sw_AT_SAT,  " Func: %s PROVIDE LOCAL INFO ERROR!!! 0x%x", __FUNCTION__, nRet);
		}
		return ERR_CONTINUE;
	}
	else if(0x01 == nComQualifier)
	{

		UINT8 pImei[16] = {0x00,};
		UINT8 nImeiLen = 0x00;
		UINT8 pResponseData[26] = {0x81, 0x03, 0x01, 0x26, 0x01, 0x82, 0x02, 0x82, 0x81, 0x83, 0x01, 0x00, 0x94, 0x08,/*0x10,0x72,0x84,0x00,0x53,0x56,0x68,0xF8*/};
		gATSATLocalInfoFlag[nSimID] = TRUE;
		pResponseData[2] = CFW_GetCurrentCmdNum(nSimID);
		CFW_EmodGetIMEIBCD(pImei, &nImeiLen, nSimID);

		if(nImeiLen > 8)
		{
			nImeiLen = 8;
		}

		SUL_MemCopy8(&pResponseData[14], pImei, nImeiLen);

#ifdef AT_DUAL_SIM
		nRet = CFW_SatResponse (0xFF, 0x00, 0x0, pResponseData, 22, nUTI, nSimID);
#else
		nRet = CFW_SatResponse (0xFF, 0x00, 0x0, pResponseData, 22, nUTI);
#endif

		AT_TC(g_sw_AT_NW, "CFW_SatResponse nRet:0x%x!\n", nRet);

		return ERR_CONTINUE;

	}
	else if((0x02 == nComQualifier) || (0x03 == nComQualifier))
	{

	}
	else if(0x05 == nComQualifier)
	{

		CFW_TSM_FUNCTION_SELECT SelecFUN;

		SelecFUN.nNeighborCell = FALSE;
		SelecFUN.nServingCell = TRUE;

		gATSATLocalInfoFlag[nSimID] = TRUE;

#ifdef  AT_DUAL_SIM
		nRet = CFW_EmodOutfieldTestStart(&SelecFUN, nUTI, nSimID);
#else
		nRet = CFW_EmodOutfieldTestStart(&SelecFUN, nUTI);
#endif

		if(nRet == ERR_SUCCESS)
		{
			AT_TC(g_sw_AT_SAT,  " Func: %s PROVIDE LOCAL INFO ERR_SUCCESS", __FUNCTION__);
		}
		else
		{
			AT_TC(g_sw_AT_SAT,  " Func: %s PROVIDE LOCAL INFO ERROR!!! 0x%x", __FUNCTION__, nRet);
		}
		return ERR_CONTINUE;
	}
	else
	{
		return ERR_NOT_SUPPORT;
	}

	return ERR_SUCCESS;
}
extern BOOL gSatFreshComm[];

UINT32 AT_SAT_SpecialCMDRefresh(UINT8 *pFetchData, UINT32 nFetchDatalen, CFW_SIM_ID nSimID)
{

	AT_TC(g_sw_AT_SAT, "%s\n", __func__);

	UINT8 nIndex    = 0x00;
	UINT8 nLength   =  0x00;
	UINT8 *pOffset  = pFetchData;
	UINT8 nNumOfFiles = 0x00;
	UINT8 *pFiles   = NULL;

	if (pOffset[1] == 0x81)
		nIndex = 2;
	else
		nIndex = 1;

	UINT8 nComQualifier = pOffset[nIndex + 5];

	nIndex = nIndex + 10;


	/*
	'00' =SIM Initialization and Full File Change Notification;
	'01' = File Change Notification;
	'02' = SIM Initialization and File Change Notification;
	'03' = SIM Initialization;
	'04' = SIM Reset;
	'05' to 'FF' = reserved values.
	*/

	AT_TC(g_sw_AT_SAT, "nComQualifier %d\n", nComQualifier);
	if( 0x00 == nComQualifier )
	{
		AT_TC(g_sw_AT_SAT, "nComQualifier 0x00 re attachment NW\n");
		//TODO
		//Ŀǰֻ���ֻ�����פ��
		//_SAT_SendSimClose( nSimID );
		//_SAT_SendSimOpen( nSimID);

		UINT8 nUTI = 0x00;
		CFW_GetFreeUTI(0, &nUTI);

		UINT32 nRet = CFW_SetComm(CFW_DISABLE_COMM, 1, nUTI, nSimID);
		gSatFreshComm[nSimID] = 0x01;

		AT_TC(g_sw_AT_SAT, "CFW_SetComm  nRet[0x%x] gSatFreshComm[%d] %d\n", nRet, nSimID, gSatFreshComm[nSimID]);

	}
	else if( 0x01 == nComQualifier )
	{
		if ((pOffset[nIndex] == 0x12) || (pOffset[nIndex] == 0x92))
		{

			if (pOffset[++nIndex] == 0x81)
				nIndex++;

			nLength     = pOffset[nIndex++];
			nNumOfFiles   = pOffset[nIndex++];

			pFiles = (UINT8 *)CSW_SIM_MALLOC(nLength);

			SUL_MemCopy8(pFiles, &pOffset[nIndex], nLength);

			//_SAT_SendSimClose( nSimID );
			//_SAT_SendSimOpen( nSimID );
			//Add by Lixp at 20130721
			//Ŀǰֻ���ֻ�����פ��
			//_SAT_SendSimClose( nSimID );
			//_SAT_SendSimOpen( nSimID);
			UINT8 nUTI = 0x00;
			CFW_GetFreeUTI(0, &nUTI);

			UINT32 nRet = CFW_SetComm(CFW_DISABLE_COMM, 1, nUTI, nSimID);
			gSatFreshComm[nSimID] = 0x11;

			AT_TC(g_sw_AT_SAT, "CFW_SetComm  nRet[0x%x] gSatFreshComm[%d] %d\n", nRet, nSimID, gSatFreshComm[nSimID]);

			return ERR_SUCCESS;
		}
		else
		{
			return ERR_SUCCESS;
		}
	}
	else if( 0x02 == nComQualifier )
	{

		if ((pOffset[nIndex] == 0x12) || (pOffset[nIndex] == 0x92))
		{

			if (pOffset[++nIndex] == 0x81)
				nIndex++;

			nLength     = pOffset[nIndex++];
			nNumOfFiles   = pOffset[nIndex++];

			pFiles = (UINT8 *)CSW_SIM_MALLOC(nLength);

			SUL_MemCopy8(pFiles, &pOffset[nIndex], nLength);
			//_SAT_SendSimClose( nSimID );
			//_SAT_SendSimOpen( nSimID );
			//Add by Lixp at 20130721
			//Ŀǰֻ���ֻ�����פ��
			//_SAT_SendSimClose( nSimID );
			//_SAT_SendSimOpen( nSimID);

			UINT8 nUTI = 0x00;
			CFW_GetFreeUTI(0, &nUTI);
			UINT32 nRet = CFW_SetComm(CFW_DISABLE_COMM, 1, nUTI, nSimID);
			gSatFreshComm[nSimID] = 0x21;

			AT_TC(g_sw_AT_SAT, "CFW_SetComm  nRet[0x%x] gSatFreshComm[%d] %d\n", nRet, nSimID, gSatFreshComm[nSimID]);


			return ERR_SUCCESS;
		}
		else
		{
		}
	}
	else if( 0x03 == nComQualifier )
	{
		//Add by Lixp at 20130721
		//Ŀǰֻ���ֻ�����פ��
		//_SAT_SendSimClose( nSimID );
		//_SAT_SendSimOpen( nSimID);

		UINT8 nUTI = 0x00;
		CFW_GetFreeUTI(0, &nUTI);
		//UINT32 nRet = CFW_SetComm(CFW_DISABLE_COMM,1,nUTI,nSimID);
		UINT32 nRet = CFW_SimReset(nUTI, nSimID);
		gSatFreshComm[nSimID] = 0x31;

		AT_TC(g_sw_AT_SAT, "CFW_SimReset  nRet[0x%x] gSatFreshComm[%d] %d\n", nRet, nSimID, gSatFreshComm[nSimID]);

		return ERR_SUCCESS;

	}
	else if( 0x04 == nComQualifier )
	{
		AT_TC(g_sw_AT_SAT, "CFW_SimInit[%d] %d\n", nSimID);
		gSatFreshComm[nSimID] = 0x41;
		CFW_SimInit( 0, nSimID );

		return ERR_SUCCESS;
	}
	else
	{
		//Reserved VALUES

	}
	CFW_SatResponse(0x01, 0x00, 0x00, NULL, 0x00, AT_ASYN_GET_DLCI(nSimID), nSimID);

	return ERR_SUCCESS;
}

UINT32 AT_SAT_SpecialCMDDisplayTxt(UINT8 *pFetchData, UINT32 nFetchDatalen, CFW_SIM_ID nSimID)
{
	UINT8 nCodeSch  = 0;
	UINT8 *pTextStr = NULL;
	UINT32 nIndex = 0x00;
	UINT8 *pOffset = pFetchData;
	UINT16 nLength = 0x00;

	//pOffset += 2;
	AT_TC(g_sw_AT_SAT, "AT_SAT_SpecialCMDDisplayTxt\n");

	if (pOffset[1] == 0x81)
		nIndex = 2;
	else
		nIndex = 1;

	nIndex = nIndex + 10;
	if ((pOffset[nIndex] == 0x0D) || (pOffset[nIndex] == 0x8D))
	{
		if (pOffset[++nIndex] == 0x81)
			nIndex++;
		nLength  = pOffset[nIndex++] - 1;
		nCodeSch = pOffset[nIndex++];
		pTextStr = pOffset + nIndex;
	}
	else
	{
		CSW_TRACE(CFW_SAT_TS_ID | C_DETAIL, "Error Invalid data Not 0x0D or 0x8D But 0x%x", pOffset[nIndex]);
		return ERR_INVALID_PARAMETER;;
	}
	UINT8 nCSWDCS = nCodeSch;
	sms_tool_CheckDcs(&nCSWDCS);
	CSW_TRACE(CFW_SAT_TS_ID | C_DETAIL, "AT_SAT_SpecialCMDDisplayTxt nLength %d nCodeSch %d nCSWDCS %d\n", nLength, nCodeSch, nCSWDCS);

	if(0x00 == nCSWDCS)
	{
		UINT8 *p = (UINT8 *)AT_MALLOC(2 * nLength);
		SUL_ZeroMemory8(p, 2 * nLength);

		SUL_Decode7Bit(pTextStr, p, nLength);
		CSW_TRACE(CFW_SAT_TS_ID | C_DETAIL, "AT_SAT_SpecialCMDDisplayTxt p %s\n", p);
		AT_FREE(p);
	}
	else
	{
		CSW_TRACE(CFW_SAT_TS_ID | C_DETAIL, "AT_SAT_SpecialCMDDisplayTxt pTextStr %s\n", pTextStr);
	}



	return ERR_SUCCESS;
}



UINT32 AT_SAT_SpecialCMDPollInterval(UINT8 *pFetchData, UINT32 nFetchDatalen, CFW_SIM_ID nSimID)
{

	UINT32 nIndex       = 0x00;
	UINT8 *pOffset      = pFetchData;
	UINT8 nLen          = 0x00;
	UINT8 nTimeUnit     = 0x00;
	UINT8 nTimeInterval = 0x00;


	AT_TC(g_sw_AT_SAT, "%s\n", __func__);

	if (pOffset[1] == 0x81)
		nIndex = 2;
	else
		nIndex = 1;

	nIndex = nIndex + 10;

	if ((pOffset[nIndex] == 0x04) || (pOffset[nIndex] == 0x84))
	{
		nLen          = pOffset[nIndex + 1];
		nTimeUnit     = pOffset[nIndex + 2];
		nTimeInterval = pOffset[nIndex + 3];
	}
	else
	{
		AT_TC(g_sw_AT_SAT, "Invald tag pOffset[nIndex] 0x%x", pOffset[nIndex]);
		return ERR_SUCCESS;
	}

	AT_TC(g_sw_AT_SAT, "Success nTimeInterval %d nTimeUnit %d", nTimeInterval, nTimeUnit);

	_ResetSimTimer(nTimeInterval, nTimeUnit, nSimID);

	return ERR_SUCCESS;
}
extern UINT32 gSATTimerValue[ ][CFW_SIM_COUNT];

UINT32 AT_SAT_SpecialCMDTimerManagement(UINT8 *pFetchData, UINT32 nFetchDatalen, CFW_SIM_ID nSimID)
{

	UINT32 nIndex		= 0x00;
	UINT8 *pOffset 		= pFetchData;
	UINT8 nTimerID		= 0x00;
	UINT8 nHour			= 0x00;
	UINT8 nMinute		= 0x00;
	UINT8 nSecond		= 0x00;
	UINT32 nTimerValue	= 0x00;

	UINT32 nRet = ERR_SUCCESS;

	AT_TC(g_sw_AT_SAT, "%s\n", __func__);

	if (pOffset[1] == 0x81)
		nIndex = 2;
	else
		nIndex = 1;

	UINT8 nComQualifier = pOffset[nIndex + 5];

	nIndex = nIndex + 10;
	if ((pOffset[nIndex] == 0x24) || (pOffset[nIndex] == 0xA4))
	{
		nTimerID = _GetTimerIdentifier(&pOffset[nIndex]) ;
		nIndex += 3;
	}
	if ((pOffset[nIndex] == 0x25) || (pOffset[nIndex] == 0xA5))
	{
		nTimerValue = _GetTimerValue(&pOffset[nIndex]);
		nHour = nTimerValue >> 16;
		nMinute = nTimerValue >> 8;
		nSecond = nTimerValue & 0xFF;
	}
	if(nTimerID)
	{
		gSATTimerValue[nTimerID - 1][nSimID] = nTimerValue ;
	}
	BOOL bRet = FALSE;
	/*
	-	TIMER MANAGEMENT
	bits 1 to 2
			00 = start
			01 = deactivate
			10 = get current value
			11 = RFU
	bits 3 to 8 RFU

	*/

	CSW_TRACE(CFW_SAT_TS_ID | C_DETAIL, "nComQualifier %d\n", nComQualifier);
	if( 0x00 == nComQualifier )
	{
		bRet = COS_SetTimerEX(0xFFFFFFFF, PRV_CFW_STK_TM_ID1_TIMER_SIM0_ID + nSimID * 8 + nTimerID - 1, COS_TIMER_MODE_SINGLE, (nHour * 60 * 60 + nMinute * 60 + nSecond) * 1000 MILLI_SECOND);
		CSW_TRACE(CFW_SAT_TS_ID | C_DETAIL, "COS_SetTimerEX	  %d\n", bRet);
		CSW_TRACE(CFW_SAT_TS_ID | C_DETAIL, "nTimerID	  %d\n", nTimerID);
		CSW_TRACE(CFW_SAT_TS_ID | C_DETAIL, "Second	  %d\n", (nHour * 60 * 60 + nMinute * 60 + nSecond));
	}
	else if( 0x01 == nComQualifier )
	{
		bRet = COS_KillTimerEX(0xFFFFFFFF, PRV_CFW_STK_TM_ID1_TIMER_SIM0_ID + nSimID * 8 + nTimerID - 1);
		CSW_TRACE(CFW_SAT_TS_ID | C_DETAIL, "COS_KillTimerEX	  %d\n", bRet);
		CSW_TRACE(CFW_SAT_TS_ID | C_DETAIL, "nTimerID	  %d\n", nTimerID);
	}

	UINT8 pResponseDataQual1[250] = {0x81, 0x03, 0x01, 0x27, 0x01, 0x82, 0x02, 0x82, 0x81, 0x83, 0x01, 0x00, 0x04, 0x01, 0x01, 0xa5, 0x03, 0x00, 0x00, (UINT8)sxs_ExistTimer(HVY_TIMER_IN + PRV_CFW_STK_TM_ID1_TIMER_SIM0_ID + nSimID * 8 + nTimerID - 1) / 16384};
	UINT8 pResponseDataQual0[250] = {0x81, 0x03, 0x01, 0x27, 0x01, 0x82, 0x02, 0x82, 0x81, 0x83, 0x01, 0x00};
	pResponseDataQual1[2] = CFW_GetCurrentCmdNum(nSimID);
	pResponseDataQual0[2] = CFW_GetCurrentCmdNum(nSimID);

	if(nComQualifier == 1)
	{
#ifdef AT_DUAL_SIM
		nRet = CFW_SatResponse (0xFF, 0x00, 0x0, pResponseDataQual1, 20,  AT_ASYN_GET_DLCI(nSimID), nSimID);
#else
		nRet = CFW_SatResponse (0xFF, 0x00, 0x0, pResponseDataQual1, 20,  AT_ASYN_GET_DLCI(nSimID),);
#endif

	}
	else if(nComQualifier == 0)
	{
#ifdef AT_DUAL_SIM
		nRet = CFW_SatResponse (0xFF, 0x00, 0x0, pResponseDataQual0, 12,  AT_ASYN_GET_DLCI(nSimID), nSimID);
#else
		nRet = CFW_SatResponse (0xFF, 0x00, 0x0, pResponseDataQual0, 12,  AT_ASYN_GET_DLCI(nSimID),);
#endif

	}
	AT_TC(g_sw_AT_NW, "CFW_SatResponse nRet:0x%x!\n", nRet);

	return ERR_CONTINUE;


}
UINT32 AT_SAT_SpecialCMDSendUSSD(UINT8 *pFetchData, UINT32 nFetchDatalen, CFW_SIM_ID nSimID)
{

	AT_TC(g_sw_AT_SAT, "%s\n", __func__);

	UINT8 nAlphaLen  = 0;
	UINT8 nUSSDLen   = 0;
	UINT8 *nAlphaStr = NULL;

	UINT8 *nUSSDStr     = NULL;
	UINT8 *pUSSDPacket  = NULL;
	UINT8   nUSSDdcs    = 0;

	UINT8   UTI     = 0;
	UINT32  nRet    = 0;

	UINT16 nMemsize = SIZEOF(CFW_SAT_SMS_RSP);
	UINT16 nLength = 0x00;
	UINT32 nIndex = 0x00;
	UINT8 *pOffset = pFetchData;

	AT_TC(g_sw_AT_SAT, "gATSATSendUSSDFlag %d\n", gATSATSendUSSDFlag[nSimID]);

	gATSATSendUSSDFlag[nSimID] = TRUE;
	if (pOffset[1] == 0x81)
		nIndex = 2;
	else
		nIndex = 1;

	nIndex = nIndex + 10;

	if ((pOffset[nIndex] == 0x05) || (pOffset[nIndex] == 0x85))
	{
		if (pOffset[++nIndex] == 0x81)
			nIndex++;
		nLength   = pOffset[nIndex++];
		nAlphaLen = nLength;
		nAlphaStr = pOffset + nIndex;
	}
	else
		nLength = 0;

	nIndex    = nIndex + nLength;
	nMemsize += nLength;

	if ((pOffset[nIndex] == 0x0A) || (pOffset[nIndex] == 0x8A))
	{
		if (pOffset[++nIndex] == 0x81)
			nIndex++;

		nLength  = pOffset[nIndex++];
		nUSSDdcs = pOffset[nIndex++];

		nUSSDLen = nLength;
		nUSSDStr = (UINT8 *)pOffset + nIndex;
	}
	else
	{
		AT_TC(g_sw_AT_SAT, "Error Invalid data Not 0x0A or 0x8A But 0x%x", pOffset[nIndex]);

		return ERR_INVALID_PARAMETER;
	}
	nMemsize += nLength;

	pUSSDPacket = (UINT8 *)AT_MALLOC(nUSSDLen - 1); //-1 is DCS
	if(pUSSDPacket == NULL)
	{
		return ERR_NO_MORE_MEMORY;
	}
	memset(pUSSDPacket, 0xFF, nUSSDLen - 1);
	memcpy(pUSSDPacket, nUSSDStr, nUSSDLen - 1);

	AT_TC(g_sw_AT_SAT, " nAddrLen = %d", nUSSDLen);
	AT_TC_MEMBLOCK(g_sw_AT_SAT, pUSSDPacket, nUSSDLen - 1, 16);

	//CFW_GetFreeUTI(0, &UTI);
	// ]]hameina[mod]2008-4-14 for bug 8055
	if (!g_ss_ussdUTIflag)  // currently not record the UTI,need a new one
	{
		nRet = AT_GetFreeUTI(CFW_SS_SRV_ID, &UTI);

		if (ERR_SUCCESS != nRet)
		{
			AT_TC(g_sw_AT_SAT, " UTI error");

			return ERR_INVALID_PARAMETER;
		}

		g_ss_ussdUTIflag = 1;

		g_ss_ussdUTI = UTI;
	}
	else
	{
		UTI = g_ss_ussdUTI;
	}

	nRet = CFW_SsSendUSSD(pUSSDPacket, nUSSDLen - 1, 3, nUSSDdcs, UTI, nSimID);
	if (nRet == ERR_SUCCESS)
	{
		AT_TC(g_sw_AT_SAT, " Success");
	}
	else
	{
		AT_TC(g_sw_AT_SAT, " CFW_SsSendUSSD error!!!! = %x", nRet);
	}

	AT_FREE(pUSSDPacket);
	pUSSDPacket = NULL;

	return ERR_SUCCESS;
}

UINT32 AT_SAT_SpecialCMDCallSetup(UINT8 *pFetchData, UINT32 nFetchDatalen, CFW_SIM_ID nSimID)
{
	AT_TC(g_sw_AT_SAT, "AT_SAT_SpecialCMDCallSetup AT_SAT_SpecialCMDCallSetup %d\n", gATSATSetupCallFlag[nSimID]);
	UINT8 nAlphaConfirmLen  = 0;
	UINT8 *pAlphaConfirmStr = NULL;

	UINT8 nAlphaSetupLen  = 0;
	UINT8 *pAlphaSetupStr = NULL;

	UINT8 nAddrLen  = 0;
	UINT8 nAddrType = 0;
	UINT8 *pAddrStr = NULL;

	UINT8 nSubAddrLen  = 0;
	UINT8 *pSubAddrStr = NULL;

	UINT8 nCapabilityCfgLen  = 0;
	UINT8 *pCapabilityCfgStr = NULL;

	UINT8 nTuint     = 0;
	UINT8 nTinterval = 0;

	CFW_SAT_CALL_RSP *pCallResp = NULL;
	UINT16 nMemsize = SIZEOF(CFW_SAT_CALL_RSP);
	UINT16 nLength = 0x00;
	UINT32 nIndex = 0x00;
	UINT8 *pOffset = pFetchData;

	gATSATSetupCallFlag[nSimID] = TRUE;
	if (pOffset[1] == 0x81)
		nIndex = 2;
	else
		nIndex = 1;
	nIndex = nIndex + 10;
	if ((pOffset[nIndex] == 0x05) || (pOffset[nIndex] == 0x85))
	{
		if (pOffset[++nIndex] == 0x81)
			nIndex++;
		nLength          = pOffset[nIndex++];
		nAlphaConfirmLen = nLength;
		pAlphaConfirmStr = pOffset + nIndex;
	}
	else
		nLength = 0;

	nIndex = nIndex + nLength;
	nMemsize += nLength;

	if ((pOffset[nIndex] == 0x06) || (pOffset[nIndex] == 0x86))
	{
		if (pOffset[++nIndex] == 0x81)
			nIndex++;
		nLength   = pOffset[nIndex++] - 1;
		nAddrLen  = nLength;
		nAddrType = pOffset[nIndex++];
		pAddrStr  = pOffset + nIndex;
	}
	else
	{
		AT_TC(g_sw_AT_SAT, "Error Invalid data Not 0x06 or 0x86 But 0x%x", pOffset[nIndex]);

		return ERR_INVALID_PARAMETER;;
	}
	nIndex = nIndex + nLength;
	nMemsize += nLength;
	if ((pOffset[nIndex] == 0x07) || (pOffset[nIndex] == 0x87))
	{
		if (pOffset[++nIndex] == 0x81)
			nIndex++;
		nLength           = pOffset[nIndex++];
		nCapabilityCfgLen = nLength;
		pCapabilityCfgStr = (UINT8 *)pOffset + nIndex;
	}
	else
		nLength = 0;

	nIndex = nIndex + nLength;
	nMemsize += nLength;
	if ((pOffset[nIndex] == 0x08) || (pOffset[nIndex] == 0x88)) // SubAddress
	{
		if (pOffset[++nIndex] == 0x81)
			nIndex++;
		nLength     = pOffset[nIndex++];
		nSubAddrLen = nLength;
		pSubAddrStr = (UINT8 *)pOffset + nIndex;
	}

	nIndex = nIndex + nLength;
	nMemsize += nLength;
	if ((pOffset[nIndex] == 0x04) || (pOffset[nIndex] == 0x84)) // Duration
	{
		nTuint     = pOffset[nIndex + 2];
		nTinterval = pOffset[nIndex + 3];
		nLength    = 4;
	}
	nIndex = nIndex + nLength;
	nMemsize += nLength;
	if ((pOffset[nIndex] == 0x1E) || (pOffset[nIndex] == 0x9E))
		nIndex = nIndex + 4;

	if ((pOffset[nIndex] == 0x05) || (pOffset[nIndex] == 0x85))
	{
		if (pOffset[++nIndex] == 0x81)
			nIndex++;
		nLength        = pOffset[nIndex++];
		nAlphaSetupLen = nLength;
		pAlphaSetupStr = pOffset + nIndex;
	}
	nMemsize += nLength;

	pCallResp = (CFW_SAT_CALL_RSP *)AT_MALLOC(nMemsize); //4//46
	if (pCallResp == NULL)
	{
		AT_TC(g_sw_AT_SAT, "Error Malloc failed\n");

		return ERR_NO_MORE_MEMORY;;
	}
	//pCallResp->nComID        = pG_SimSat->nCurCmd;
	//pCallResp->nComQualifier = nComQualifier;
	pCallResp->nAlphaConfirmLen = nAlphaConfirmLen;
	pCallResp->pAlphaConfirmStr = (UINT8 *)pCallResp + SIZEOF(CFW_SAT_CALL_RSP);
	SUL_MemCopy8(pCallResp->pAlphaConfirmStr, pAlphaConfirmStr, nAlphaConfirmLen);

	pCallResp->nAddrLen  = nAddrLen;
	pCallResp->nAddrType = nAddrType;
	pCallResp->pAddrStr  = pCallResp->pAlphaConfirmStr + nAlphaConfirmLen;
	SUL_MemCopy8(pCallResp->pAddrStr, pAddrStr, nAddrLen);

	pCallResp->nCapabilityCfgLen = nCapabilityCfgLen;
	pCallResp->pCapabilityCfgStr = pCallResp->pAddrStr + nAddrLen;
	SUL_MemCopy8(pCallResp->pCapabilityCfgStr, pCapabilityCfgStr, nCapabilityCfgLen);

	pCallResp->nSubAddrLen = nSubAddrLen;
	pCallResp->pSubAddrStr = pCallResp->pCapabilityCfgStr + nCapabilityCfgLen;
	SUL_MemCopy8(pCallResp->pSubAddrStr, pSubAddrStr, nSubAddrLen);

	pCallResp->nTuint     = nTuint;
	pCallResp->nTinterval = nTinterval;

	pCallResp->nAlphaSetupLen = nAlphaSetupLen;
	pCallResp->pAlphaSetupStr = pCallResp->pSubAddrStr + nSubAddrLen;
	SUL_MemCopy8(pCallResp->pAlphaSetupStr, pAlphaSetupStr, nAlphaSetupLen);


	CFW_DIALNUMBER nDialNumber;
	UINT8 nCCIndex = 0x00;
	nDialNumber.pDialNumber = AT_MALLOC(pCallResp->nAddrLen);
	SUL_MemSet8(nDialNumber.pDialNumber, 0x00, pCallResp->nAddrLen);
	SUL_MemCopy8(nDialNumber.pDialNumber, pCallResp->pAddrStr, pCallResp->nAddrLen);
	nDialNumber.nDialNumberSize = pCallResp->nAddrLen;
	nDialNumber.nType = pCallResp->nAddrType;

	if (pCallResp != NULL)
	{
		AT_FREE(pCallResp);
		pCallResp = NULL;
	}
	CFW_CcInitiateSpeechCallEx(&nDialNumber, &nCCIndex, AT_ASYN_GET_DLCI(nSimID), nSimID);
	return ERR_SUCCESS;
}

UINT8 *gSATSpecialCMDData[CFW_SIM_COUNT] = {NULL,};
UINT8 gSATSpecialCMDDataLen[CFW_SIM_COUNT] = {0x00,};

UINT32 AT_SAT_SpecialCMDProcess(UINT8 *pFetchData, UINT32 nFetchDatalen, CFW_SIM_ID nSimID)
{
	if(!pFetchData)
	{
		return 0x00;
	}

	AT_TC_MEMBLOCK(g_sw_AT_SAT, pFetchData, nFetchDatalen, 16);

	UINT32 nIndex   = 0x00;
	UINT32 nLength  = 0x00;
	UINT32 nRet     = 0x00;

	UINT8 *pOffset  = pFetchData;


	if (pOffset[1] == 0x81)
		nIndex = 2;
	else
		nIndex = 1;

	nLength  = pOffset[nIndex] + nIndex; // Update the length

	AT_TC(g_sw_AT_SAT, "%s DataLen[%d]\n\n", __func__, nLength);

	UINT8 nSAT_CmdType      = pOffset[nIndex + 4];

	AT_TC(g_sw_AT_SAT, "Fetch data nSAT_CmdType 0x%x\n\n", nSAT_CmdType);

	switch(nSAT_CmdType)
	{
		//SAT PROVIDE LOCAL INFORMATION
	case 0x26:
		nRet = AT_SAT_SpecialCMDProvideLocalInfo(pFetchData, nFetchDatalen, nSimID);
		break;


		//SAT SMS
	case 0x13:
		AT_SAT_SpecialCMDSendSMS(pFetchData, nFetchDatalen, nSimID);
		break;

		//SAT USSD
	case 0x12:
		AT_SAT_SpecialCMDSendUSSD(pFetchData, nFetchDatalen, nSimID);
		break;
#if 0
	case 0x05:
	{
		UINT8 nRspData[] = {0x81, 0x03, 0x02, 0x05, 0x00, 0x02, 0x82, 0x81, 0x83, 0x01, 0x00};
		CFW_SatResponse(0xFF, 0x00, 0, nRspData, 0x0b, AT_ASYN_GET_DLCI(nSimID), nSimID);
		nRet = ERR_CONTINUE;
	}
	break;
	case 0x03:
	{
		UINT8 nRspData[] = {0x81, 0x03, 0x02, 0x03, 0x00, 0x02, 0x82, 0x81, 0x83, 0x01, 0x00};
		CFW_SatResponse(0xFF, 0x00, 0, nRspData, 0x0b, AT_ASYN_GET_DLCI(nSimID), nSimID);
		nRet = ERR_CONTINUE;
	}
#endif
	break;
	//SAT CALL
	case 0x10:
	{
		if(gSATSpecialCMDData[nSimID])
		{
			AT_FREE(gSATSpecialCMDData[nSimID]);
			gSATSpecialCMDData[nSimID] = NULL;
		}

		gSATSpecialCMDData[nSimID] = (UINT8 *)AT_MALLOC(nFetchDatalen);

		SUL_ZeroMemory8(gSATSpecialCMDData[nSimID], nFetchDatalen);
		SUL_MemCopy8(gSATSpecialCMDData[nSimID], pFetchData, nFetchDatalen);

		gSATSpecialCMDDataLen[nSimID] = nFetchDatalen;

	}
	AT_TC(g_sw_AT_SAT, "AT_SAT_SpecialCMDCallSetup no process\n\n");
	//AT_SAT_SpecialCMDCallSetup(pFetchData, nFetchDatalen,nSimID);
	break;

	case 0x01:
	{
		AT_SAT_SpecialCMDRefresh(pFetchData, nFetchDatalen, nSimID);
	}
	break;

	case 0x21:
	{
		AT_SAT_SpecialCMDDisplayTxt(pFetchData, nFetchDatalen, nSimID);
	}
	break;

	case 0x3:
	{
		AT_SAT_SpecialCMDPollInterval(pFetchData, nFetchDatalen, nSimID);
	}
	break;
	case 0x27:
	{
		nRet = AT_SAT_SpecialCMDTimerManagement(pFetchData, nFetchDatalen, nSimID);
	}
	break;

	default:
		break;
	}
	if(ERR_CONTINUE == nRet)
		return 0x00;
	else
		return nSAT_CmdType;
}

UINT8 gDestAsciiData[CFW_SIM_COUNT][512]            = {{0x00,},};
UINT8 gDestAsciiDataSetUpMenu[CFW_SIM_COUNT][512]   = {{0x00,},};

UINT8 _GetStarSharp(UINT8 n)
{
	if( 0x0a == n ) return '*';
	else if( 0x0b == n ) return '#';
	else if( 0x0c == n ) return 'p';
	else if( 0x0d == n ) return 'w';
	else if( 0x0e == n ) return 'w';
	else if( 0x0f == n ) return 'w';
	else return (n + '0');

}

UINT8 *_GetSSString(UINT8 *pString, UINT32 nLen)
{
	UINT8 *p = (UINT8 *)AT_MALLOC(2 * nLen + 2);

	SUL_ZeroMemory8(p, 2 * nLen + 2);

	UINT32 i = 0x00;
	UINT32 j = 0x00;

	for( ; i < nLen; i++)
	{
		p[j] = _GetStarSharp(pString[i] & 0xF);
		p[j + 1] = _GetStarSharp((pString[i] >> 4) & 0xF);
		j = j + 2;
	}

	if(nLen)
	{
		if(p[2 * nLen - 1] == 'w') p[2 * nLen - 1] = 0x00;
	}

	AT_TC(g_sw_AT_SAT, "_GetUSSDString strlen %d %s\n", strlen(p), p);

	return p;

}


#define _IsAddressTag(nTag)     ((nTag == 0x06) ||  (nTag == 0x86))
#define _IsSSStringTag(nTag)    ((nTag == 0x09) ||  (nTag == 0x89))
#define _IsUSSDStringTag(nTag)  ((nTag == 0x0A) ||  (nTag == 0x8A))

/*
SS string
Byte(s) Description Length
1   SS string tag   1
2 to (Y 1)+2    Length (X)  Y
(Y 1)+3     TON and NPI 1
(Y 1)+4 to (Y 1)+X+2    SS or USSD string   X - 1

*/
UINT32 _ProcessCallControlSS(UINT8 *pData, CFW_SIM_ID nSim)
{
	UINT32 nRet = ERR_SUCCESS;
	UINT8 *w     = _GetSSString( &( pData[5] ), pData[3] - 1 );

	gATSATSendUSSDFlag[nSim] = TRUE;

	nRet = CFW_SsSendUSSD(w, strlen(w), 131, 0, AT_ASYN_GET_DLCI(nSim), nSim);

	AT_FREE(w);
	w = NULL;

	AT_TC(g_sw_AT_SAT, "_ProcessCallControlSS nRet 0x%x", nRet);

	if( ERR_SUCCESS != nRet )
	{
		CFW_SatResponse(0x11, 0x34, 0x00, NULL, 0x00, AT_ASYN_GET_DLCI(nSim), nSim);
		gATSATSendUSSDFlag[nSim] = FALSE;
	}

	return nRet;
}


/*
USSD string
Byte(s) Description Length
1   USSD string tag 1
2 to (Y-1)+2    Length (X)  Y
(Y-1)+3 Data coding scheme  1
(Y-1)+4 to (Y-1)+X+2    USSD string X-1

*/
UINT32 _ProcessCallControlUSSD(UINT8 *pData, CFW_SIM_ID nSim)
{
	UINT32 nRet = ERR_SUCCESS;
	//UINT8*w     = _GetUSSDString( &( pData[5] ), pData[3] - 1 );

	gATSATSendUSSDFlag[nSim] = TRUE;

	nRet = CFW_SsSendUSSD(&(pData[5]), pData[3], 3, pData[4], AT_ASYN_GET_DLCI(nSim), nSim);


	AT_TC(g_sw_AT_SAT, "_ProcessCallControlUSSD nRet 0x%x", nRet);

	if( ERR_SUCCESS != nRet )
	{
		CFW_SatResponse(0x12, 0x34, 0x00, NULL, 0x00, AT_ASYN_GET_DLCI(nSim), nSim);
		gATSATSendUSSDFlag[nSim] = FALSE;
	}
	return nRet;
}

/*
Address
Byte(s) Description Length
1   Address tag 1
2 to (Y 1)+2    Length (X)  Y
(Y 1)+3 TON and NPI 1
(Y 1)+4 to (Y 1)+X+2    Dialling number string  X 1

*/
UINT32 _ProcessCallControlAdress(UINT8 *pData, CFW_SIM_ID nSim)
{
	UINT32 nRet = ERR_SUCCESS;

	gATSATSetupCallFlag[nSim] = TRUE;

	CFW_DIALNUMBER nDialNumber;
	UINT8 nCCIndex = 0x00;

	nDialNumber.pDialNumber = AT_MALLOC(pData[3]);

	SUL_MemSet8(nDialNumber.pDialNumber, 0x00, pData[3]);
	SUL_MemCopy8(nDialNumber.pDialNumber, &(pData[5]), pData[3] - 1);

	nDialNumber.nDialNumberSize = pData[3] - 1;
	nDialNumber.nType           = pData[4];

	nRet = CFW_CcInitiateSpeechCallEx(&nDialNumber, &nCCIndex, AT_ASYN_GET_DLCI(nSim), nSim);

	AT_TC(g_sw_AT_SAT, "_ProcessCallControlAdress nRet 0x%x", nRet);

	if( ERR_SUCCESS != nRet )
	{
		CFW_SatResponse(0x10, 0x34, 0x00, NULL, 0x00, AT_ASYN_GET_DLCI(nSim), nSim);
		gATSATSetupCallFlag[nSim] = FALSE;
	}
	return nRet;
}

UINT8 _GetCallControlStringTag(UINT8 *pData)
{
	return (pData[2]);
}

VOID AT_SAT_AsyncEventProcess(COS_EVENT *pEvent)
{

	PAT_CMD_RESULT pResult = 0;

	CFW_EVENT CfwEvent;
	CFW_EVENT *pCfwEvent = &CfwEvent;

#ifdef AT_DUAL_SIM
	UINT8 nSim;
#endif

	AT_CosEvent2CfwEvent(pEvent, pCfwEvent);

#ifdef AT_DUAL_SIM
	nSim = pCfwEvent->nFlag;
#endif
	AT_TC(g_sw_AT_SAT, "SAT_AsyncEventProcess: nEventId = %d, nType:0x%x\n", pCfwEvent->nEventId, pCfwEvent->nType);

	if ( EV_CFW_SAT_RESPONSE_RSP == pCfwEvent->nEventId )
	{
		if (pCfwEvent->nType == 0)
		{

			AT_TC(g_sw_AT_SAT, "SAT_AsyncEventProcess: gATSATSetupCallFlag=%d, gATSATLocalInfoFlag=%d,gATSATSendUSSDFlag=%d,gATSATSendSMSFlag=%d \n",
			      gATSATSetupCallFlag[nSim], gATSATLocalInfoFlag[nSim], gATSATSendUSSDFlag[nSim], gATSATSendSMSFlag[nSim]);

			if(!(gATSATSetupCallFlag[nSim] || gATSATLocalInfoFlag[nSim] || gATSATSendUSSDFlag[nSim] || gATSATSendSMSFlag[nSim]))
			{
				AT_TC(g_sw_AT_SAT, "c\n");

				pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME,
				                      0, NULL, 0, /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));

				if (pResult != NULL)
					AT_Notify2ATM(pResult, /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));

				if (pResult != NULL)
				{
					AT_FREE(pResult);
					pResult = NULL;
				}
			}
			else
			{
				gATSATSetupCallFlag[nSim] = gATSATLocalInfoFlag[nSim] = gATSATSendUSSDFlag[nSim] = gATSATSendSMSFlag[nSim] = FALSE;
			}


			AT_TC(g_sw_AT_SAT, "EV_CFW_SAT_RESPONSE_RSP    CMD_FUNC_SUCC  pCfwEvent->nParam1~2 0x%x 0x%x", pCfwEvent->nParam1, pCfwEvent->nParam2);

			if((0xD4 != pCfwEvent->nParam1 ) && (0xFE != pCfwEvent->nParam1))
			{
				if (0x90 == pCfwEvent->nParam2)
				{
					UINT8 Str[] = "STNN";

					pResult = AT_CreateRC(CSW_IND_NOTIFICATION, CMD_RC_CR, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME,
					                      0, Str, AT_StrLen(Str), /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));

					AT_TC(g_sw_AT_SAT, "EV_CFW_SAT_RESPONSE_RSP STNN SW1 0x90 No fetch data");

				}
			}
			else //if(0xD4 == pCfwEvent->nParam1)
			{
				CFW_SAT_TERMINAL_ENVELOPE_CNF *p = (CFW_SAT_TERMINAL_ENVELOPE_CNF *)( pCfwEvent->nParam2);
#ifndef CHIP_HAS_AP
				if ( 0x90 == ( p->Sw1 & 0xFF ))
				{
					UINT8 Str[] = "STNN";

					pResult = AT_CreateRC(CSW_IND_NOTIFICATION, CMD_RC_CR, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME,
					                      0, Str, AT_StrLen(Str), /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));

					AT_TC(g_sw_AT_SAT, "EV_CFW_SAT_RESPONSE_RSP STNN SW1 0x90 No fetch data");

					if (pResult != NULL)
					{
						AT_Notify2ATM(pResult, /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));
					}

					if (pResult != NULL)
					{
						AT_FREE(pResult);
						pResult = NULL;
					}

				}
#endif
				AT_TC(g_sw_AT_SAT, "EV_CFW_SAT_RESPONSE_RSP STNN 0x%x p->NbByte %d", pCfwEvent->nParam1, p->NbByte);

				if( 0x00 != p->NbByte )
				{
					/*
					'00' = Allowed, no modification
					'01' = Not allowed
					'02' = Allowed with modifications

					*/
					UINT8 nFlag =  (p->ResponseData[0]) & 0xFF;
					UINT8 *pStr = NULL;
					AT_TC_MEMBLOCK(g_sw_AT_SAT, p->ResponseData, p->NbByte, 16);

					if(0x00 == nFlag)
					{
						pStr = "Allowed, no modification";
					}
					else if(0x01 == nFlag)
					{
						pStr = "Not allowed";
					}
					else if(0x02 == nFlag)
					{
						/*
						Description Section M/O Min Length
						Call control result -   M   Y   1
						Length (A+B+C+D+E+F)    -   M   Y   1 or 2
						Address or SS string or USSD string 12.1, 12.14 or 12.17
						O
						N
						A
						Capability configuration parameters 1   12.4    O   N   B
						Subaddress  12.3    O   N   C
						Alpha identifier    12.2    O   N   D
						BC repeat indicator 12.42   M/O N   E
						Capability configuration parameters 2   12.4    O   N   F

						*/
						pStr = "Allowed with modifications";


						UINT32 nRet = ERR_SUCCESS;

						UINT8 nTag = _GetCallControlStringTag(p->ResponseData);


						if(_IsAddressTag(nTag))
						{
							AT_TC(g_sw_AT_SAT, "_IsAddressTag");
							nRet = _ProcessCallControlAdress(p->ResponseData, nSim);
						}
						else if(_IsSSStringTag(nTag))
						{
							AT_TC(g_sw_AT_SAT, "_IsSSStringTag");
							nRet = _ProcessCallControlSS(p->ResponseData, nSim);
						}
						else if(_IsUSSDStringTag(nTag))
						{
							AT_TC(g_sw_AT_SAT, "_IsUSSDStringTag");
							nRet = _ProcessCallControlUSSD(p->ResponseData, nSim);
						}
						else
						{
							AT_TC(g_sw_AT_SAT, "else");
						}

						AT_TC(g_sw_AT_SAT, "After Proscess nRet 0x%x", nRet);

					}
					pResult = AT_CreateRC(CSW_IND_NOTIFICATION, CMD_RC_CR, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME,
					                      0, pStr, AT_StrLen(pStr), /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));

					AT_TC(g_sw_AT_SAT, "EV_CFW_SAT_RESPONSE_RSP 0xfe %s", pStr);
					if (pResult != NULL)
						AT_Notify2ATM(pResult, /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));

					if (pResult != NULL)
					{
						AT_FREE(pResult);
						pResult = NULL;
					}
				}
				else
				{
					UINT8 Str[] = "STNN";

					pResult = AT_CreateRC(CSW_IND_NOTIFICATION, CMD_RC_CR, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME,
					                      0, Str, AT_StrLen(Str), /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));

				        AT_TC(g_sw_AT_SAT, "EV_CFW_SAT_RESPONSE_RSP STNN 0x%x,p->Sw1 = 0x%02x, p->NbByte = 0x%x", pCfwEvent->nParam1, p->Sw1, p->NbByte);

					if (pResult != NULL)
					{
						AT_Notify2ATM(pResult, /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));
					}

					if (pResult != NULL)
					{
						AT_FREE(pResult);
						pResult = NULL;
					}

				}

				AT_FREE(p);
				p = NULL;

			}
		}
		else
		{
			if(!(gATSATSetupCallFlag[nSim] || gATSATLocalInfoFlag[nSim] || gATSATSendUSSDFlag[nSim] || gATSATSendSMSFlag[nSim]))
			{
				AT_TC(g_sw_AT_SAT, "error code  p1=  %x,p2=%x\n", pCfwEvent->nParam1, pCfwEvent->nParam2);
				pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME,
				                      0, NULL, 0, /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));

			}
			else
			{
				gATSATSetupCallFlag[nSim] = gATSATLocalInfoFlag[nSim] = gATSATSendUSSDFlag[nSim] = gATSATSendSMSFlag[nSim] = FALSE;
			}
			AT_TC(g_sw_AT_SAT, "EV_CFW_SAT_RESPONSE_RSP    CMD_FUNC_FAIL");
		}
	}
	else if (pCfwEvent->nEventId == EV_CFW_SAT_ACTIVATION_RSP)
	{
		AT_TC(g_sw_AT_SAT, "p1=%x,p2=%x,type==%x\n", pCfwEvent->nParam1, pCfwEvent->nParam2, pCfwEvent->nType);

		if (pCfwEvent->nType == 0)
		{
			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME,
			                      0, NULL, 0, /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));

			if (pResult != NULL)
				AT_Notify2ATM(pResult, /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			AT_TC(g_sw_AT_SAT, "EV_CFW_SAT_ACTIVATION_RSP    CMD_FUNC_SUCC");

			AllowedInstance = INSTANCE;

			if (0x90 == pCfwEvent->nParam2)
			{
				UINT8 Str[] = "STNN";

				pResult = AT_CreateRC(CSW_IND_NOTIFICATION, CMD_RC_CR, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME,
				                      0, Str, AT_StrLen(Str), /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));
				AT_TC(g_sw_AT_SAT, "EV_CFW_SAT_ACTIVATION_RSP STNN SW1 0x90 No fetch data");
			}
		}
		else
		{
			pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME,
			                      0, NULL, 0, /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));
			AT_TC(g_sw_AT_SAT, "EV_CFW_SAT_ACTIVATION_RSP    CMD_FUNC_FAIL");
		}




	}
	else if (pCfwEvent->nEventId == EV_CFW_SAT_CMDTYPE_IND)
	{
		if(CFW_GetSATIndFormate())
		{
			UINT8 nMessage[30];
			UINT8 nString[] = "^STN: %u";

			//AT_MemZero(gFetchData, 256);
			//strcpy(gFetchData, pCfwEvent->nParam1); // by wulc debug 20121012
			//AT_MemZero(nMessage, 30);

			AT_Sprintf(nMessage, nString, pCfwEvent->nParam1);
			AT_TC(g_sw_AT_SAT, "nMessage == %s", nMessage);
			pResult = AT_CreateRC(CSW_IND_NOTIFICATION, CMD_RC_CR, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME,
			                      0, nMessage, AT_StrLen(nMessage), AT_ASYN_GET_DLCI(nSim));

			AT_Notify2ATM(pResult, /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}
		}
		else
		{
			UINT32 nCMD = AT_SAT_SpecialCMDProcess((UINT8 *)pCfwEvent->nParam1, pCfwEvent->nParam2, nSim);

			if(0x00 == nCMD)
			{
				return;
			}

			AT_TC(g_sw_AT_SAT, "We got sat command");

			// AT_TC_MEMBLOCK(g_sw_SAT, (UINT8*)pCfwEvent->nParam1, AT_StrLen((UINT8*)pCfwEvent->nParam1), pCfwEvent->nParam2);

			UINT8 nDestAsciiData[512] = { 0x00, };
			UINT16 nDestAsciiDataLen  = 0x00;

			UINT32 i          = 0x00;
			UINT8 nSwitchData = 0x00;
			UINT8 *p          = (UINT8 *)pCfwEvent->nParam1;

			for (i = 0x00; i < pCfwEvent->nParam2; i++)
			{
				nSwitchData = (p[i] >> 4) + (p[i] << 4);
				p[i]        = nSwitchData;

			}
			nDestAsciiDataLen = SUL_GsmBcdToAsciiEx(((UINT8 *)pCfwEvent->nParam1), pCfwEvent->nParam2, nDestAsciiData);

			UINT8 nMessage[518] = { 0x00, };

			strcpy(nMessage, "^STN:");  // by wulc debug 20121012
			strcat(nMessage, nDestAsciiData);

			//if( 0x25 == nCMD )
			SUL_MemCopy8(gDestAsciiDataSetUpMenu[nSim], nDestAsciiData, 512);

			SUL_MemCopy8(gDestAsciiData[nSim], nDestAsciiData, 512);

			// SUL_MemCopy8(nMessage+5,(UINT8*)pCfwEvent->nParam1,pCfwEvent->nParam2);
			pResult = AT_CreateRC(CSW_IND_NOTIFICATION, CMD_RC_CR, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME,
			                      0, nMessage, nDestAsciiDataLen + 5, /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));
			AT_Notify2ATM(pResult, /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

		}

	}
	else
	{
		AT_TC(g_sw_AT_SAT, "SAT_AsyncEventProcess: WARNING no process nEventId = %d\n", pCfwEvent->nEventId);
		return;
	}
	if (pResult != NULL)
		AT_Notify2ATM(pResult, /* pCfwEvent->nUTI */ AT_ASYN_GET_DLCI(nSim));

	if (pResult != NULL)
	{
		AT_FREE(pResult);
		pResult = NULL;
	}

	return;
}

VOID AT_SAT_CmdFunc_STA(AT_CMD_PARA *pParam)
{
	PAT_CMD_RESULT pResult;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	AT_TC(g_sw_AT_SAT, "STA ENTER ok");

	if (pParam == NULL)
	{
		goto STA_ERROR;
	}
	else
	{
		AT_CMD_PARA *Param = pParam;

		if (Param->pPara == NULL) // First parameter(Length in PDU mode,Address in Text mode) is NULL.
			goto STA_ERROR;

		switch (Param->iType)
		{

		case AT_CMD_SET:
		{
			UINT8 NumOfParam = 0;
			UINT8 *Num       = Param->pPara;

			AT_TC(g_sw_AT_SAT, "6");

			if (ERR_SUCCESS != AT_Util_GetParaCount(Num, &NumOfParam))
				goto STA_ERROR;

			if (NumOfParam != 1)
				goto STA_ERROR;

			AT_TC(g_sw_AT_SAT, "5");

			// Get first parameter
			if ((Param->pPara[1] != 0) || (Param->pPara[0] > '1'))
				goto STA_ERROR;

			if (*Num == '1')
				gATCurrentAlphabet = UCS2_SET;
			else if (*Num == '0')
				gATCurrentAlphabet = GSM_SET;
			else
				goto STA_ERROR;

			if (AllowedInstance == NONE_INSTANCE)
			{
#ifdef AT_DUAL_SIM
				if (ERR_SUCCESS == CFW_SatActivation(0, pParam->nDLCI, nSim))
#else
				if (ERR_SUCCESS == CFW_SatActivation(0, pParam->nDLCI))
#endif
				{
					pResult = AT_CreateRC(CMD_FUNC_SUCC_ASYN, CMD_RC_OK,
					                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

					AT_TC(g_sw_AT_SAT, "NONE_INSTANCE");

					// add by wangxd for bug 8672
					g_ActiveSatFlag = 1;

					// add by wangxd for bug 8672
				}
				else
					pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
					                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);
			}
			else
			{
				pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
				                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);
				AT_TC(g_sw_AT_SAT, "INSTANCE");
			}

			AT_TC(g_sw_AT_SAT, "STA EXEC ok");

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return; // ERR_SUCCESS;
		}
		case AT_CMD_TEST:
		{
			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, "^STA: (0,1)", AT_StrLen("^STA: (0,1)"), pParam->nDLCI); // change "^STA: (0,1),(0,1)", 18 to "^STA: (0,1)", AT_StrLen("^STA: (0,1)")

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;
		}
		case AT_CMD_READ:
		{
			CFW_PROFILE *pProfile;

			// UINT8 nStr[255];                //modified by wangxd for bug 8523

			// add by wangxd for bug 8523
			UINT8 nStr[64] = { 0 };

			// add_end by wangxd for bug 8523
			UINT8 *pDest = nStr;

			pDest += AT_Sprintf(nStr, "^STA: %u,%u", gATCurrentAlphabet, AllowedInstance);

			// Adjust the code because csw code has been upgrade.

#ifdef AT_DUAL_SIM
			CFW_SimGetMeProfile(&pProfile, nSim);
#else
			CFW_SimGetMeProfile(&pProfile);
#endif


			AT_SAT_TransmitBinary(pDest, pProfile->pSat_ProfileData, pProfile->nSat_ProfileLen);
			AT_TC(g_sw_AT_SAT, "STA=(%s),LEN=%d", nStr, pProfile->nSat_ProfileLen);

			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
			                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, nStr, AT_StrLen(nStr), pParam->nDLCI);

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;
		}

		default:
			goto STA_ERROR;
		}
	}

STA_ERROR:

	pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
	                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);
	AT_TC(g_sw_AT_SAT, "3");

	if (pResult != NULL)
		AT_Notify2ATM(pResult, pParam->nDLCI);

	if (pResult != NULL)
	{
		AT_FREE(pResult);
		pResult = NULL;
	}

	return;
}

#define CFW_SAT_IND_PDU 0
#define CFW_SAT_IND_TEXT 1

VOID AT_SAT_CmdFunc_STR(AT_CMD_PARA *pParam)
{
	PAT_CMD_RESULT pResult;
	UINT32 nRet = ERR_SUCCESS;

	INT32 iRet = ERR_SUCCESS;
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	UINT8 pSATPDUGsmData[255] = { 0x00, };


	UINT8 *p          = (UINT8 *)pSATPDUGsmData;
	UINT8 i           = 0x00;
	UINT8 nSwitchData = 0x00;

	AT_TC(g_sw_AT_SAT, "CMD STR:start  nSim:%d", nSim);
	if (pParam == NULL)
	{
		AT_TC(g_sw_AT_SAT, "CMD STR:ERROR! pParam == NULL");
		goto STR_ERROR;
	}
	else
	{
		AT_CMD_PARA *Param = pParam;

		if (Param->pPara == NULL) // First parameter(Length in PDU mode,Address in Text mode) is NULL.
		{
			AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!Param->pPara == NULL");
			goto STR_ERROR;
		}

		AT_TC(g_sw_AT_SAT, "CMD STR: Param->iType %d", Param->iType);

		switch (Param->iType)
		{

		case AT_CMD_SET:
		{
			UINT8 NumOfParam = 0;
			UINT8 *Num       = Param->pPara;
			UINT8 Buf[5];
			UINT8 Cmd, State, Item;
			UINT8 *InString = NULL;
			UINT8 UTI = 0;


			i          = 5;

			if (ERR_SUCCESS != AT_Util_GetParaCount(Num, &NumOfParam))
			{
				AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!GetParaCount");
				goto STR_ERROR;
			}
			AT_TC(g_sw_AT_SAT, "CMD STR:NumOfParam %d", NumOfParam);

			if ((NumOfParam < 2) || (NumOfParam > 5))
			{
				AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!NumOfParam reage is err.");
				goto STR_ERROR;
			}

			// Get first parameter
			if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 0, Buf, &i))) // Get first parameter.
			{
				AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!Get first parameter is err.");
				goto STR_ERROR;
			}

			i = 5;

			Cmd = AT_StrAToI(Buf);
			if (NumOfParam == 3)
			{
				BOOL bRet = CFW_GetSATIndFormate();
				//bRet = CFW_SAT_IND_TEXT ;
				AT_TC(g_sw_AT_SAT, "CMD STR:Get Ind formate:%d", bRet);

				if (CFW_SAT_IND_PDU == bRet)
				{
					//UINT8* pData = (UINT8*)AT_MALLOC(255);

					UINT32 nSATDataLen = 0x00;

					//AT_MemZero(pData, 255);
					if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 1, Buf, &i))) // Get second parameter.
					{
						AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!Get second parameter is err.");
						goto STR_ERROR;
					}
					nSATDataLen = AT_StrAToI(Buf);

					AT_TC(g_sw_AT_SAT, "nSATDataLen %d", nSATDataLen);

					UINT8 *pSATPDUData = NULL;

					pSATPDUData = (UINT8 *)AT_MALLOC(255);
					AT_MemZero(pSATPDUData, 255);

					nSATDataLen = 255;

					if (ERR_SUCCESS != (iRet = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_STRING, pSATPDUData, (UINT8 *)&nSATDataLen)))
					{
						AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!Get third parameter is err.");
						goto STR_ERROR;
					}

					AT_TC(g_sw_AT_SAT, "Cmd %d  pSATPDUData %s", Cmd, pSATPDUData);


					nSATDataLen = SUL_AsciiToGsmBcdEx(pSATPDUData, nSATDataLen, pSATPDUGsmData);

					for (i = 0x00; i < nSATDataLen; i++)
					{
						nSwitchData = (p[i] >> 4) + (p[i] << 4);
						p[i]        = nSwitchData;

					}

					CFW_GetFreeUTI(0 , &UTI);
					if (0xFF == Cmd)
					{
						nRet = CFW_SatResponse(0xFF, 0x00, 0x00, pSATPDUGsmData, nSATDataLen, UTI, nSim);
						I_AM_HERE();
					}
					else if (0xFE == Cmd)
					{
						nRet = CFW_SatResponse(0xFE, 0x00, 0x00, pSATPDUGsmData, nSATDataLen, UTI, nSim);
						I_AM_HERE();
					}
					else
					{

					}

					if (ERR_SUCCESS == nRet)
					{

						pResult =
						    AT_CreateRC(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0,
						                pParam->nDLCI);

						I_AM_HERE();
					}
					else
					{
						pResult =
						    AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0,
						                pParam->nDLCI);

						I_AM_HERE();
					}

					if (pResult != NULL)
						AT_Notify2ATM(pResult, pParam->nDLCI);

					if (pResult != NULL)
					{
						AT_FREE(pResult);
						pResult = NULL;
					}

					if (pSATPDUData != NULL)
					{
						AT_FREE(pSATPDUData);
						pSATPDUData = NULL;
					}

					return;
				}
			}

			//
			// Get second parameter
			if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 1, Buf, &i)))
			{
				AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!Get second parameter is err.");
				goto STR_ERROR;
			}

			State = AT_StrAToI(Buf);

			// Get third parameter
			i = 5;

			if (NumOfParam == 3 || NumOfParam == 4 || NumOfParam == 5)
			{
				// The first Code is null.
				if (ERR_SUCCESS != (iRet = AT_Util_GetPara(Param->pPara, 2, Buf, &i)))
				{
					AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!Get third parameter is err.");
					goto STR_ERROR;
				}

				Item = AT_StrAToI(Buf);
			}
			else
				Item = 0;

			// Get fourth parameter
			i = 253;

			if (NumOfParam == 4  || NumOfParam == 5)
			{
				InString = (UINT8 *)AT_MALLOC(255);

				AT_MemZero(InString, 255);

				// Wangcf,Because the string include scheme byte. the lenght of the string add 1.

				if (ERR_SUCCESS != AT_Util_GetPara(Param->pPara, 3, InString + 1, &i))  // Get second parameter.
				{
					AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!Get fourth parameter is err.");
					goto STR_ERROR;
				}

				for (i = 0; i < AT_StrLen(InString + 1); i++)
					AT_TC(g_sw_AT_SAT, "%c", *(InString + i + 1));

				// add by wangxd for bug 8671

				UINT8 uParaLen  = 1;
				UINT32 uParamOk = 0;
				UINT8 uCmdPara  = 0;

				uParamOk = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uCmdPara, &uParaLen);

				if (uParamOk != ERR_SUCCESS)
				{
					AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!Get 0 parameter is fail.");
					goto STR_ERROR;
					return;
				}
				if ((uCmdPara != 36 ) && (uCmdPara != 35 ) && (uCmdPara != 34 ) && (uCmdPara != 33 ) && (uCmdPara != 16 ) && (uCmdPara != 20 ) && (uCmdPara != 23 ) && (uCmdPara != 211 ))
				{
					AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!Get 0 parameter isn't 35&&34 %d.", uCmdPara);
					goto STR_ERROR;
					return;
				}

				// add_end by wangxd for bug 8671
			}
			else
			{
				InString = NULL;
			}

			AT_TC(g_sw_AT_SAT, "CMD STR: InString 0x%x", InString);
			if (InString != NULL)
			{
				UINT8 *CmdData = NULL;
				UINT8 j        = 0;
				UINT8 nMin, nMax, nStrLen;
				AT_TC(g_sw_AT_SAT, "CMD STR: InString str:%s", InString);
				if (Cmd == 0x23)
				{
					CFW_SAT_INPUT_RSP *pInput = NULL;
#ifdef AT_DUAL_SIM

					if (CFW_SatGetInformation(Cmd, (PVOID)&CmdData, nSim) != ERR_SUCCESS)
#else
					if (CFW_SatGetInformation(Cmd, (PVOID)&CmdData) != ERR_SUCCESS)

#endif
					{
						AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!SatGetInformation is fail");
						goto STR_ERROR;
					}
					pInput = (CFW_SAT_INPUT_RSP *)CmdData;

					nMax = pInput->nResMaxLen;

					nMin = pInput->nResMinLen;

					nStrLen = AT_StrLen(InString + 1) - 2;

					AT_TC(g_sw_AT_SAT, "max = %u,min=%u,Len=%u", nMax, nMin, nStrLen);

					if ((nStrLen > nMax) || (nStrLen < nMin))
						goto STR_ERROR;

					if( NumOfParam == 5)
					{
						UINT8 nSchLen  = 1;
						UINT32 uParamOk = 0;
						UINT8 nSch  = 0;
						uParamOk = AT_Util_GetParaWithRule(pParam->pPara, 4, AT_UTIL_PARA_TYPE_UINT8, &nSch, &nSchLen);

						if (uParamOk != ERR_SUCCESS)
						{
							AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!Get 5 parameter is fail.");
							goto STR_ERROR;
							return;
						}
						*InString = nSch;

					}
					else
					{
						if (pInput->nDefTextSch != 0)
							*InString = pInput->nDefTextSch;
						else if (pInput->nTextSch != 0)
							*InString = pInput->nTextSch;
						else
							*InString = 0x04;
					}
					AT_TC(g_sw_AT_SAT, "CMD STR: *InString 0x%x", *InString);

					I_AM_HERE();
				}
				else if (Cmd == 0x22 )
				{
					CFW_SAT_INPUT_RSP *pInput = NULL;
#ifdef AT_DUAL_SIM

					if (CFW_SatGetInformation(Cmd, (PVOID)&CmdData, nSim) != ERR_SUCCESS)
#else
					if (CFW_SatGetInformation(Cmd, (PVOID)&CmdData) != ERR_SUCCESS)

#endif
					{
						AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!SatGetInformation is fail");
						goto STR_ERROR;
					}
					pInput = (CFW_SAT_INPUT_RSP *)CmdData;

					nMax = pInput->nResMaxLen;

					nMin = pInput->nResMinLen;

					nStrLen = AT_StrLen(InString + 1) - 2;

					AT_TC(g_sw_AT_SAT, "max = %u,min=%u,Len=%u", nMax, nMin, nStrLen);

					// if ((nStrLen > nMax) || (nStrLen < nMin))
					//goto STR_ERROR;

					//if (pInput->nDefTextSch != 0)
					//*InString = pInput->nDefTextSch;
					//else if (pInput->nTextSch != 0)
					// *InString = pInput->nTextSch;
					//else
					*InString = 0x04;

					AT_TC(g_sw_AT_SAT, "CMD STR: *InString 0x%x", *InString);

					I_AM_HERE();
				}

				else if (Cmd == 0x26)
				{
					for (j = 0; j < i + 1; j++)
						InString[j] = InString[j + 1];
				}
			}

			AT_TC(g_sw_AT_SAT, "CMD STR: Secord NumOfParam 0x%x", NumOfParam);

			if (NumOfParam == 2)
			{
				Item     = 0;
				InString = NULL;
				i        = 0;
			}
			else if (NumOfParam == 3)
			{
				InString = NULL;
				i        = 0;
			}
			else
			{
				if( (0x10 == Cmd) || (0x21 == Cmd) || (0xD3 == Cmd) || (0x14 == Cmd) || (0x24 == Cmd) || (0x22 == Cmd) || (0x23 == Cmd))
				{
					if(NumOfParam == 5)
					{
						UINT8 nAddLen  = 1;
						UINT32 uParamOk = 0;
						UINT8 nAddtion  = 0;
						uParamOk = AT_Util_GetParaWithRule(pParam->pPara, 4, AT_UTIL_PARA_TYPE_UINT8, &nAddtion, &nAddLen);

						if (uParamOk != ERR_SUCCESS)
						{
							AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!Get 5 parameter is fail.");
							goto STR_ERROR;
							return;
						}
						if(0x22 == Cmd)
						{
							UINT8 nInput = 0;
							uParamOk = AT_Util_GetParaWithRule(pParam->pPara, 3, AT_UTIL_PARA_TYPE_UINT8, &nInput, &nAddLen);
							if (uParamOk != ERR_SUCCESS)
							{
								AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!0x22 == Cmd Get 4 parameter is fail.");
								goto STR_ERROR;
								return;
							}

							InString[0] = nAddtion;
							InString[1] = nInput;
							i = 2;
						}
						else if((0 == nAddtion) && (0x23 == Cmd))
						{
							//"B69B6AB402"--> B6 9B 6A B4 02
							//we need do something
						}
						else
						{
							*InString = nAddtion;
							i = 1;
						}
					}

				}
				else
				{
					i           = AT_StrLen(InString + 1) ; // remove "
					AT_TC(g_sw_AT_SAT, "CMD STR: instring len: i: %d", i);

					InString[i] = 0;
					for(i = 1; i < AT_StrLen(InString + 1) + 1; i++ )
					{
						InString[i] = InString[i + 1];
					}
					i           = AT_StrLen(InString + 1) + 1 ; // remove "

					AT_TC(g_sw_AT_SAT, "CMD STR: *InString 2222 0x%x", *InString);
				}
			}
#if 0
			// add by wangxd for bug8672
			if (!g_ActiveSatFlag)
			{
				AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!no have active g_ActiveSatFlag: %d.", g_ActiveSatFlag);
				pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
				                      ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

				AT_Notify2ATM(pResult, pParam->nDLCI);

				if (pResult != NULL)
				{
					AT_FREE(pResult);
					pResult = NULL;
				}
				return;
			}
#endif
			// add_end by wangxd for bug 8672
			AT_TC(g_sw_AT_SAT, "CMD STR:para vual Cmd0x%x,State:%d,Item:%d,InString:0x%x", Cmd, State, Item, InString);

#ifdef AT_DUAL_SIM
			if (ERR_SUCCESS == CFW_SatResponse(Cmd, State, Item, InString, i, 32, nSim))
#else
			if (ERR_SUCCESS == CFW_SatResponse(Cmd, State, Item, InString, i, 32))

#endif
			{
				pResult = AT_CreateRC(CMD_FUNC_SUCC_ASYN, CMD_RC_OK,
				                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

				AT_TC(g_sw_AT_SAT, "CMD STR: SatResponse is OK.");
			}
			else
			{
				pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
				                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);
				AT_TC(g_sw_AT_SAT, "CMD STR:ERROR!SatResponse is fail.");
			}

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;
		}

		case AT_CMD_TEST:
		{

			UINT8 Str[] = "^STR: (16,19,33,35,36,37,38,211,254,255)";

			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
			                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;
		}

		case AT_CMD_READ:
		{
			UINT8 Str[50];

#ifdef AT_DUAL_SIM
			UINT8 nCmd = CFW_SatGetCurCMD(nSim);
#else
			UINT8 nCmd = CFW_SatGetCurCMD();

#endif

			if (nCmd == 0xFF)
			{
				goto STR_ERROR;
			}

			AT_Sprintf(Str, "^STR: %u", nCmd);

			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
			                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;
		}

		default:
			goto STR_ERROR;
		}
	}

STR_ERROR:

	pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
	                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

	if (pResult != NULL)
		AT_Notify2ATM(pResult, pParam->nDLCI);

	if (pResult != NULL)
	{
		AT_FREE(pResult);
		pResult = NULL;
	}

	return;
}

//
//Using to get STN message data
//we will save the STN message for android.
//
VOID AT_SAT_CmdFunc_STNR(AT_CMD_PARA *pParam)
{
	PAT_CMD_RESULT pResult;
	//UINT32 nRet = ERR_SUCCESS;

	//INT32 iRet = ERR_SUCCESS;
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	//  UINT8 pSATPDUGsmData[255] = { 0x00, };


	//UINT8* p          = (UINT8*)pSATPDUGsmData;
	//UINT8 i           = 0x00;
	//UINT8 nSwitchData = 0x00;


	if (pParam == NULL)
		goto STR_ERROR;
	else
	{
		AT_CMD_PARA *Param = pParam;

		AT_TC(g_sw_AT_SAT, "-------->>STNR Param->iType %d", Param->iType);

		if (Param->pPara == NULL) // First parameter(Length in PDU mode,Address in Text mode) is NULL.
		{
			AT_TC(g_sw_AT_SAT, "-------->>xx");
			goto STR_ERROR;
		}

		switch (Param->iType)
		{

		case AT_CMD_SET:
		{
#if 0
			UINT8 NumOfParam = 0;
			UINT8 *Num       = Param->pPara;
			UINT8 Buf[5];
			UINT8 Cmd, State, Item;
			UINT8 *InString = NULL;

			//CFW_SimListCountPbkEntries(CFW_PBK_SIM_FIX_DIALLING,1,2,3,0);

			CFW_SimInit( nSim );

			pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
			                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

			I_AM_HERE();

			AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}
			return;
#endif
			UINT8 Str[524] = {0x00,};

			AT_Sprintf(Str, "^STNR: %s", gDestAsciiDataSetUpMenu[nSim]);

			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
			                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;

		}

		case AT_CMD_TEST:
		{

			UINT8 Str[] = "^STNR: (Setup Menu, Display text.......)";

			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
			                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;
		}

		case AT_CMD_READ:
		{
			UINT8 Str[524] = {0x00,};

			AT_Sprintf(Str, "^STNR: %s", gDestAsciiData[nSim]);

			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
			                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;
		}

		default:
			goto STR_ERROR;
		}
	}

STR_ERROR:

	pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
	                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

	if (pResult != NULL)
		AT_Notify2ATM(pResult, pParam->nDLCI);

	if (pResult != NULL)
	{
		AT_FREE(pResult);
		pResult = NULL;
	}

	return;
}



//
//Do communciation work from RIL

#define AT_STRC_MAKE_CALL   0x01
#define AT_STRC_SEND_SMS    0x02
#define AT_STRC_SEND_USSD   0x03

#define AT_STRC_OK          0x01
#define AT_STRC_CANCEL      0x00

VOID AT_SAT_CmdFunc_STRC(AT_CMD_PARA *pParam)
{
	PAT_CMD_RESULT pResult;
	UINT32 nRet = ERR_SUCCESS;

	INT32 iRet = ERR_SUCCESS;
#ifdef AT_DUAL_SIM
	UINT8 nSimID = AT_SIM_ID(pParam->nDLCI);
#endif

	if (pParam == NULL)
		goto STR_ERROR;
	else
	{
		AT_CMD_PARA *Param = pParam;

		AT_TC(g_sw_AT_SAT, "-------->>AT_SAT_CmdFunc_STRC");

		if (Param->pPara == NULL) // First parameter(Length in PDU mode,Address in Text mode) is NULL.
		{
			AT_TC(g_sw_AT_SAT, "STRC");
			goto STR_ERROR;
		}

		switch (Param->iType)
		{
		case AT_CMD_SET:
		{
			UINT8 NumOfParam = 0;
			UINT8 *Num       = Param->pPara;
			UINT8 Buf;

			//UINT8* InString = NULL;
			//UINT8 UTI = 0;
			UINT8 nEnableFlag = 0x00;
			UINT8 i = 1;
			AT_TC(g_sw_AT_SAT, "AT_SAT_CmdFunc_STRC Enter AT_CMD_SET");
			if (ERR_SUCCESS != AT_Util_GetParaCount(Num, &NumOfParam))
				goto STR_ERROR;

			AT_TC(g_sw_AT_SAT, "NumOfParam %d", NumOfParam);

			if (NumOfParam > 2)
			{
				goto STR_ERROR;
			}

			// Get first parameter
			if (ERR_SUCCESS != (iRet = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &nEnableFlag, &i))) // Get first parameter.
			{
				AT_TC(g_sw_AT_SAT, "AT_Util_GetPara iRet Err 0x%x", iRet);
				goto STR_ERROR;
			}


			i = 1;
			// Get second parameter
			if (ERR_SUCCESS != (iRet = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &Buf, &i))) // Get first parameter.
			{
				AT_TC(g_sw_AT_SAT, "AT_Util_GetPara iRet Err 0x%x", iRet);
				goto STR_ERROR;
			}
			if( nEnableFlag == AT_STRC_OK )
			{
				switch(Buf)
				{
#if 0
				case AT_STRC_SEND_SMS:
					AT_SAT_SpecialCMDSendSMS(gSATSpecialCMDData[nSimID], gSATSpecialCMDDataLen[nSimID], nSimID);
					break;

				case AT_STRC_SEND_USSD:
					AT_SAT_SpecialCMDSendUSSD(gSATSpecialCMDData[nSimID], gSATSpecialCMDDataLen[nSimID], nSimID);
					break;
#endif
				case AT_STRC_MAKE_CALL:
					if( gSATSpecialCMDData[nSimID] && gSATSpecialCMDDataLen[nSimID])
					{
						AT_SAT_SpecialCMDCallSetup(gSATSpecialCMDData[nSimID], gSATSpecialCMDDataLen[nSimID], nSimID);
					}
					else
					{
						goto STR_ERROR;
					}
					break;

				default:
					break;
				}
			}
			else
			{
				switch(Buf)
				{
				case AT_STRC_SEND_SMS:

					nRet = CFW_SatResponse(0x13, 10, 0x00, NULL, 0x00, pParam->nDLCI, nSimID);
					break;

				case AT_STRC_SEND_USSD:
					nRet = CFW_SatResponse(0x12, 10, 0x00, NULL, 0x00, pParam->nDLCI, nSimID);
					break;

				case AT_STRC_MAKE_CALL:
					nRet = CFW_SatResponse(0x10, 10, 0x00, NULL, 0x00, pParam->nDLCI, nSimID);
					break;

				default:
					break;
				}
				AT_TC(g_sw_AT_SAT, "User cancel nRet 0x%x", nRet);

			}

			AT_FREE(gSATSpecialCMDData[nSimID]);

			gSATSpecialCMDData[nSimID]      = NULL;
			gSATSpecialCMDDataLen[nSimID]   = 0x00;

			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
			                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0x00, pParam->nDLCI);

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;
		}

		case AT_CMD_TEST:
		{

			UINT8 Str[] = "^STRC: (AT_STRC_MAKE_CALL, AT_STRC_SEND_SMS, AT_STRC_SEND_USSD)";

			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
			                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;
		}

		case AT_CMD_READ:
		{
			UINT8 Str[50];

#ifdef AT_DUAL_SIM
			UINT8 nCmd = CFW_SatGetCurCMD(nSimID);
#else
			UINT8 nCmd = CFW_SatGetCurCMD();

#endif

			if (nCmd == 0xFF)
			{
				goto STR_ERROR;
			}

			AT_Sprintf(Str, "^STRC: %u", nCmd);

			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
			                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;
		}

		default:
			goto STR_ERROR;
		}
	}

STR_ERROR:

	pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
	                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

	if (pResult != NULL)
		AT_Notify2ATM(pResult, pParam->nDLCI);

	if (pResult != NULL)
	{
		AT_FREE(pResult);
		pResult = NULL;
	}

	return;
}

VOID _OutputLocalLanuge(UINT16 *pUCS2, UINT32 nLen)
{
	UINT8 nOutString;
	UINT8 *pOutString = &nOutString ;
	UINT32 nOutStringLen;
	UINT16 *p = (UINT16 *)pOutString;

	if(nLen)
		ML_Unicode2LocalLanguageBigEnding((UINT8 *)pUCS2, nLen, &pOutString, &nOutStringLen, ML_CP936);


	PAT_CMD_RESULT pResult;
	pResult = AT_CreateRC(CSW_IND_NOTIFICATION, CMD_RC_CR, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME,
	                      0, pOutString, AT_StrLen(pOutString), /* pCfwEvent->nUTI */0);

	if (pResult != NULL)
	{
		AT_Notify2ATM(pResult, 0);
		AT_FREE(pResult);
		pResult = NULL;
	}

	AT_TC(g_sw_AT_SAT, "pOutString %s", p);
	AT_TC(g_sw_AT_SAT, "pOutString %x%x", pOutString[0], pOutString[1]);

	AT_FREE(pOutString);
}


VOID AT_SAT_CmdFunc_STGI(AT_CMD_PARA *pParam)
{
	INT32 iRetValue = 0;
	PAT_CMD_RESULT pResult;
	UINT8 *pMessageBuf = NULL;
	UINT16 len         = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	AT_TC(g_sw_AT_SAT, "CMD STGI:start  nSim:%d", nSim);

	if (pParam == NULL)
	{
		AT_TC(g_sw_AT_SAT, "CMD STGI:ERROR! pParam == NULL");
		iRetValue = CMD_FUNC_FAIL;
		goto STGI_ERROR;
	}
	else
	{
		AT_CMD_PARA *Param = pParam;

		if (Param->pPara == NULL) // First parameter(Length in PDU mode,Address in Text mode) is NULL.
		{
			AT_TC(g_sw_AT_SAT, "CMD STGI:ERROR! Param->pPara == NULL");
			goto STGI_ERROR;

		}

		AT_TC(g_sw_AT_SAT, "CMD STGI: Param->iType %d", Param->iType);
		switch (Param->iType)
		{

		case AT_CMD_SET:
		{
			UINT8 Len = 5;
			UINT8 CmdBuf[5];
			UINT8 NumOfParam = 0;
			UINT8 *Num       = Param->pPara;
			UINT8 nCmdType   = 0;

			CFW_SAT_MENU_RSP *p = NULL;

			// /////CFW_SAT_RESPONSE* pSimSatResponseData = 0;
			UINT8 *CmdData;

			if (ERR_SUCCESS != AT_Util_GetParaCount(Num, &NumOfParam))
			{
				AT_TC(g_sw_AT_SAT, "CMD STGI:ERROR!GetParaCount");
				goto STGI_ERROR;
			}

			if (NumOfParam != 1)
			{
				AT_TC(g_sw_AT_SAT, "CMD STGI:ERROR!NumOfParam reage is err.");
				goto STGI_ERROR;
			}
			// Get first parameter.
			if (ERR_SUCCESS != AT_Util_GetPara(Param->pPara, 0, CmdBuf, &Len))
			{
				AT_TC(g_sw_AT_SAT, "CMD STGI:ERROR!Get first parameter is err.");
				goto STGI_ERROR;
			}

			nCmdType = CmdBuf[0];

			nCmdType = (nCmdType - 0x30) * 10 + CmdBuf[1] - 0x30;

			AT_TC(g_sw_AT_SAT, "nCmdType == %x", nCmdType);

			AT_TC(g_sw_AT_SAT, "nCmdType == 35 :nCmd = %d--Len = %d", nCmdType, Len);

			AT_TC(g_sw_AT_SAT, "CmdBuf=%s : %x %x %x", CmdBuf, CmdBuf[0], CmdBuf[1], CmdBuf[2]);

			AT_TC(g_sw_AT_SAT, "Param ->pPara=%s : %x %x %x", Param->pPara, Param->pPara[0], Param->pPara[1],
			      Param->pPara[2]);
#ifdef AT_DUAL_SIM

			if (CFW_SatGetInformation(nCmdType, (PVOID)&CmdData, nSim) != ERR_SUCCESS)
#else
			if (CFW_SatGetInformation(nCmdType, (PVOID)&CmdData) != ERR_SUCCESS)

#endif
			{
				AT_TC(g_sw_AT_SAT, "CMD STGI:ERROR!SatGetInformation is fail");
				goto STGI_ERROR;
			}
			if (nCmdType == 37 || nCmdType == 36)
			{
				UINT8 i;
				UINT32 Count = 0;
				UINT16 nNum, nMem;

				UINT8 *q = NULL;

				CFW_SAT_ITEM_LIST *pItemList = NULL;

				p = (CFW_SAT_MENU_RSP *)CmdData;

				if (p != NULL)
					pItemList = p->pItemList;

				Count = AT_SAT_Count(pItemList);

				nNum = Count >> 16;

				nMem = Count & 0xFFFF;

				AT_TC(g_sw_AT_SAT, "1nMem = %d,12*(UINT8)nNum=%d,%d", nMem, 27 * (UINT8)nNum, (p->nAlphaLen - 1) * 2 + 28);

				nMem = nMem + 27 * (UINT8)nNum + (p->nAlphaLen - 1) * 2 + 31; // 101;//11;

				AT_TC(g_sw_AT_SAT, "2nMem = %d", nMem);

				/* */
				pMessageBuf = (UINT8 *)AT_MALLOC(nMem);

				if (pMessageBuf == NULL)
					goto STGI_ERROR;
				AT_MemZero(pMessageBuf, nMem);
				q = pMessageBuf;

				q += AT_Sprintf(q, "^STGI: %u,0,%u", nCmdType, nNum);

				AT_TC(g_sw_AT_SAT, "*p->pAlphaStr ==0x%x,gATCurrentAlphabet = %d", *p->pAlphaStr, gATCurrentAlphabet);

				AT_TC(g_sw_AT_SAT, "pAlphaStr ==0x%x, nAlphaLen = %d, gATCurrentAlphabet = %d", *p->pAlphaStr, p->nAlphaLen,
				      gATCurrentAlphabet);

				for (i = 0; i < p->nAlphaLen; i++)
					AT_TC(g_sw_AT_SAT, "    menu = %x", *(p->pAlphaStr + i));

				if (p->nAlphaLen != 0)
				{
					// ��һ���ֽڲ��Ǳ��뷽ʽ������ж�ɾ����
					// if(((*p->pAlphaStr &0x80) == 0x80)&&gATCurrentAlphabet == UCS2_SET)
					if (gATCurrentAlphabet == UCS2_SET)
						q += AT_SAT_TransmitBinary(q, p->pAlphaStr + 1, p->nAlphaLen - 1);
					else
						q += AT_Sprintf(q, ",\" \"");
				}
				else
					q += AT_Sprintf(q, ",\" \"");

				q += AT_Sprintf(q, ",%u\r\n", p->nComQualifier);

				if (pItemList != NULL)
					for (i = 0; i < nNum; i++)
					{
						q += AT_Sprintf(q, "^STGI: %u,%u", nCmdType, pItemList->nItemID);
						AT_TC(g_sw_AT_SAT, "*p->pAlphaStr ==0x%x,gATCurrentAlphabet = %d", *p->pAlphaStr, gATCurrentAlphabet);

						// ��һ���ֽڲ��Ǳ��뷽ʽ������ж�ɾ����
						// if(((*p->pAlphaStr & 0x80) == 0x80)&&gATCurrentAlphabet == UCS2_SET)

						if (gATCurrentAlphabet == UCS2_SET)
							q += AT_SAT_TransmitBinary(q, pItemList->pItemStr + 1, pItemList->nItemLen - 1);
						else
							q += AT_Sprintf(q, ",\" \"");

						q += AT_Sprintf(q, ",%u\r\n", p->nComQualifier);

						if (pItemList->pNextItem != NULL)
							pItemList = pItemList->pNextItem;
						else
							break;
					}

				*q = '\0';

				AT_TC(g_sw_AT_SAT, "Message end = %x,finished address =%x", pMessageBuf + nMem, q);
				AT_TC(g_sw_AT_SAT, "36-37nMem = %d,message len = %d", nMem, AT_StrLen(pMessageBuf));

				len = strlen(pMessageBuf);
				AT_Util_TrimRspStringSuffixCrLf(pMessageBuf, &len);
				pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
				                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, pMessageBuf, AT_StrLen(pMessageBuf),
				                      pParam->nDLCI);

				if (pResult != NULL)
				{
					AT_Notify2ATM(pResult, pParam->nDLCI);
					AT_FREE(pResult);
					pResult = NULL;
				}

				AT_FREE(pMessageBuf);

				return;
			}
			else if (nCmdType == 33)
			{
				UINT16 nMem;

				CFW_SAT_DTEXT_RSP *pDText;
				UINT8 *q = NULL;

				pDText = (CFW_SAT_DTEXT_RSP *)CmdData;

				nMem        = 2 * (UINT8)(pDText->nTextLen) + 15 + 10;
				pMessageBuf = (UINT8 *)AT_MALLOC(nMem);

				if (pMessageBuf == NULL)
				{
					AT_TC(g_sw_AT_SAT, "CMD STGI:ERROR!nCmdType == 33 malloc is fail");
					goto STGI_ERROR;
				}
				AT_MemZero(pMessageBuf, nMem);
				q = pMessageBuf;

				q += AT_Sprintf(q, "^STGI: 33");

				q += AT_SAT_TransmitBinary(q, pDText->pTextStr, pDText->nTextLen);

				q += AT_Sprintf(q, ",%u,%u\r\n", pDText->nTextSch, pDText->nComQualifier);

				*q = '\0';

				AT_TC(g_sw_AT_SAT, "Message end = %x,finished address =%x", pMessageBuf + nMem, q);

				AT_TC(g_sw_AT_SAT, "33nMem = %d,message len = %d", nMem, AT_StrLen(pMessageBuf));

				len = strlen(pMessageBuf);

				AT_Util_TrimRspStringSuffixCrLf(pMessageBuf, &len);

				pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
				                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, pMessageBuf, AT_StrLen(pMessageBuf),
				                      pParam->nDLCI);

				if (pResult != NULL)
				{
					AT_Notify2ATM(pResult, pParam->nDLCI);
					AT_FREE(pResult);
					pResult = NULL;
				}

				AT_FREE(pMessageBuf);

				return;
			}
			else if (nCmdType == 38)
			{
				SAT_BASE_RSP *pBase = NULL;
				UINT8 nMessageBuf[20];
				UINT8 *q = nMessageBuf;

				pBase = (SAT_BASE_RSP *)CmdData;
				q += AT_Sprintf(q, "^STGI: %u,%u", pBase->nComID, pBase->nComQualifier);

				*q = '\0';

				// add by wangxd for bug 8534
				q = nMessageBuf;

				// add_end by wangxd

				pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
				                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, q, AT_StrLen(q), pParam->nDLCI);

				if (pResult != NULL)
				{
					AT_Notify2ATM(pResult, pParam->nDLCI);
					AT_FREE(pResult);
					pResult = NULL;
				}

				return;
			}

			else if (nCmdType == 19)
			{
				UINT16 nMem;
				UINT8 *q = NULL;

				CFW_SAT_SMS_RSP *pShortMsg;

				pShortMsg   = (CFW_SAT_SMS_RSP *)CmdData;
				nMem        = pShortMsg->nAlphaLen + pShortMsg->nAddrLen + pShortMsg->nPDULen;
				nMem        = 2 * nMem + 8 + 6 + 12;
				pMessageBuf = (UINT8 *)AT_MALLOC(nMem);

				if (pMessageBuf == NULL)
				{
					AT_TC(g_sw_AT_SAT, "CMD STGI:ERROR!nCmdType == 19 malloc is fail");
					goto STGI_ERROR;
				}
				AT_MemZero(pMessageBuf, nMem);
				q = pMessageBuf;

				q += AT_Sprintf(q, "^STGI: 19");

				if (pShortMsg->nAlphaLen == 0)
					q += AT_Sprintf(q, ",\"\"");
				else
					q += AT_SAT_TransmitBinary(q, pShortMsg->pAlphaStr + 1, pShortMsg->nAlphaLen - 1);

				q += AT_Sprintf(q, ",%u", pShortMsg->nAddrType);

				if (pShortMsg->nAddrLen == 0)
					q += AT_Sprintf(q, ",\"\"");
				else
					q += AT_SAT_TransmitBinary(q, pShortMsg->pAddrStr, pShortMsg->nAddrLen);

				if (pShortMsg->nPDULen == 0)
					q += AT_Sprintf(q, ",\"\"");
				else
					q += AT_SAT_TransmitBinary(q, pShortMsg->pPDUStr, pShortMsg->nPDULen);

				q += AT_Sprintf(q, "\r\n");

				*q = '\0';

				AT_TC(g_sw_AT_SAT, "Message end = %x,finished address =%x", pMessageBuf + nMem, q);

				AT_TC(g_sw_AT_SAT, "19nMem = %d,message len = %d", nMem, AT_StrLen(pMessageBuf));

				len = strlen(pMessageBuf);

				AT_Util_TrimRspStringSuffixCrLf(pMessageBuf, &len);

				pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
				                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, pMessageBuf, AT_StrLen(pMessageBuf),
				                      pParam->nDLCI);

				if (pResult != NULL)
				{
					AT_Notify2ATM(pResult, pParam->nDLCI);
					AT_FREE(pResult);
					pResult = NULL;
				}

				AT_FREE(pMessageBuf);

				return;

			}
			else if (nCmdType == 16)
			{
				UINT16 nMem = 0;
				UINT8 *q    = NULL;

				CFW_SAT_CALL_RSP *pCall;

				pCall       = (CFW_SAT_CALL_RSP *)CmdData;
				nMem        = pCall->nAlphaConfirmLen + pCall->nAddrLen + pCall->nSubAddrLen + pCall->nAlphaSetupLen;
				nMem        = 2 * (nMem + 16) + 6 + 17;
				pMessageBuf = (UINT8 *)AT_MALLOC(nMem);

				if (pMessageBuf == NULL)
				{
					AT_TC(g_sw_AT_SAT, "CMD STGI:ERROR!nCmdType == 16 malloc is fail");
					goto STGI_ERROR;
				}
				AT_MemZero(pMessageBuf, nMem);
				q = pMessageBuf;

				q += AT_Sprintf(q, "^STGI: 16");

				if (pCall->nAlphaConfirmLen == 0)
					q += AT_Sprintf(q, ",\"\"");
				else
					q += AT_SAT_TransmitBinary(q, pCall->pAlphaConfirmStr, pCall->nAlphaConfirmLen);

				q += AT_Sprintf(q, ",%u", pCall->nAddrType);

				if (pCall->nAddrLen == 0)
					q += AT_Sprintf(q, ",\"\"");
				else
					q += AT_SAT_TransmitBinary(q, pCall->pAddrStr, pCall->nAddrLen);

				if (pCall->nSubAddrLen == 0)
					q += AT_Sprintf(q, ",\"\"");
				else
					q += AT_SAT_TransmitBinary(q, pCall->pSubAddrStr, pCall->nSubAddrLen);

				if (pCall->nAlphaSetupLen == 0)
					q += AT_Sprintf(q, ",\"\"");
				else
					q += AT_SAT_TransmitBinary(q, pCall->pAlphaSetupStr, pCall->nAlphaSetupLen);

				q += AT_Sprintf(q, ",%u,%u,%u\r\n", pCall->nTuint, pCall->nTinterval, pCall->nComQualifier);

				*q = '\0';

				AT_TC(g_sw_AT_SAT, "Message end = %x,finished address =%x", pMessageBuf + nMem, q);

				AT_TC(g_sw_AT_SAT, "16nMem = %d,message len = %d", nMem, AT_StrLen(pMessageBuf));

				len = strlen(pMessageBuf);

				AT_Util_TrimRspStringSuffixCrLf(pMessageBuf, &len);

				pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
				                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, pMessageBuf, AT_StrLen(pMessageBuf),
				                      pParam->nDLCI);

				if (pResult != NULL)
				{
					AT_Notify2ATM(pResult, pParam->nDLCI);
					AT_FREE(pResult);
					pResult = NULL;
				}

				AT_FREE(pMessageBuf);

				return;

			}
			else if (nCmdType == 35)
			{

				UINT16 nMem;
				UINT8 *q = NULL;

				CFW_SAT_INPUT_RSP *pInput;

				pInput      = (CFW_SAT_INPUT_RSP *)CmdData;
				nMem        = pInput->nDefTextLen + pInput->nTextLen;
				nMem        = 2 * (nMem + 3) + 28 + 30;  /* 3; */
				pMessageBuf = (UINT8 *)AT_MALLOC(nMem);

				if (pMessageBuf == NULL)
				{
					AT_TC(g_sw_AT_SAT, "CMD STGI:ERROR!nCmdType == 35 malloc is fail");
					goto STGI_ERROR;
				}
				AT_MemZero(pMessageBuf, nMem);
				q = pMessageBuf;

				q += AT_Sprintf(q, "^STGI: 35");

				q += AT_SAT_TransmitBinary(q, pInput->pTextStr, pInput->nTextLen);

				q += AT_Sprintf(q, ",%u", pInput->nTextSch);

				if (pInput->nDefTextLen == 0)
					q += AT_Sprintf(q, ",\"\"");
				else
					q += AT_SAT_TransmitBinary(q, pInput->pDefTextStr, pInput->nDefTextLen);

				q += AT_Sprintf(q, ",%u", pInput->nDefTextSch);

				q += AT_Sprintf(q, ",%u,%u,%u", pInput->nResMaxLen, pInput->nResMinLen, pInput->nComQualifier);

				q += AT_Sprintf(q, "\r\n");

				*q = '\0';

				AT_TC(g_sw_AT_SAT, "Message end = %x,finished address =%x", pMessageBuf + nMem, q);

				AT_TC(g_sw_AT_SAT, "35nMem = %d,message len = %d", nMem, AT_StrLen(pMessageBuf));

				len = strlen(pMessageBuf);

				AT_Util_TrimRspStringSuffixCrLf(pMessageBuf, &len);

				pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
				                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, pMessageBuf, AT_StrLen(pMessageBuf),
				                      pParam->nDLCI);

				if (pResult != NULL)
				{
					AT_Notify2ATM(pResult, pParam->nDLCI);
					AT_FREE(pResult);
					pResult = NULL;
				}

				AT_FREE(pMessageBuf);

				return;

			}
			else
				Len = 0;

			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
			                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;
		}

		case AT_CMD_TEST:
		{
			UINT8 Str[] = "^STGI: (16,19,33,35,36,37,38,211)";

			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
			                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;
		}

		break;

		case AT_CMD_READ:
		{
			UINT8 Str[50];

#ifdef AT_DUAL_SIM
			UINT8 nCmd = CFW_SatGetCurCMD(nSim);
#else
			UINT8 nCmd = CFW_SatGetCurCMD();

#endif

			if (nCmd == 0xFF)
				goto STGI_ERROR;

			AT_Sprintf(Str, "^STGI: %u", nCmd);

			pResult = AT_CreateRC(CMD_FUNC_SUCC, CMD_RC_OK,
			                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, Str, AT_StrLen(Str), pParam->nDLCI);

			if (pResult != NULL)
				AT_Notify2ATM(pResult, pParam->nDLCI);

			if (pResult != NULL)
			{
				AT_FREE(pResult);
				pResult = NULL;
			}

			return;
		}

		break;

		default:
			goto STGI_ERROR;
		}
	}

STGI_ERROR:

	pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR,
	                      CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

	if (pResult != NULL)
		AT_Notify2ATM(pResult, pParam->nDLCI);

	if (pResult != NULL)
	{
		AT_FREE(pResult);
		pResult = NULL;
	}

	return;
}

UINT32 AT_SAT_Count(CFW_SAT_ITEM_LIST *pMenu)
{
	CFW_SAT_ITEM_LIST *p = pMenu;
	UINT16 nMemSum = 0;
	UINT16 i       = 0;

	while (p != NULL)
	{
		nMemSum += p->nItemLen - 1;
		i++;
		p = p->pNextItem;
	}

	nMemSum = (nMemSum << 1);

	return (i << 16) | nMemSum;
}

UINT8 AT_SAT_TransmitBinary(UINT8 *pBuffer, UINT8 *pStr, UINT8 nLen)
{
	UINT8 *pBuf   = pBuffer;
	UINT8 *p      = pStr;
	UINT8 nHigh4b = 0;
	UINT8 nLow4b  = 0;
	UINT8 i;

	*pBuf = ',';
	pBuf++;
	*pBuf = '"';
	pBuf++;

	for (i = 0; i < nLen; i++)
	{
		nHigh4b = *p >> 4;
		nLow4b  = *p & 0x0F;
		//AT_TC(g_sw_AT_SAT, "    p = %x", *p);

		if (nHigh4b <= 9)
		{
			//AT_TC(g_sw_AT_SAT, ".");
			*pBuf = nHigh4b + '0';
		}
		else
		{
			//AT_TC(g_sw_AT_SAT, "+");
			*pBuf = nHigh4b + 'A' - 10;
		}

		pBuf++;

		if (nLow4b <= 9)
		{
			//AT_TC(g_sw_AT_SAT, ".");
			*pBuf = nLow4b + '0';
		}
		else
		{
			//AT_TC(g_sw_AT_SAT, ".");
			*pBuf = nLow4b + 'A' - 10;
		}

		pBuf++;

		p++;
	}

	*pBuf = '"';

	pBuf++;

	return nLen * 2 + 3;
}


#define  OK_RETURN(pResult,pString,nDLCI) do{   pResult = AT_CreateRC(  CMD_FUNC_SUCC,\
        CMD_RC_OK, \
        CMD_ERROR_CODE_OK,\
        CMD_ERROR_CODE_TYPE_CME,\
        0,\
        pString,\
        strlen(pString),\
        nDLCI);\
    AT_Notify2ATM(pResult,nDLCI);\
    if(pResult != NULL){ \
        AT_FREE(pResult);\
        pResult = NULL; \
    }\
    return;\
}while(0)
#define  ERROR_RETURN(pResult,reason,nDLCI) do{ pResult = AT_CreateRC(CMD_FUNC_FAIL,\
            CMD_RC_ERROR, \
            reason,\
            CMD_ERROR_CODE_TYPE_CME,\
            0,\
            NULL,\
            0,\
            nDLCI);\
        AT_Notify2ATM(pResult,nDLCI);\
        if(pResult != NULL){ \
            AT_FREE(pResult);\
            pResult = NULL; \
        }\
        return;\
    }while(0)


void AT_SIM_CmdFunc_STF(AT_CMD_PARA *pParam)
{
	// for ATM2NOTIFY pResult,result  code.
	PAT_CMD_RESULT pResult = NULL;

	// for CSW interface return value
	//UINT32 return_val;

	// from  ATM
	//  u_gCurrentCmdStamp[nSim] = pParam->uCmdStamp;

	// check  intut para,return if NULL
	if (pParam == NULL)
	{
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
	}

	// check  different cmd type
	switch (pParam->iType)
	{
	case AT_CMD_SET:
	{
		UINT8 paraCount = 0x00;
		UINT8 nMode = 0x00;

		UINT8 nSize = 0x01;

		INT32 iRet = AT_Util_GetParaCount(pParam->pPara, &paraCount);
		if ((iRet != ERR_SUCCESS) || (paraCount != 1))
		{
			AT_TC(g_sw_GPRS, "AT+STF:paraCount: %d", paraCount);
			AT_SIMID_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
			return;
		}

		iRet     = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &nMode, &nSize);
		if (iRet != ERR_SUCCESS)
		{
			AT_TC(g_sw_GPRS, "AT+STF:iRet : %d !", iRet);
			AT_SIMID_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
			return;
		}

		if((0x00 != nMode) && (0x01 != nMode))
		{
			AT_TC(g_sw_GPRS, "AT+STF:nService : %d !", nMode);
			AT_SIMID_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
			return;
		}


		CFW_SetSATIndFormate(nMode);
		//CFW_SetSATIndFormate(1);


		if(0x00 == nMode)
			OK_RETURN(pResult, "Set STF: PDU mode", pParam->nDLCI);
		else
			OK_RETURN(pResult, "Set STF TEXT mode", pParam->nDLCI);

	}
	break;
	case AT_CMD_TEST:
	{
#if 0
		OK_NULL_RETURN(pResult, pParam->nDLCI);
#else
		OK_RETURN(pResult, "+STF: ", pParam->nDLCI);
#endif
	}
	break;
	case AT_CMD_READ:
	{
		//UINT8 nOutString[50] = {0x00,};
		if(0x00 == CFW_GetSATIndFormate())
			OK_RETURN(pResult, "+STF: PDU mode", pParam->nDLCI);
		else
			OK_RETURN(pResult, "+STF: TEXT mode", pParam->nDLCI);
	}
	break;


	default:
	{
		ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_SUPPORTED, pParam->nDLCI);
	}
	}
}

