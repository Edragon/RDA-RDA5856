// //////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002-2012, Coolsand Technologies, Inc.
// All Rights Reserved
//
// This source code is property of Coolsand. The information contained in this
// file is confidential. Distribution, reproduction, as well as exploitation,
// or transmission of any content of this file is not allowed except if
// expressly permitted.Infringements result in damage claims!
//
// FILENAME: at_cmd_sat.h
//
// DESCRIPTION:
// TODO: ...
//
// REVISION HISTORY:
// NAME              DATE                REMAKS
// Lixp      2012-2-20       Created initial version 1.0
//
// //////////////////////////////////////////////////////////////////////////////

#ifndef __AT_CMD_SAT_H__
#define __AT_CMD_SAT_H__

struct COS_EVENT;

struct AT_CMD_PARA;

VOID AT_SAT_AsyncEventProcess(COS_EVENT *pEvent);

VOID AT_SAT_CmdFunc_STGI(AT_CMD_PARA *pParam);
VOID AT_SAT_CmdFunc_STA(AT_CMD_PARA *pParam);
VOID AT_SAT_CmdFunc_STR(AT_CMD_PARA *pParam);
VOID AT_SAT_CmdFunc_STNR(AT_CMD_PARA *pParam);
VOID AT_SAT_CmdFunc_STRC(AT_CMD_PARA *pParam);

UINT32 AT_SAT_Count(CFW_SAT_ITEM_LIST *pMenu);
UINT8 AT_SAT_TransmitBinary(UINT8 *pBuffer, UINT8 *pStr, UINT8 nLen);
UINT32 CFW_SimGetMeProfile(CFW_PROFILE **pMeProfile, CFW_SIM_ID nSimID);
void AT_SIM_CmdFunc_STF(AT_CMD_PARA *pParam);

extern UINT8 g_ss_ussdUTI;
extern UINT8 g_ss_ussdUTIflag;
#ifdef CFW_MULTI_SIM
VOID CFW_EmodGetIMEIBCD(UINT8 *pImei, UINT8 *pImeiLen, CFW_SIM_ID nSimID);
#else
VOID CFW_EmodGetIMEIBCD(UINT8 *pImei, UINT8 *pImeiLen);
#endif

#define SECOND        * 16384
#define MILLI_SECOND  SECOND / 1000
#define MILLI_SECONDS MILLI_SECOND

#endif
