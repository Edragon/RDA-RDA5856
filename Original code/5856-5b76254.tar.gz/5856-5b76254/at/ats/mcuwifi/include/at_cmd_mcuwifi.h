/*********************************************************
 *
 * File Name
 *	at_cmd_tcpip.h
 * Author
 * 	Felix
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 * 	
 *********************************************************/

#ifndef __AT_CMD_MUSIC_H__
#define __AT_CMD_MUSIC_H__

#include "event.h"
#include "at_common.h"

extern VOID AT_MCUWIFI_CmdFunc_Enter_Smart(AT_CMD_PARA* pParam);


#endif
 
