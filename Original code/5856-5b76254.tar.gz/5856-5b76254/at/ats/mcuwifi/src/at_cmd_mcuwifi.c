// //////////////////////////////////////////////////////////////////////////////
#include "at_common.h"
#include "MainTask.h"
#include "at_cmd_mcuwifi.h"

void AT_MCUWIFI_CmdFunc_Enter_Smart(AT_CMD_PARA* param)
{
	printf("at command enter smartconfig\n\r");
}
