/*********************************************************
 *
 * File Name
 *	at_cmd_tcpip.h
 * Author
 * 	Felix
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 * 	
 *********************************************************/

#ifndef __AT_CMD_RECORD_H__
#define __AT_CMD_RECORD_H__

#include "event.h"
#include "at_common.h"

extern VOID AT_RECORD_CmdFunc_Start(AT_CMD_PARA* pParam);
extern VOID AT_RECORD_CmdFunc_Pause(AT_CMD_PARA* pParam);
extern VOID AT_RECORD_CmdFunc_Over(AT_CMD_PARA* pParam);
extern VOID AT_RECORD_CmdFunc_UartStart(AT_CMD_PARA* pParam);
extern VOID AT_RECORD_CmdFunc_UartStop(AT_CMD_PARA* pParam);
#endif
 
