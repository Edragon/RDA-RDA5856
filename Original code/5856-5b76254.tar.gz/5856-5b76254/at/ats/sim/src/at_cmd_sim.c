/*********************************************************
 *
 * File Name
 *	?
 * Author
 * 	?
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 *
 *********************************************************/

#include "at_common.h"
#include "at_cmd_sim.h"
#include "csw.h"
// add for crsm begin
#define  API_SIM_EF_ADN       0
#define  API_SIM_EF_FDN       1
#define  API_SIM_EF_SMS       2
#define  API_SIM_EF_CCP       3
#define  API_SIM_EF_MSISDN    4
#define  API_SIM_EF_SMSP      5
#define  API_SIM_EF_SMSS      6
#define  API_SIM_EF_LND       7
#define  API_SIM_EF_SMSR      8
#define  API_SIM_EF_SDN       9
#define  API_SIM_EF_EXT1      10
#define  API_SIM_EF_EXT2      11
#define  API_SIM_EF_EXT3      12
#define  API_SIM_EF_BDN       13
#define  API_SIM_EF_EXT4      14
#define  API_SIM_EF_LP        15
#define  API_SIM_EF_IMSI      16
#define  API_SIM_EF_KC        17
#define  API_SIM_EF_PLMNSEL   18
#define  API_SIM_EF_HPLMN     19
#define  API_SIM_EF_ACMMAX    20
#define  API_SIM_EF_SST       21
#define  API_SIM_EF_ACM       22  // 
#define  API_SIM_EF_GID1      23
#define  API_SIM_EF_GID2      24
#define  API_SIM_EF_PUCT      25
#define  API_SIM_EF_CBMI      26
#define  API_SIM_EF_SPN       27
#define  API_SIM_EF_CBMID     28
#define  API_SIM_EF_BCCH      29
#define  API_SIM_EF_ACC       30
#define  API_SIM_EF_FPLMN     31
#define  API_SIM_EF_LOCI      32
#define  API_SIM_EF_AD        33
#define  API_SIM_EF_PHASE     34
#define  API_SIM_EF_VGCS      35
#define  API_SIM_EF_VGCSS     36
#define  API_SIM_EF_VBS       37
#define  API_SIM_EF_VBSS      38
#define  API_SIM_EF_EMLPP     39
#define  API_SIM_EF_AAEM      40
#define  API_SIM_EF_ECC       41
#define  API_SIM_EF_CBMIR     42
#define  API_SIM_EF_NIA       43  // 
#define  API_SIM_EF_KCGPRS    44
#define  API_SIM_EF_LOCIGPRS  45
#define  API_SIM_EF_SUME      46
#define  API_SIM_EF_PLMNWACT  47
#define  API_SIM_EF_OPLMNWACT 48
#define  API_SIM_EF_HPLMNACT  49
#define  API_SIM_EF_CPBCCH    50
#define  API_SIM_EF_INVSCAN   51
#define  API_SIM_EF_RPLMNAC   52
#define  API_SIM_EF_ICCID     53
#define  API_SIM_EF_ELP       54
#define  API_SIM_EF_IMG       55  // 
#define  API_SIM_EF_MBDN      56


// add for 3G USIM
#define    API_USIM_EF_LI			57
#define    API_USIM_EF_ARR         		58
#define    API_USIM_EF_IMSI        		59
#define    API_USIM_EF_KEYS        		60
#define    API_USIM_EF_KEYS_PS          61
#define    API_USIM_EF_DCK		       62
#define    API_USIM_EF_HPLMN      		63
#define    API_USIM_EF_CNL		       64
#define    API_USIM_EF_ACM_MAX    	65
#define    API_USIM_EF_UST        		66
#define    API_USIM_EF_ACM        		67
#define    API_USIM_EF_FDN        		68
#define    API_USIM_EF_SMS        		69
#define    API_USIM_EF_GID1       		70
#define    API_USIM_EF_GID2       		71
#define    API_USIM_EF_MSISDN     	72
#define    API_USIM_EF_PUCT       		73
#define    API_USIM_EF_SMSP       		74
#define    API_USIM_EF_SMSS       		75
#define    API_USIM_EF_CBMI       		76
#define    API_USIM_EF_SPN        		77
#define    API_USIM_EF_SMSR       		78
#define    API_USIM_EF_CBMID      		79
#define    API_USIM_EF_SDN        		80
#define    API_USIM_EF_EXT2       		81
#define    API_USIM_EF_EXT3       		82
#define    API_USIM_EF_BDN        		83
#define    API_USIM_EF_EXT5       		84
#define    API_USIM_EF_CBMIR      		85
#define    API_USIM_EF_EXT4       		86
#define    API_USIM_EF_EST        		87
#define    API_USIM_EF_ACL        		88
#define    API_USIM_EF_CMI        		89
#define    API_USIM_EF_START_HFN  	90
#define    API_USIM_EF_THRESHOLD  	91
#define    API_USIM_EF_PLMNWACT      92
#define    API_USIM_EF_OPLMNWACT    93
#define    API_USIM_EF_HPLMNWACT    94
#define    API_USIM_EF_EHPLMN    	       95
#define    API_USIM_EF_PS_LOCI    	96
#define    API_USIM_EF_ACC        		97
#define    API_USIM_EF_FPLMN       	98
#define    API_USIM_EF_LOCI        		99
#define    API_USIM_EF_ICI         		100
#define    API_USIM_EF_OCI         		101
#define    API_USIM_EF_ICT         		102
#define    API_USIM_EF_OCT        		103
#define    API_USIM_EF_AD			104
#define    API_USIM_EF_EMLPP	      	105
#define    API_USIM_EF_AAEM		       106
#define    API_USIM_EF_ECC		       107
#define    API_USIM_EF_HIDDENKEY   	108
#define    API_USIM_EF_NETPAR      	109
#define    API_USIM_EF_PNN         		110
#define    API_USIM_EF_OPL         		111
#define    API_USIM_EF_MBDN       		112
#define    API_USIM_EF_EXT6        		113
#define    API_USIM_EF_MBI         		114
#define    API_USIM_EF_MWIS       		115
#define    API_USIM_EF_CFIS       		116
#define    API_USIM_EF_EXT7       		117
#define    API_USIM_EF_SPDI		       118
#define    API_USIM_EF_MMSN		       119
#define    API_USIM_EF_EXT8		       120
#define    API_USIM_EF_MMSICP	       121
#define    API_USIM_EF_MMSUP	       122
#define    API_USIM_EF_MMSUCP	       123
#define    API_USIM_EF_NIA		       124
#define    API_USIM_EF_VGCS		       125
#define    API_USIM_EF_VGCSS	      	126
#define    API_USIM_EF_VBS		       127
#define    API_USIM_EF_VBSS		       128
#define    API_USIM_EF_VGCSCA	       129
#define    API_USIM_EF_VBSCA	      	130
#define    API_USIM_EF_GBAP		       131
#define    API_USIM_EF_MSK		       132
#define    API_USIM_EF_MUK		       133
#define    API_USIM_EF_GBANL	      	134
#define    API_USIM_EF_EHPLMNPI      	135
#define    API_USIM_EF_LRPLMNSI        136
#define    API_USIM_EF_NAFKCA	       137

//files under DF MEXE
#define    API_USIM_EF_MEXE_ST    	138
#define    API_USIM_EF_ARPK       		139
#define    API_USIM_EF_TPRK       		140
#define    API_USIM_EF_ORPK                141

//files under DF GSM ACCESS
#define    API_USIM_EF_KC         		142
#define    API_USIM_EF_KC_GPRS    	143
#define    API_USIM_EF_CPBCCH     	144
#define    API_USIM_EF_INVSCAN    	145

// file under MF
#define    API_USIM_EF_DIR      	       146
#define    API_USIM_EF_ARR_MF		147

// phonebook under DF_TELECOM, USIM globle phonebook
#define    API_USIM_EF_GB_PBR		148
#define    API_USIM_EF_GB_IAP		149
#define    API_USIM_EF_GB_IAP1		150
#define    API_USIM_EF_GB_ADN		151
#define    API_USIM_EF_GB_ADN1		152
#define    API_USIM_EF_GB_EXT1		153
#define    API_USIM_EF_GB_PBC		154
#define    API_USIM_EF_GB_PBC1		155
#define    API_USIM_EF_GB_GRP		156
#define    API_USIM_EF_GB_GRP1		157
#define    API_USIM_EF_GB_AAS		158
#define    API_USIM_EF_GB_GAS		159
#define    API_USIM_EF_GB_ANRA		160
#define    API_USIM_EF_GB_ANRB		161
#define    API_USIM_EF_GB_ANRC		162
#define    API_USIM_EF_GB_ANRA1	163
#define    API_USIM_EF_GB_ANRB1		164
#define    API_USIM_EF_GB_ANRC1		165
#define    API_USIM_EF_GB_SNE		166
#define    API_USIM_EF_GB_SNE1		167
#define    API_USIM_EF_GB_CCP1		168
#define    API_USIM_EF_GB_UID		169
#define    API_USIM_EF_GB_UID1		170
#define    API_USIM_EF_GB_PSC		171
#define    API_USIM_EF_GB_CC		172
#define    API_USIM_EF_GB_PUID		173
#define    API_USIM_EF_GB_EMAIL		174
#define    API_USIM_EF_GB_EMAIL1	175

// phonebook under ADF USIM, USIM local phonebook
#define    API_USIM_EF_PBR			176
#define    API_USIM_EF_IAP			177
#define    API_USIM_EF_IAP1			178
#define    API_USIM_EF_ADN			179
#define    API_USIM_EF_ADN1			180
#define    API_USIM_EF_EXT1			181
#define    API_USIM_EF_PBC			182
#define    API_USIM_EF_PBC1			183
#define    API_USIM_EF_GRP			184
#define    API_USIM_EF_GRP1			185
#define    API_USIM_EF_AAS			186
#define    API_USIM_EF_GAS			187
#define    API_USIM_EF_ANRA			188
#define    API_USIM_EF_ANRB			189
#define    API_USIM_EF_ANRC			190
#define    API_USIM_EF_ANRA1		191
#define    API_USIM_EF_ANRB1		192
#define    API_USIM_EF_ANRC1		193
#define    API_USIM_EF_SNE			194
#define    API_USIM_EF_SNE1			195
#define    API_USIM_EF_CCP1			196
#define    API_USIM_EF_UID			197
#define    API_USIM_EF_UID1			198
#define    API_USIM_EF_PSC			199
#define    API_USIM_EF_CC			200
#define    API_USIM_EF_PUID			201
#define    API_USIM_EF_EMAIL   		202
#define    API_USIM_EF_EMAIL1		203


// add for crsm end
#define	 ERROR_RETURN(pResult,reason,nDLCI) do{ pResult = AT_CreateRC(CMD_FUNC_FAIL,\
			CMD_RC_ERROR, \
			reason,\
			CMD_ERROR_CODE_TYPE_CME,\
			0,\
			NULL,\
			0,\
			nDLCI);\
	AT_Notify2ATM(pResult,nDLCI);\
	if(pResult != NULL){ \
		AT_FREE(pResult);\
		pResult	= NULL;	\
	}\
	return;\
}while(0)
#define	 OK_RETURN(pResult,pString,nDLCI) do{	pResult	= AT_CreateRC(	CMD_FUNC_SUCC,\
			CMD_RC_OK, \
			CMD_ERROR_CODE_OK,\
			CMD_ERROR_CODE_TYPE_CME,\
			0,\
			pString,\
			strlen(pString),\
			nDLCI);\
	AT_Notify2ATM(pResult,nDLCI);\
	if(pResult != NULL){ \
		AT_FREE(pResult);\
		pResult	= NULL;	\
	}\
	return;\
}while(0)

#define	 OK_NULL_RETURN(pResult,nDLCI) do{  pResult =	AT_CreateRC(	CMD_FUNC_SUCC,\
			CMD_RC_OK, \
			CMD_ERROR_CODE_OK,\
			CMD_ERROR_CODE_TYPE_CME,\
			0,\
			NULL,\
			0,\
			nDLCI);\
	AT_Notify2ATM(pResult,nDLCI);\
	if(pResult != NULL){ \
		AT_FREE(pResult);\
		pResult	= NULL;	\
	}\
	return;\
}while(0)
// AT_20071114_CA0W_B
#define	 OK_ASYN_RETURN(pResult,nDLCI) do{  pResult =	AT_CreateRC(	CMD_FUNC_SUCC_ASYN,\
			CMD_RC_OK, \
			CMD_ERROR_CODE_OK,\
			CMD_ERROR_CODE_TYPE_CME,\
			0,\
			NULL,\
			0,\
			nDLCI);\
	AT_Notify2ATM(pResult,nDLCI);\
	if(pResult != NULL){ \
		AT_FREE(pResult);\
		pResult	= NULL;	\
	}\
	return;\
}while(0)
// AT_20071114_CAOW_E

// debug definition
#define	MYDEBUG	AT_TC(g_sw_AT_SIM, "!")

// define trigger debug inform output by trace:   1 ---> debug;   0 ---> colse debug  //add by wxd
#define	SIM_DEBUG 0

// CPIN related definition.actually this  is enough for all the code
#define	PIN1CODEMAX 12
#define PINNEEDPUK 3

// status of PUK1
#ifdef CFW_MULTI_SIM
UINT8 g_Pin1PukStauts[CFW_SIM_COUNT] = {0,};
static UINT8 g_Pin1ErrorTimes[CFW_SIM_COUNT] = {0,};
#else
UINT8 g_Pin1PukStauts         = 0;  // 1  ---> SIM need enter PUK
static UINT8 g_Pin1ErrorTimes = 0;  // record pin1 error times  for bug8046
#endif


UINT8 g_uCmer_ind[NUMBER_OF_SIM];

#define gATCurrentuCmer_ind g_uCmer_ind

// #define PUK1CODEMAX 12
#define	SIM_UTI	6

// CLCK related
#define	U16_SWAP(x)   ((((x) & 0xFF) <<	8) | (((x) >> 8) & 0xFF))
#define	FAC_MAX_NUM 6
#define	CLCK_PWD_MAX 12
// static UINT8 clckTestSTR[] = "+CLCK: (\"PS\",\"PF\",\"SC\",\"FD\",\"PN\",\"PU\",\"PP\",\"PC\")";

// CPWD related
/*
******************************************************************************
*	#define	CFW_STY_FAC_TYPE_SC  0x5343
*	#define	CFW_STY_FAC_TYPE_PS  0x5053
*	#define	CFW_STY_FAC_TYPE_P2  0x5032
*	#define	CFW_STY_FAC_TYPE_PF  0x5046
*	#define	CFW_STY_FAC_TYPE_PN  0x504E
*	#define	CFW_STY_FAC_TYPE_PU  0x5055
*	#define	CFW_STY_FAC_TYPE_PP  0x5050
*	#define	CFW_STY_FAC_TYPE_PC  0x5043
*	#define	CFW_STY_FAC_TYPE_FD  0x4644
*
*	+CPWD: ("PS",4),("PF",8),("SC",8),("AO",4),("OI",4),("OX",4),("AI",4),("IR",4),(
*	"AB",4),("AG",4),("AC",4),("PN",8),("PU",8),("PP",8),("PC",8),("P2",8)
*****************************************************************************
*/

// static UINT8 cpwdTestSTR[] = "+CPWD: (\"PS\",4),(\"PF\",8),(\"SC\",8),(\"PN\",8),(\"PU\",8),(\"P2\",8),(\"PC\",8),(\"FD\",8)";

// *************time stamp for asyn event timeout in ATM*************//

static UINT32 u_gCurrentCmdStamp[CFW_SIM_COUNT] = {0x00,};

/*
******************************************************************************************************
#define	CFW_STY_AUTH_READY		   0  //Phone is not waiting for any password.
#define	CFW_STY_AUTH_PIN1_READY		   1  //Phone is not waiting for PIN1 password.
#define	CFW_STY_AUTH_SIMPIN		   2  //Phone is waiting for the SIM Personal Identification Number (PIN)
#define	CFW_STY_AUTH_SIMPUK		   3  //Phone is waiting for the SIM Personal Unlocking	Key (PUK).
#define	CFW_STY_AUTH_PHONE_TO_SIMPIN	   4  //Phone is waiting for the phone-to-SIM card password.
#define	CFW_STY_AUTH_PHONE_TO_FIRST_SIMPIN 5  //Phone is waiting for the phone-to-first-SIM card PIN.
#define	CFW_STY_AUTH_PHONE_TO_FIRST_SIMPUK 6  //Phone is waiting for the phone-to-first-SIM card PUK.
#define	CFW_STY_AUTH_SIMPIN2		   7  //Phone is waiting for the SIM PIN2.
#define	CFW_STY_AUTH_SIMPUK2  ----NO	     8	//Phone	is waiting for the SIM PUK2.
#define	CFW_STY_AUTH_NETWORKPIN		   9  //Phone is waiting for the network personalization PIN.
#define	CFW_STY_AUTH_NETWORKPUK		   10 //Phone is waiting for the network personalization PUK.
#define	CFW_STY_AUTH_NETWORK_SUBSETPIN	   11 //Phone is waiting for the network subset	personalization	PIN.
#define	CFW_STY_AUTHNETWORK_SUBSETPUK	   12 //Phone is waiting for the network subset	personalization	PUK.
#define	CFW_STY_AUTH_PROVIDERPIN	   13 //Phone is waiting for the service provider personalization PIN.
#define	CFW_STY_AUTH_PROVIDERPUK	   14 //Phone is waiting for the service provider personalization PUK.
#define	CFW_STY_AUTH_CORPORATEPIN	   15 //Phone is waiting for the corporate personalization PIN.
#define	CFW_STY_AUTH_CORPORATEPUK	   16 //Phone is waiting for the corporate personalization PUK.
#define	CFW_STY_AUTH_NOSIM		   17 //No SIM inserted.
#define	CFW_STY_AUTH_PIN1BLOCK		   18
#define	CFW_STY_AUTH_PIN2BLOCK		   19
#define	CFW_STY_AUTH_PIN1_DISABLE	   20
#define	CFW_STY_AUTH_SIM_PRESENT	   21
#define	CFW_STY_AUTH_SIM_END		   22
********************************************************************************************************
*/
/************CFW_SimGetAuthenticationStatus string********************/
static UINT8 cpinasynSTR[23][20] =
{
	"+CPIN:READY",
	"+CPIN:PIN1 READY",
	"+CPIN:SIM PIN",
	"+CPIN:SIM PUK",
	"+CPIN:PH-SIM PIN", // no  PUK supported!!
	"+CPIN:PH-FSIM PIN",
	"+CPIN:PH-FSIM PUK",
	"+CPIN:SIM PIN2",
	"+CPIN:SIM PUK2",
	"+CPIN:PH-NET PIN",
	"+CPIN:PH-NET PUK",
	"+CPIN:PH-NETSUB PIN",
	"+CPIN:PH-NETSUB PUK",
	"+CPIN:PH-SP PIN",
	"+CPIN:PH-SP PUK",
	"+CPIN:PH-CORP PIN",
	"+CPIN:PH-CORP PUK",
	"+CPIN:NO SIM",
	"+CPIN:PIN1 BLOCK",
	"+CPIN:PIN2 BLOCK",
	"+CPIN:PIN1 DISABLE",
	"+CPIN:SIM PRESENT",
};

// cpinc exe cmd type output string!
#if 0
static UINT8 cpincexeasynSTR[10] = { 0 };
#else
UINT8 cpincexeasynSTR[20] = { 0 };
#endif

/*
********************************************************************************
* because CPIN CPIN2,CPIN2 will	call some CFW interface,and wait same event    *
* so following definition is to	seperate it									   *
* ERR_CME_SIM_UNKNOW														   *
********************************************************************************
*/

#define	CPIN		1
#define	CPIN2		2
#define	CPINCEXE	3
#define	CPINCREAD	4
#define	CLCK		5
#define	CPWD		6

// for get auth  response ,different cmd call wait same event

static UINT8 AT_security_currentCMD[CFW_SIM_COUNT] = {0x00,};

// AT_20071105_CAOW_B
static UINT8 gLstStatusRec; // 1--->pin1 or puk1,2--->pin2 or puk2

// AT_20071105_CAOW_E

#ifdef AT_DUAL_SIM
UINT8 gAtSimID = 0;
#endif

#ifdef AT_SUPPORT_BT
UINT8 gAtBTFlag = 0;
#endif

/************************cmd realization***************************************/

// AT_20071114_CAOW_B
extern UINT32 CFW_SimGetACMMax(UINT16 nUTI, CFW_SIM_ID nSimID);
extern UINT32 CFW_SimSetACMMax(UINT32 iACMMaxValue, UINT8 *pPin2, UINT8 nPinSize, UINT16 nUTI, CFW_SIM_ID nSimID);
extern UINT32 CFW_SimReadRecordWithLen (
    UINT8 nFileID,
    UINT8 nRecordNum,
    UINT16 nLen,
    UINT16 nUTI
#ifdef CFW_MULTI_SIM
    , CFW_SIM_ID nSimID
#endif
);

#define CRMPDATALENGTH		120
#define CAMMLENGTH			20
#define PIN2CODELENGTH		12

// AT_20071123_CAOW_B
UINT32 AT_CAMM_STRtoUINT32(UINT8 *pData)
{
	UINT32 iLen = 0;
	UINT32 res  = 0;
	UINT8 *data = pData;
	UINT8 iCnt  = 0;

	UINT8 temp;

	UINT8 t;

	iLen = AT_StrLen(pData);

	if (iLen != 6)
		return ERR_AT_CME_PARAM_INVALID;

	for (iCnt = 0; iCnt < iLen; iCnt++)
	{
		temp = * (data + iCnt);

		if (temp <= 57 && temp >= 48) // '0'-'9'
		{
			t = temp - 48;
			res |= (((UINT32)t) << ((5 - iCnt) * 4));
		}
		else if ((temp <= 102 && temp >= 97) || (temp <= 70 && temp >= 65)) // 'a'-'f','A'-'F'
		{
			if (temp <= 102 && temp >= 97)
				temp -= 32;

			t = 10 + temp - 65;

			res |= (((UINT32)t) << ((5 - iCnt) * 4));
		}
		else
		{
			return ERR_AT_CME_PARAM_INVALID;
		}

	}

	AT_TC(g_sw_AT_SIM, "res = %lu", res);

	return res;

}

// AT_20071123_CAOW_E
// add for crsm begin
#define CRSM_READ_BINARY    176
#define CRSM_READ_RECORD    178
#define CRSM_GET_RESPONSE   192
#define CRSM_UPDATE_BINARY  214
#define CRSM_UPDATE_RECORD  220
#define CRSM_STATUS         242

UINT32 ATGetStackSimFileID(UINT16 n3GppFileID, CFW_SIM_ID nSimID)
{
	switch (n3GppFileID)
	{
	case 0x6F3A:
	{
		if(CFW_GetSimType(nSimID))
			return API_USIM_EF_GB_ADN;
		else
			return API_SIM_EF_ADN;
	}
	case 0x6F46:
		return API_SIM_EF_SPN;
	case 0x6F3B:
		return API_SIM_EF_FDN;
	case 0x6F3C:
		return API_SIM_EF_SMS;
	case 0x6F3D:
		return API_SIM_EF_CCP;
	case 0x6F40:
		return API_SIM_EF_MSISDN;
	case 0x6F42:
		return API_SIM_EF_SMSP;
	case 0x6F43:
		return API_SIM_EF_SMSS;
	case 0x6F44:
		return API_SIM_EF_LND;
	case 0x6F47:
		return API_SIM_EF_SMSR;
	case 0x6F4:
		return API_SIM_EF_SDN;
	case 0x6F4A:
		return API_SIM_EF_EXT1;
	case 0x6F4B:
		return API_SIM_EF_EXT2;
	case 0x6F4C:
		return API_SIM_EF_EXT3;
	case 0x6F4D:
		return API_SIM_EF_BDN;
	case 0x6F4E:
		return API_SIM_EF_EXT4;
	case 0x6F05:
		return API_SIM_EF_LP;
	case 0x6F07:
		return API_SIM_EF_IMSI;
	case 0x6F20:
		return API_SIM_EF_KC;
	case 0x6F30:
		return API_SIM_EF_PLMNSEL;
	case 0x6F31:
		return API_SIM_EF_HPLMN;
	case 0x6F37:
		return API_SIM_EF_ACMMAX;
	case 0x6F38:
		return API_SIM_EF_SST;
	case 0x6F39:
		return API_SIM_EF_ACM;
	case 0x6F3E:
		return API_SIM_EF_GID1;
	case 0x6F3F:
		return API_SIM_EF_GID2;
	case 0x6F41:
		return API_SIM_EF_PUCT;
	case 0x6F45:
		return API_SIM_EF_CBMI;
	case 0x6F74:
		return API_SIM_EF_BCCH;
	case 0x6F78:
		return API_SIM_EF_ACC;
	case 0x6F7B:
		return API_SIM_EF_FPLMN;
	case 0x6F7E:
		return API_SIM_EF_LOCI;
	case 0x6FAD:
		return API_SIM_EF_AD;
	case 0x6FAE:
		return API_SIM_EF_PHASE;
	case 0x6FB1:
		return API_SIM_EF_VGCS;
	case 0x6FB2:
		return API_SIM_EF_VGCSS;
	case 0x6FB3:
		return API_SIM_EF_VBS;
	case 0x6FB4:
		return API_SIM_EF_VBSS;
	case 0x6FB5:
		return API_SIM_EF_EMLPP;
	case 0x6FB6:
		return API_SIM_EF_AAEM;
	case 0x6FB7:
		return API_SIM_EF_ECC;
	case 0x6F50:
		return API_SIM_EF_CBMIR;
	case 0x6F51:
		return API_SIM_EF_NIA;
	case 0x6F52:
		return API_SIM_EF_KCGPRS;
	case 0x6F53:
		return API_SIM_EF_LOCIGPRS;
	case 0x6F54:
		return API_SIM_EF_SUME;
	case 0x6F60:
		return API_SIM_EF_PLMNWACT;
	case 0x6F61:
		return API_SIM_EF_OPLMNWACT;
	case 0x6F62:
		return API_SIM_EF_HPLMNACT;

	case 0x6F63:
		return API_SIM_EF_CPBCCH;

	case 0x6F64:
		return API_SIM_EF_INVSCAN;

	case 0x0000:
		return API_SIM_EF_RPLMNAC;

	case 0x2FE2:
		return API_SIM_EF_ICCID;

	case 0x2F05:
		return API_SIM_EF_ELP;

	case 0x4F20:
		return API_SIM_EF_IMG;

	case 0x0001:
		return API_SIM_EF_MBDN;
	default:
		return 0xFFF;
	}
}
extern UINT8 gFetchData[256];

UINT32 gCrsmCommandDataLen[CFW_SIM_COUNT] = {0x00,};

// add for crsm end
VOID AT_SIM_CmdFunc_CRSM(AT_CMD_PARA *pParam)
{
	// #ifdef DEBUG_AT
	UINT8 uParaCount             = 0;
	UINT32 eParamOk              = 0;
	UINT8 uCommand               = 0;
	UINT32 uiFileid              = 0;
	UINT32 uiP1                  = 0;
	UINT32 uiP2                  = 0;
	UINT32 uiP3                  = 0;
	UINT8 usData[CRMPDATALENGTH] = { 0 }; // /????????data����Ӧ���Ƕ���?
	UINT8 uStrLen                = 0;
	PAT_CMD_RESULT pResult       = NULL;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	u_gCurrentCmdStamp[nSim] = pParam->uCmdStamp;

	if (pParam == NULL)
	{
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		return;
	}

	if (pParam->iType == AT_CMD_TEST)
	{
		OK_NULL_RETURN(pResult, pParam->nDLCI);
		return;
	}
	else if (pParam->iType == AT_CMD_SET)
	{
		if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		/* check para count */
		if ((1 > uParaCount) || (6 < uParaCount))
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		if (uParaCount == 3 || uParaCount == 4) // if param count equal to 3 or 4,then the fifth param must be filled
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		/* get all param */
		uStrLen = 1;

		eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &uCommand, &uStrLen);

		if (eParamOk != ERR_SUCCESS)  /* get uCallType failed */
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		/* if(uCommand > ??????)
		{
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID,pParam->nDLCI);
		return;
		}
		*/

		/* get uCommand successful */
		if (uCommand != 242 && uParaCount < 2)  // except STATUS, other <command> need <fileid> at least
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		if (uParaCount > 1)
		{

			uStrLen  = 4;
			eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT32, &uiFileid, &uStrLen);

			if (eParamOk != ERR_SUCCESS)  /* get uVolume failed */
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
				return;
			}

			/* if(uiFileid > ??????)
			{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID,pParam->nDLCI);
			return;
			}
			*/
			if ((uCommand != 192 && uCommand != 242) && uParaCount == 2)  // except STATUS and GET RESPONSE, <P1>,<P2>,<P3> is needed.
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
				return;
			}

			if (uParaCount > 2)
			{
				uStrLen  = 4;
				eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_UINT32, &uiP1, &uStrLen);

				if (eParamOk != ERR_SUCCESS)  /* get uType failed */
				{
					ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
					return;
				}

				uStrLen = 4;

				eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 3, AT_UTIL_PARA_TYPE_UINT32, &uiP2, &uStrLen);

				if (eParamOk != ERR_SUCCESS)  /* get uType failed */
				{
					ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
					return;
				}

				uStrLen = 4;

				eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 4, AT_UTIL_PARA_TYPE_UINT32, &uiP3, &uStrLen);

				if ((eParamOk != ERR_SUCCESS) || (uiP3 > 0xFF) || (uiP3 < 0)) /* get uType failed */
				{
					ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
					return;
				}

				/* if(uiP1 >???????)
				{
				ERROR_RETURN(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
				return;
				} */

				if (uParaCount > 5)
				{
					uStrLen  = CRMPDATALENGTH;
					eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 5, AT_UTIL_PARA_TYPE_STRING, usData, &uStrLen);

					if (eParamOk != ERR_SUCCESS)  /* get uIndex failed */
					{
						ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
						return;
					}

					/* if(usData > ?????)
					{
					ERROR_RETURN(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME);
					return;
					} */
				}
			}
		}

		AT_TC(g_sw_AT_SIM,
		      "uParaCount = %d,uCommand = %d,uiFileid = %d,uiP1 = %d,uiP2 = %d,uiP3 = %d,usData = %s,uStrLen = %d",
		      uParaCount, uCommand, uiFileid, uiP1, uiP2, uiP3, usData, uStrLen);

		UINT32 nRet = 0x00;

		// call csw function
		// CFW_XXXXXXXX();
		gCrsmCommandDataLen[nSim] = uiP3;

		switch (uCommand)
		{
		case CRSM_READ_BINARY:
		{
			nRet = CFW_SimReadBinary(ATGetStackSimFileID(uiFileid, nSim), ((uiP1) << 8) + uiP2, uiP3, pParam->nDLCI, nSim);
		}

		break;
		case CRSM_UPDATE_BINARY:
		{
			UINT8 *pGetData = (UINT8 *)AT_MALLOC(uiP3 * 2);
			SUL_ZeroMemory8(pGetData, uiP3 * 2);
			UINT8 nBCDLen       = SUL_AsciiToGsmBcdEx(usData, uiP3 * 2, pGetData);
			UINT8 nSwitchHLData = 0x00;
			UINT32 i;

			for (i = 0; i < nBCDLen; i++)
			{
				nSwitchHLData = ((pGetData[i] & 0x0f) << 4) + (pGetData[i] >> 4);
				pGetData[i]   = nSwitchHLData;
			}
			nRet =
			    CFW_SimUpdateBinary(ATGetStackSimFileID(uiFileid, nSim), ((uiP1) << 8) + uiP2, pGetData, uiP3, pParam->nDLCI, nSim);

			CSW_SIM_FREE(pGetData);
		}

		break;
		case CRSM_READ_RECORD:
		{
			nRet = CFW_SimReadRecord(ATGetStackSimFileID(uiFileid, nSim), uiP1, pParam->nDLCI, nSim);
		}
		break;
		case CRSM_UPDATE_RECORD:
		{
			UINT8 *pGetData = (UINT8 *)AT_MALLOC(uiP3 * 2);
			SUL_ZeroMemory8(pGetData, uiP3 * 2);
			UINT8 nBCDLen       = SUL_AsciiToGsmBcdEx(usData, uiP3 * 2, pGetData);
			UINT8 nSwitchHLData = 0x00;
			UINT32 i;

			for (i = 0; i < nBCDLen; i++)
			{
				nSwitchHLData = ((pGetData[i] & 0x0f) << 4) + (pGetData[i] >> 4);
				pGetData[i]   = nSwitchHLData;
			}
			if(0x6F3B == uiFileid)//FDN file
			{
				//AT_FDN_UpdateRecord(uiP1, uiP3, pGetData, nSim);
			}
			nRet = CFW_SimUpdateRecord(ATGetStackSimFileID(uiFileid, nSim), uiP1, uiP3, pGetData, pParam->nDLCI, nSim);
			CSW_SIM_FREE(pGetData);
		}

		break;
		case CRSM_GET_RESPONSE:
#  if 0
		{
			if (0x00 == gFetchData[0])
			{
				OK_RETURN(pResult, "+CRSM,111,0");
				return ERR_SUCCESS;
			}
			else
			{
				UINT8 nRetString[256] = { 0x00, };

				strcpy(nRetString, "+CRSM:144,0,");
				UINT8 nAsciiRetString[512] = { 0x00, };

				SUL_GsmBcdToAscii((UINT8)(gFetchData), strlen((UINT8)(gFetchData)), nAsciiRetString);
				strcat(nRetString, nAsciiRetString);
				OK_RETURN(pResult, nRetString);
				AT_MemZero(gFetchData, 256);
				return ERR_SUCCESS;

			}

			// nRet = CFW_SimReadRecord(ATGetStackSimFileID(uiFileid),uiP1,pParam->nDLCI,nSim);
		}

		break;
#endif
		case CRSM_STATUS:
		{
			nRet = CFW_SimGetFileStatus(ATGetStackSimFileID(uiFileid, nSim), pParam->nDLCI, nSim);
		}

		break;
		default:
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}
		}

		if (ERR_SUCCESS != nRet)
		{
			AT_TC(g_sw_AT_SIM, "nRet = 0x%x", nRet);

			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		OK_ASYN_RETURN(pResult, pParam->nDLCI);
	}
	else if (pParam->iType == AT_CMD_TEST)
	{
		ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_SUPPORTED, pParam->nDLCI);
		return;
	}

}



//uiFileid File ID
//Start Index
//Count
typedef struct _AT_CRSML
{
	UINT32 nStartIndex;
	UINT32 nCount;
	UINT32 nCurrentIndex;
	UINT32 nLen;
	UINT32 nFileID;
} AT_CRSML;

AT_CRSML gCrsml[CFW_SIM_COUNT];

VOID AT_SIM_CmdFunc_CRSML(AT_CMD_PARA *pParam)
{
	// #ifdef DEBUG_AT
	UINT8 uParaCount             = 0;
	UINT32 eParamOk              = 0;
	//UINT8 uCommand               = 0;
	UINT32 uiFileid              = 0;
	//UINT32 uiP1                  = 0;
	//UINT32 uiP2                  = 0;
	UINT32 uiP3                  = 0;
	//	UINT8 usData[CRMPDATALENGTH] = { 0 }; // /????????data����Ӧ���Ƕ���?
	UINT8 uStrLen                = 0;

	UINT32 nStartIndex = 0x00;
	UINT32 nCount = 0x00;
	PAT_CMD_RESULT pResult       = NULL;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	u_gCurrentCmdStamp[nSim] = pParam->uCmdStamp;

	if (pParam == NULL)
	{
		I_AM_HERE();
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		return;
	}

	if (pParam->iType == AT_CMD_TEST)
	{
		I_AM_HERE();
		OK_NULL_RETURN(pResult, pParam->nDLCI);
		return;
	}
	else if (pParam->iType == AT_CMD_SET)
	{
		if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
		{
			I_AM_HERE();
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		/* check para count */
		if (3 != uParaCount)
		{
			I_AM_HERE();
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}


		/* get all param */
		uStrLen = 4;

		eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT32, &uiFileid, &uStrLen);

		if (eParamOk != ERR_SUCCESS)  /* get uCallType failed */
		{
			I_AM_HERE();
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		uStrLen  = 4;
		eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT32, &nStartIndex, &uStrLen);

		if (eParamOk != ERR_SUCCESS)  /* get uType failed */
		{
			I_AM_HERE();
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		uStrLen = 4;

		eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_UINT32, &nCount, &uStrLen);

		if (eParamOk != ERR_SUCCESS)  /* get uType failed */
		{
			I_AM_HERE();
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		AT_TC(g_sw_AT_SIM,
		      "uParaCount = %d,,uiFileid = %d,nStartIndex = %d,nCount = %d", uParaCount, uiFileid, nStartIndex, nCount);

		UINT32 nRet = 0x00;

		// call csw function
		// CFW_XXXXXXXX();
		gCrsmCommandDataLen[nSim] = uiP3;
		gCrsml[nSim].nCount = nCount;
		gCrsml[nSim].nStartIndex  = nStartIndex;
		gCrsml[nSim].nCurrentIndex = nStartIndex;
		gCrsml[nSim].nFileID = uiFileid;
#if 0
		nRet = CFW_SimReadRecord(ATGetStackSimFileID(uiFileid), nStartIndex, pParam->nDLCI, nSim);
		if (ERR_SUCCESS != nRet)
		{
			AT_TC(g_sw_AT_SIM, "nRet = 0x%x", nRet);

			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}
#else
		nRet = CFW_SimGetFileStatus(ATGetStackSimFileID(uiFileid, nSim), pParam->nDLCI, nSim);
		if (ERR_SUCCESS != nRet)
		{
			AT_TC(g_sw_AT_SIM, "nRet = 0x%x", nRet);

			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}
#endif

		OK_ASYN_RETURN(pResult, pParam->nDLCI);
	}
	else if (pParam->iType == AT_CMD_TEST)
	{
		ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_SUPPORTED, pParam->nDLCI);
		return;
	}

}


VOID AT_SIM_CmdFunc_CAMM(AT_CMD_PARA *pParam)
{
	UINT8 uParaCount                 = 0;
	UINT32 eParamOk                  = 0;
	UINT32 iACMMax                   = 0;
	UINT8 usACMMax[CAMMLENGTH]       = { 0 }; // /????????data����Ӧ���Ƕ���?
	UINT8 usPassword[PIN2CODELENGTH] = { 0 };
	UINT8 uStrLen                    = 0;
	UINT32 nResult                   = 0;
	//  UINT8 nUTI                       = pParam->nDLCI;
	PAT_CMD_RESULT pResult           = NULL;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	u_gCurrentCmdStamp[nSim] = pParam->uCmdStamp;

	if (pParam == NULL)
	{
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		return;
	}

	if (pParam->iType == AT_CMD_TEST)
	{
		OK_NULL_RETURN(pResult, pParam->nDLCI);
		return;
	}
	else if (pParam->iType == AT_CMD_READ)
	{
		// AT_20071130_CAOW_B shield for return error first
#if 0
		// get UTI value
		nResult = AT_GetFreeUTI(CFW_SIM_SRV_ID, &nUTI);

		if (ERR_SUCCESS != nResult)
		{
			// get UTI error
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		nResult = CFW_SimGetACMMax(nUTI);

#else
#ifdef AT_DUAL_SIM
		nResult = CFW_SimGetACMMax(pParam->nDLCI, nSim);

#else
		nResult = CFW_SimGetACMMax(pParam->nDLCI);

#endif
#endif

		// AT_20071130_CAOW_E

		// execute result return

		if (ERR_SUCCESS == nResult)
		{
			OK_ASYN_RETURN(pResult, pParam->nDLCI);
		}
		else
		{
			ERROR_RETURN(pResult, ERR_AT_CME_EXE_FAIL, pParam->nDLCI);
		}

	}
	else if (pParam->iType == AT_CMD_SET)
	{
		if ((pParam->pPara == NULL) || (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &uParaCount))) /* GET param count */
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		/* check para count */
		if (uParaCount != 2)
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		/* get all param */
		uStrLen = CAMMLENGTH;

		eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, usACMMax, &uStrLen);

		if (eParamOk != ERR_SUCCESS)  /* get uCallType failed */
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		if (uParaCount > 1)
		{

			uStrLen  = PIN2CODELENGTH;
			eParamOk = AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, &usPassword, &uStrLen);

			if (eParamOk != ERR_SUCCESS)  /* get uVolume failed */
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
				return;
			}

			/* if(usPassword > ??????)
			   {
			   ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID);
			   return;
			   }
			 */

		}

		AT_TC(g_sw_AT_SIM, "uParaCount = %d,usACMMax = %s,usPassword = %s,uStrLen = %d", uParaCount, usACMMax, usPassword,
		      uStrLen);

		iACMMax = AT_CAMM_STRtoUINT32(usACMMax);

		if (iACMMax == ERR_AT_CME_PARAM_INVALID)
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			return;
		}

		AT_TC(g_sw_AT_SIM, "uParaCount = %d,usACMMax = %s,usPassword = %s,uStrLen = %d,iACMMax = %lu", uParaCount, usACMMax,
		      usPassword, uStrLen, iACMMax);

		// AT_20071130_CAOW_B
#if 0
		// get UTI value
		nResult = AT_GetFreeUTI(CFW_SIM_SRV_ID, &nUTI);

		if (ERR_SUCCESS != nResult)
		{
			// get UTI error
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		// call CSW interface function
		nResult = CFW_SimSetACMMax(iACMMax, usPassword, uStrLen, nUTI);

#else
#ifdef AT_DUAL_SIM
		nResult = CFW_SimSetACMMax(iACMMax, usPassword, uStrLen, pParam->nDLCI, nSim);

#else
		nResult = CFW_SimSetACMMax(iACMMax, usPassword, uStrLen, pParam->nDLCI);

#endif

#endif
		// AT_20071130_CAOW_E

		// execute result return
		if (ERR_SUCCESS == nResult)
		{
			OK_ASYN_RETURN(pResult, pParam->nDLCI);
		}
		else
		{
			ERROR_RETURN(pResult, ERR_AT_CME_EXE_FAIL, pParam->nDLCI);
		}

	}
	else  // changyg[+] 2008-6-12 default wrong process for bug 8758
	{
		ERROR_RETURN(pResult, ERR_AT_CME_EXE_NOT_SURPORT, pParam->nDLCI);
	}
}

// AT_20071114_CAOW_E

/*
 *******************************************************************************
 *  possible input from	ATM:												   *
 *  AT+cpin=? -->test, return OK;											   *
 *	AT+cpin? --> read,wait asyncrounous event,response e.g.:				   *
 *			---> "+CPIN: SIM PIN","+CPIN: READY"							   *
 *	AT+cpin="1234"(4<pinSize<8)	-->reponse:OK,ERROR							   *
 *	AT+cpin="12345678","1234"(pukSize=8),(4<pinSize<8) -->reponse:OK,ERROR	   *
 *******************************************************************************
*/
void AT_SIM_CmdFunc_CPIN(AT_CMD_PARA *pParam)
{
	// for ATM2NOTIFY pResult,result  code.
	PAT_CMD_RESULT pResult = NULL;

	// for CSW interface return value
	UINT32 return_val;
	UINT8 nUTI = pParam->nDLCI;

	UINT8 i                    = 20; // a temp pointer
	UINT8 NumOfParam           = 0; // NumOfParam  from pParam,UART's input
	UINT8 uPin[PIN1CODEMAX]    = { 0 };  // same with inteface
	UINT8 nPinSize             = 0; // same with inteface
	UINT8 uNewPin[PIN1CODEMAX] = { 0 }; // same with inteface
	UINT8 nNewPinSize          = 0;  // same with inteface
	UINT8 nOption              = 1;  // same with inteface

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	// from  ATM
	u_gCurrentCmdStamp[nSim] = pParam->uCmdStamp;

	// check  intut ppara,return if NULL

	if (pParam == NULL)
	{
		AT_TC(g_sw_AT_SIM, "_CPIN_PARAM_1!");
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
	}

	// check  different cmd type
	switch (pParam->iType)
	{

	case AT_CMD_SET:
	{
		// AT_CMD_SET-------------------->

		/********************************************************
			 *	UINT32 CFW_SimEnterAuthentication(		*
			 *				  UINT8* pPin,		*
			 *				  UINT8	 nPinSize,	*
			 *				  UINT8* pNewPin,	*
			 *				  UINT8	 nNewPinSize,	*
			 *				  UINT8	 nOption,	*
			 *				  UINT16 nUTI);		*
			 ********************************************************/

		// 1. ckeck pParam->pPara
		if (NULL == pParam->pPara)
		{
			AT_TC(g_sw_AT_SIM, "_CPIN_PARAM_2!");
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		// 2. get parameter count and check it.  if error ,return.
		if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &NumOfParam))
		{
			AT_TC(g_sw_AT_SIM, "_CPIN_PARAM_3!");
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		if ((NumOfParam != 1) && (NumOfParam != 2))
		{
			AT_TC(g_sw_AT_SIM, "_CPIN_PARAM_4!");
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		i = PIN1CODEMAX;  // 7.24  changed form 15 to PIN1CODEMAX.

		// 3.1 get and check it.!if error return.

		if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, uPin, &i))
		{
			AT_TC(g_sw_AT_SIM, "_CPIN_PARAM_5!");
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		// 3.3 update nPinSize for call  CFW interface
		nPinSize = (UINT8)AT_StrLen(uPin);

		if ((nPinSize > 8) || (nPinSize < 1))
		{
			AT_TC(g_sw_AT_SIM, "_CPIN_PARAM_6!");
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		for (i = 0; i < nPinSize; i++)
		{
			if ((*(uPin + i) < '0') || (*(uPin + i) > '9'))
			{
				AT_TC(g_sw_AT_SIM, "_CPIN_PARAM_7!");
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}
		} // ----------->the first parameter is correct.

		// 4.if  there are two paras, get and check it.
		if (NumOfParam == 2)  //
		{
			i = PIN1CODEMAX;

			// 4.2 get and check it.

			if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, uNewPin, &i))
			{
				AT_TC(g_sw_AT_SIM, "_CPIN_PARAM_8!");
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}

			// 4.3 update nNewPinSize for call CFW interface
			nNewPinSize = (UINT8)AT_StrLen(uNewPin);

			if ((nNewPinSize > 8) || (nNewPinSize < 0))
			{
				AT_TC(g_sw_AT_SIM, "_CPIN_PARAM_9!");
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}

			for (i = 0; i < nNewPinSize; i++)
			{
				if ((*(uNewPin + i) < '0') || (*(uNewPin + i) > '9'))
				{
					AT_TC(g_sw_AT_SIM, "_CPIN_PARAM_10!");
					ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
				}
			}
		} // -------->end if two parameter
		else
		{
			// -------->if only one parameter
			nNewPinSize = 0;

			// nOption = 0; yaoal;7.24; delete this for cpin  can accept cpin2.

			// add by wangxd for bug8046
#if 1
#if SIM_DEBUG
			AT_TC(g_sw_AT_SIM, "CPIN g_Pin1PukStauts=%d,g_Pin1ErrorTimes=%d", g_Pin1PukStauts[nSim], g_Pin1ErrorTimes[nSim]);
#endif
#ifdef AT_DUAL_SIM
			if (g_Pin1PukStauts[nSim])
#else
			if (g_Pin1PukStauts)
#endif
			{
				AT_TC(g_sw_AT_SIM, "_CPIN_PARAM_11!");
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}
#endif
			// add_end by wangxd
		}

		// 5. get free UTI for CFW interface
#if 1
		if (ERR_SUCCESS != AT_GetFreeUTI(CFW_SIM_SRV_ID, &nUTI))
		{
			AT_TC(g_sw_AT_SIM, "_CPIN_PARAM_12!");
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

#else
		nUTI = SIM_UTI;

		AT_TC(g_sw_AT_SIM, "------------>UTI!");

		if (ERR_SUCCESS != CFW_IsFreeUTI(nUTI, CFW_SIM_SRV_ID))
		{
			AT_TC(g_sw_AT_SIM, "not free UTI!");
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

#endif
		// 6. call CFW interface
		if ((nNewPinSize > 0) && (nPinSize < 8))
		{
			UINT16 nFac = CFW_STY_FAC_TYPE_SC;

			AT_TC(g_sw_AT_SIM, "change pswrd!");

#ifdef AT_DUAL_SIM
			return_val = CFW_SimChangePassword(nFac, uPin, nPinSize, uNewPin, nNewPinSize, pParam->nDLCI, nSim);
#else
			return_val = CFW_SimChangePassword(nFac, uPin, nPinSize, uNewPin, nNewPinSize, pParam->nDLCI);
#endif
		}
		else
		{
			AT_TC(g_sw_AT_SIM, "Enter Authenti!");

#ifdef AT_DUAL_SIM
			return_val = CFW_SimEnterAuthentication(uPin, nPinSize, uNewPin, nNewPinSize, nOption, pParam->nDLCI, nSim);
#else
			return_val = CFW_SimEnterAuthentication(uPin, nPinSize, uNewPin, nNewPinSize, nOption, pParam->nDLCI);
#endif
		}

		// 7. check the  return value
		if (ERR_SUCCESS != return_val)
		{
			AT_TC(g_sw_AT_SIM, "------------>UTI!");

			if (ERR_CFW_INVALID_PARAMETER == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}
			else if (ERR_CME_OPERATION_NOT_ALLOWED == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_ALLOWED, pParam->nDLCI);
			}
			else if (ERR_NO_MORE_MEMORY == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_NO_MEMORY, pParam->nDLCI);
			}
			else
			{
				ERROR_RETURN(pResult, ERR_AT_CME_EXE_NOT_SURPORT, pParam->nDLCI); // this error code need to be check
			}
		}

		// AT_20071105_CAOW_B
		gLstStatusRec = 1;

		// AT_20071105_CAOW_E

		// 8. OK ,and send OK to ATM.
		AT_security_currentCMD[nSim] = CPIN;

		pResult = AT_CreateRC(CMD_FUNC_SUCC_ASYN,
		                      CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

		AT_Notify2ATM(pResult, pParam->nDLCI);

		if (pResult != NULL)
		{
			AT_FREE(pResult);
			pResult = NULL;
		}

		// 10. return
		return;
	} // <--------AT_CMD_SET-------------

	break;

	case AT_CMD_TEST:
	{
		OK_NULL_RETURN(pResult, pParam->nDLCI);
	}

	case AT_CMD_READ:
	{
#if SIM_DEBUG
		AT_TC(g_sw_AT_SIM, "AT_GetFreeUTI =%d", return_val);
		return_val = AT_GetFreeUTI(CFW_SIM_SRV_ID, &nUTI);

		if (ERR_SUCCESS != return_val)
		{
			ERROR_RETURN(pResult, return_val, pParam->nDLCI);
		}

		AT_TC(g_sw_AT_SIM, "UTI =	%d", nUTI);

#endif
		nUTI = SIM_UTI;
#ifdef AT_DUAL_SIM

		return_val = CFW_SimGetAuthenticationStatus(pParam->nDLCI, nSim);
#else
		return_val = CFW_SimGetAuthenticationStatus(pParam->nDLCI);

#endif

		if (ERR_SUCCESS != return_val)
		{
			if (ERR_CFW_INVALID_PARAMETER == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}
			else if (ERR_CME_OPERATION_NOT_ALLOWED == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_ALLOWED, pParam->nDLCI);
			}
			else if (ERR_NO_MORE_MEMORY == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_NO_MEMORY, pParam->nDLCI);
			}
			else if ((ERR_CME_SIM_NOT_INSERTED == return_val) || (ERR_CFW_SIM_NOT_INITIATE == return_val))
			{
				ERROR_RETURN(pResult, ERR_AT_CME_SIM_NOT_INSERTED, pParam->nDLCI);
			}
			else
			{
				ERROR_RETURN(pResult, ERR_AT_CME_EXE_NOT_SURPORT, pParam->nDLCI); // this error code need to be check
			}
		}

		AT_security_currentCMD[nSim] = CPIN;

		pResult = AT_CreateRC(CMD_FUNC_SUCC_ASYN,
		                      CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);
		AT_Notify2ATM(pResult, pParam->nDLCI);

		if (pResult != NULL)
		{
			AT_FREE(pResult);
			pResult = NULL;
		}

		return;
	}

	break;

	default:
	{
		ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_SUPPORTED, pParam->nDLCI);
	}
	} // <----------end of switch cmd  type-------
} // <-----end of  this funnction------------------------------------------------

/*
 *******************************************************************************
 *  possible input from	ATM:
 *  AT+cpin2=? -->test,	return OK;
 *	AT+cpin2? --> read,wait	asyncrounous event,response e.g.:
 *			  --> "+CPIN: SIM PIN","+CPIN: READY"
 *	AT+cpin2="1234"(4<pinSize<8)	-->reponse:OK,ERROR
 *	AT+cpin2="12345678","1234"(pukSize=8),(4<pinSize<8) -->reponse:OK,ERROR
 *	remain problem:
 *	1.if data from UART is larger than actual buffer
 *******************************************************************************
*/
void AT_SIM_CmdFunc_CPIN2(AT_CMD_PARA *pParam)
{
	// for ATM2NOTIFY pResult,result  code.
	PAT_CMD_RESULT pResult = NULL;

	// for CSW interface return value
	UINT32 return_val;
	UINT8 nUTI = pParam->nDLCI; // by wulc 2012.03.12

	UINT8 i           = 20; // a temp pointer
	UINT8 NumOfParam  = 0; // NumOfParam from pParam,UART's input
	UINT8 uPin[20]    = { 0 }; // same with inteface
	UINT8 nPinSize    = 0; // same with inteface
	UINT8 uNewPin[20] = { 0 };  // same with inteface
	UINT8 nNewPinSize = 0;  // same with inteface
	UINT8 nOption     = 2;  // same with inteface

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	// from  ATM
	u_gCurrentCmdStamp[nSim] = pParam->uCmdStamp;

	// check  intut pPara,return if NULL

	if (pParam == NULL)
	{
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
	}

	// check  different cmd type
	switch (pParam->iType)
	{

	case AT_CMD_SET:
	{
		// AT_CMD_SET-------------------->

		/*******************************************************
			UINT32 CFW_SimEnterAuthentication(
						  UINT8* pPin,
						  UINT8	 nPinSize,
						  UINT8* pNewPin,
						  UINT8	 nNewPinSize,
						  UINT8	 nOption,
						  UINT16 nUTI
						);
			********************************************************/

		// 1. ckeck pParam->pPara
		if (NULL == pParam->pPara)
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		// 2. get parameter count and check it.  if error ,return.
		if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &NumOfParam))
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		if ((NumOfParam != 1) && (NumOfParam != 2))
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		// 3.1 get and check it.!if error return.
		if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, uPin, &i))
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		// 3.3 update nPinSize for call  CFW interface
		nPinSize = (UINT8)AT_StrLen(uPin);

		if ((nPinSize > 8) || (nPinSize < 1))
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		for (i = 0; i < nPinSize; i++)
		{
			if ((*(uPin + i) < '0') || (*(uPin + i) > '9'))
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}

		} // ----------->the first parameter is correct.

		// 4.if  there is two para, get and check it.
		if (NumOfParam == 2)  //
		{
			// 4.1 get and check it.
			if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, uNewPin, &i))
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}

			// 4.3 update nNewPinSize for call CFW interface
			nNewPinSize = (UINT8)AT_StrLen(uNewPin);

			if ((nNewPinSize > 8) || (nNewPinSize < 1))
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}

			for (i = 0; i < nNewPinSize; i++)
			{
				if ((*(uNewPin + i) < '0') || (*(uNewPin + i) > '9'))
				{
					ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
				}
			}
		} // -------->end two parameter

		// 5. get free UTI for CFW interface
#if SIM_DEBUG
		if (ERR_SUCCESS != AT_GetFreeUTI(CFW_SIM_SRV_ID, &nUTI))
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

#else
		nUTI = SIM_UTI;

#endif
		// 6. call CFW interface

#ifdef AT_DUAL_SIM
		return_val = CFW_SimEnterAuthentication(uPin, nPinSize, uNewPin, nNewPinSize, nOption, pParam->nDLCI, nSim);
#else
		return_val = CFW_SimEnterAuthentication(uPin, nPinSize, uNewPin, nNewPinSize, nOption, pParam->nDLCI);

#endif

		// 7. check the  return value
		if (ERR_SUCCESS != return_val)
		{
			if (ERR_CFW_INVALID_PARAMETER == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}
			else if (ERR_CME_OPERATION_NOT_ALLOWED == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_ALLOWED, pParam->nDLCI);
			}
			else if (ERR_NO_MORE_MEMORY == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_NO_MEMORY, pParam->nDLCI);
			}
			else
			{
				ERROR_RETURN(pResult, ERR_AT_CME_EXE_NOT_SURPORT, pParam->nDLCI); // this error code need to be check
			}
		}

		// AT_20071105_CAOW_B
		gLstStatusRec = 2;

		// AT_20071105_CAOW_E

		// 8. OK ,and send asyn  OK to ATM.
		AT_security_currentCMD[nSim] = CPIN2;

		pResult = AT_CreateRC(CMD_FUNC_SUCC_ASYN,
		                      CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

		AT_Notify2ATM(pResult, pParam->nDLCI);

		if (pResult != NULL)
		{
			AT_FREE(pResult);
			pResult = NULL;
		}

		// 10. return
		return;
	} // <--------AT_CMD_SET-------------

	break;

	case AT_CMD_TEST:
	{
		pResult = AT_CreateRC(CMD_FUNC_SUCC,
		                      CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);
		AT_Notify2ATM(pResult, pParam->nDLCI);

		if (pResult != NULL)
		{
			AT_FREE(pResult);
			pResult = NULL;
		}

		return;
	}

	break;

	case AT_CMD_READ:
	{
#if SIM_DEBUG
		return_val = AT_GetFreeUTI(CFW_SIM_SRV_ID, &nUTI);

		if (ERR_SUCCESS != return_val)
		{
			ERROR_RETURN(pResult, return_val, pParam->nDLCI);
		}

#else
		nUTI = SIM_UTI;

#endif
#ifdef AT_DUAL_SIM

		return_val = CFW_SimGetAuthenticationStatus(pParam->nDLCI, nSim);
#else
		return_val = CFW_SimGetAuthenticationStatus(pParam->nDLCI);

#endif

		if (ERR_SUCCESS != return_val)
		{
			if (ERR_CFW_INVALID_PARAMETER == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}
			else if (ERR_CME_OPERATION_NOT_ALLOWED == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_ALLOWED, pParam->nDLCI);
			}
			else if (ERR_NO_MORE_MEMORY == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_NO_MEMORY, pParam->nDLCI);
			}
			else
			{
				ERROR_RETURN(pResult, ERR_AT_CME_EXE_NOT_SURPORT, pParam->nDLCI); // this error code need to be check
			}
		}

		AT_security_currentCMD[nSim] = CPIN2;

		pResult = AT_CreateRC(CMD_FUNC_SUCC_ASYN,
		                      CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);
		AT_Notify2ATM(pResult, pParam->nDLCI);

		if (pResult != NULL)
		{
			AT_FREE(pResult);
			pResult = NULL;
		}

		return;
	}

	break;

	default:
	{
		ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_SUPPORTED, pParam->nDLCI);
	}
	} // <----------end of switch cmd  type-------
} // <----------------end  of this funnction

/*
*******************************************************************************
*  Write: AT+CLCK=<fac>,<mode>[,<passwd>[,<class>]]
*  Test:  AT+CLCK=?
*  possible input from ATM:
*  AT+CLCK=?			-->res:+CLCK: ("PS","PF","SC","AO","OI","OX","AI",
*				 "IR","AB","AG","AC","FD","PN","PU","PP","PC")
*				 OK
*  AT+CLCK="SC",1,"1234"---->reponse:OK,ERROR
*  AT+CLCK="SC",2		---->read,res:1.ERROR(when need	to enter pin),2.+clck:1(No need	to enter pin)
*  AT+CLCK="SC",0,"1234"---->reponse:OK,ERROR
*******************************************************************************
*/
void AT_SIM_CmdFunc_CLCK(AT_CMD_PARA *pParam)
{
	// for ATM2NOTIFY pResult,result  code.
	PAT_CMD_RESULT pResult = NULL;

	// for CSW interface return value
	UINT32 return_val = 0;
	UINT8 nUTI        = pParam->nDLCI;

	UINT8 i                 = 20; // a temp pointer
	UINT8 NumOfParam        = 0; // NumOfParam from pParam,UART's input
	UINT8 uFAC[FAC_MAX_NUM] = { 0 };  // store the fac string
	UINT8 FACsize;  //
	UINT16 nFac;  // same with inteface
	UINT8 uBufPwd[CLCK_PWD_MAX] = { 0 };  // same with inteface
	UINT8 nPwdSize              = 0; // same with inteface
	UINT8 nClassx               = 0;
	UINT8 nMode;  // same with inteface

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	// from  ATM
	u_gCurrentCmdStamp[nSim] = pParam->uCmdStamp;
	AT_TC(g_sw_AT_SIM, "CLCK: start\n");

	// check  intut ppara,return if NULL

	if (pParam == NULL)
	{
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
	}

	// check  different cmd type
	switch (pParam->iType)
	{

	case AT_CMD_SET:
	{
		// AT_CMD_SET-------------------->

		/*********************************************
			*UINT32	CFW_SimSetFacilityLock (	     *
			*		UINT16 nFac,		     *
			*		UINT8* pBufPwd,		     *
			*		UINT8  nPwdSize,	     *
			*		UINT8  nMode,		     *
			*		UINT16 nUTI);		     *
			**********************************************/

		// 1. ckeck pParam->pPara
		if (NULL == pParam->pPara)
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		// 2. get parameter count and check it.  if error ,return.
		if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &NumOfParam))
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		if ((NumOfParam != 2) && (NumOfParam != 3) && (NumOfParam != 4))
		{
			AT_TC(g_sw_AT_SIM, "CLCK: error num range!\n");
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		i = FAC_MAX_NUM;

		// 3.1 get and check it.!if error return.

		if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, uFAC, &i))
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		// 3.3 update nPinSize for call  CFW interface
		FACsize = (UINT8)AT_StrLen(uFAC);

		if (2 != FACsize)
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		/***************************************************************************
			*	#define	CFW_STY_FAC_TYPE_SC  0x5343 --support
			*	#define	CFW_STY_FAC_TYPE_PS  0x5053
			*	#define	CFW_STY_FAC_TYPE_P2  0x5032
			*	#define	CFW_STY_FAC_TYPE_PF  0x5046
			*	#define	CFW_STY_FAC_TYPE_PN  0x504E
			*	#define	CFW_STY_FAC_TYPE_PU  0x5055
			*	#define	CFW_STY_FAC_TYPE_PP  0x5050
			*	#define	CFW_STY_FAC_TYPE_PC  0x5043
			*	#define	CFW_STY_FAC_TYPE_FD  0x4644 --support
			****************************************************************************/
		nFac = * (UINT16 *)uFAC;

		nFac = U16_SWAP(nFac);

		switch (nFac)
		{
		case CFW_STY_FAC_TYPE_AO:

		case CFW_STY_FAC_TYPE_OI:

		case CFW_STY_FAC_TYPE_OX:

		case CFW_STY_FAC_TYPE_AI:

		case CFW_STY_FAC_TYPE_IR:

		case CFW_STY_FAC_TYPE_AB:

		case CFW_STY_FAC_TYPE_AG:

		case CFW_STY_FAC_TYPE_AC:

		case CFW_STY_FAC_TYPE_SC:

		case CFW_STY_FAC_TYPE_PS:

		case CFW_STY_FAC_TYPE_P2:

		case CFW_STY_FAC_TYPE_PF:

		case CFW_STY_FAC_TYPE_PN:

		case CFW_STY_FAC_TYPE_PU:

		case CFW_STY_FAC_TYPE_PP:

		case CFW_STY_FAC_TYPE_PC:

		case CFW_STY_FAC_TYPE_FD:
			break;

		default:
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}
		}

		// 3.4 get the second para and check it;
		i = 1;

		if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &nMode, &i))
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		if (!
		        ((((0 == nMode) || (1 == nMode)) && ((3 == NumOfParam) || (4 == NumOfParam)))
		         || ((2 == nMode) && ((2 == NumOfParam) || (3 == NumOfParam)))))
		{
			AT_TC(g_sw_AT_SIM, "CLCK: error 2 para range!\n");
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		// 4.if  there is three para, get and check it.
		if (NumOfParam >= 3)  //
		{
			if (2 == nMode)
			{
				i = 1;
				if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_UINT8, &nClassx, &i))
				{
					AT_TC(g_sw_AT_SIM, "CLCK: error 3 para mode ==2!\n");
					ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
				}

			}
			else
			{
				i = CLCK_PWD_MAX;

				// 4.1 get and check it.

				if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_STRING, uBufPwd, &i))
				{
					ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
				}

				// 4.3 update nNewPinSize for call CFW interface
				nPwdSize = (UINT8)AT_StrLen(uBufPwd);

				if ((nPwdSize > 8) || (nPwdSize < 1))
				{
					ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
				}

				for (i = 0; i < nPwdSize; i++)
				{
					if ((*(uBufPwd + i) < '0') || (*(uBufPwd + i) > '9'))
					{
						ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
					}
				}
			} // --->end three parameter

		} // --->end three parameter

		if (NumOfParam == 4)  //
		{
			i = 1;
			if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &nClassx, &i))
			{
				AT_TC(g_sw_AT_SIM, "CLCK: error 4 para!\n");
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}

		}

		// 5. get free UTI for CFW interface
#if SIM_DEBUG
		if (ERR_SUCCESS != AT_GetFreeUTI(CFW_SIM_SRV_ID, &nUTI))
		{
			AT_TC(g_sw_AT_SIM, "CLCK:NO UTI! error=0x%x", return_val);
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

#else
		nUTI = SIM_UTI;

#endif
		// 6. if mode == 0 or mode == 1  call CFW interface SetFacilityLock
		if ((0 == nMode) || (1 == nMode))
		{

			if((nFac == CFW_STY_FAC_TYPE_SC) || (nFac == CFW_STY_FAC_TYPE_FD))
			{
				/* CFW_SimSetFacilityLock(UINT16  nFac, UINT8 * pBufPwd, UINT8 nPwdSize, UINT8 nMode, UINT16 nUTI) */
				AT_TC(g_sw_AT_SIM, "Set Facility Lock nFac:0x%x,uBufPwd:%s,nPwdSize:0x%x,nMode:0x%x\n", nFac, uBufPwd, nPwdSize,
				      nMode);
#ifdef AT_DUAL_SIM
				return_val = CFW_SimSetFacilityLock(nFac, uBufPwd, nPwdSize, nMode, pParam->nDLCI, nSim);
#else
				return_val = CFW_SimSetFacilityLock(nFac, uBufPwd, nPwdSize, nMode, pParam->nDLCI);
#endif
			}
			else
			{
#ifdef AT_DUAL_SIM
				return_val = CFW_SsSetFacilityLock(nFac, uBufPwd, nPwdSize, nClassx, nMode, pParam->nDLCI, nSim);
#else
				return_val = CFW_SsSetFacilityLock(nFac, uBufPwd, nPwdSize, nClassx, nMode, pParam->nDLCI);
#endif
			}
		}
		else
		{
			/***************mode ==	2********************
				*	UINT32 CFW_SimGetFacilityLock (
				*			UINT16 nFac,
				*			UINT16 nUTI );
				****************************************8***/
			if((nFac == CFW_STY_FAC_TYPE_SC) || (nFac == CFW_STY_FAC_TYPE_FD))
			{
#ifdef AT_DUAL_SIM
				return_val = CFW_SimGetFacilityLock(nFac, pParam->nDLCI, nSim);
#else
				return_val = CFW_SimGetFacilityLock(nFac, pParam->nDLCI);
#endif
			}
			else
			{
				switch(nClassx)
				{
					//Specify the sum of class to represent the class information.
					//Reference to csw development document
				case 1:
					nClassx = 11;
					break;
				case 2:
					nClassx = 16;
					break;
				case 4:
					nClassx = 13;
					break;
				case 7:
					nClassx = 20;
					break;
				default:
					break;
				}

#ifdef AT_DUAL_SIM
				return_val = CFW_SsQueryFacilityLock(nFac, nClassx, pParam->nDLCI, nSim);
#else
				return_val = CFW_SsQueryFacilityLock(nFac, nClassx, pParam->nDLCI);
#endif

			}
		}

		// 7. check the  return value
		if (ERR_SUCCESS != return_val)
		{
			if (ERR_CFW_INVALID_PARAMETER == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}
			else if (ERR_CME_OPERATION_NOT_ALLOWED == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_ALLOWED, pParam->nDLCI);
			}
			else if (ERR_NO_MORE_MEMORY == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_NO_MEMORY, pParam->nDLCI);
			}
			else
			{
				ERROR_RETURN(pResult, ERR_AT_CME_EXE_NOT_SURPORT, pParam->nDLCI); // this error code need to be check
			}
		}

		// AT_20071105_CAOW_B
		if (nFac == CFW_STY_FAC_TYPE_SC)
			gLstStatusRec = 1;
		else if (nFac == CFW_STY_FAC_TYPE_FD)
			gLstStatusRec = 2;

		// AT_20071105_CAOW_E

		// 8. OK ,and send OK to ATM.
		pResult = AT_CreateRC(CMD_FUNC_SUCC_ASYN,
		                      CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

		AT_Notify2ATM(pResult, pParam->nDLCI);

		if (pResult != NULL)
		{
			AT_FREE(pResult);
			pResult = NULL;
		}

		// 10. return
		return;
	} // <--------AT_CMD_SET-------------

	break;

	case AT_CMD_TEST:
	{
		// AT_SIM_07.09.06_CW_B
#if 0
		OK_RETURN(pResult, "+CLCK: (\"PS\",\"PF\",\"SC\",\"FD\",\"PN\",\"PU\",\"PP\",\"PC\")");
#else
		OK_RETURN(pResult, "+CLCK: (\"SC\",\"FD\",\"AO\",\"OX\",\"OI\")", pParam->nDLCI);
#endif
		// AT_SIM_07.09.06_CW_E
	}

	break;

	default:
	{
		ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_SUPPORTED, pParam->nDLCI);
	}
	} // <----------end of switch cmd  type-------
}

/*
 *******************************************************************************
 *  AT+CPWD=<fac>,<oldpwd>,<newpwd>; -->OK,ERROR
 *  AT+CPWD=<fac>,<newpwd>;
 *  AT+CPWD=?	-->+CPWD: list of supported (<fac>,<pwdlength>)s
 *  possible input from	ATM:
 *  AT+CPWD=?  -->test,	return OK;
 *******************************************************************************
*/
void AT_SIM_CmdFunc_CPWD(AT_CMD_PARA *pParam)
{
	// for ATM2NOTIFY pResult,result  code.
	PAT_CMD_RESULT pResult = NULL;

	// for CSW interface return value
	UINT32 return_val;
	UINT8 nUTI = pParam->nDLCI;

	UINT8 i                 = 20; // a temp
	UINT8 NumOfParam        = 0; // NumOfParam from pParam,UART's input
	UINT8 uFAC[FAC_MAX_NUM] = { 0 };
	UINT8 numofpFAC;
	UINT16 nFac;
	UINT8 uBufOldPwd[PIN1CODEMAX] = { 0 };
	UINT8 nOldPwdSize             = 0;
	UINT8 uBufNewPwd[PIN1CODEMAX] = { 0 };
	UINT8 nNewPwdSize             = 0;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif
	// from  ATM
	u_gCurrentCmdStamp[nSim] = pParam->uCmdStamp;

	// check  intut ppara,return if NULL

	if (pParam == NULL)
	{
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
	}

	// check  different cmd type
	switch (pParam->iType)
	{

	case AT_CMD_SET:
	{
		// AT_CMD_SET-------------------->

		/*******************************************************
					UINT32 CFW_SimChangePassword(
					  UINT16 nFac,
					  UINT8* pBufOldPwd,
					  UINT8	 nOldPwdSize,
					  UINT8* pBufNewPwd,
					  UINT8	 nNewPwdSize,
					  UINT16 nUTI				);
			********************************************************/

		// 1. ckeck pParam->pPara
		if (NULL == pParam->pPara)
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		// 2. get parameter count and check it.  if error ,return.
		if (ERR_SUCCESS != AT_Util_GetParaCount(pParam->pPara, &NumOfParam))
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		if ((NumOfParam != 3) && (NumOfParam != 2))
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		i = FAC_MAX_NUM;

		// 3.1 get and check it.!if error return.

		if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, uFAC, &i))
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		numofpFAC = (UINT8)AT_StrLen(uFAC);

		if (2 != numofpFAC)
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

		/***************************************************************************
			*	#define	CFW_STY_FAC_TYPE_SC  0x5343   ---supported
			*	#define	CFW_STY_FAC_TYPE_PS  0x5053
			*	#define	CFW_STY_FAC_TYPE_P2  0x5032   ---supported
			*	#define	CFW_STY_FAC_TYPE_PF  0x5046
			*	#define	CFW_STY_FAC_TYPE_PN  0x504E
			*	#define	CFW_STY_FAC_TYPE_PU  0x5055
			*	#define	CFW_STY_FAC_TYPE_PP  0x5050
			*	#define	CFW_STY_FAC_TYPE_PC  0x5043
			*	#define	CFW_STY_FAC_TYPE_FD  0x4644
			****************************************************************************/
		nFac = * (UINT16 *)uFAC;

		nFac = U16_SWAP(nFac);

		switch (nFac)
		{

		case CFW_STY_FAC_TYPE_SC:
			// case CFW_STY_FAC_TYPE_PS :

		case CFW_STY_FAC_TYPE_P2:
			// case CFW_STY_FAC_TYPE_PF :
			// case CFW_STY_FAC_TYPE_PN :
			// case CFW_STY_FAC_TYPE_PU :
			// case CFW_STY_FAC_TYPE_PP :
			// case CFW_STY_FAC_TYPE_PC :
			// case CFW_STY_FAC_TYPE_FD :
			break;

		default:
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}
		} // end of switch(nFac)

		// 4.if  there is two para, get and store it to new password buffer, NULL old psw
		if (NumOfParam == 2)  //
		{
			i = PIN1CODEMAX;

			// 4.2 get and check it.

			if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, uBufNewPwd, &i))
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}

			// 4.3 update nNewPinSize for call CFW interface
			nNewPwdSize = (UINT8)AT_StrLen(uBufNewPwd);

			if ((nNewPwdSize > 8) || (nNewPwdSize < 1))
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}

			for (i = 0; i < nNewPwdSize; i++)
			{
				if ((*(uBufNewPwd + i) < '0') || (*(uBufNewPwd + i) > '9'))
				{
					ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
				}
			}
		} // -------->end of two parameter
		else
		{
			// -------->if three parameter

			i = PIN1CODEMAX;

			// 4.2 get and check it.

			if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, uBufOldPwd, &i))
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}

			// 4.3 update nNewPinSize for call CFW interface
			nOldPwdSize = (UINT8)AT_StrLen(uBufOldPwd);

			if ((nOldPwdSize > 8) || (nOldPwdSize < 1))
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}

			for (i = 0; i < nOldPwdSize; i++)
			{
				if ((*(uBufOldPwd + i) < '0') || (*(uBufOldPwd + i) > '9'))
				{
					ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
				}
			}

			// get the third  parameter
			i = PIN1CODEMAX;

			// 4.2 get and check it.
			if (ERR_SUCCESS != AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_STRING, uBufNewPwd, &i))
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}

			// 4.3 update nNewPinSize for call CFW interface
			nNewPwdSize = (UINT8)AT_StrLen(uBufNewPwd);

			if ((nNewPwdSize > 8) || (nNewPwdSize < 1))
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}

			for (i = 0; i < nNewPwdSize; i++)
			{
				if ((*(uBufNewPwd + i) < '0') || (*(uBufNewPwd + i) > '9'))
				{
					ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
				}
			}
		} // -------->if three parameter

		// 5. get free UTI for CFW interface
#if SIM_DEBUG
		if (ERR_SUCCESS != AT_GetFreeUTI(CFW_SIM_SRV_ID, &nUTI))
		{
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
		}

#else
		nUTI = SIM_UTI;

#endif
		// 6. call CFW interface
		/* CFW_SimChangePassword(UINT16 nFac, UINT8 * pBufOldPwd, UINT8 nOldPwdSize, UINT8 * pBufNewPwd,  UINT8 nNewPwdSize, UINT16 nUTI) */
#ifdef AT_DUAL_SIM

		return_val = CFW_SimChangePassword(nFac, uBufOldPwd, nOldPwdSize, uBufNewPwd, nNewPwdSize, pParam->nDLCI, nSim);
#else
		return_val = CFW_SimChangePassword(nFac, uBufOldPwd, nOldPwdSize, uBufNewPwd, nNewPwdSize, pParam->nDLCI);

#endif

		// 7. check the  return value
		if (ERR_SUCCESS != return_val)
		{

			if (ERR_CFW_INVALID_PARAMETER == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}
			else if (ERR_CME_OPERATION_NOT_ALLOWED == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_ALLOWED, pParam->nDLCI);
			}
			else if (ERR_NO_MORE_MEMORY == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_NO_MEMORY, pParam->nDLCI);
			}
			else
			{
				ERROR_RETURN(pResult, ERR_AT_CME_EXE_NOT_SURPORT, pParam->nDLCI); // this error code need to be check
			}
		}

		// AT_20071105_CAOW_B
		if (nFac == CFW_STY_FAC_TYPE_SC)
			gLstStatusRec = 1;
		else if (nFac == CFW_STY_FAC_TYPE_P2)
			gLstStatusRec = 2;

		// AT_20071105_CAOW_E

		// 8. OK ,and send OK to ATM.
		pResult = AT_CreateRC(CMD_FUNC_SUCC_ASYN,
		                      CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);

		AT_Notify2ATM(pResult, pParam->nDLCI);

		if (pResult != NULL)
		{
			AT_FREE(pResult);
			pResult = NULL;
		}

		// 10. return
		return;
	} // <--------AT_CMD_SET-------------

	break;

	case AT_CMD_TEST:
	{
		// AT_SIM_07.09.06_CW_B
#if 0
		OK_RETURN(pResult,
		          "+CPWD: (\"PS\",4),(\"PF\",8),(\"SC\",8),(\"PN\",8),(\"PU\",8),(\"P2\",8),(\"PC\",8),(\"FD\",8)");
#else
		OK_RETURN(pResult, "+CPWD: (\"SC\",8),(\"P2\",8)", pParam->nDLCI);
#endif
		// AT_SIM_07.09.06_CW_E
	}

	default:
	{
		ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_SUPPORTED, pParam->nDLCI);
	}
	} // <----------end of switch cmd  type-------

}

/*
 *******************************************************************************
 *  possible input from	ATM:
 *  AT^cpinc=? -->test,	return OK;
 *	AT^cpinc?  --> read,wait asyncrounous event,response e.g.:
 *			   --> "^SPIC: SIM PIN2"
 *	AT^cpinc   --> exe	-->reponse:  "^SPIC: 3"
 *	AT^cpinc="SC" ---we didn't support this
 *******************************************************************************
*/
void AT_SIM_CmdFunc_CPINC(AT_CMD_PARA *pParam)
{
	// for ATM2NOTIFY pResult,result  code.
	PAT_CMD_RESULT pResult = NULL;

	// for CSW interface return value
	UINT32 return_val;
	UINT8 nUTI = pParam->nDLCI;
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	// from  ATM
	u_gCurrentCmdStamp[nSim] = pParam->uCmdStamp;

	// check  intut ppara,return if NULL

	if (pParam == NULL)
	{
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
	}

	// check  different cmd type
	switch (pParam->iType)
	{

	case AT_CMD_EXE:
	{
		/*********************************************
			*UINT32	CFW_SimGetAuthenticationStatus (     *
			*		UINT16 nUTI);		     *
			**********************************************/
#if SIM_DEBUG
		return_val = AT_GetFreeUTI(CFW_SIM_SRV_ID, &nUTI);

		if (ERR_SUCCESS != return_val)
		{
			ERROR_RETURN(pResult, return_val, pParam->nDLCI);
		}

#else
		nUTI = SIM_UTI;

#endif
#ifdef AT_DUAL_SIM

		return_val = CFW_SimGetAuthenticationStatus(pParam->nDLCI, nSim);
#else
		return_val = CFW_SimGetAuthenticationStatus(pParam->nDLCI);

#endif

		if (ERR_SUCCESS != return_val)
		{
			if (ERR_CFW_INVALID_PARAMETER == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}
			else if (ERR_CME_OPERATION_NOT_ALLOWED == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_ALLOWED, pParam->nDLCI);
			}
			else if (ERR_NO_MORE_MEMORY == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_NO_MEMORY, pParam->nDLCI);
			}
			else
			{
				ERROR_RETURN(pResult, ERR_AT_CME_EXE_NOT_SURPORT, pParam->nDLCI); // this error code need to be check
			}
		}

		AT_security_currentCMD[nSim] = CPINCEXE;

		pResult = AT_CreateRC(CMD_FUNC_SUCC_ASYN,
		                      CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);
		AT_Notify2ATM(pResult, pParam->nDLCI);

		if (pResult != NULL)
		{
			AT_FREE(pResult);
			pResult = NULL;
		}

		return;
	} // AT_CMD_EXE<--------------------

	// AT_SIM_07.09.06_CW_B
#if 0

	case AT_CMD_READ:
	{
		// AT_CMD_READ-------------------->
		/*********************************************
			*UINT32	CFW_SimGetAuthenticationStatus (     *
			*		UINT16 nUTI);		     *
			**********************************************/
#  if SIM_DEBUG
		return_val = AT_GetFreeUTI(CFW_SIM_SRV_ID, &nUTI);

		if (ERR_SUCCESS != return_val)
		{
			ERROR_RETURN(pResult, return_val);
		}

#else
		nUTI = SIM_UTI;

#endif
		return_val = CFW_SimGetAuthenticationStatus(nUTI);

		if (ERR_SUCCESS != return_val)
		{
			if (ERR_CFW_INVALID_PARAMETER == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
			}
			else if (ERR_CME_OPERATION_NOT_ALLOWED == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_ALLOWED, pParam->nDLCI);
			}
			else if (ERR_NO_MORE_MEMORY == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_NO_MEMORY, pParam->nDLCI);
			}
			else
			{
				ERROR_RETURN(pResult, ERR_AT_CME_EXE_NOT_SURPORT, pParam->nDLCI); // this error code need to be check
			}
		}

		AT_security_currentCMD = CPINCREAD;

		pResult = AT_CreateRC(CMD_FUNC_SUCC_ASYN, CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0);
		AT_Notify2ATM(pResult, pParam->nDLCI);

		if (pResult != NULL)
		{
			AT_FREE(pResult);
			pResult = NULL;
		}

		return;
	} // <--------AT_CMD_READ-------------

#endif
	// AT_SIM_07.09.06_CW_E

	case AT_CMD_TEST:
	{
		// AT_SIM_07.09.06_CW_B
#if 0
		OK_NULL_RETURN(pResult, pParam->nDLCI);
#else
		OK_RETURN(pResult, "^CPINC: PIN1&PIN2: (1-3), PUK1&PUK2: (1-10)", pParam->nDLCI);
#endif
		// AT_SIM_07.09.06_CW_E
	}

	default:
	{
		ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_SUPPORTED, pParam->nDLCI);
	}
	} // <----------end of switch cmd  type-------
}

/*
 *******************************************************************************
 *	#define	EV_CFW_SIM_CHANGE_PWD_RSP		 (EV_CFW_SIM_RSP_BASE+8)
 *	#define	EV_CFW_SIM_GET_AUTH_STATUS_RSP		 (EV_CFW_SIM_RSP_BASE+9)
 *	#define	EV_CFW_SIM_ENTER_AUTH_RSP		 (EV_CFW_SIM_RSP_BASE+11)
 *	#define	EV_CFW_SIM_SET_FACILITY_LOCK_RSP	 (EV_CFW_SIM_RSP_BASE+12)
 *	#define	EV_CFW_SIM_GET_FACILITY_LOCK_RSP	 (EV_CFW_SIM_RSP_BASE+13)
 *******************************************************************************
*/
VOID AT_SIM_AsyncEventProcess(COS_EVENT *pEvent)
{
	CFW_EVENT CFWev;

	CFW_EVENT *pcfwEv = &CFWev;
	AT_CosEvent2CfwEvent(pEvent, pcfwEv);
	PAT_CMD_RESULT pResult = NULL;
	UINT8 sStr[10]         = { 0 };

#ifdef AT_DUAL_SIM
	UINT8 nSim = pcfwEv->nFlag;
#endif

	AT_TC(g_sw_AT_SIM, "---- event id = %x,param1 = %x,param3 = %x,nSim = %d", pEvent->nEventId, pEvent->nParam1, pEvent->nParam3, nSim);
	pcfwEv->nUTI = AT_ASYN_GET_DLCI(nSim);
	// add by wangxd for bug 8046

	if (pcfwEv->nParam1 == PINNEEDPUK)
	{
#ifdef AT_DUAL_SIM
		g_Pin1PukStauts[nSim] = 1;
#else
		g_Pin1PukStauts = 1;
#endif
	}
	else
	{
#ifdef AT_DUAL_SIM
		g_Pin1PukStauts[nSim] = 0;
#else
		g_Pin1PukStauts = 0;
#endif
	}
	// add_end by wangxd

	switch (pcfwEv->nEventId)
	{
		// AT_20071114_CAOW_B
		// set ACMM response

	case EV_CFW_SIM_SET_ACMMAX_RSP:
		// check command life cycle

		if (AT_IsAsynCmdAvailable("+CAMM", u_gCurrentCmdStamp[nSim], CFWev.nUTI))
		{
			if (pcfwEv->nType == 0)
			{
				if (pcfwEv->nParam1 == ERR_SUCCESS)
					OK_NULL_RETURN(pResult, pcfwEv->nUTI);
				else
					ERROR_RETURN(pResult, (pcfwEv->nParam1 - ERR_CME_PHONE_FAILURE), pcfwEv->nUTI);

			}
			else
			{
				ERROR_RETURN(pResult, (pcfwEv->nParam1 - ERR_CME_PHONE_FAILURE), pcfwEv->nUTI);
			}
		}

		break;

	case EV_CFW_SIM_GET_ACMMAX_RSP:
		// check command life cycle

		if (AT_IsAsynCmdAvailable("+CAMM", u_gCurrentCmdStamp[nSim], CFWev.nUTI))
		{
			if (pcfwEv->nType == 0)
			{
				// AT_20071126_CAOW_B for bug#7121
#if 0
				AT_Sprintf(sStr, "+CAMM:%lu", pcfwEv->nParam1);
#else
				AT_Sprintf(sStr, "+CAMM:%x", pcfwEv->nParam1);
#endif
				// AT_20071126_CAOW_E
				OK_RETURN(pResult, sStr, pcfwEv->nUTI);
			}
			else
			{
				ERROR_RETURN(pResult, (pcfwEv->nParam1 - ERR_CME_PHONE_FAILURE), pcfwEv->nUTI);
			}
		}

		break;

		// AT_20071114_CAOW_E

	case EV_CFW_SIM_ENTER_AUTH_RSP:
	{
		if (CPIN == AT_security_currentCMD[nSim])
		{
			AT_security_currentCMD[nSim] = 0;

			if (AT_IsAsynCmdAvailable("+CPIN", u_gCurrentCmdStamp[nSim], CFWev.nUTI))
			{
				AT_SIM_CmdFunc_CPIN_Set_AsyncEventProcess(pcfwEv, pResult);
			} // if AT_IsAsynCmdAvailable
		}
		else if (CPIN2 == AT_security_currentCMD[nSim])
		{
			AT_security_currentCMD[nSim] = 0;

			if (AT_IsAsynCmdAvailable("+CPIN2", u_gCurrentCmdStamp[nSim], CFWev.nUTI))
			{
				AT_SIM_CmdFunc_CPIN2_Set_AsyncEventProcess(pcfwEv, pResult);
			} // if AT_IsAsynCmdAvailable
		}

		break;
	}

	/**********************************************
	 * AT+cpin? -->:+CPIN: READY,+CPIN: SIM PIN	 *
	 * AT+cpin2?-->:+CPIN2: SIM PUK2				 *
	 * AT^cpinc -->:^SPIC: 2						 *
	 * AT^cpinc?-->:^cpinc:SIM PUK(not supported) *
	 **********************************************/

	case EV_CFW_SIM_GET_AUTH_STATUS_RSP:
	{

		switch (AT_security_currentCMD[nSim])
		{

		case CPIN:
		{
			AT_security_currentCMD[nSim] = 0;

			if (AT_IsAsynCmdAvailable("+CPIN", u_gCurrentCmdStamp[nSim], CFWev.nUTI))
			{

				AT_SIM_CmdFunc_CPIN1_Read_AsyncEventProcess(pcfwEv, pResult);
			} // end if
		} // <--------------CPIN read-----

		break;

		case CPIN2:
		{
			AT_security_currentCMD[nSim] = 0;

			if (AT_IsAsynCmdAvailable("+CPIN2", u_gCurrentCmdStamp[nSim], CFWev.nUTI))
			{
				AT_SIM_CmdFunc_CPIN2_Read_AsyncEventProcess(pcfwEv, pResult);
			} // end if
		}

		break;

		case CPINCEXE:
		{
			AT_security_currentCMD[nSim] = 0;

			if (AT_IsAsynCmdAvailable("^CPINC", u_gCurrentCmdStamp[nSim], CFWev.nUTI))
			{
				AT_SIM_CmdFunc_CPINC_Exe_AsyncEventProcess(pcfwEv, pResult);
			} // end if
		}

		break;

		// AT_SIM_07.09.06_CW_B
#if 0

		case CPINCREAD:
		{
			AT_security_currentCMD = 0;

			if (AT_IsAsynCmdAvailable("^CPINC", u_gCurrentCmdStamp))
			{
				AT_SIM_CmdFunc_CPINC_Read_AsyncEventProcess(pcfwEv, pResult);
			} // end if
		}

		break;
#endif
		// AT_SIM_07.09.06_CW_E

		default: // this should not happen
		{

			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pcfwEv->nUTI);
			break;
		}
		} // end of switch(AT_security_currentCMD)
	} // ---> EV_CFW_SIM_GET_AUTH_STATUS_RSP

	case EV_CFW_SIM_CHANGE_PWD_RSP:
	{
		if (AT_IsAsynCmdAvailable("+CPWD", u_gCurrentCmdStamp[nSim], CFWev.nUTI))
		{
			AT_SIM_CmdFunc_CPWD_Set_AsyncEventProcess(pcfwEv, pResult);
		} // if AT_IsAsynCmdAvailable
	}

	break;

	case EV_CFW_SIM_SET_FACILITY_LOCK_RSP:
	{
		if (AT_IsAsynCmdAvailable("+CLCK", u_gCurrentCmdStamp[nSim], CFWev.nUTI))
		{
			AT_SIM_CmdFunc_CLCK_Set_AsyncEventProcess(pcfwEv, pResult);
		} // if AT_IsAsynCmdAvailable
	}

	break;

	case EV_CFW_SIM_GET_FACILITY_LOCK_RSP:
	{
		if (AT_IsAsynCmdAvailable("+CLCK", u_gCurrentCmdStamp[nSim], CFWev.nUTI))
		{
			AT_SIM_CmdFunc_CLCK_Read_AsyncEventProcess(pcfwEv, pResult);
		}
	}

	break;
	case EV_CFW_SIM_READ_BINARY_RSP:
	case EV_CFW_SIM_UPDATE_BINARY_RSP:
	case EV_CFW_SIM_READ_RECORD_RSP:
	case EV_CFW_SIM_UPDATE_RECORD_RSP:
	case EV_CFW_SIM_GET_FILE_STATUS_RSP:
	{
		if (AT_IsAsynCmdAvailable("+CRSM", u_gCurrentCmdStamp[nSim], CFWev.nUTI))
		{
			AT_SIM_CmdFunc_CRSM_AsyncEventProcess(pcfwEv, pResult);
		}
		else if (AT_IsAsynCmdAvailable("+CRSML", u_gCurrentCmdStamp[nSim], CFWev.nUTI))
		{
			AT_SIM_CmdFunc_CRSML_AsyncEventProcess(pcfwEv, pResult);
		}
		else// sometimes STNN interrupt CRSM,we still need deal with EV_CFW_SIM_READ_BINARY_RSP
		{
			AT_SIM_CmdFunc_CRSM_AsyncEventProcess(pcfwEv, pResult);
		}
	}
	break;

	case EV_CFW_SIM_RESET_RSP:
	{
		AT_TC(g_sw_AT_SIM, "EV_CFW_SIM_RESET_RSP asyn event nType=%d,nParam1=%d", pcfwEv->nType, pcfwEv->nParam1);
		if (pcfwEv->nType == 0)
		{
			OK_NULL_RETURN(pResult, pcfwEv->nUTI);

		}
		else
		{
			ERROR_RETURN(pResult, CMD_RC_SIMDROP, pcfwEv->nUTI);
		}

	}
	break;
	default:
	{
		break;
	}
	} // end of switch
}

VOID AT_SIM_CmdFunc_CPIN_Set_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult)
{
	UINT32 retErrCode = 50;

#ifdef AT_DUAL_SIM
	UINT8 nSim = pcfwEv->nFlag;
#endif
#if SIM_DEBUG
	AT_TC(g_sw_AT_SIM, "CPIN asyn event nType=%d,nParam1=%d", pcfwEv->nType, pcfwEv->nParam1);
#endif

	if (0 == pcfwEv->nType && 0 == pcfwEv->nParam1)
	{
		// end ok yaoal changed it //&& 0 == pcfwEv->nParam1//
		OK_NULL_RETURN(pResult, pcfwEv->nUTI);
	}
	else
	{
		// end error
#if SIM_DEBUG
		AT_TC(g_sw_AT_SIM, "CPIN AsyncEventProcess g_Pin1PukStauts=%d,g_Pin1ErrorTimes=%d", g_Pin1PukStauts[nSim], g_Pin1ErrorTimes[nSim]);
#endif
		// add by wangxd for bug 8046
#ifdef AT_DUAL_SIM
		if (g_Pin1PukStauts[nSim])
			g_Pin1ErrorTimes[nSim] = 0;
		else
		{
			if ((pcfwEv->nParam1 != ERR_CFW_QUEUE_FULL) || (pcfwEv->nParam1 != ERR_CMS_MEMORY_FAILURE))
				g_Pin1ErrorTimes[nSim]++;

			if (g_Pin1ErrorTimes[nSim] >= 3)
			{
				g_Pin1PukStauts[nSim]  = 1;
				g_Pin1ErrorTimes[nSim] = 0;
			}
		}
#else
		if (g_Pin1PukStauts)
			g_Pin1ErrorTimes = 0;
		else
		{
			if ((pcfwEv->nParam1 != ERR_CFW_QUEUE_FULL) || (pcfwEv->nParam1 != ERR_CMS_MEMORY_FAILURE))
				g_Pin1ErrorTimes++;

			if (g_Pin1ErrorTimes >= 3)
			{
				g_Pin1PukStauts  = 1;
				g_Pin1ErrorTimes = 0;
			}
		}
#endif
		// modify by frank
		retErrCode = AT_SetCmeErrorCode(pcfwEv->nParam1, 1);
		ERROR_RETURN(pResult, retErrCode, pcfwEv->nUTI);
	}
}

VOID AT_SIM_CmdFunc_CPIN2_Set_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult)
{
	UINT32 retErrCode = 50;

#ifdef AT_DUAL_SIM
	//  UINT8 nSim = pcfwEv->nFlag;
#endif

#if SIM_DEBUG
	AT_TC(g_sw_AT_SIM, "CPIN asyn event nType=%d,nParam1=%d", pcfwEv->nType, pcfwEv->nParam1);
#endif

	if (0 == pcfwEv->nType && 0 == pcfwEv->nParam1)
	{
		// end ok yaoal changed it //&& 0 == pcfwEv->nParam1//
		OK_NULL_RETURN(pResult, pcfwEv->nUTI);
	}
	else
	{
		// end error
		// modify by frank
		retErrCode = AT_SetCmeErrorCode(pcfwEv->nParam1, 1);
		ERROR_RETURN(pResult, retErrCode, pcfwEv->nUTI);

	}
}

/*************************************************************
* in 27007,this	command	is not included
* so i do the same as at55 does
* if nType == 0, i will	return OK,no matter nParam1'value is
*************************************************************/
VOID AT_SIM_CmdFunc_CPIN2_Read_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult)
{
	UINT32 retErrCode = 50;

#ifdef AT_DUAL_SIM
	//  UINT8 nSim = pcfwEv->nFlag;
#endif

	if (0 == pcfwEv->nType)
	{
		// end ok
		// AT_20071217_CAOW_B for bug#6950,7050,7120,7184
#if 0
		if (CFW_STY_AUTH_SIMPIN2 == pcfwEv->nParam1)
		{
			OK_RETURN(pResult, "+CPIN2:SIM PIN2", pcfwEv->nUTI);
		}
		else if (CFW_STY_AUTH_SIMPUK2 == pcfwEv->nParam1)
		{
			OK_RETURN(pResult, "+CPIN2:SIM PUK2", pcfwEv->nUTI);
		}
		else if (CFW_STY_AUTH_NOSIM == pcfwEv->nParam1)
		{
			OK_RETURN(pResult, "+CPIN2:NO SIM", pcfwEv->nUTI);
		}
		else if (CFW_STY_AUTH_PIN2BLOCK == pcfwEv->nParam1)
		{
			OK_RETURN(pResult, "+CPIN2:PIN2 BLOCK", pcfwEv->nUTI);
		}
		else
		{
			// is this return right? i need  to check.!
			OK_RETURN(pResult, "+CPIN2: READY", pcfwEv->nUTI);
		}

#else
		if (CFW_STY_AUTH_NOSIM == pcfwEv->nParam1)
			OK_RETURN(pResult, "+CPIN2:NO SIM", pcfwEv->nUTI);
		else if ((LOUINT16(pcfwEv->nParam2) & 0xF000) >> 12 == 0)
			OK_RETURN(pResult, "+CPIN2:PIN2 BLOCK", pcfwEv->nUTI);
		else if ((LOUINT16(pcfwEv->nParam2) & 0xF00) >> 8 == 0)
			OK_RETURN(pResult, "+CPIN2:SIM PUK2", pcfwEv->nUTI);
		else if ((LOUINT16(pcfwEv->nParam2) & 0xF00) >> 8 == 3)
			OK_RETURN(pResult, "+CPIN2: READY", pcfwEv->nUTI);
		else if (((LOUINT16(pcfwEv->nParam2) & 0xF00) >> 8 == 1) || ((LOUINT16(pcfwEv->nParam2) & 0xF00) >> 8 == 2))
			OK_RETURN(pResult, "+CPIN2:SIM PIN2", pcfwEv->nUTI);

#endif
		// AT_20071217_CAOW_E
	}
	else
	{
		// end error
		// modify by frank
		retErrCode = AT_SetCmeErrorCode(pcfwEv->nParam1, 1);
		ERROR_RETURN(pResult, retErrCode, pcfwEv->nUTI);
	}
}

/*************************************************************
*	OK or FAIL
*************************************************************/
VOID AT_SIM_CmdFunc_CPWD_Set_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult)
{
	UINT32 retErrCode = 50;

#ifdef AT_DUAL_SIM
	//  UINT8 nSim = pcfwEv->nFlag;
#endif

	if (0 == pcfwEv->nType)
	{
		// end ok
		OK_NULL_RETURN(pResult, pcfwEv->nUTI);
	}
	else if (0xF0 == pcfwEv->nType)
	{
		// end error
		// modify by frank
		retErrCode = AT_SetCmeErrorCode(pcfwEv->nParam1, 1);
		ERROR_RETURN(pResult, retErrCode, pcfwEv->nUTI);
	}
	else
	{
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pcfwEv->nUTI);
	}
}

/*************************************************************
*	OK or FAIL
*************************************************************/
VOID AT_SIM_CmdFunc_CLCK_Set_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult)
{
	UINT32 retErrCode = 50;

#ifdef AT_DUAL_SIM
	UINT8 nSim = pcfwEv->nFlag;
#endif
	if (0 == pcfwEv->nType)
	{
		// end ok
#ifdef AT_DUAL_SIM
#ifdef __AT_MOD_PBK__
		AT_FDN_SetStatus(nSim);
#endif
#endif
		OK_NULL_RETURN(pResult, pcfwEv->nUTI);
	}
	else if (0xF0 == pcfwEv->nType)
	{
		// end error
		// modify by frank
		retErrCode = AT_SetCmeErrorCode(pcfwEv->nParam1, 1);
		if(ERR_AT_CME_SIM_FAILURE == retErrCode)
		{
			if(CFW_STY_FAC_TYPE_FD == pcfwEv->nParam2)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_SIM_PUK2_REQUIRED, pcfwEv->nUTI);
			}
		}
		else
			ERROR_RETURN(pResult, retErrCode, pcfwEv->nUTI);
	}
	else
	{
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pcfwEv->nUTI);
	}
}

VOID AT_SIM_CmdFunc_CLCK_Read_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult)
{
	UINT32 retErrCode = 50;

#ifdef AT_DUAL_SIM
	//  UINT8 nSim = pcfwEv->nFlag;
#endif

	if (0 == pcfwEv->nType)
	{
		// end ok

		// AT_SIM_07.09.06_CW_B
		AT_Sprintf(cpincexeasynSTR, "+CLCK:%d", LOUINT8(pcfwEv->nParam1));

		// AT_SIM_07.09.06_CW_E

		OK_RETURN(pResult, cpincexeasynSTR, pcfwEv->nUTI);
	}
	else if (0xF0 == pcfwEv->nType)
	{
		// end error
		// modify by frank
		retErrCode = AT_SetCmeErrorCode(pcfwEv->nParam1, 1);
		ERROR_RETURN(pResult, retErrCode, pcfwEv->nUTI);
	}
	else
	{
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pcfwEv->nUTI);
	}
}

/*************************************************************
* in 27007,this	command	is not included
* so i do the same as at55 does
* if nType == 0, i will	return OK,no matter nParam1'value is
*************************************************************/
VOID AT_SIM_CmdFunc_CPINC_Read_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult)
{
	UINT32 retErrCode = 50;

#ifdef AT_DUAL_SIM
	//  UINT8 nSim = pcfwEv->nFlag;
#endif

	if (0 == pcfwEv->nType)
	{
		// end ok
		// check value if in a valued range.
		switch (pcfwEv->nParam1)
		{

		case CFW_STY_AUTH_READY:

		case CFW_STY_AUTH_PIN1_READY:

		case CFW_STY_AUTH_SIMPIN:

		case CFW_STY_AUTH_SIMPUK:

		case CFW_STY_AUTH_SIMPIN2:

		case CFW_STY_AUTH_SIMPUK2:

		case CFW_STY_AUTH_PHONE_TO_SIMPIN:

		case CFW_STY_AUTH_NETWORKPUK:

		case CFW_STY_AUTH_PIN1_DISABLE:
			break;

		default:
			OK_NULL_RETURN(pResult, pcfwEv->nUTI);
		}

		OK_RETURN(pResult, cpinasynSTR[pcfwEv->nParam1], pcfwEv->nUTI);

	}
	else
	{
		// end error
		// modify by frank
		retErrCode = AT_SetCmeErrorCode(pcfwEv->nParam1, 1);
		ERROR_RETURN(pResult, retErrCode, pcfwEv->nUTI);
	}
}
VOID AT_SIM_CmdFunc_CRSM_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult)
{
	//UINT8 cPin1Param1 = pcfwEv->nParam1;

	// const char *str = pcfwEv->nParam1;
	// AT_TC(g_sw_SIM, "In CRSM Param1Len  =%d,pcfwEv->nParam1=%d", Param1Len,pcfwEv->nParam1);
#ifdef AT_DUAL_SIM
	UINT8 nSim = pcfwEv->nFlag;
#endif

	// return event type success:
	UINT8 nRetString[530] = { 0x00, };

	if (pcfwEv->nType == 0)
	{
		if ((pcfwEv->nEventId == EV_CFW_SIM_UPDATE_RECORD_RSP) || (pcfwEv->nEventId == EV_CFW_SIM_UPDATE_BINARY_RSP))
		{
			strcpy(nRetString, "+CRSM:144,0");
		}
		else if(pcfwEv->nEventId == EV_CFW_SIM_GET_FILE_STATUS_RSP)
		{
			strcpy(nRetString, "+CRSM:144,0,");
			UINT8 nAsciiRetString[512] = { 0x00, };
			SUL_GsmBcdToAsciiEx((UINT8 *)(pcfwEv->nParam1), pcfwEv->nParam2, nAsciiRetString);
			if(nAsciiRetString[0] != 0x62)
			{
				SUL_GsmBcdToAsciiEx((UINT8 *)(pcfwEv->nParam1), gCrsmCommandDataLen[nSim], nAsciiRetString);
			}
			strcat(nRetString, nAsciiRetString);
		}
		else
		{
			strcpy(nRetString, "+CRSM:144,0,");
			UINT8 nAsciiRetString[512] = { 0x00, };
			UINT8 nGetData[512] = { 0x00, };

			UINT8  *in  = NULL;
			UINT8   nSwitchData = 0x00;
			UINT8   i = 0x00;
			AT_MemCpy(nGetData, (UINT8 *)(pcfwEv->nParam1), gCrsmCommandDataLen[nSim]);
			in = (UINT8 *)nGetData;

			for (i = 0x00; i < gCrsmCommandDataLen[nSim]; i++)
			{
				nSwitchData = (in[i] >> 4) + (in[i] << 4);
				in[i]       = nSwitchData;
			}
			// SUL_GsmBcdToAscii((UINT8*)(pcfwEv->nParam1),gCrsmCommandDataLen,nAsciiRetString);
			SUL_GsmBcdToAsciiEx((UINT8 *)nGetData, gCrsmCommandDataLen[nSim], nAsciiRetString);

			// SUL_GsmBcdToAscii((UINT8)(pcfwEv->nParam1),(UINT8)pcfwEv->nParam2,nAsciiRetString);

			strcat(nRetString, nAsciiRetString);
		}
		OK_RETURN(pResult, nRetString, pcfwEv->nUTI);

	}
	else if (pcfwEv->nType == 0xf0)
	{
		OK_RETURN(pResult, "+CRSM:111,0", pcfwEv->nUTI);
	}

	// return error:
	// ERROR_RETURN(pResult, (pcfwEv->nParam1 - ERR_CME_PHONE_FAILURE));

}

extern CFW_SIMSTATUS g_cfw_sim_status[];
typedef struct _CFW_UsimEfStatus
{
	UINT8   efStructure;   // 1:Transparent ; 2: Linear Fixed ; 6: Cyclic
	INT16   fileId;
	INT16   fileSize;
	UINT8   recordLength;
	UINT8   numberOfRecords;
} CFW_UsimEfStatus;

extern VOID CFW_UsimDecodeEFFcp (UINT8 *RespData, CFW_UsimEfStatus *pSimEfStatus);
VOID AT_SIM_CmdFunc_CRSML_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult)
{

#ifdef AT_DUAL_SIM
	UINT8 nSim = pcfwEv->nFlag;
#endif
	UINT8 nRetString[530] = { 0x00, };
	if(EV_CFW_SIM_GET_FILE_STATUS_RSP == pcfwEv->nEventId)
	{
		if (pcfwEv->nType == 0)
		{
			UINT8 *p = (UINT8 *)pcfwEv->nParam1;
			UINT8 nSwitchHLData = 0x00;
			UINT32 i;
			for(i = 0; i < 256; i++)
			{
				nSwitchHLData = ((p[i] & 0x0f) << 4) + (p[i] >> 4);
				p[i] = nSwitchHLData;
			}

			if(g_cfw_sim_status[nSim].UsimFlag == FALSE)
			{
				gCrsml[nSim].nLen =  p[14];
			}
			else
			{
				CFW_UsimEfStatus gUsim;
				CFW_UsimDecodeEFFcp((UINT8 *)pcfwEv->nParam1,  &gUsim);
				gCrsml[nSim].nLen = gUsim.recordLength;
			}


			AT_TC(g_sw_AT_SIM, TSTXT("gUsim.recordLength %d\n"), gCrsml[nSim].nLen);

			UINT32 nRet = CFW_SimReadRecordWithLen(ATGetStackSimFileID(gCrsml[nSim].nFileID, nSim), gCrsml[nSim].nCurrentIndex, gCrsml[nSim].nLen, pcfwEv->nUTI, nSim);
			if (ERR_SUCCESS != nRet)
			{
				AT_TC(g_sw_AT_SIM, "nRet = 0x%x", nRet);

				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pcfwEv->nUTI);
				return;
			}
		}
		else
		{
			OK_RETURN(pResult, "+CRSM:111,0", pcfwEv->nUTI);
		}
	}
	else if(EV_CFW_SIM_READ_RECORD_RSP == pcfwEv->nEventId)
	{
		if (pcfwEv->nType == 0)
		{

			strcpy(nRetString, "+CRSM:144,0,");
			UINT8 nAsciiRetString[512] = { 0x00, };

			SUL_GsmBcdToAsciiEx((UINT8 *)(pcfwEv->nParam1), pcfwEv->nParam2, nAsciiRetString);

			strcat(nRetString, nAsciiRetString);

			if(gCrsml[nSim].nCurrentIndex < (gCrsml[nSim].nStartIndex + gCrsml[nSim].nCount))
			{
				gCrsml[nSim].nCurrentIndex++;
#ifdef AT_DUAL_SIM
				AT_SIMID_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, nRetString, AT_StrLen(nRetString),  pcfwEv->nUTI);
#else
				AT_SIMID_Result_OK(CMD_FUNC_CONTINUE, CMD_RC_OK, 0, nRetString, AT_StrLen(nRetString),  pcfwEv->nUTI);
#endif
			}
			else
			{
				OK_RETURN(pResult, nRetString, pcfwEv->nUTI);
				return;

			}

			UINT32 nRet = CFW_SimReadRecordWithLen(ATGetStackSimFileID(gCrsml[nSim].nFileID, nSim), gCrsml[nSim].nCurrentIndex, gCrsml[nSim].nLen, pcfwEv->nUTI, nSim);

			if (ERR_SUCCESS != nRet)
			{
				AT_TC(g_sw_AT_SIM, "nRet = 0x%x", nRet);

				ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pcfwEv->nUTI);
				return;
			}

			OK_ASYN_RETURN(pResult, pcfwEv->nUTI);

		}
		else if (pcfwEv->nType == 0xf0)
		{
			OK_RETURN(pResult, "+CRSM:111,0", pcfwEv->nUTI);
		}
	}
}

/***********************************************************************

This function is used to tackle bug8124

When receive async event about CPIN1, SIM modle will call this function

This function is added by wangxd

************************************************************************/
VOID AT_SIM_CmdFunc_CPIN1_Read_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult)
{
	UINT32 retErrCode = 50;
	UINT8 cPin1Param1 = pcfwEv->nParam1;

#ifdef AT_DUAL_SIM
	//  UINT8 nSim = pcfwEv->nFlag;
#endif

	// return event type success:

	if (pcfwEv->nType == 0)
	{

		// check patrameters:   (ate module should check parameters!)
		if (!((0 <= pcfwEv->nParam1) && (22 >= pcfwEv->nParam1)))
			ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pcfwEv->nUTI);

		if ((cPin1Param1 == CFW_STY_AUTH_PIN1_DISABLE) || (cPin1Param1 == CFW_STY_AUTH_PIN1_READY))
			cPin1Param1 = 0;

		OK_RETURN(pResult, cpinasynSTR[cPin1Param1], pcfwEv->nUTI);

	}

	// event other type:
	if ((pcfwEv->nType == 0xf0) && (AT_ModuleGetInitResult() == AT_MODULE_INIT_NO_SIM))
	{
		cPin1Param1 = 17;
		OK_RETURN(pResult, cpinasynSTR[cPin1Param1], pcfwEv->nUTI);
	}

	// modify by frank
	retErrCode = AT_SetCmeErrorCode(pcfwEv->nParam1, 1);
	ERROR_RETURN(pResult, retErrCode, pcfwEv->nUTI);

}

/*************************************************************************************
This function is used to tackle bug8124 and bug8310

When receive async event about CPINC, SIM event process modle will call this function

This function is added by wangxd

*************************************************************************************/
VOID AT_SIM_CmdFunc_CPINC_Exe_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult)
{
	UINT32 retErrCode    = 50;
	UINT8 cPincTraceInfo = 0;
	UINT8 cPincParam1    = pcfwEv->nParam1;

#ifdef AT_DUAL_SIM
	//  UINT8 nSim = pcfwEv->nFlag;
#endif

#if SIM_DEBUG
	AT_TC(g_sw_AT_SIM, "pcfwEv->nType == %d, pcfwEv->nParam1 == 0x%x", pcfwEv->nType, pcfwEv->nParam1);
	AT_TC(g_sw_AT_SIM, "gLstStatusRec == %d", gLstStatusRec);
	AT_TC(g_sw_AT_SIM, "CPINC_Event pcfwEv->nParam1 = %d", pcfwEv->nParam1);
#endif

	// return event type success:

	if (pcfwEv->nType == 0)
	{

		AT_Sprintf(cpincexeasynSTR, "^CPINC:%d,%d,%d,%d", LOUINT16(pcfwEv->nParam2) & 0x0F, (LOUINT16(pcfwEv->nParam2) & 0xF0) >> 4,
		           (LOUINT16(pcfwEv->nParam2) & 0xF00) >> 8, (LOUINT16(pcfwEv->nParam2) & 0xF000) >> 12);

#if 0
		// switch return event auth type:
		switch (cPincParam1)
		{

		case CFW_STY_AUTH_READY:

		case CFW_STY_AUTH_PIN1_READY:

		case CFW_STY_AUTH_SIMPIN:
		{
			// PIN1 count:
			cPincTraceInfo = LOUINT16(pcfwEv->nParam2) & 0x0F;
			AT_TC(g_sw_AT_SIM, "Event inter READ,PIN1_READ,SIMPIN;  PIN1_Count = %d", cPincTraceInfo);

			AT_Sprintf(cpincexeasynSTR, "^CPINC:%d", LOUINT16(pcfwEv->nParam2) & 0x0F);
			break;
		}

		case CFW_STY_AUTH_SIMPUK:
		{
			// PUK1 count:
			cPincTraceInfo = (LOUINT16(pcfwEv->nParam2) & 0xF0) >> 4;
			AT_TC(g_sw_AT_SIM, "Event inter SIMPUK; PUK1_Count = %d", cPincTraceInfo);

			AT_Sprintf(cpincexeasynSTR, "^CPINC:%d", (LOUINT16(pcfwEv->nParam2) & 0xF0) >> 4);
			break;
		}

		case CFW_STY_AUTH_SIMPIN2:
		{
			// PIN2 count:
			cPincTraceInfo = (LOUINT16(pcfwEv->nParam2) & 0xF00) >> 8;
			AT_TC(g_sw_AT_SIM, "Event inter SIMPIN2; PIN2_Count = %d", cPincTraceInfo);

			AT_Sprintf(cpincexeasynSTR, "^CPINC:%d", (LOUINT16(pcfwEv->nParam2) & 0xF00) >> 8);
			break;
		}

		case CFW_STY_AUTH_SIMPUK2:
		{
			// PUK2 count:
			cPincTraceInfo = (LOUINT16(pcfwEv->nParam2) & 0xF000) >> 12;
			AT_TC(g_sw_AT_SIM, "Event inter SIMPUK2; PUK2_Count = %d", cPincTraceInfo);

			AT_Sprintf(cpincexeasynSTR, "^CPINC:%d", (LOUINT16(pcfwEv->nParam2) & 0xF000) >> 12);
			break;
		}

		// when input wrong password beyond three times or input wrong PUK beyond ten times,
		// and when the phone is waiting for the service provide personalization such as PIN1,PIN2,PUK1,PUK2 etc.,
		// then the program will enter default section:

		default:
		{

#if SIM_DEBUG

			cPincTraceInfo = LOUINT16(pcfwEv->nParam2) & 0x0F;
			AT_TC(g_sw_AT_SIM, "Event inter Default; PIN1_Count = %d", cPincTraceInfo);

			cPincTraceInfo = 0;
			cPincTraceInfo = (LOUINT16(pcfwEv->nParam2) & 0xF0) >> 4;
			AT_TC(g_sw_AT_SIM, "Event inter Default; PUK1_Count = %d", cPincTraceInfo);

			cPincTraceInfo = 0;
			cPincTraceInfo = (LOUINT16(pcfwEv->nParam2) & 0xF00) >> 8;
			AT_TC(g_sw_AT_SIM, "Event inter Default; PIN2_Count = %d", cPincTraceInfo);

			cPincTraceInfo = 0;
			cPincTraceInfo = (LOUINT16(pcfwEv->nParam2) & 0xF000) >> 12;
			AT_TC(g_sw_AT_SIM, "Event inter Default; PUK2_Count = %d", cPincTraceInfo);

			AT_TC(g_sw_AT_SIM, "Event inter Default; gLstStatusRec = %d", gLstStatusRec);
#endif

			// PUK1 count:

			if ((gLstStatusRec == 1) && ((LOUINT16(pcfwEv->nParam2) & 0x0F) == 0))
			{
				AT_Sprintf(cpincexeasynSTR, "^CPINC:%d", (LOUINT16(pcfwEv->nParam2) & 0xF0) >> 4);
				gLstStatusRec = 0;
				break;
			}

			// PIN1 count:
			if ((gLstStatusRec == 1) && ((LOUINT16(pcfwEv->nParam2) & 0x0F) != 0))
			{
				AT_Sprintf(cpincexeasynSTR, "^CPINC:%d", LOUINT16(pcfwEv->nParam2) & 0x0F);
				gLstStatusRec = 0;
				break;
			}

			// PUK2 count:
			if ((gLstStatusRec == 2) && ((LOUINT16(pcfwEv->nParam2) & 0xF00) >> 8 == 0))
			{
				AT_Sprintf(cpincexeasynSTR, "^CPINC:%d", (LOUINT16(pcfwEv->nParam2) & 0xF000) >> 12);
				gLstStatusRec = 0;
				break;
			}

			// PIN2 count:
			if ((gLstStatusRec == 2) && ((LOUINT16(pcfwEv->nParam2) & 0xF00) >> 8 != 0))
			{
				AT_Sprintf(cpincexeasynSTR, "^CPINC:%d", (LOUINT16(pcfwEv->nParam2) & 0xF00) >> 8);
				gLstStatusRec = 0;
				break;
			}

			// :)
			// PIN1 count:
			if (!gLstStatusRec)
			{
				AT_Sprintf(cpincexeasynSTR, "^CPINC:%d", LOUINT16(pcfwEv->nParam2) & 0x0F);
				break;
			}

			// general count:
			gLstStatusRec = 0;

			OK_RETURN(pResult, "^CPINC:3", pcfwEv->nUTI);

			break;

		} // end default...
		}
#endif

		pResult = AT_CreateRC(CMD_FUNC_SUCC,
		                      CMD_RC_OK,
		                      CMD_ERROR_CODE_OK,
		                      CMD_ERROR_CODE_TYPE_CME, 0, cpincexeasynSTR, strlen(cpincexeasynSTR), pcfwEv->nUTI);

		AT_Notify2ATM(pResult, pcfwEv->nUTI);
		memset(cpincexeasynSTR, 0, 20);

		if (pResult != NULL)
		{
			AT_FREE(pResult);
			pResult = NULL;
		}

	}
	else
	{
		// modify by frank
		retErrCode = AT_SetCmeErrorCode(pcfwEv->nParam1, 1);
		ERROR_RETURN(pResult, retErrCode, pcfwEv->nUTI);
	}

}

#ifdef AT_DUAL_SIM
VOID AT_SIMID_Result_OK(UINT32 uReturnValue,
                        UINT32 uResultCode, UINT8 nDelayTime, UINT8 *pBuffer, UINT16 nDataSize, UINT8 nUTI)
{
	PAT_CMD_RESULT pResult = NULL;

	// �������
	pResult = AT_CreateRC(uReturnValue,
	                      uResultCode, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, nDelayTime, pBuffer, nDataSize, nUTI);

	AT_Notify2ATM(pResult, nUTI);

	if (pResult != NULL)
	{
		AT_FREE(pResult);
		pResult = NULL;
	}

	return;
}
VOID AT_SIMID_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nUTI)
{
	PAT_CMD_RESULT pResult = NULL;

	// �������
	pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, uErrorCode, nErrorType, 0, 0, 0, nUTI);

	AT_Notify2ATM(pResult, nUTI);

	if (pResult != NULL)
	{
		AT_FREE(pResult);
		pResult = NULL;
	}

	return;
}
VOID AT_SIM_CmdFunc_SETSIM(AT_CMD_PARA *pParam)
{
	UINT8 paraCount = 0;
	//UINT32 nResult  = ERR_SUCCESS;
	INT32 iRet      = 0;

	UINT8 nTypSize = 0;
	UINT8 nIndex   = 0;
	UINT8 nSim     = 0;

	AT_TC(g_sw_GPRS, "AT+SIM:CmdFunc_SETSIM ");

	if (pParam == NULL)
	{
		AT_TC(g_sw_GPRS, "AT+SIM:pParam == NULL !");
		AT_SIMID_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
		return;
	}
	switch (pParam->iType)
	{
	case AT_CMD_SET:
		iRet = AT_Util_GetParaCount(pParam->pPara, &paraCount);
		if ((iRet != ERR_SUCCESS) || (paraCount != 1))
		{
			AT_TC(g_sw_GPRS, "AT+SIM:paraCount: %d", paraCount);
			AT_SIMID_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
			return;
		}

		nTypSize = sizeof(nSim);
		iRet     = AT_Util_GetParaWithRule(pParam->pPara, nIndex, AT_UTIL_PARA_TYPE_UINT8, &nSim, &nTypSize);
		if (iRet != ERR_SUCCESS)
		{
			AT_TC(g_sw_GPRS, "AT+SIM:iRet : %d !", iRet);
			AT_SIMID_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
			return;
		}
		if (nSim < 5)
		{
			gAtSimID = nSim;
			AT_TC(g_sw_GPRS, "From SIM:%d", nSim);
		}
		else
		{
			AT_TC(g_sw_GPRS, "AT+SIM:iRet : %d !", iRet);
			AT_SIMID_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
			return;
		}
		AT_SIMID_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
		break;

	case AT_CMD_READ:
		break;

	case AT_CMD_TEST:
		break;

	default:
		AT_SIMID_Result_Err(ERR_AT_CME_OPERATION_NOT_ALLOWED, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
		break;
	}

	return;
}


/*
 *******************************************************************************
 *  possible input from	ATM:
 *  AT^creset=? -->test,	return OK;
 *	AT^creset   --> exe	-->reponse:  "OK" && "+CME ERROR:11"
 *******************************************************************************
*/
void AT_SIM_CmdFunc_CRESET(AT_CMD_PARA *pParam)
{
	// for ATM2NOTIFY pResult,result  code.
	PAT_CMD_RESULT pResult = NULL;

	// for CSW interface return value
	UINT32 return_val;
	//UINT8 nUTI = pParam->nDLCI;
#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	// from  ATM
	u_gCurrentCmdStamp[nSim] = pParam->uCmdStamp;

	// check  intut para,return if NULL

	if (pParam == NULL)
	{
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
	}

	// check  different cmd type
	switch (pParam->iType)
	{

	case AT_CMD_EXE:


#ifdef AT_DUAL_SIM

		return_val = CFW_SimReset(pParam->nDLCI, nSim);
#else
		return_val = CFW_SimReset(pParam->nDLCI);

#endif

		if (ERR_SUCCESS != return_val)
		{
			if (ERR_NO_MORE_MEMORY == return_val)
			{
				ERROR_RETURN(pResult, ERR_AT_CME_NO_MEMORY, pParam->nDLCI);
			}
			else
			{
				ERROR_RETURN(pResult, ERR_AT_CME_EXE_NOT_SURPORT, pParam->nDLCI);
			}
		}

		pResult = AT_CreateRC(CMD_FUNC_SUCC_ASYN,
		                      CMD_RC_OK, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, 0, NULL, 0, pParam->nDLCI);
		AT_Notify2ATM(pResult, pParam->nDLCI);

		if (pResult != NULL)
		{
			AT_FREE(pResult);
			pResult = NULL;
		}
		break;

	case AT_CMD_TEST:
	{

#if 0
		OK_NULL_RETURN(pResult, pParam->nDLCI);
#else
		OK_RETURN(pResult, "^CRESET: ", pParam->nDLCI);
#endif

	}

	default:
	{
		ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_SUPPORTED, pParam->nDLCI);
	}
	}
}


/*
 ========================================================================================================
 *  possible input from	ATM:
 *  AT+CSST=? -->test,	return OK;
 *	AT+CSST=n   --> set	-->reponse:  "service xxx allocated ( not allocated ) and activated(not activated)"
 ========================================================================================================

*/

const UINT8 gSSTServicesName[][50] =
{
	"CHV1disablefunction",
	"AbbreviatedDiallingNumbers(ADN)",
	"FixedDiallingNumbers(FDN)",
	"ShortMessageStorage(SMS)",
	"AdviceofCharge(AoC)",
	"CapabilityConfigurationParameters(CCP)",
	"PLMNselector",
	"RFU",
	"MSISDN",
	"Extension1",
	"Extension2",
	"SMSParameters",
	"LastNumberDialled(LND)",
	"CellBroadcastMessageIdentifier",
	"GroupIdentifierLevel1",
	"GroupIdentifierLevel2",
	"ServiceProviderName",
	"ServiceDiallingNumbers(SDN)",
	"Extension3",
	"RFU",
	"VGCSGroupIdentifierList(EFVGCSandEFVGCSS)",
	"VBSGroupIdentifierList(EFVBSandEFVBSS)",
	"enhancedMultiLevelPrecedenceandPreemptionService",
	"AutomaticAnswerforeMLPP",
	"DatadownloadviaSMSCB",
	"DatadownloadviaSMSPP",
	"Menuselection",
	"Callcontrol",
	"ProactiveSIM",
	"CellBroadcastMessageIdentifierRanges",
	"BarredDiallingNumbers(BDN)",
	"Extension4",
	"DepersonalizationControlKeys",
	"CooperativeNetworkList",
	"ShortMessageStatusReports",
	"Network'sindicationofalertingintheMS",
	"MobileOriginatedShortMessagecontrolbySIM",
	"GPRS",
	"Image(IMG)",
	"SoLSA(SupportofLocalServiceArea)",
	"USSDstringdataobjectsupportedinCallControl",
	"RUNATCOMMANDcommand",
	"UsercontrolledPLMNSelectorwithAccessTechnology",
	"OperatorcontrolledPLMNSelectorwithAccessTechnology",
	"HPLMNSelectorwithAccessTechnology",
	"CPBCCHInformation",
	"InvestigationScan",
	"ExtendedCapabilityConfigurationParameters",
	"MExE",
	"RPLMNlastusedAccessTechnology",

};

void AT_SIM_CmdFunc_CSST(AT_CMD_PARA *pParam)
{
	// for ATM2NOTIFY pResult,result  code.
	PAT_CMD_RESULT pResult = NULL;

	// for CSW interface return value
	UINT32 return_val;

#ifdef AT_DUAL_SIM
	UINT8 nSim = AT_SIM_ID(pParam->nDLCI);
#endif

	// from  ATM
	u_gCurrentCmdStamp[nSim] = pParam->uCmdStamp;

	// check  intut para,return if NULL
	if (pParam == NULL)
	{
		ERROR_RETURN(pResult, ERR_AT_CME_PARAM_INVALID, pParam->nDLCI);
	}

	// check  different cmd type
	switch (pParam->iType)
	{
	case AT_CMD_SET:
	{
		UINT8 paraCount = 0x00;
		UINT8 nService = 0x00;

		UINT8 nSize = 0x01;

		INT32 iRet = AT_Util_GetParaCount(pParam->pPara, &paraCount);
		if ((iRet != ERR_SUCCESS) || (paraCount != 1))
		{
			AT_TC(g_sw_GPRS, "AT+CSST:paraCount: %d", paraCount);
			AT_SIMID_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
			return;
		}

		iRet	 = AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &nService, &nSize);
		if (iRet != ERR_SUCCESS)
		{
			AT_TC(g_sw_GPRS, "AT+CSST:iRet : %d !", iRet);
			AT_SIMID_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);
			return;
		}

#ifdef AT_DUAL_SIM
		return_val = CFW_GetSSTStatus(nService, nSim);
#else
		return_val = CFW_GetSSTStatus(nService);
#endif
		UINT8 nOutString[300] = {0x00,};
		AT_Sprintf(nOutString, "Services %s ", gSSTServicesName[nService - 1]);

		if(return_val & 0x01)
			SUL_StrCat(nOutString, " < allocated > ");
		else
			SUL_StrCat(nOutString, " <  not allocated > ");

		if(return_val & 0x02)
			SUL_StrCat(nOutString, " <  activated > ");
		else
			SUL_StrCat(nOutString, " <  not activated > ");


		OK_RETURN(pResult, nOutString, pParam->nDLCI);
	}
	break;
	case AT_CMD_TEST:
	{

#if 0
		OK_NULL_RETURN(pResult, pParam->nDLCI);
#else
		OK_RETURN(pResult, "+CSST: ", pParam->nDLCI);
#endif

	}
	default:
	{
		ERROR_RETURN(pResult, ERR_AT_CME_OPERATION_NOT_SUPPORTED, pParam->nDLCI);
	}
	}
}

#endif

