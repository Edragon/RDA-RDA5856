/*********************************************************
 *
 * File Name
 *	at_cmd_sim.h
 * Author
 * 	Felix
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 *
 *********************************************************/

#ifndef __AT_CMD_SIM_H__
#define __AT_CMD_SIM_H__

#include "csw.h"
#include "at_module.h"
#include "at_common.h"
#include "at_utility.h"
#include "at_define.h"


#ifdef ONLY_AT_SINGLE_SIM
#define AT_BACKSIMID(a)
#define AT_SIM_ID(x) 0
#define AT_ASYN_GET_DLCI(x) ((x == 0)?1:5)

#else
// #define AT_BACKSIMID(a) AT_SendToSIMID(a)
#define AT_BACKSIMID(a)
// #define AT_SIM_ID gAtSimID
#define AT_SIM_ID(x) ((x <= 4)?0:1)        // x is uti or channel id
#define AT_ASYN_GET_DLCI(x) ((x == 0)?1:5) // x is sim id
#endif



// AT_20071114_CAOW_B
VOID AT_SIM_CmdFunc_CRSM(AT_CMD_PARA *pParam);
VOID AT_SIM_CmdFunc_CAMM(AT_CMD_PARA *pParam);
// AT_20071114_CAOW_E

//Add by XP 201311129
VOID AT_SIM_CmdFunc_CRSML(AT_CMD_PARA *pParam);
VOID AT_SIM_CmdFunc_CRESET(AT_CMD_PARA *pParam);
VOID AT_SIM_CmdFunc_CPIN(AT_CMD_PARA *pParam);
VOID AT_SIM_CmdFunc_CPIN2(AT_CMD_PARA *pParam);
VOID AT_SIM_CmdFunc_CPINC(AT_CMD_PARA *pParam);
VOID AT_SIM_CmdFunc_CLCK(AT_CMD_PARA *pParam);
VOID AT_SIM_CmdFunc_CPWD(AT_CMD_PARA *pParam);
VOID AT_SIM_AsyncEventProcess(COS_EVENT *pEvent);
VOID AT_SIM_CmdFunc_CSST(AT_CMD_PARA *pParam);

VOID AT_SIM_CmdFunc_CPIN_Set_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult);

// void AT_SIM_CmdFunc_CPIN_Read_AsyncEventProcess(CFW_EVENT * pcfwEv, PAT_CMD_RESULT pResult);
VOID AT_SIM_CmdFunc_CPIN2_Set_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult);
VOID AT_SIM_CmdFunc_CPIN2_Read_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult);
VOID AT_SIM_CmdFunc_CPWD_Set_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult);
VOID AT_SIM_CmdFunc_CLCK_Set_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult);
VOID AT_SIM_CmdFunc_CLCK_Read_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult);
VOID AT_SIM_CmdFunc_CPINC_Exe_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult);
VOID AT_SIM_CmdFunc_CPINC_Read_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult);
VOID AT_SIM_CmdFunc_CPIN1_Read_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult);

#ifdef CFW_MULTI_SIM
UINT32 CFW_SimReadBinary(UINT8 nFileId, UINT8 nOffset, UINT8 nBytesToRead, UINT16 nUTI, CFW_SIM_ID nSimID);
#else
UINT32 CFW_SimReadBinary(UINT8 nFileId, UINT8 nOffset, UINT8 nBytesToRead, UINT16 nUTI);
#endif
#ifdef CFW_MULTI_SIM
UINT32 CFW_SimUpdateBinary(UINT8 nFileId,
                           UINT8 nOffset, UINT8 *pData, UINT8 nBytesToWrite, UINT16 nUTI, CFW_SIM_ID nSimID);
#else
UINT32 CFW_SimUpdateBinary(UINT8 nFileId, UINT8 nOffset, UINT8 *pData, UINT8 nBytesToWrite, UINT16 nUTI);
#endif

VOID AT_FDN_UpdateRecord(UINT8 nIdx, UINT8 nRecordSize, UINT8 *pData, UINT8 nSim);

UINT32 CFW_SimGetFileStatus(
    UINT8 nFileID,
    UINT16 nUTI
#ifdef CFW_MULTI_SIM
    , CFW_SIM_ID nSimID
#endif
);
UINT32 CFW_SimUpdateRecord (
    UINT8    nFileID,
    UINT8    nRecordNum,
    UINT8    nRecordSize,
    //UINT8  * pPIN2,
    //UINT8    nPinSize,//Remove by lixp for AT issue
    UINT8   *pData,
    UINT16   nUTI
#ifdef CFW_MULTI_SIM
    , CFW_SIM_ID nSimID
#endif
);


VOID AT_SIM_CmdFunc_CRSM_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult);
VOID AT_SIM_CmdFunc_CRSML_AsyncEventProcess(CFW_EVENT *pcfwEv, PAT_CMD_RESULT pResult);


VOID AT_FDN_SetStatus(UINT8 nSim);
VOID AT_SIMID_Result_OK(UINT32 uReturnValue, UINT32 uResultCode, UINT8 nDelayTime,
                        UINT8 *pBuffer, UINT16 nDataSize, UINT8 nUTI);

#ifdef CFW_MULTI_SIM
UINT32 CFW_SimReset(UINT16 nUTI, CFW_SIM_ID nSimID);
UINT8 CFW_GetSSTStatus(UINT8 nServiceNum, CFW_SIM_ID nSimID);
#else
UINT32 CFW_SimReset(UINT16 nUTI);
#endif



#ifdef AT_DUAL_SIM
VOID AT_SIM_CmdFunc_SETSIM(AT_CMD_PARA *pParam);
#endif
#endif
