/*********************************************************
 *
 * File Name
 *  at_cmd_tcpip.h
 * Author
 *  Felix
 * Date
 *  2007/11/25
 * Descriptions:
 *  ...
 *
 *********************************************************/

#ifndef __AT_CMD_MUSIC_H__
#define __AT_CMD_MUSIC_H__

#include "event.h"
#include "at_common.h"
typedef enum {

    AT_MUSIC_STREAM_NONE,
    AT_MUSIC_STREAM_UART,
    AT_MUSIC_STREAM_LOCAL
}AT_STREAM_TYPE;

typedef enum
{
    UART_PLAY_STATUS_STOP,
    UART_PLAY_STATUS_PLAY,
    UART_PLAY_STATUS_PAUSE,
    UART_REC_STATUS_START,
    UART_REC_STATUS_STOP,
} AT_UART_STATUS;

extern VOID AT_MUSIC_CmdFunc_ModeSwitch(AT_CMD_PARA* pParam);
extern VOID AT_MUSIC_CmdFunc_Play(AT_CMD_PARA* pParam);
extern VOID AT_MUSIC_CmdFunc_Pause(AT_CMD_PARA* pParam);
extern VOID AT_MUSIC_CmdFunc_State(AT_CMD_PARA* pParam);
extern int AT_MUSIC_UartPlay_GetStatus(void);
extern VOID AT_MUSIC_UartPlay_SetStatus(AT_UART_STATUS status);

extern VOID AT_MUSIC_UartPlay_CmdFunc_Play(AT_CMD_PARA* pParam);
extern VOID AT_MUSIC_UartPlay_CmdFunc_Stop(AT_CMD_PARA* pParam);
extern VOID AT_MUSIC_UartPlay_CmdFunc_Pause(AT_CMD_PARA* pParam);
extern VOID AT_MUSIC_UartPlay_CmdFunc_Resume(AT_CMD_PARA* pParam);
extern VOID AT_MUSIC_UartPlay_CmdFunc_RawData(AT_CMD_PARA* pParam);
extern VOID AT_MUSIC_UartPlay_CmdFunc_FTCodec(AT_CMD_PARA* pParam);
extern VOID AT_MUSIC_UartPlay_CmdFunc_SetMicGain(AT_CMD_PARA* pParam);
extern VOID AT_MUSIC_UartPlay_CmdFunc_GetStatus(AT_CMD_PARA* pParam);
extern VOID AT_MUSIC_UartPlay_CmdFunc_PlayInterAud(AT_CMD_PARA* pParam);

#endif

