/*********************************************************
 *
 * File Name
 *	at_cmd_tcpip.h
 * Author
 * 	Felix
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 * 	
 *********************************************************/

#ifndef __AT_CMD_TCPIP_H__
#define __AT_CMD_TCPIP_H__

#define AT_TCPIP_ADDRLEN 20

#define  AT_TCPIP_ERR -1



typedef enum {
  DNS_QUERY_INVALID,
  DNS_QUERY_QUEUED,
  DNS_QUERY_COMPLETE
} DNS_QUERY_RESULT;

typedef struct _stAT_Tcpip_Paras
{
  UINT8 uType;
  UINT8 uProtocol;
  UINT8 uSocket;
  UINT8 uDomain;
  UINT16 uPort;
  UINT8 uaIPAddress[AT_TCPIP_ADDRLEN + 3];
} stAT_Tcpip_Paras;


extern VOID AT_TCPIP_CmdFunc_Ipconfig(AT_CMD_PARA* pParam);
extern VOID AT_TCPIP_CmdFunc_ConnectTo(AT_CMD_PARA* pParam);
extern VOID AT_TCPIP_CmdFunc_DisConnect(AT_CMD_PARA* pParam);
extern VOID AT_TCPIP_CmdFunc_Listen(AT_CMD_PARA* pParam);
extern VOID AT_TCPIP_CmdFunc_SRead(AT_CMD_PARA* pParam);
extern VOID AT_TCPIP_CmdFunc_SWrite(AT_CMD_PARA* pParam);
extern VOID AT_TCPIP_CmdFunc_SocTest(AT_CMD_PARA* pParam);


extern VOID AT_TCPIP_Result_OK(UINT32 uReturnValue,
                        UINT32 uResultCode, UINT8 nDelayTime, UINT8* pBuffer, UINT16 nDataSize, UINT8 nDLCI);
extern VOID AT_TCPIP_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI);
#endif
 
