// //////////////////////////////////////////////////////////////////////////////
#ifdef CFW_TCPIP_SUPPORT
#include "at_common.h"
#include "at_cmd_tcpip.h"

#if 1//defined(SOC_TEST)

#include "tcpip_sockets.h"
#include "tcpip_netdb.h"

#define SOC_TEST_BASE_MSG_ID       (0)
#define SOC_TEST_CONNECT_MSG_ID     (SOC_TEST_BASE_MSG_ID + 1)
#define SOC_TEST_LISTEN_MSG_ID     (SOC_TEST_BASE_MSG_ID + 2)
#define SOC_TEST_READ_MSG_ID     (SOC_TEST_BASE_MSG_ID + 3)
#define SOC_TEST_WRITE_MSG_ID     (SOC_TEST_BASE_MSG_ID + 4)
#define SOC_TEST_PERF_MSG_ID     (SOC_TEST_BASE_MSG_ID + 5)

#define MAX_REV_BUF_SIZE   (512*1024)

static BOOL soctest_init = FALSE;
static INT8 client_soc_id = -1;
static INT8 server_soc_id = -1;

static UINT8 host_addr[100] = {0};

static UINT8 gTestBuf[MAX_REV_BUF_SIZE]= {0};

#define SOC_PERF_TIMER_SECOND 5
static UINT8 soc_perf_timer = 0;
static UINT32 soc_recv_bytes, soc_send_bytes;

void AT_TCPIP_SocketPerfPrintTimeOut(void* inMsg)
{
    AT_WriteUartString("\r\nsoc_perf(KB/s):rec:%d\tsnd:%d\r\n", 
    		soc_recv_bytes/1024/(SOC_PERF_TIMER_SECOND),
    		soc_send_bytes/1024/(SOC_PERF_TIMER_SECOND)
    		);

    soc_recv_bytes = 0;
    soc_send_bytes = 0;
}

void AT_TCPIP_DisconnectToHost(void)
{
    if ( client_soc_id != -1 )
    {
        close(client_soc_id);
        client_soc_id = -1;
    }
    
    if ( server_soc_id != -1 )
    {
        close(server_soc_id);
        server_soc_id = -1;
    }
	
    if(soc_perf_timer)
    {
        COS_KillTimer(soc_perf_timer);
        soc_perf_timer = 0;
    }

    AT_WriteUartString("socket closed");
}


BOOL AT_TCPIP_ConnectToHost(UINT8 * host_Addr, U32 host_port)
{
    struct hostent* host_resolve = NULL;
    struct sockaddr_in sock_add;
    S8 ret_val = 0;
    
    //UINT8 * host_Addr = "www.baidu.com";//"192.168.1.40";
    //U32 host_port = 80;



    // Step 1: Open the socket. This shall be a TCP socket.
    // create socket
    client_soc_id = socket(AF_INET, SOCK_STREAM, 0);

    if (client_soc_id < 0)
    {
        AT_WriteUartString("client_soc_id<0\r\n");
        AT_TCPIP_DisconnectToHost();
        return FALSE;
    }


    if((host_resolve = gethostbyname(host_Addr)) == NULL)
    {
        AT_WriteUartString("Invaild host name\r\n");
        AT_TCPIP_DisconnectToHost();
        return FALSE;
    }

    AT_WriteUartString(inet_ntoa(*host_resolve->h_addr_list[0]));

    // Step 3: Connect the Socket
    memset(&sock_add,0x00,sizeof(struct sockaddr_in));

    sock_add.sin_family=AF_INET;
    sock_add.sin_addr= *((struct in_addr *)host_resolve->h_addr_list[0]);
    sock_add.sin_port=htons(host_port);


    ret_val = connect(client_soc_id, (struct sockaddr *) &sock_add, sizeof(struct sockaddr));
    if(ret_val < 0)
    {
        AT_WriteUartString("((ret_val < 0) && (ret_val != SOC_WOULDBLOCK))\r\n");
        AT_TCPIP_DisconnectToHost();
        return FALSE;
    }
    else
    {
    	AT_WriteUartString("connect OK\r\n socket id = %d\r\n", client_soc_id);
    }


    return TRUE;
}

BOOL AT_TCPIP_Listen(U32 port)
{
    struct sockaddr_in s_add,c_add;
    int sin_size;

    server_soc_id = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(-1 == server_soc_id)
    {
        AT_WriteUartString("socket fail ! \r\n");
        return -1;
    }

    memset(&s_add,0, sizeof(struct sockaddr_in));
    
    s_add.sin_family=AF_INET;
    s_add.sin_addr.s_addr=htonl(INADDR_ANY);
    s_add.sin_port=htons(port);

    if(-1 == bind(server_soc_id,(struct sockaddr *)(&s_add), sizeof(struct sockaddr)))
    {
        AT_WriteUartString("bind fail !\r\n");
        return -1;
    }

    if(-1 == listen(server_soc_id,5))
    {
        AT_WriteUartString("listen fail !\r\n");
        return -1;
    }

	AT_WriteUartString("listen port = %d OK\r\n", port);
	AT_WriteUartString("socket id = %d\r\n", server_soc_id);

    
    sin_size = sizeof(struct sockaddr_in);

    client_soc_id = accept(server_soc_id, (struct sockaddr *)(&c_add), &sin_size);
    if(-1 == client_soc_id)
    {
        AT_WriteUartString("accept fail !\r\n");
        return -1;
    }
    
    AT_WriteUartString("New connect from %s : %d\r\n",ip_ntoa(&c_add.sin_addr),ntohs(c_add.sin_port));
	AT_WriteUartString("socket id = %d\r\n", client_soc_id);

    return 0;
}

void AT_TCPIP_SocketPerf(UINT32 op, UINT32 max_bytes)
{
    INT32 read_len,write_len;
    UINT32 offset_bytes;
    UINT32 cost_time;

    
	soc_recv_bytes = 0;
	soc_send_bytes = 0;
    soc_perf_timer = COS_SetTimer(SOC_PERF_TIMER_SECOND * 1000,
                                        AT_TCPIP_SocketPerfPrintTimeOut, NULL, COS_TIMER_MODE_PERIODIC);

	AT_WriteUartString("\r\AT_TCPIP_SocketPerf,op=%d,max=%d\r\n",op,max_bytes);

	cost_time = COS_GetTickCount();
	for(offset_bytes = 0;offset_bytes < max_bytes;)
	{
		read_len = 0;
		write_len = 0;
		if(1 == op)  //read
		{
			read_len = read(client_soc_id, gTestBuf, MAX_REV_BUF_SIZE);
		}
		else if(2 == op)	 //write
		{
			write_len = write(client_soc_id, gTestBuf, 1024);
		}
		else if(3 == op)  //write &read
		{
			write_len = write(client_soc_id, gTestBuf, 1024);
			read_len = read(client_soc_id, gTestBuf, MAX_REV_BUF_SIZE);
		}

		if(read_len<=0 && write_len <=0)
		{
			AT_WriteUartString("\r\nread_len<=0 || write_len <= 0 \r\n");
			break;
		}
		
		offset_bytes += read_len + write_len;

		soc_recv_bytes += read_len;
		soc_send_bytes += write_len;
	}

	cost_time = COS_GetTickCount() - cost_time;

	AT_WriteUartString("Finish!data_len=%d, time = %ds,avg=%dKB/s\r\n",
						offset_bytes, cost_time/1000,
						((offset_bytes /1024)* 1000) /cost_time
						);
	COS_KillTimer(soc_perf_timer);
	soc_perf_timer = 0;
}

TASK_ENTRY SocTestTaskEntry(void *pData)
{
    COS_EVENT ev;

	while(1)
	{
	    COS_WaitEvent(MOD_SOC_TEST, &ev, COS_WAIT_FOREVER);

	    switch(ev.nEventId)
	    {
	    	case SOC_TEST_PERF_MSG_ID:
	    		AT_TCPIP_SocketPerf(ev.nParam1, ev.nParam2);
	    		break;
	    		
	    	case SOC_TEST_LISTEN_MSG_ID:
	    		AT_TCPIP_Listen(ev.nParam1);
	    		break;

	    	case SOC_TEST_CONNECT_MSG_ID:
	    		AT_TCPIP_ConnectToHost(ev.nParam1, ev.nParam2);
	    		break;
	    	
	    }

	}
}


void SocTestInit(void)
{
	if(!soctest_init)
	{
		COS_CreateTask(SocTestTaskEntry, MOD_SOC_TEST,
						NULL, NULL,
						512, 
						230, 
						COS_CREATE_DEFAULT, 0, "Soc test Task");
	}

	soctest_init = TRUE;
}


void SOcTestDeinit(void)
{

}

BOOL SendSocTestEvent(UINT32 ev_id, UINT32 p1, UINT32 p2, UINT32 p3)
{
    COS_EVENT ev;
    
	ev.nEventId = ev_id;
	ev.nParam1 = p1;
	ev.nParam2 = p2;
	ev.nParam3 = p3;
	
	return COS_SendEvent(MOD_SOC_TEST, &ev, COS_WAIT_FOREVER, COS_EVENT_PRI_NORMAL);
}
#endif /* SOC_TEST */


VOID AT_TCPIP_CmdFunc_ConnectTo(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;
    INT32 iRet = ERR_SUCCESS;

    if(NULL == pParam)
    {
        goto Param_ERROR;
    }
    else
    {
        if (pParam->pPara == NULL)
        {
            goto Param_ERROR;
        }

        switch (pParam->iType)
        {

            case AT_CMD_SET:
            {
                UINT8 Len ;
                UINT32 host_port;

                iRet = AT_Util_GetParaCount(pParam->pPara, &Len);

                if((ERR_SUCCESS != iRet)||(Len < 2))
                {
                    goto Param_ERROR;
                }

                Len = sizeof(host_addr);
                AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_STRING, host_addr, &Len);

                Len = 4;
                AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT32, &host_port, &Len);

				SocTestInit();
				
                if (-1 ==client_soc_id)
                {
		            if(SendSocTestEvent(SOC_TEST_CONNECT_MSG_ID,host_addr, host_port, 0))
                        AT_TCPIP_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
                    else
                        AT_TCPIP_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
                }
                else
                {
                    AT_TCPIP_Result_OK(CMD_FUNC_SUCC, CMD_RC_BUSY, 0, NULL, 0, pParam->nDLCI);
                }

                return;
            }
            default:
            {
                goto Param_ERROR;
            }

        }
    }

Param_ERROR:

    AT_TCPIP_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);

    return;

}


VOID AT_TCPIP_CmdFunc_Listen(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;
    INT32 iRet = ERR_SUCCESS;

    if(NULL == pParam)
    {
        goto Param_ERROR;
    }
    else
    {
        if (pParam->pPara == NULL)
        {
            goto Param_ERROR;
        }

        switch (pParam->iType)
        {

            case AT_CMD_SET:
            {
                UINT8 Len ;
                UINT32 host_port;

                iRet = AT_Util_GetParaCount(pParam->pPara, &Len);

                if((ERR_SUCCESS != iRet)||(Len < 1))
                {
                    goto Param_ERROR;
                }

                Len = 4;
                AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT32, &host_port, &Len);

				SocTestInit();

	            if(SendSocTestEvent(SOC_TEST_LISTEN_MSG_ID,host_port, 0, 0))
	                AT_TCPIP_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
	            else
	                AT_TCPIP_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
	                
                return;
            }
            default:
            {
                goto Param_ERROR;
            }

        }
    }

Param_ERROR:

    AT_TCPIP_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);

    return;

}



/******************************************************************************
 * AT_TCPIP_CmdFunc_SRead: 
 * DESCRIPTION: - Socket read,  AT+SREAD=socket_id
 * 
 * Input: 
 * Output: 
 * Returns: 
 * 
 * 
 ******************************************************************************/
VOID AT_TCPIP_CmdFunc_SRead(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;
    INT32 iRet = ERR_SUCCESS;

    if(NULL == pParam)
    {
        goto Param_ERROR;
    }
    else
    {
        if (pParam->pPara == NULL)
        {
            goto Param_ERROR;
        }

        switch (pParam->iType)
        {

            case AT_CMD_SET:
            {
                UINT8 param_cnt, Len ;
                UINT8 soc_id;
                UINT16 rec_len;

                iRet = AT_Util_GetParaCount(pParam->pPara, &param_cnt);

                if((ERR_SUCCESS != iRet)||(param_cnt < 1))
                {
                    goto Param_ERROR;
                }

				if(param_cnt == 1)
				{
	                Len = 1;
	                AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &soc_id, &Len);
	            }

	            memset(gTestBuf, 0, sizeof(gTestBuf));
	            rec_len = read(soc_id, gTestBuf, sizeof(gTestBuf));
				
                if(rec_len > 0)
                {
                	AT_WriteUartString(gTestBuf);
                    AT_TCPIP_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
               }
                else
                    AT_TCPIP_Result_OK(CMD_FUNC_FAIL, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);

                return;
            }
            default:
            {
                goto Param_ERROR;
            }

        }
    }

Param_ERROR:

    AT_TCPIP_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);

    return;

}


/******************************************************************************
 * AT_TCPIP_CmdFunc_SWrite: 
 * DESCRIPTION: - Socket write, AT+SWRITE=socket_id,"string to wirite"
 * 
 * Input: 
 * Output: 
 * Returns: 
 * 
 * 
 ******************************************************************************/
VOID AT_TCPIP_CmdFunc_SWrite(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;
    INT32 iRet = ERR_SUCCESS;

    if(NULL == pParam)
    {
        goto Param_ERROR;
    }
    else
    {
        if (pParam->pPara == NULL)
        {
            goto Param_ERROR;
        }

        switch (pParam->iType)
        {

            case AT_CMD_SET:
            {
                UINT8 param_cnt,Len ;
                UINT8 str[100] = {0};
                UINT8 soc_id;
                UINT16 write_len;

                iRet = AT_Util_GetParaCount(pParam->pPara, &param_cnt);

                if((ERR_SUCCESS != iRet)||(param_cnt < 2))
                {
                    goto Param_ERROR;
                }

                Len = 1;
                AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &soc_id, &Len);
                
                Len = sizeof(str);
                AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_STRING, str, &Len);



                write_len = write(soc_id, str, strlen(str));

			    
				memset(str, 0x0, sizeof(str));
				sprintf(str,"strlen=%d,write_len=%d",strlen(str),write_len);
				AT_TCPIP_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, str, 0, pParam->nDLCI);

                return;
            }
            default:
            {
                goto Param_ERROR;
            }

        }
    }

Param_ERROR:

    AT_TCPIP_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);

    return;

}

VOID AT_TCPIP_CmdFunc_DisConnect(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;

    if(NULL == pParam)
    {
        goto Param_ERROR;
    }
    else
    {
        if (pParam->pPara == NULL)
        {
            goto Param_ERROR;
        }

        switch (pParam->iType)
        {
            case AT_CMD_EXE:
            {
                AT_TCPIP_DisconnectToHost();
                AT_TCPIP_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);
                return;
            }
            default:
            {
                goto Param_ERROR;
            }

        }
    }

Param_ERROR:

    AT_TCPIP_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);

    return;

}


VOID AT_TCPIP_CmdFunc_Ipconfig(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;

    if(NULL == pParam)
    {
        goto Param_ERROR;
    }
    else
    {
        if (pParam->pPara == NULL)
        {
            goto Param_ERROR;
        }

        switch (pParam->iType)
        {

            case AT_CMD_EXE:
            {
                UINT8 pBUffer[1000]= {0};


                netif_printf_all_netinfo(pBUffer, 100);
				
                AT_TCPIP_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, pBUffer, strlen(pBUffer), pParam->nDLCI);

                return;
            }
            default:
            {
                goto Param_ERROR;
            }

        }
    }

Param_ERROR:

    AT_TCPIP_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);

    return;

}

VOID AT_TCPIP_CmdFunc_SocTest(AT_CMD_PARA* pParam)
{
    PAT_CMD_RESULT pResult;
    INT32 iRet = ERR_SUCCESS;

    if(NULL == pParam)
    {
        goto Param_ERROR;
    }
    else
    {
        if (pParam->pPara == NULL)
        {
            goto Param_ERROR;
        }

        switch (pParam->iType)
        {

            case AT_CMD_SET:
            {
                UINT8 param_cnt,Len ;
                UINT8 soc_id,option;
                UINT32 max_data_len_KB;


                iRet = AT_Util_GetParaCount(pParam->pPara, &param_cnt);

                if((ERR_SUCCESS != iRet)||(param_cnt < 3))
                {
                    goto Param_ERROR;
                }

                Len = 1;
                AT_Util_GetParaWithRule(pParam->pPara, 0, AT_UTIL_PARA_TYPE_UINT8, &soc_id, &Len);
                
                Len = 1;
                AT_Util_GetParaWithRule(pParam->pPara, 1, AT_UTIL_PARA_TYPE_UINT8, &option, &Len);
                if(option < 1 || option > 3)
                {
                    goto Param_ERROR;
                }
 
                Len = sizeof(UINT32);
                AT_Util_GetParaWithRule(pParam->pPara, 2, AT_UTIL_PARA_TYPE_UINT32, &max_data_len_KB, &Len);


				SendSocTestEvent(SOC_TEST_PERF_MSG_ID,option,
									max_data_len_KB * 1024, 0);

				AT_TCPIP_Result_OK(CMD_FUNC_SUCC, CMD_RC_OK, 0, NULL, 0, pParam->nDLCI);

                return;
            }
            default:
            {
                goto Param_ERROR;
            }

        }
    }

Param_ERROR:
	AT_WriteUartString("Useage: AT+SOCTEST=<sock_id>,<option>,<data_len(KB)>\r\n");
	AT_WriteUartString("<option> 1:read, 2:write, 3:write &read\r\n");
    AT_TCPIP_Result_Err(ERR_AT_CME_PARAM_INVALID, CMD_ERROR_CODE_TYPE_CME, pParam->nDLCI);

    return;

}

			    
/*****************************************************************************
* Name:        AT_TCPIP_Result_OK
* Description: TCP/IP module execute ok process.
* Parameter:  UINT32 uReturnValue,
                    UINT32 uResultCode,
                    UINT8  nDelayTime,
                    UINT8* pBuffer,
                    UINT16 nDataSize
* Return:       VOID
* Remark:      n/a
* Author:       YangYang
* Data:          2008-5-15
******************************************************************************/
VOID AT_TCPIP_Result_OK(UINT32 uReturnValue,
                        UINT32 uResultCode, UINT8 nDelayTime, UINT8* pBuffer, UINT16 nDataSize, UINT8 nDLCI)
{

    PAT_CMD_RESULT pResult = NULL;

    // �������

    pResult = AT_CreateRC(uReturnValue,
                          uResultCode, CMD_ERROR_CODE_OK, CMD_ERROR_CODE_TYPE_CME, nDelayTime, pBuffer, nDataSize, nDLCI);

    AT_Notify2ATM(pResult, nDLCI);

    if (pResult != NULL)

    {

        AT_FREE(pResult);

        pResult = NULL;

    }

    return;

}
/*****************************************************************************
* Name:        AT_TCPIP_Result_Err
* Description: TCP/IP module execute error process.
* Parameter:   UINT32 uErrorCode, UINT8 nErrorType
* Return:      VOID
* Remark:      n/a
* Author:      YangYang
* Data:        2008-5-15
******************************************************************************/
VOID AT_TCPIP_Result_Err(UINT32 uErrorCode, UINT8 nErrorType, UINT8 nDLCI)
{

    PAT_CMD_RESULT pResult = NULL;

    // �������

    pResult = AT_CreateRC(CMD_FUNC_FAIL, CMD_RC_ERROR, uErrorCode, nErrorType, 0, 0, 0, nDLCI);

    AT_Notify2ATM(pResult, nDLCI);

    if (pResult != NULL)

    {

        AT_FREE(pResult);

        pResult = NULL;

    }

    return;

}

#endif
