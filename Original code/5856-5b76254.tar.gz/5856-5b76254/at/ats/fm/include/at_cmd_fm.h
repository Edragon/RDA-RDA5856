/*********************************************************
 *
 * File Name
 *	at_cmd_tcpip.h
 * Author
 * 	Felix
 * Date
 * 	2007/11/25
 * Descriptions:
 *	...
 * 	
 *********************************************************/

#ifndef __AT_CMD_FM_H__
#define __AT_CMD_FM_H__

#include "event.h"
#include "at_common.h"

extern VOID AT_FM_CmdFunc_ModeSwitch(AT_CMD_PARA* pParam);
extern VOID AT_FM_CmdFunc_AutoSearch(AT_CMD_PARA* pParam);
extern VOID AT_FM_CmdFunc_HoldMode(AT_CMD_PARA* pParam);
extern VOID AT_FM_CmdFunc_StopSearch(AT_CMD_PARA* pParam);
extern VOID AT_FM_CmdFunc_Frequence(AT_CMD_PARA* pParam);
extern VOID AT_FM_CmdFunc_GetState(AT_CMD_PARA* pParam);

#endif
 
