//==============================================================================
//
//            Copyright (C) 2012-2013, RDA Microelectronics.
//                            All Rights Reserved
//
//      This source code is the property of RDA Microelectronics and is
//      confidential.  Any  modification, distribution,  reproduction or
//      exploitation  of  any content of this file is totally forbidden,
//      except  with the  written permission  of   RDA Microelectronics.
//
//==============================================================================
//
//    THIS FILE WAS GENERATED FROM ITS CORRESPONDING XML VERSION WITH COOLXML.
//
//                       !!! PLEASE DO NOT EDIT !!!
//
//  $HeadURL: http://svn.rdamicro.com/svn/developing1/modem2G/AT/source_code/bv5/soft_cmux/soft/at/include/at_map.h $
//  $Author: lixp $
//  $Date: 2014-12-04 22:13:48 +0800 (星期�? 2014-12-04) $
//  $Revision: 23893 $
//
//==============================================================================
//
/// @file
/// This file contains the portion of the module's memory map that will be accessible
/// through CoolWatcher (or any CoolXml tool). It is also used for the get version
/// mechanism.
//
//==============================================================================

#ifndef _AT_MAP_H_
#define _AT_MAP_H_



// =============================================================================
//  MACROS
// =============================================================================
// =============================================================================
//  TYPES
// =============================================================================
typedef enum
{
    AT_DBG_HST_INVAILD              = 0x0,
    AT_DBG_HST_PC_READ_ENABLE       = 0x1,
    AT_DBG_HST_PC_WRITE_ENABLE      = 0x2,
    AT_DBG_HST_HST_READ_ENABLE      = 0x4,
    AT_DBG_HST_HST_WRITE_ENABLE     = 0x8,
} AT_IN_DBG_HST_STATE;
// ============================================================================
// AT_IN_DBG_HST_ACCESS_T
// -----------------------------------------------------------------------------
///
// =============================================================================
typedef struct
{
    AT_IN_DBG_HST_STATE state;            //0x00000000
    UINT16  rxBufLen;                     //0x00000004
    UINT16  txBufLen;                     //0x00000006
    UINT8*  rxBufPtr;                     //0x00000008
    UINT8*  txBufPtr;                     //0x0000000C
} AT_IN_DBG_HST_ACCESS_T; //Size : 0x10


// ============================================================================
// AT_MAP_ACCESS_T
// -----------------------------------------------------------------------------
/// Type used to define the accessible structures of the module.
// =============================================================================
typedef struct
{
    AT_IN_DBG_HST_ACCESS_T *atInDbgHstPtr; //0x00000000
} AT_MAP_ACCESS_T; //Size : 0x4


// =============================================================================
// at_RegisterYourself
// -----------------------------------------------------------------------------
/// This function registers the module itself to HAL so that the version and
/// the map accessor are filled. Then, the module get version function and the
/// CoolWatcher get version command will work.
// =============================================================================
PUBLIC VOID at_RegisterYourself(VOID);



#endif

