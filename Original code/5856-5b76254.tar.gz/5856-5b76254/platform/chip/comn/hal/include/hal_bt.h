////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//            Copyright (C) 2013, RDA Microeletronics.                        //
//                            All Rights Reserved                             //
//                                                                            //
//      This source code is the property of RDA Microeletronics and is        //
//      confidential.  Any  modification, distribution,  reproduction or      //
//      exploitation  of  any content of this file is totally forbidden,      //
//      except  with the  written permission  of  RDA Microeletronics.        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  $HeadURL: http://svn.rdamicro.com/svn/developing1/Sources/chip/branches/8809p/hal/include/hal_bt.h $ //
//    $Author: huazeng $                                                        // 
//    $Date: 2013-01-26 15:39:54 +0800 (星期六, 2013-01-26) $                     //   
//    $Revision: 18861 $                                                         //   
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
/// @file hal_bt.h                                                           //
/// Prototypes for BT IRQ handler                                             //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////


#include "cs_types.h"


// =============================================================================
//  TYPES
// =============================================================================

// =============================================================================
// HAL_BT_HOST_IRQ_HANDLER_T
// -----------------------------------------------------------------------------
/// This is a generic type for a user irq handler, called when BT has some
/// data to send to host.
// =============================================================================
typedef VOID (*HAL_BT_HOST_IRQ_HANDLER_T)(VOID);


// =============================================================================
//  FUNCTIONS 
// =============================================================================

// =============================================================================
// hal_BtSetIrqHandler
// -----------------------------------------------------------------------------
/// Set an function called when an irq indicating that BT has sent some data
/// to host.
// =============================================================================
PUBLIC VOID hal_BtSetHostIrqHandler(HAL_BT_HOST_IRQ_HANDLER_T handler);


// =============================================================================
// hal_BtStart
// -----------------------------------------------------------------------------
/// Start BT CPU.
// =============================================================================
PUBLIC VOID hal_BtStart(VOID *main, VOID *irqHdlr, VOID *stackStartAddr);


// =============================================================================
// hal_BtStop
// -----------------------------------------------------------------------------
/// Stop BT CPU.
// =============================================================================
PUBLIC VOID hal_BtStop(VOID);

// =============================================================================
// hal_BtNotifyDataSent
// -----------------------------------------------------------------------------
/// Tell BT that host just sends some data.
// =============================================================================
PUBLIC VOID hal_BtNotifyDataSent(VOID);
PUBLIC void hal_BtEnableSleep(BOOL sleep);
PUBLIC UINT32 hal_BtReadBTClock(void);
PUBLIC UINT32 hal_BtReadNativeClock(void);

