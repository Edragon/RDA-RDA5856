////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//            Copyright (C) 2003-2007, Coolsand Technologies, Inc.            //
//                            All Rights Reserved                             //
//                                                                            //
//      This source code is the property of Coolsand Technologies and is      //
//      confidential.  Any  modification, distribution,  reproduction or      //
//      exploitation  of  any content of this file is totally forbidden,      //
//      except  with the  written permission  of  Coolsand Technologies.      //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  $HeadURL: http://svn.rdamicro.com/svn/developing1/Workspaces/aint/bv5_dev/platform/chip/hal/src/hal_irq.c $ //
//    $Author: admin $                                                        // 
//    $Date: 2012-07-17 19:30:16 +0800 (周二, 17 七月 2012) $                     //   
//    $Revision: 16368 $                                                          //   
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
/// @file hal_irq.c
/// IRQ module driver implementation
//                                                                            //
////////////////////////////////////////////////////////////////////////////////


#include "cs_types.h"

#include "global_macros.h"
#include "sys_irq.h"

#include "chip_id.h"

#include "halp_irq.h"
#include "halp_os_stub.h"
#include "halp_debug.h"
#include "halp_profile.h"
#include "halp_irq_prio.h"

#include "hal_debug.h"
#include "hal_mem_map.h"


// =============================================================================
//  MACROS
// =============================================================================


// =============================================================================
//  GLOBAL VARIABLES
// =============================================================================


// =============================================================================
//  FUNCTIONS
// =============================================================================
#if UNIT_TEST==1
HAL_MODULE_IRQ_HANDLER_T test_hanlder = NULL;
UINT test_irq_id = 0;
PUBLIC void hal_IrqSetDispatchHandler(UINT id, HAL_MODULE_IRQ_HANDLER_T handle)
{
    test_irq_id = id;
    test_hanlder = handle;
}
#endif
// =============================================================================
// hal_IrqDispatch
// -----------------------------------------------------------------------------
/// IRQ dispatcher. Calls the interrupt handler according to their priorities
/// defined in the relevant macros and array.
// =============================================================================
PROTECTED VOID HAL_FUNC_INTERNAL hal_IrqDispatch(VOID)
{
#if UNIT_TEST==1
    UINT32 cause = hwp_sysIrq->Cause;
    UINT32 bit = 1;
    UINT8 i;
    UINT32 unused __attribute__ ((unused));
    UINT32 mask;

    //sxr_EnterScSchedule();
    
    // gestion Mask
    // save current Mask
    mask = hwp_sysIrq->Mask_Set;
    // Mask all IT
    hwp_sysIrq->Mask_Clear = SYS_IRQ_MASK_SET_MASK;
    // Re-enable irq    
    hwp_sysIrq->SC = 1;

    for(i=0;i<SYS_IRQ_QTY;i++)
    {
        if (cause & bit)
        {
            HAL_PROFILE_IRQ_ENTER(i);
            // clear irq bit of reenabled higher prio irqs as those will be treated 
            // by an other interrupt call
            cause &= ~g_halIrqPriorityMask[i];
            // Setup priority mask for this irq
            hwp_sysIrq->Mask_Set = g_halIrqPriorityMask[i];

            if(i==test_irq_id)
            {
                test_hanlder(i);
            }

            // Mask all IT
            hwp_sysIrq->Mask_Clear =SYS_IRQ_MASK_SET_MASK;
            
            HAL_PROFILE_IRQ_EXIT(i);
        }
        bit = bit << 1;
    }

    // Disable irq
    unused = hwp_sysIrq->SC;
    // Restore previous mask
    hwp_sysIrq->Mask_Set = mask; 

    //sxr_ExitScSchedule();
#else
    UINT32 cause = hwp_sysIrq->Cause;
    UINT32 bit = 1;
    UINT8 i;
    UINT32 unused __attribute__ ((unused));
    UINT32 mask;

    sxr_EnterScSchedule();
    
    // gestion Mask
    // save current Mask
    mask = hwp_sysIrq->Mask_Set;
    // Mask all IT
    hwp_sysIrq->Mask_Clear = SYS_IRQ_MASK_SET_MASK;
    // Re-enable irq    
    hwp_sysIrq->SC = 1;

    for(i=0;i<SYS_IRQ_QTY;i++)
    {
        if (cause & bit)
        {
            HAL_PROFILE_IRQ_ENTER(i);
            // clear irq bit of reenabled higher prio irqs as those will be treated 
            // by an other interrupt call
            cause &= ~g_halIrqPriorityMask[i];
            // Setup priority mask for this irq
            hwp_sysIrq->Mask_Set = g_halIrqPriorityMask[i];

            if(g_halHwModuleIrqHandler[i])
            {
                (g_halHwModuleIrqHandler[i])(i);
            }

            // Mask all IT
            hwp_sysIrq->Mask_Clear =SYS_IRQ_MASK_SET_MASK;
            
            HAL_PROFILE_IRQ_EXIT(i);
        }
        bit = bit << 1;
    }

    // Disable irq
    unused = hwp_sysIrq->SC;
    // Restore previous mask
    hwp_sysIrq->Mask_Set = mask; 
#if (CHIP_ASIC_ID == CHIP_ASIC_ID_5855)||(CHIP_ASIC_ID == CHIP_ASIC_ID_8809P)\
	||(CHIP_ASIC_ID == CHIP_ASIC_ID_5856)
 //   hwp_sysIrq->Mask_Clear = 0x40000000;//mask pmu interrupt
#endif

    sxr_ExitScSchedule();
#endif
}


// =============================================================================
// hal_XCpuSleep
// -----------------------------------------------------------------------------
/// Put the XCpu in sleep mode until next irq.
/// @todo see how mike used that one and named it...
// =============================================================================
PROTECTED VOID hal_XCpuSleep()
{
    hwp_sysIrq->WakeUp_Mask = hwp_sysIrq->Mask_Set;
    //hwp_sysIrq->Cpu_Sleep = (SYS_IRQ_SLEEP);
    {
        UINT32 flush_wr_buff __attribute__((unused)) = hwp_sysIrq->Cpu_Sleep;
    }
}

