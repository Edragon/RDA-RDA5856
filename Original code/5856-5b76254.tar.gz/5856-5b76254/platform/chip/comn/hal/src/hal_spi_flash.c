////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//    $Author: huangyx $                                                        //
//    $Date:20151110                                                       //
//    $Revision: $                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
///     @file hal_spi_flash.c                                                       //
///     Implementation of the SPI Flash .                                     //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////



#include "hal_spi_flash.h"
#include "spi_flsh.h"
#include "halp_debug.h"
#include "sys_ctrl.h"

// =============================================================================
//
// -----------------------------------------------------------------------------
// =============================================================================


// =============================================================================
//  MACROS
// =============================================================================
#ifndef SPIFLASH_NO_TRACE
#define HAL_SPIFLASH_ASSERT(BOOL, format, ...)
#else
#define HAL_SPIFLASH_ASSERT   HAL_ASSERT
#endif



#define hal_SpiFlashWaitBusy()	while (gc_halSpiFlashHwp->status&SPI_FLASH_BUSY_STAT)
#define hal_SpiFlashWaitRead()	while ((gc_halSpiFlashHwp->status&SPI_FLASH_RX_FIFO_EMPTY)==0)


#if defined(CHIP_HAS_FLSH_CACHE)

#define hal_FlashCacheEnable()  do{\
    if(gc_halFlashCahceOn)	\
    {	\
        gc_halFlashCacheHwp->conf |= FLSH_CACHE_ENABLE;\
    }\
}while(0)

#define hal_FlashCacheDisable() do{\
	gc_halFlashCacheHwp->conf &= ~FLSH_CACHE_ENABLE;\
}while(0)

#endif /* CHIP_HAS_FLSH_CACHE */
// =============================================================================
//  TYPES
// =============================================================================
PRIVATE HWP_SPI_FLSH_T* CONST gc_halSpiFlashHwp = hwp_spi_flsh;


// =============================================================================
//  FUNCTIONS
// =============================================================================

#ifdef CHIP_HAS_FLSH_CACHE
PRIVATE HWP_FLSH_CACHE_T* CONST gc_halFlashCacheHwp = hwp_flsh_cache;
//Disable cache always if FALSE
PRIVATE BOOL gc_halFlashCahceOn;
/******************************************************************************
 * hal_FlashCacheOn: 
 * DESCRIPTION: - 
 * 
 * Input: 
 * Output: 
 * Returns: 
 * 
 * 
 ******************************************************************************/
PUBLIC VOID hal_FlashCacheOn(HAL_FLASH_CACHE_MAP_T map)
{
    UINT32 config = gc_halFlashCacheHwp->conf;

    config &= (~(FLSH_CACHE_SIZE_MASK | FLSH_CACHE_FLASH_MAP_MASK));
    config |= FLSH_CACHE_SIZE(HAL_FLASH_CACHE_TO_CACHE_SIZE(map)) 
    			|FLSH_CACHE_FLASH_MAP(HAL_FLASH_CACHE_TO_FLASH_MAP(map)) 
    			| FLSH_CACHE_ENABLE;

    gc_halFlashCacheHwp->conf = config;

    //Force flush cache for now(hardware problem)
    //gc_halFlashCacheHwp->flush = FLSH_CACHE_LINE_FLUSH;
    //while(gc_halFlashCacheHwp->flush & FLSH_CACHE_LINE_FLUSH);

    gc_halFlashCahceOn = TRUE;
}

/******************************************************************************
 * hal_FlashCacheOff: 
 * DESCRIPTION: - 
 * 
 * Input: 
 * Output: 
 * Returns: 
 * 
 * 
 ******************************************************************************/
PUBLIC VOID hal_FlashCacheOff(VOID)
{
	hal_FlashCacheDisable();
    gc_halFlashCahceOn = FALSE;
}

PUBLIC VOID hal_FlashCacheFlush(VOID)
{
    gc_halFlashCacheHwp->flush = FLSH_CACHE_LINE_FLUSH;
    while(gc_halFlashCacheHwp->flush & FLSH_CACHE_LINE_FLUSH);
}

/******************************************************************************
 * hal_FlashCacheDebugOn: 
 * DESCRIPTION: - 
 * 
 * Input: 
 * Output: 
 * Returns: 
 * 
 * 
 ******************************************************************************/
PUBLIC VOID hal_FlashCacheDebugOn(VOID)
{
    gc_halFlashCacheHwp->irq_mask = FLSH_CACHE_FLUSH_DONE_IRQ_MASK;
}

/******************************************************************************
 * hal_FlashCacheIrqHandler: 
 * DESCRIPTION: - 
 * 
 * Input: 
 * Output: 
 * Returns: 
 * 
 * 
 ******************************************************************************/
PROTECTED VOID hal_FlashCacheIrqHandler(UINT8 interruptId)
{
    UINT32 irq = gc_halFlashCacheHwp->irq;
    UINT32 status = gc_halFlashCacheHwp->status ;
    
    hal_HstSendEvent(BOOT_EVENT,0xcac0e000 + interruptId);
    hal_HstSendEvent(BOOT_EVENT,irq);
    hal_HstSendEvent(BOOT_EVENT,status);
    
    gc_halFlashCacheHwp->status = FLSH_CACHE_STATUS_ADDR_RANGE_ERR
                                  |FLSH_CACHE_STATUS_WRITE_ERR
                                  |FLSH_CACHE_STATUS_CACHE_DISABLE_ERR
                                  |FLSH_CACHE_STATUS_FLUSH_DONE
                                  ;
}


#endif /* CHIP_HAS_FLSH_CACHE */


PUBLIC BOOL hal_SpiFlashIsBusy(VOID)
{
    UINT32 data_tmp_32;
    data_tmp_32 = gc_halSpiFlashHwp->status;

    return (((data_tmp_32&SPI_FLASH_BUSY_STAT)==1)||((data_tmp_32&SPI_FLASH_READ_STATE_BUSY)==0));
}

PUBLIC BOOL hal_SpiFlashIsTxFifoEmpty(VOID)
{
    return (hwp_spi_flsh->status&SPI_FLASH_TX_FIFO_EMPTY);
}


/******************************************************************************
 * hal_SpiFlashDisableRead: 
 * DESCRIPTION: - Disable continous read and cache before erase/write spi flash
 * 
 * Input: 
 * Output: 
 * Returns: 
 * 
 * 
 ******************************************************************************/
PUBLIC VOID hal_SpiFlashDisableRead(VOID)
{
	hal_SpiFlashWaitRead();
#ifdef SPI_FLASH_CONTINUOUS_READ
    hal_SpiFlashWaitBusy();
    gc_halSpiFlashHwp->dual_spi = SPI_FLASH_AHB_READ_DISABLE;
#endif
#ifdef CHIP_HAS_FLSH_CACHE
    hal_FlashCacheDisable();
#endif /* CHIP_HAS_FLSH_CACHE */
    return ;
}


PUBLIC VOID hal_SpiFlashEnableRead(VOID)
{
#ifdef SPI_FLASH_CONTINUOUS_READ
    hal_SpiFlashWaitBusy();
    gc_halSpiFlashHwp->dual_spi = 0x0;
#endif
#ifdef CHIP_HAS_FLSH_CACHE
    hal_FlashCacheEnable();
#endif /* CHIP_HAS_FLSH_CACHE */
    return ;
}

/****************************************************************************/
/*  data_array[]: bytes array to be push                                    */
/*  data_cnt:           push data count                                     */
/*  quard_flag:     true for quard operation, false for serial operation;   */
/*                               only valid for extended operation          */
/****************************************************************************/
PUBLIC BOOL hal_SpiFlashPushTxFifoData(UINT8 data_array[], UINT32 data_cnt, BOOL quard_flag)
{
    UINT32 i, data_tmp_32;

	hal_SpiFlashWaitBusy();

    for(i = 0; i < data_cnt; i++)
    {
        HAL_SPIFLASH_ASSERT((data_array != NULL) ,"NULL destination for PushTxFifoData");

        data_tmp_32 = (UINT32)data_array[i];
        if(quard_flag)
            data_tmp_32 = data_tmp_32 | 0x100;

        if(gc_halSpiFlashHwp->status&SPI_FLASH_TX_FIFO_FULL)
        {
        	return FALSE;
        }
        else
        {
        	gc_halSpiFlashHwp->tx_fifo_data = data_tmp_32;
        }
    }
    return TRUE;
}

PUBLIC UINT32 hal_SpiFlashGetRxData(UINT8* destAddress, UINT32 length)
{
    UINT32 i;
    UINT32 nbAvailable = length;

    // Check the address pointer.
    HAL_SPIFLASH_ASSERT((destAddress != NULL) ,"NULL destination for Rx");

    while (gc_halSpiFlashHwp->status&SPI_FLASH_RX_FIFO_EMPTY);
    
    hal_SpiFlashWaitBusy();
    
    // Get data byte by byte.
    for (i = 0; i < nbAvailable; i++)
    {
        *(destAddress + i) = (UINT8) gc_halSpiFlashHwp->rx_fifo_data;
    }

    return i;
}



PROTECTED BOOL hal_SpiFlashClearFifoData(BOOL clr_read_flag,BOOL clr_write_flag)
{
    UINT32 data_tmp_32 = 0;
    UINT32 wait_flag = 0;


    if(clr_read_flag)
    {
        data_tmp_32 |= SPI_FLASH_RX_FIFO_CLR;
        wait_flag |= SPI_FLASH_RX_FIFO_EMPTY;
    }

    if(clr_write_flag)
    {
        data_tmp_32 |= SPI_FLASH_TX_FIFO_CLR;
        wait_flag |= SPI_FLASH_TX_FIFO_EMPTY;
    }

    hal_SpiFlashWaitBusy();
    gc_halSpiFlashHwp->fifo_ctrl = data_tmp_32;

    return TRUE;
}

/********************************************************************/
/*  opmode = 0: normal operation                                                                        */
/*  opmode = 1: extended serial read                                                                */
/*  opmode = 2: extended quard read                                                                 */
/*  opmode = 3: extended write          (OPCODE_WRITE_ENABLE, flash_addr, opmode, 0);                                                               */
/********************************************************************/
PROTECTED VOID hal_SpiFlashSendCmd(UINT8 cmd, UINT32 addr, UINT8 opmode, UINT16 blocksize)
{
    UINT32 data_tmp_32;

    if(blocksize!=0)
    {
        hal_SpiFlashWaitBusy();
        data_tmp_32 = gc_halSpiFlashHwp->trans_mode &(~SPI_FLASH_TX_BLOCK_SIZE_MASK);
        gc_halSpiFlashHwp->trans_mode = data_tmp_32|SPI_FLASH_TX_BLOCK_SIZE(blocksize);
    }
	
    if(opmode==0)
    {
        data_tmp_32 = ((addr<<8)&0xffffff00)|cmd;
    }
    else if(opmode==1)
    {
        data_tmp_32 = (((cmd<<8)|0x10000)&0x000fff00);
    }
    else if(opmode==2)
    {
        data_tmp_32 = (((cmd<<8)|0x30000)&0x000fff00);
    }
    else if(opmode==3)
    {
        data_tmp_32 = ((cmd<<8)&0x000fff00);
    }
    else
    {
        data_tmp_32 = ((cmd<<8)&0x000fff00);
    }

    hal_SpiFlashWaitBusy();
    gc_halSpiFlashHwp->tx_cmd_addr = data_tmp_32;

    return;
}

PUBLIC BOOL hal_SpiFlashInit(HAL_SPI_FLASH_CFG_T *cfg)
{
    UINT32 data_tmp_32;

    HAL_SPIFLASH_ASSERT((cfg != NULL) ,"NULL cfg");

#if defined(SPI_FLSH_26M) || defined(__FORCE_WORK_IN_26MHZ__LOCAL)
    hal_SysSetSpiFlashClock(HAL_SYS_SPIFLASH_FREQ_52M);
#elif defined(SPI_FLSH_52M)
    hal_SysSetSpiFlashClock(HAL_SYS_SPIFLASH_FREQ_104M);
#elif defined(SPI_FLSH_78M)
	hal_SysSetSpiFlashClock(HAL_SYS_SPIFLASH_FREQ_156M);
#elif defined(SPI_FLSH_89M)
	hal_SysSetSpiFlashClock(HAL_SYS_SPIFLASH_FREQ_178M);
#elif defined(SPI_FLSH_104M)
	hal_SysSetSpiFlashClock(HAL_SYS_SPIFLASH_FREQ_208M);
#else
#error spi clk is out of 104MHz.
#endif

#if defined(dual_spi_flash)
#error Fix me!!
#endif /* dual_spi_flash */


	data_tmp_32 = 0;
    switch(cfg->readMode)
    {
    	case HAL_SPI_FLASH_READ_DUAL_MODE:
    		data_tmp_32 |= SPI_FLASH_DUAL_MODE;
    		break;

    	case HAL_SPI_FLASH_READ_QUARD_MODE:
    		data_tmp_32 |= SPI_FLASH_QUAD_MODE;
    		break;
    		
    	case HAL_SPI_FLASH_READ_SERIAL_MODE:
    	default:
    		break;
    }
    
    switch(cfg->cmdMode)
    {
    	case HAL_SPI_FLASH_CMD_DUAL_MODE:
    		HAL_SPIFLASH_ASSERT(0, "NOT support now!");
    		break;

    	case HAL_SPI_FLASH_CMD_QUARD_MODE:
    		data_tmp_32 |= SPI_FLASH_CMD_QUAD_EN;
    		break;
    		
    	case HAL_SPI_FLASH_CMD_SERIAL_MODE:
    	default:
    		break;
    }

    data_tmp_32 |= SPI_FLASH_CLK_DIVIDER(cfg->clkDiv) | SPI_FLASH_SAMPLE_DELAY(cfg->sampleDelay);

	if(cfg->dinCapEdge)
	{
		data_tmp_32 |= SPI_FLASH_DIN_CAP_EDGE;
	}
	
	if(cfg->holdPin)
	{
		data_tmp_32 |= SPI_FLASH_HOLD_PIN;
	}
	
	if(cfg->wpPin)
	{
		data_tmp_32 |= SPI_FLASH_WPROCTECT_PIN;
	}
	
	hal_HstSendEvent(SYS_EVENT, data_tmp_32);
    hal_SpiFlashWaitBusy();
    
    gc_halSpiFlashHwp->flash_config = data_tmp_32;
    return TRUE;
}

PUBLIC VOID hal_SpiFlashContinuousMode(BOOL enable)
{
    hal_SpiFlashWaitBusy();

    if(enable)
    {
        gc_halSpiFlashHwp->trans_mode |= SPI_FLASH_TX_CONT_MODE;
    }
    else
    {
        gc_halSpiFlashHwp->trans_mode &= ~SPI_FLASH_TX_CONT_MODE;
    }
}



