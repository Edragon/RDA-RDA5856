////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//            Copyright (C) 2003-2007, Coolsand Technologies, Inc.            //
//                            All Rights Reserved                             //
//                                                                            //
//      This source code is the property of Coolsand Technologies and is      //
//      confidential.  Any  modification, distribution,  reproduction or      //
//      exploitation  of  any content of this file is totally forbidden,      //
//      except  with the  written permission  of  Coolsand Technologies.      //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  $HeadURL: http://10.10.100.14/svn/developing1/Sources/chip/branches/8808/boot/include/boot_cipher.h $ //
//    $Author: admin $                                                       // 
//    $Date: 2010-07-07 20:28:03 +0800 (星期三, 07 七月 2010) $                     //   
//    $Revision: 269 $                                                          //   
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
/// @file boot_nand.h                                                         //
/// BOOT NAND driver                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////


#ifndef _BOOT_NAND_H_
#define _BOOT_NAND_H_

/// @defgroup BOOT NAND Driver
///
/// @{
///

#include "cs_types.h"

// =============================================================================
//  MACROS
// =============================================================================

// =============================================================================
//  TYPES
// =============================================================================

// =============================================================================
//  FUNCTIONS
// =============================================================================

// =============================================================================
// boot_NandOpen
// -----------------------------------------------------------------------------
/// Initialize NAND flash controller
/// @param None
/// @return None
// =============================================================================

PUBLIC VOID boot_NandOpen(VOID);


// =============================================================================
// boot_NandGetPageSize
// -----------------------------------------------------------------------------
/// Get the page size of the NAND flash
/// @param None
/// @return The page size
// =============================================================================

PUBLIC UINT32 boot_NandGetPageSize(VOID);


// =============================================================================
// boot_NandReadByPageNum
// -----------------------------------------------------------------------------
/// Read one page of data from NAND flash by page number
/// @param page    The page number in NAND flash
/// @param pData   Pointing to a buffer to hold the data (should be word-aligned)
/// @param len     The number of bytes to be read (should be mulitple of 4)
/// @return None
// =============================================================================

PUBLIC VOID boot_NandReadByPageNum(UINT32 page, UINT32 *pData, UINT32 len);


// =============================================================================
// boot_NandReadPages
// -----------------------------------------------------------------------------
/// Read multiple page data from NAND flash
/// @param addr    The start address in NAND flash (should be page-aligned)
/// @param pData   Pointing to a buffer to hold the data (should be word-aligned)
/// @param len     The number of bytes to be read (should be mulitple of 4)
/// @return None
// =============================================================================

PUBLIC VOID boot_NandReadPages(UINT32 addr, UINT32 *pData, UINT32 len);


/// @} <-- End of the nand group

#endif // _BOOT_NAND_H_

