////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//            Copyright (C) 2003-2007, Coolsand Technologies, Inc.            //
//                            All Rights Reserved                             //
//                                                                            //
//      This source code is the property of Coolsand Technologies and is      //
//      confidential.  Any  modification, distribution,  reproduction or      //
//      exploitation  of  any content of this file is totally forbidden,      //
//      except  with the  written permission  of  Coolsand Technologies.      //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  $HeadURL: http://10.10.100.14/svn/developing1/Sources/chip/branches/8808/boot/include/boot_cipher.h $ //
//    $Author: admin $                                                       // 
//    $Date: 2010-07-07 20:28:03 +0800 (星期三, 07 七月 2010) $                     //   
//    $Revision: 269 $                                                          //   
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
/// @file boot_dma.h                                                            //
/// BOOT DMA driver                                                           //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////


#ifndef _BOOT_DMA_H_
#define _BOOT_DMA_H_

/// @defgroup BOOT DMA Driver
///
/// @{
///

#include "cs_types.h"

// =============================================================================
//  MACROS
// =============================================================================

// =============================================================================
//  TYPES
// =============================================================================

// =============================================================================
//  FUNCTIONS
// =============================================================================

// =============================================================================
// boot_DmaCopy
// -----------------------------------------------------------------------------
/// Copy data via DMA
/// @param dst  The destination address
/// @param src  The source address
/// @param len  The data length in bytes
/// @return None
// =============================================================================

PUBLIC VOID boot_DmaCopy(VOID *dst, CONST VOID *src, UINT32 len);


// =============================================================================
// boot_DmaSet
// -----------------------------------------------------------------------------
/// Set the memory to a pattern value via DMA
/// @param dst      The destination address (should be word-aligned)
/// @param pattern  The pattern to be written
/// @param len      The data length in bytes (should be mulitple of 4)
/// @return None
// =============================================================================

PUBLIC VOID boot_DmaSet(UINT32 *dst, UINT32 pattern, UINT32 len);


/// @} <-- End of the dma group

#endif // _BOOT_DMA_H_


