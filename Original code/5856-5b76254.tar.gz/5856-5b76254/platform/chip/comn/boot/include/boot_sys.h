////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//            Copyright (C) 2012-2013, RDA Microelectronics.                  //
//                            All Rights Reserved                             //
//                                                                            //
//      This source code is the property of RDA Microelectronics and is       //
//      confidential.  Any  modification, distribution,  reproduction or      //
//      exploitation  of  any content of this file is totally forbidden,      //
//      except  with the  written permission  of   RDA Microelectronics.      //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//
//  $HeadURL: http://svn.rdamicro.com/svn/developing1/Sources/chip/branches/gallite441/boot/include/boot_sys.h $
//  $Author: huazeng $
//  $Date: 2012-12-11 19:10:10 +0800 (周二, 11 十二月 2012) $
//  $Revision: 18119 $
//
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
/// @file boot_sys.h
/// That file describes the BOOT SYSTEM driver API.
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef _BOOT_SYS_H_
#define _BOOT_SYS_H_

#include "cs_types.h"
#include "hal_sys.h"


/// @defgroup system BOOT Sytem Driver
/// description
/// ...
/// @{



// =============================================================================
//  MACROS
// =============================================================================


// =============================================================================
//  FUNCTIONS
// =============================================================================


// ============================================================================
// hal_SysSetupPLL
// ----------------------------------------------------------------------------
/// Setup PLL at early system boot time.
// ============================================================================
PUBLIC VOID boot_SysSetupPLL(VOID);


// =============================================================================
// hal_SysGetChipId
// -----------------------------------------------------------------------------
/// That function gives the chip ID the software is running on.
/// @param part Which part of the chip ID
/// @return The requested part of the chip ID.
// =============================================================================
PUBLIC UINT32 boot_SysGetChipId(HAL_SYS_CHIP_ID_T part);



/// @} // end of the system group



#endif // _BOOT_SYS_H_

