////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//            Copyright (C) 2013, RDA Microeletronics.                        //
//                            All Rights Reserved                             //
//                                                                            //
//      This source code is the property of RDA Microeletronics and is        //
//      confidential.  Any  modification, distribution,  reproduction or      //
//      exploitation  of  any content of this file is totally forbidden,      //
//      except  with the  written permission  of  RDA Microeletronics.        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  $HeadURL: http://svn.coolsand-tech.com/svn/developing1/Sources/chip/branches/gallite441/hal/8809/include/hal_rda_abb.h $ //
//    $Author: huazeng $                                                        //
//    $Date: 2013-05-24 15:00:13 +0800 (五, 2013-05-24) $                     //
//    $Revision: 20422 $                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
/// @file hal_rda_abb.h                                                       //
///                                                                           //
/// This file decribes the registers of RDA Analog Base Band.                 //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////


#ifndef _HAL_RDA_ABB_H_
#define _HAL_RDA_ABB_H_

#include "cs_types.h"

// ----------------
// Default volumes
// ----------------

// Default ABB DAC digital gain is -2dB for receiver
#define DEFAULT_ABB_DAC_GAIN_RECEIVER (-2)
// Default ABB DAC digital gain is -2dB for speaker
#define DEFAULT_ABB_DAC_GAIN_SPEAKER (-2)
// Earpiece output energy is too large
// Reduce default ABB DAC digital gain to -2dB
#define DEFAULT_ABB_DAC_GAIN_HEAD (-2)
// Default ABB ADC (MIC) digital gain is 0dB
#define DEFAULT_ABB_ADC_GAIN (0)

// Max ABB DAC digital gain is -2dB for earpiece
#define MAX_ABB_DAC_GAIN_HEAD (-2)
// Max ABB ADC (MIC) digital gain is 12dB
#define MAX_ABB_ADC_GAIN (12)


// ----------------
// Types
// ----------------

// SIM selection state
typedef enum
{
    HAL_ABB_SIM_SELECT_SIM0 = (1<<0),
    HAL_ABB_SIM_SELECT_SIM1 = (1<<1),
    HAL_ABB_SIM_SELECT_SIM2 = (1<<2),
    HAL_ABB_SIM_SELECT_SIM3 = (1<<3),
} HAL_ABB_SIM_SELECT_T;


// ----------------
// APIs
// ----------------

PUBLIC VOID hal_AbbOpen(VOID);
PUBLIC BOOL hal_AbbRegRead(UINT32 addr, UINT32* pData);
PUBLIC VOID hal_AbbRegBlockingRead(UINT32 addr, UINT32* pData);
PUBLIC BOOL hal_AbbRegWrite(UINT32 addr, UINT32 data);

PUBLIC VOID hal_AbbEnableUsbPhy(BOOL enable);

PUBLIC VOID hal_AbbEnableSim(UINT32 simMask);

void hal_abbLineInMode(BOOL isLineInMode);

#endif // _HAL_RDA_ABB_H_

