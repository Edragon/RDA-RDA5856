////////////////////////////////////////////////////////////////////////////////
//                                                                            //
/// @file btcpu_power.c                                                         //
/// That file contains the BTCPU Power function                                 //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#include "cs_types.h"
#include "chip_id.h"

#include "global_macros.h"
#include "sys_ctrl.h"
#include "bb_sram.h"

#include "sys_irq.h"
#include "gpio.h"


