////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//            Copyright (C) 2003-2007, Coolsand Technologies, Inc.            //
//                            All Rights Reserved                             //
//                                                                            //
//      This source code is the property of Coolsand Technologies and is      //
//      confidential.  Any  modification, distribution,  reproduction or      //
//      exploitation  of  any content of this file is totally forbidden,      //
//      except  with the  written permission  of  Coolsand Technologies.      //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  $HeadURL: http://svn.rdamicro.com/svn/developing1/Sources/chip/branches/8809p/boot/8809p/src/boot_romstring.c $
//  $Author: huazeng $
//  $Date: 2013-07-08 16:03:51 +0800 (星期一, 2013-07-08) $
//  $Revision: 20595 $
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
/// @file hal_romstring.h
/// That file describes the Dark Minds Behind This All.
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#define STRINGIFY_VALUE(s) STRINGIFY(s)
#define STRINGIFY(s) #s

const char boot_romCsString[] =
    STRINGIFY_VALUE(CT_ASIC_CAPD) "\n"
    "Copyright Coolsand Technologies 2002-2012\n";


const char boot_romDT[] =
    "Coolsand\n"
    "RDA\n";



