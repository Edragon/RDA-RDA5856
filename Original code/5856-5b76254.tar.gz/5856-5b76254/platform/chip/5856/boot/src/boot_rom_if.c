////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//            Copyright (C) 2003-2007, Coolsand Technologies, Inc.            //
//                            All Rights Reserved                             //
//                                                                            //
//      This source code is the property of Coolsand Technologies and is      //
//      confidential.  Any  modification, distribution,  reproduction or      //
//      exploitation  of  any content of this file is totally forbidden,      //
//      except  with the  written permission  of  Coolsand Technologies.      //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
/// @file                                                                     //
/// That file contains the function called by rom but implement in flash
/// a fixed location in ROM.
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#include "cs_types.h"
#include "hal_debug.h"
#include "hal_sys.h"
#include <stdarg.h>
#include <string.h>


void (*g_pPrintf_ROM) (u32 Id, const ascii *Fmt, va_list argPtr);

#if CHIP_HAS_BTCPU==1
void sxs_vprintf (u32 Id, const ascii *Fmt, va_list argPtr)
{
    if(g_pPrintf_ROM)
    {
        g_pPrintf_ROM(Id, Fmt, argPtr);
    }
}
#endif
VOID hal_GetK1(UINT32* k1)
{
    asm volatile("move $2, $27\n\tsw $2, 0(%0)"::"r"((k1)):"$2");
}



