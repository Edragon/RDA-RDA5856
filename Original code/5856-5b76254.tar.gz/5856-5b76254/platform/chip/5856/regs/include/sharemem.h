//==============================================================================
//                                                                              
//            Copyright (C) 2003-2007, Coolsand Technologies, Inc.              
//                            All Rights Reserved                               
//                                                                              
//      This source code is the property of Coolsand Technologies and is        
//      confidential.  Any  modification, distribution,  reproduction or        
//      exploitation  of  any content of this file is totally forbidden,        
//      except  with the  written permission  of  Coolsand Technologies.        
//                                                                              
//==============================================================================
//                                                                              
//    THIS FILE WAS GENERATED FROM ITS CORRESPONDING XML VERSION WITH COOLXML.  
//                                                                              
//                       !!! PLEASE DO NOT EDIT !!!                             
//                                                                              
//  $HeadURL: http://svn.coolsand-tech.com/svn/developing1/Sources/chip/branches/gallite441/regs/gallite/include/bb_ahb_monitor.h $                                                                   
//  $Author: admin $                                                                    
//  $Date: 2010-07-07 20:28:03 +0800 (星期三, 07 七月 2010) $                                                                      
//  $Revision: 269 $                                                                  
//                                                                              
//==============================================================================
//
/// @file
//
//==============================================================================

#ifndef _BB_AHB_SHAREMEM_H_
#define _BB_AHB_SHAREMEM_H_

#ifdef CT_ASM
#error "You are trying to use in an assembly code the normal H description of 'bb_ahb_monitor'."
#endif



// =============================================================================
//  MACROS
// =============================================================================

// =============================================================================
//  TYPES
// =============================================================================

// ============================================================================
// BB_AHB_MONITOR_T
// -----------------------------------------------------------------------------
/// 
// =============================================================================

#define SHAREMEM_SIZE       (256)

typedef struct
{
    REG32                          Rx_Buff[SHAREMEM_SIZE*3];                      //0x00000000
    REG32                          Tx_Buff[SHAREMEM_SIZE*2];                      //0x00000400
} HWP_AHB_SHAREMEM_T;



#endif

