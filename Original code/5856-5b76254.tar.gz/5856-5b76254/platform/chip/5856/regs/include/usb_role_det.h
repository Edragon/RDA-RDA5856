//
// Created by             :RDA SH-DIGITAL
// Filename               :usb_role_det.h
// Author                 :tianwq
// Created On             :2015-08-29 14:51:41
// Last Modified          :
// Update Count           :2015-08-29 14:51:41
// Description            :
//
//======================================================================
#ifndef __USB_ROLE_DET_H__
#define __USB_ROLE_DET_H__
//Auto-gen by reg_gen
#include "cs_types.h"

#define REG_USB_ROLE_DET_BASE 0x01a2e000 //shaohuima

typedef volatile struct
{
    REG32 INTERVAL                      ; //0x00    
    REG32 FORCE_CFG                     ; //0x04    
    REG32 INT_CLR                       ; //0x08  
    REG32 INT_STATUS                    ; //0x0c
    REG32 IRQ_MASK                      ; //0x10    
} HWP_USB_ROLE_DET_T;

#define hwp_usb_role_det ((HWP_USB_ROLE_DET_T*)KSEG1(REG_USB_ROLE_DET_BASE))

//INTERVAL
#define USB_ROLE_DET_DET_INTERVAL(n)   (((n)&0x7)<<0)      
#define USB_ROLE_DET_LOOP_INTERVAL(n)  (((n)&0x7)<<4) 
#define USB_ROLE_DET_wait_INTERVAL(n)  (((n)&0x7)<<8) 
#define USB_ROLE_DET_LOOP_TIME(n)  (((n)&0xF)<<12)      
#define USB_ROLE_DET_LOOP_TIME_MASK      (0xF<<12)

//INT_STATUS
#define USB_ROLE_DET_INT_STATUS        (1<<0)              

//INT_CLR
#define USB_ROLE_DET_INT_CLEAR         (1<<0)              

//IRQ_MASK
#define USB_ROLE_DET_INT_MASK_Det          (1<<0)

#define USB_ROLE_DET_INT_MASK_Timeout          (1<<1)



#endif


