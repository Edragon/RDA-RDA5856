//
// Created by             :RDA SH-DIGITAL
// Filename               :ahb_monitor.h
// Author                 :tianwq
// Created On             :2015-08-29 14:50:41
// Last Modified          :
// Update Count           :2015-08-29 14:50:41
// Description            :
//
//======================================================================
#ifndef __AHB_MONITOR_H__
#define __AHB_MONITOR_H__
//Auto-gen by reg_gen
#include "cs_types.h"

#define REG_AHB_MONITOR_BASE 0x0

typedef volatile struct
{
    REG32 AHB_Monitor_Ctrl              ; //0x00    
    REG32 AHB_Monitor_Count             ; //0x04    
    REG32 AHB_Monitor_Use               ; //0x08    
    REG32 AHB_Monitor_Latency           ; //0x0c    
} HWP_AHB_MONITOR_T;

#define hwp_ahb_monitor ((HWP_AHB_MONITOR_T*)KSEG1(REG_AHB_MONITOR_BASE))

//AHB_Monitor_Ctrl
#define AHB_MONITOR_ENABLE             (1<<0)              
#define AHB_MONITOR_RECORD             (1<<4)              
#define AHB_MONITOR_ACCUMULATION_MODE  (1<<5)              
#define AHB_MONITOR_TARGET(n)          (((n)&0xF)<<8)      
#define AHB_MONITOR_TIME_WINDOW(n)     (((n)&0x7)<<16)     

//AHB_Monitor_Count
#define AHB_MONITOR_ACCESS_COUNT(n)    (((n)&0xFFFFFF)<<0) 

//AHB_Monitor_Use
#define AHB_MONITOR_USE(n)             (((n)&0xFFFFFF)<<0) 

//AHB_Monitor_Latency
#define AHB_MONITOR_LATENCY(n)         (((n)&0xFFFFFF)<<0) 
#define AHB_MONITOR_ACCESS_CNT(n)      (((n)&0xFF)<<24)    


#endif


