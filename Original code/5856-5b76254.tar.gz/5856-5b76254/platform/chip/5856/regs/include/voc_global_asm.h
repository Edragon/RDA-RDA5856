#ifndef _VOC_GLOBAL_ASM_H_
#define _VOC_GLOBAL_ASM_H_

//THIS FILE HAS BEEN GENERATED WITH COOLWATCHER. PLEASE EDIT WITH CARE !

#ifndef CT_ASM
#error "You are trying to use in a normal C code the assembly H description of 'voc_global'."
#endif


/// AHB Address bus size
#define AHB_NB_BITS_ADDR                         (26)


#endif
