#ifndef _IR_H_
#define _IR_H_
/*
#ifdef CT_ASM
#error "You are trying to use in an assembly code the normal H description of 'gpio'."
#endif
*/
#include "8809p_generic_config.h"

extern void IR_Init();

#define REG_IR_BASE               (0x01A0E000)

typedef volatile struct
{
    REG32                          IR_CONTROL;             //0x00000000
    REG32                          IR_TIME_S1;             //0x00000004
    REG32                          IR_TIME_S2;             //0x00000008
    REG32                          IR_TIME_S3;             //0x0000000C
    REG32                          IR_TIME_S4;             //0x00000010
    REG32                          IR_TIME_S5;             //0x00000014
    REG32                          IR_CODE;                //0x00000018
    REG32                          IR_STATUS;              //0x0000001C
} HWP_IR_T;


#define hwp_ir                    ((HWP_IR_T*) KSEG1(REG_IR_BASE))

//ir_ctrl
#define IR_IR_EN                       (1<<0)              
#define IR_IR_MODE(n)                  (((n)&0x3)<<1)      
#define IR_IR_END_DETECT_EN            (1<<3)              
#define IR_IR_INT_EN                   (1<<4)              
#define IR_IR_INT_VERIFY_EN            (1<<5)              
#define IR_IR_USERCODE_VERIFY          (1<<6)              
#define IR_IR_DATACODE_VERIFY          (1<<7)              
#define IR_BIT_TIME_1(n)               (((n)&0x7F)<<8)     
#define IR_BIT_TIME_2(n)               (((n)&0xFF)<<16)    
#define IR_IR_BIT_CYCLE(n)             (((n)&0x7F)<<24)    

//ir_time_1
#define IR_IR_TIME_S1(n)               (((n)&0xFFF)<<0)    

//ir_time_2
#define IR_IR_TIME_S2(n)               (((n)&0xFFF)<<0)    

//ir_time_3
#define IR_IR_TIME_S3(n)               (((n)&0xFFF)<<0)    

//ir_time_4
#define IR_IR_TIME_S4(n)               (((n)&0xFFF)<<0)    

//ir_time_5
#define IR_IR_TIME_S5(n)               (((n)&0xFFF)<<0)    

//ir_code
#define IR_R_GPINT_CTRL_R(n)           (((n)&0xFF)<<0)     

//ir_fsm
#define IR_IR_STATUS(n)                (((n)&0xFF)<<0)     

#endif
