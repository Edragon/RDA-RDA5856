//
// Created by             :RDA SH-DIGITAL
// Filename               :ahb_monitor_asm.h
// Author                 :tianwq
// Created On             :2015-08-29 14:50:42
// Last Modified          :
// Update Count           :2015-08-29 14:50:42
// Description            :
//
//======================================================================
#ifndef __AHB_MONITOR_ASM_H__
#define __AHB_MONITOR_ASM_H__
//Auto-gen by reg_gen
#define REG_AHB_MONITOR_BASE 0x0

#define REG_AHB_MONITOR_BASE_HI BASE_HI(REG_AHB_MONITOR_BASE)
#define REG_AHB_MONITOR_BASE_LO BASE_LO(REG_AHB_MONITOR_BASE)

#define REG_AHB_Monitor_Ctrl           REG_AHB_MONITOR_BASE_LO+0x00
#define REG_AHB_Monitor_Count          REG_AHB_MONITOR_BASE_LO+0x04
#define REG_AHB_Monitor_Use            REG_AHB_MONITOR_BASE_LO+0x08
#define REG_AHB_Monitor_Latency        REG_AHB_MONITOR_BASE_LO+0x0c

//AHB_Monitor_Ctrl
#define AHB_MONITOR_ENABLE             (1<<0)              
#define AHB_MONITOR_RECORD             (1<<4)              
#define AHB_MONITOR_ACCUMULATION_MODE  (1<<5)              
#define AHB_MONITOR_TARGET(n)          (((n)&0xF)<<8)      
#define AHB_MONITOR_TIME_WINDOW(n)     (((n)&0x7)<<16)     

//AHB_Monitor_Count
#define AHB_MONITOR_ACCESS_COUNT(n)    (((n)&0xFFFFFF)<<0) 

//AHB_Monitor_Use
#define AHB_MONITOR_USE(n)             (((n)&0xFFFFFF)<<0) 

//AHB_Monitor_Latency
#define AHB_MONITOR_LATENCY(n)         (((n)&0xFFFFFF)<<0) 
#define AHB_MONITOR_ACCESS_CNT(n)      (((n)&0xFF)<<24)    


#endif


